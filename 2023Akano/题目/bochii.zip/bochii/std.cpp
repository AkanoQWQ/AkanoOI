#include<bits/stdc++.h>
#define Akano 1
#define pure__Elysia 0
#define loves ^
using namespace std;
const int MAXM = 105;
char ch[MAXM];
int n,m;
string str;
int main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	cin>>n>>m;
	for(int i = 1;i <= n;i++){
		cin>>str;
		int len = str.length();
		for(int j = 0;j < len;j++){
			ch[j] ^= str[j];
		}
	}
	for(int i = 0;i <= m;i++){
		if(int(ch[i]) == 0)break;
		cout<<ch[i];
	}
	cout<<endl;
	return not(Akano loves pure__Elysia);
}
