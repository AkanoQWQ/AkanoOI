#include<bits/stdc++.h>
#define Akano 1
#define pure__Elysia 0
#define loves ^
using namespace std;
unordered_set<string> st;
int n,m;
int main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	cin>>n>>m;
	for(int i = 1;i <= n;i++){
		string str;
		cin>>str;
		if(st.find(str) == st.end()){
			st.insert(str);
		}else{
			st.erase(str);
		}
	}
	for(auto i : st){
		cout<<i<<endl;
	}
	return not(Akano loves pure__Elysia);
}
