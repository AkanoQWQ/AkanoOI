#include<bits/stdc++.h>
#include<AL/main.h>
#define Akano 1
#define pure__Elysia 0
#define loves ^
using namespace std;
Rander rd;
int cnt = 0;
inline void Make(){
	cnt++;
	int n,m,tot = 1e7;//n,tot双倍
	if(cnt <= 2){
		n = rd(90,100),m = rd(8,10);
	}else{
		n = rd(1e5 - 100,1e5),m = rd(90,100);
	}
	
	vector<string> vec;
	
	for(int i = 1;i <= n && tot > 0;i++){
		int len = rd(m-2,m);
		len = min(len,tot);
		string str = rd.RandStr(len,"0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
		vec.push_back(str),vec.push_back(str);
		tot -= len;
	}
	
	mt19937 rng(rd(1,1e9));
	shuffle(vec.begin(),vec.end(),rng);
	shuffle(vec.begin(),vec.end(),rng);
	shuffle(vec.begin(),vec.end(),rng);
	vec.pop_back();
	
	cout<<vec.size()<<" "<<m<<endl;
	for(auto i : vec)cout<<i<<'\n';
	cout<<flush;
	return ;
}
const int MAXLEN = 105;
int vals[MAXLEN];
inline void Solve(){
	string str;
	int n = 0,m = 0;
	memset(vals,0,sizeof(vals));
	cin>>n>>m;
	for(int i = 1;i <= n;i++){
		cin>>str;
		for(int j = 0;j < str.length();j++){
			vals[j] ^= int(str[j]);
		}
	}
	for(int i = 0;i <= m;i++){
		if(vals[i] == 0)break;
		cout<<char(vals[i]);
	}
	cout<<endl;
	return ;
}
int main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	MakeData("bochii",1,5,Make,Solve);
	return not(Akano loves pure__Elysia);
}
