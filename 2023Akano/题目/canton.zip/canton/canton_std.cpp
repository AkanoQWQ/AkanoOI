#include<bits/stdc++.h>
#define Akano 1
#define pure__Elysia 0
#define loves ^
using namespace std;
const int MAXN = 2e4 + 1018 + 1108;
const int MAXM = 1e5 + 1018 + 1108;
struct Tool{
	int l,r;
}t[MAXN];
int n,m,q;

namespace Subtask1{//q * n * m / w
	bitset<MAXM> est;
	inline void Solve(){
		for(int i = 1;i <= q;i++){
			int l,r;
			cin>>l>>r;
			est.reset();
			for(int j = l;j <= r;j++){
				for(int k = t[j].l;k <= t[j].r;k++){
					est[k] = true;
				}
			}
			cout<<est.count()<<endl;
		}
		return ;
	}
}
namespace Subtask1_arr{//q * n * m
	bool est[MAXM];
	inline void Solve(){
		for(int i = 1;i <= q;i++){
			int l,r;
			cin>>l>>r;
			for(int i = 1;i <= m;i++)est[i] = false;
			for(int j = l;j <= r;j++){
				for(int k = t[j].l;k <= t[j].r;k++){
					est[k] = true;
				}
			}
			int cnt = 0;
			for(int i = 1;i <= m;i++)cnt += est[i];
			cout<<cnt<<endl;
		}
		return ;
	}
}
namespace Subtask2{//q * n * logn
	inline void Solve(){
		for(int i = 1;i <= q;i++){
			int l,r;
			cin>>l>>r;
			vector<pair<int,int> > vec;
			for(int j = l;j <= r;j++){
				vec.emplace_back(t[j].l,t[j].r);
			}
			sort(vec.begin(),vec.end());
			int cnt = 0,rr = 0;
			for(auto seg : vec){
				int ll = max(rr+1,seg.first);
				cnt += max(seg.second - ll + 1,0);
				rr = max(rr,seg.second);
			}
			cout<<cnt<<endl;
		}
		return ;
	}
}
namespace Subtask3{//q * sqrt(n) * logn + q * n
	multiset<pair<int,int> > now;
	struct Query{
		int l,r,id,blk;
	}ask[MAXN];
	int blk_len;
	bool Cmp(Query q1,Query q2){
		if(q1.blk != q2.blk)return q1.blk < q2.blk;
		if(q1.blk & 1){
			return q1.r > q2.r;
		}else{
			return q1.r < q2.r;
		}
	}
	int ans[MAXN];
	inline void Solve(){
		blk_len = sqrt(n);
		for(int i = 1;i <= q;i++){
			cin>>ask[i].l>>ask[i].r;
			ask[i].id = i,ask[i].blk = ask[i].l / blk_len;
		}
		sort(ask+1,ask+q+1,Cmp);
		int l = 1,r = 0;
		for(int u = 1;u <= q;u++){
			while(l > ask[u].l){
				l--;
				now.insert(make_pair(t[l].l,t[l].r));
			}
			while(r < ask[u].r){
				r++;
				now.insert(make_pair(t[r].l,t[r].r));
			}
			while(l < ask[u].l){
				auto it = now.find(make_pair(t[l].l,t[l].r));
				now.erase(it);
				l++;
			}
			while(r > ask[u].r){
				auto it = now.find(make_pair(t[r].l,t[r].r));
				now.erase(it);
				r--;
			}
			int cnt = 0,rr = 0;
			for(auto seg : now){
				int ll = max(rr+1,seg.first);
				cnt += max(seg.second - ll + 1,0);
				rr = max(rr,seg.second);
			}
			ans[ask[u].id] = cnt;
		}
		for(int i = 1;i <= q;i++){
			cout<<ans[i]<<'\n';
		}
		return ;
	}
}
namespace Subtask4{//q * sqrt(n) * logn
	class SegmentTree{
	private:
		struct Node{
			int len,tot,ans,lazy;
			//tot : 覆盖当前区间的颜色段的个数
		}node[MAXM * 8];
		inline void PushUp(int p){
			if(node[p].tot > 0){
				node[p].ans = node[p].len;
				return ;
			}
			if(node[p].len == 1){
				node[p].ans = 0;
				return ;
			}
			node[p].ans = node[p*2].ans + node[p*2+1].ans;
			return ;
		}
		inline void Pushdown(int p){
			if(node[p].lazy == 0 || node[p].len == 1)return ;
			node[p*2].tot += node[p].lazy;
			node[p*2].lazy += node[p].lazy;
			node[p*2].ans = node[p*2].ans;
			node[p*2+1].tot += node[p].lazy;
			node[p*2+1].lazy += node[p].lazy;
			node[p*2+1].ans = node[p*2+1].ans;
			node[p].lazy = 0;
			return ;
		}
		void Build(int p,int l,int r){
			node[p].len = r - l + 1;
			node[p].ans = node[p].tot = node[p].lazy = 0;
			if(l == r)return ;
			const int mid = (l + r) >> 1;
			Build(p*2,l,mid),Build(p*2+1,mid+1,r);
			return ;
		}
		void Change(int p,int l,int r,int OBJL,int OBJR,int _val){
			if(OBJL <= l && r <= OBJR){
				node[p].tot += _val;
				PushUp(p);//特殊的,因为要更新
				return ;
			}
			const int mid = (l + r) >> 1;
			if(mid >= OBJL)Change(p*2,l,mid,OBJL,OBJR,_val);
			if(mid < OBJR)Change(p*2+1,mid+1,r,OBJL,OBJR,_val);
			PushUp(p);
			return ;
		}
	public:
		inline void Build(){
			Build(1,1,m);
			return ;
		}
		inline void Change(int l,int r,int _val){
			Change(1,1,m,l,r,_val);
			return ;
		}
		inline int Query(){
			return node[1].ans;
		}
	}tr;
	struct Query{
		int l,r,id,blk;
	}ask[MAXN];
	int blk_len;
	bool Cmp(Query q1,Query q2){
		if(q1.blk != q2.blk)return q1.blk < q2.blk;
		if(q1.blk & 1){
			return q1.r > q2.r;
		}else{
			return q1.r < q2.r;
		}
	}
	int ans[MAXN];
	inline void Solve(){//q * sqrt(n) * logn + q * n
		blk_len = sqrt(n);
		for(int i = 1;i <= q;i++){
			cin>>ask[i].l>>ask[i].r;
			ask[i].id = i,ask[i].blk = ask[i].l / blk_len;
		}
		sort(ask+1,ask+q+1,Cmp);
		int l = 1,r = 0;
		tr.Build();
		for(int u = 1;u <= q;u++){
			while(l > ask[u].l){
				l--;
				tr.Change(t[l].l,t[l].r,1);
			}
			while(r < ask[u].r){
				r++;
				tr.Change(t[r].l,t[r].r,1);
			}
			while(l < ask[u].l){
				tr.Change(t[l].l,t[l].r,-1);
				l++;
			}
			while(r > ask[u].r){
				tr.Change(t[r].l,t[r].r,-1);
				r--;
			}
			ans[ask[u].id] = tr.Query();
		}
		for(int i = 1;i <= q;i++){
			cout<<ans[i]<<'\n';
		}
		return ;
	}
}
int main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	cin>>n>>m>>q;
	for(int i = 1;i <= n;i++){
		cin>>t[i].l>>t[i].r;
	}
	Subtask4::Solve();
	return not(Akano loves pure__Elysia);
}
