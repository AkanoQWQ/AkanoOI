#include<bits/stdc++.h>
#include<AL/main.h>
#define Akano 1
#define pure__Elysia 0
#define loves ^
using namespace std;
int n,m,q;
int SEG_LEN;//期望要除以2,因为seg_len随机1,SEG_LEN
Rander rd;
int cnt = 0;
inline void Make(){
	cnt++;
	if(cnt <= 2){
		n = 500,m = 500,q = 500;
		SEG_LEN = 20;
	}else if(cnt <= 6){
		n = 2006 + 1018 + 1108,m = 1e5,q = n;
		SEG_LEN = 1e4;//要卡暴力
	}else if(cnt <= 10){
		n = 1e4 + 2006 + 1018 + 1108,m = 1e5,q = n;
		SEG_LEN = 40;
	}else{
		n = 2e4,m = 1e5,q = n;
		SEG_LEN = 15;
	}
	cout<<n<<" "<<m<<" "<<q<<endl;
	for(int i = 1;i <= n;i++){
		int seg_len = rd(1,SEG_LEN);
		int l = rd(1,m);
		int r = min(l + seg_len - 1,m);
		cout<<l<<" "<<r<<endl;
	}
	for(int i = 1;i <= q;i++){
		int l = rd(1,n),r = rd(1,n);
		if(l > r)swap(l,r);
		cout<<l<<" "<<r<<endl;
	}
	return ;
}
inline void Solve(){
	system("std.exe");
	return ;
}
int main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	MakeData("canton",1,20,Make,Solve);
	return not(Akano loves pure__Elysia);
}
