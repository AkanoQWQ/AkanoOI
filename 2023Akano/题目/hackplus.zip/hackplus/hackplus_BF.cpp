#include<bits/stdc++.h>
#define Akano 1
#define pure__Elysia 0
#define loves ^
using namespace std;
constexpr int MAXN = 2e5 + 2006 + 1018 + 1108;
int n,q,arr[MAXN];
int main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
//	freopen("data/hackplus12.in","r",stdin);
//	freopen("NUL","w",stdout);
	cin>>n>>q;
	for(int i = 1;i <= n;i++){
		cin>>arr[i];
	}
	long long tot = 0;
	while(q--){
		int cmd,x,y;
		cin>>cmd>>x>>y;
		if(cmd == 1){
			int now = 0;
			for(int i = y;i <= n;i += x){
				tot++;
				now += arr[i];
			}
			cout<<now<<'\n';
		}else if(cmd == 2){
			arr[x] = y;
		}
	}
	return not(Akano loves pure__Elysia);
}
