#include<bits/stdc++.h>
#include<AL/main.h>
#define Akano 1
#define pure__Elysia 0
#define loves ^
using namespace std;
constexpr int MAXVAL = 1018;
int cnt = 0,n,q;
Rander rd;
inline void Make(){
	cnt++;
	bool smallp = false;
	if(cnt <= 4){
		n = 1e4 + rd(-100,0),q = 1e4 + rd(-100,0);
	}else if(cnt <= 10){
		n = 2e5 + rd(-100,0),q = 2e5 + rd(-100,0);
		smallp = true;
	}else{
		n = 2e5 + rd(-100,0),q = 2e5 + rd(-100,0);
	}
	cout<<n<<" "<<q<<'\n';
	for(int i = 1;i <= n;i++){
		cout<<rd(1,MAXVAL)<<" ";
	}
	cout<<'\n';
	for(int i = 1;i <= q;i++){
		int opt = rd(1,100),p,x,v;
		if(opt <= 80){
			opt = 1;
		}else{
			opt = 2;
		}
		if(opt == 1){
			int randval = rd(1,100);
			if(smallp){
				if(randval <= 40){
					p = rd(2,5);
				}else{
					p = rd(2,200);
				}
			}else{
				if(randval <= 40){//卡暴力
					p = rd(2,5);
				}else if(randval <= 80){
					p = sqrt(n) + rd(-20,20);
				}else if(randval <= 90){//卡记忆化
					p = n - rd(10,40);
				}else{
					p = rd(sqrt(n),n-10);
				}
			}
			x = rd(0,p-1);
			cout<<opt<<" "<<p<<" "<<x<<'\n';
		}else{
			x = rd(1,n),v = rd(1,MAXVAL);
			cout<<opt<<" "<<x<<" "<<v<<'\n';
		}
	}
	return ;
}
inline void Solve(){
	system("hackplus_std.exe");
	return ;
}
int main(){
	MakeData("hackplus",1,20,Make,Solve);
	return not(Akano loves pure__Elysia);
}
