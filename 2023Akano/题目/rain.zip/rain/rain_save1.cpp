#include<bits/stdc++.h>
#define Akano 1
#define pure__Elysia 0
#define loves ^
using namespace std;
using ll = long long;
struct Position;
using POS = Position;
constexpr int MAXN = 1018;
constexpr double INF = 1e9 + 1018 + 1108;
constexpr double startT = 1018 + 1108;
constexpr double endT = 0.00010181108;
constexpr double deltaT = 0.9997610181108;
constexpr double alphaV = 100;
constexpr bool DEBUG_MODE = false;
struct Position{
	int x,y;
	Position() = default;
	Position(int _x,int _y){
		x = _x,y = _y;
		return ;
	}
};
inline double P(double x){
	return x * x;
}
inline double Dis(POS p1,POS p2){
	return sqrt(P(p1.x-p2.x) + P(p1.y-p2.y));
}
int n,perm[MAXN],otp[MAXN];
Position p[MAXN];
double totans,nowans;
inline double Calc(){
	double ret = 0;
	for(int i = 1;i < n;i++){
		ret += Dis(p[perm[i]],p[perm[i+1]]);
	}
	return ret;
}
inline void SA(){
	static mt19937 rng(time(0));
	double temp = startT;
	nowans = Calc();
	while(temp > endT){
		int dis = 1.0f * rng() / UINT_MAX * (temp / startT) * n;
		int pos = ((rng() % (n-2)) + 2),nxt = pos;
		if(rng() % 2){
			nxt = min(n-1,pos + dis);
		}else{
			nxt = max(2,pos - dis);
		}
		swap(perm[pos],perm[nxt]);
		double newans = Calc();
		if(DEBUG_MODE && newans > nowans){
			cerr<<"poss "<<exp(-double(newans - nowans) / nowans * alphaV / temp)<<endl;
		}
		if(newans <= nowans){
			nowans = newans;
		}else if(rng() < exp(-double(newans - nowans) / nowans * alphaV / temp) * UINT_MAX){
			
		}else{
			swap(perm[pos],perm[nxt]);
		}
		temp *= deltaT;
	}
	return ;
}
int main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	freopen("rain.in","r",stdin);
	cin>>n;
	for(int i = 1;i <= n;i++){
		cin>>p[i].x>>p[i].y;
	}
	for(int bigT = 1;bigT <= 5;bigT++){
		for(int i = 1;i <= n;i++){
			perm[i] = i;
		}
		for(int smallT = 1;smallT <= 20;smallT++){
			SA();
		}
		if(nowans > totans){
			for(int i = 1;i <= n;i++){
				otp[i] = perm[i];
			}
			totans = nowans;
		}
	}
	cout<<totans<<endl;
	for(int i = 1;i <= n;i++){
		cout<<otp[i]<<" ";
	}
	cout<<endl;
	return not(Akano loves pure__Elysia);
}
