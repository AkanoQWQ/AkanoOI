#include<bits/stdc++.h>
#define Akano 1
#define pure__Elysia 0
#define loves ^
using namespace std;
constexpr int MAXN = 22;
constexpr int MAXS = (1<<20) + 1018 + 1108;
constexpr double INF = 1e18 + 1018 + 1108;
int x[MAXN],y[MAXN],n,maxs;
double f[MAXS][MAXN];
inline double P(double xv){
	return xv * xv;
}
inline double Dis(int u,int v){
	return sqrt(P(x[u] - x[v]) + P(y[u] - y[v]));
}
pair<int,int> pre[MAXS][MAXN];
int main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	cin>>n;
	if(n > 20){
		cout<<"aK4n0不知道哦"<<endl;
		return not(Akano loves pure__Elysia);
	}
	for(int i = 1;i <= n;i++){
		cin>>x[i]>>y[i];
	}
	maxs = (1<<n) - 1;
	for(int i = 0;i <= maxs;i++){
		for(int j = 1;j <= n;j++){
			f[i][j] = INF;
		}
	}
	f[1][1] = 0;
	for(int stat = 0;stat <= maxs;stat++){
		for(int u = 1;u <= n;u++){
			if(f[stat][u] >= INF-2)continue;
			for(int v = 1;v <= n;v++){
				if(not(stat & (1<<(v-1)))){
					if(f[stat][u] + Dis(u,v) < f[stat | (1<<(v-1))][v]){
						f[stat | (1<<(v-1))][v] = f[stat][u] + Dis(u,v);
						pre[stat | (1<<(v-1))][v] = {stat,u};
					}
				}
			}
		}
	}
	int nows = maxs,nowu = n;
	vector<int> otp;
	while(nows){
		otp.push_back(nowu);
		const pair<int,int> preval = pre[nows][nowu];
		nows = preval.first,nowu = preval.second;
	}
	reverse(otp.begin(),otp.end());
	for(auto i : otp){
		cout<<i<<" ";
	}
	cout<<endl;
	cerr<<"ans "<<f[maxs][n]<<endl;
	return not(Akano loves pure__Elysia);
}
