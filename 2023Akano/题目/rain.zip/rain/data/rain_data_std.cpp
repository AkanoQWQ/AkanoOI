#include<bits/stdc++.h>
#define Akano 1
#define pure__Elysia 0
#define loves ^
using namespace std;
using ll = long long;
struct Position;
using POS = Position;
constexpr int MAXN = 108;
constexpr double INF = 1e18 + 1018 + 1108;
constexpr double startT = 10181108;
constexpr double endT = 0.00010181108;
constexpr double deltaT = 0.99610181108;
constexpr double alphaV = 100;
struct Position{
	int x,y;
	Position() = default;
	Position(int _x,int _y){
		x = _x,y = _y;
		return ;
	}
};
inline double P(double x){
	return x * x;
}
inline double Dis(POS p1,POS p2){
	return sqrt(P(p1.x-p2.x) + P(p1.y-p2.y));
}
int n,perm[MAXN],otp[MAXN];
Position p[MAXN];
double totans = INF,nowans;
inline double Calc(){
	double ret = 0;
	for(int i = 1;i < n;i++){
		ret += Dis(p[perm[i]],p[perm[i+1]]);
	}
	return ret;
}
mt19937 rng(time(0));
inline bool Judge1(double newans,double Innowans,double temp){
	return (rng() < exp(-double(newans - Innowans) / Innowans * alphaV  / temp) * UINT_MAX);
}
inline bool Judge2(double newans,double Innowans,double temp){
	return (rng() < exp(-double(newans - Innowans) / temp) * UINT_MAX);
}
inline void SA(){
	double temp = startT;
	while(temp > endT){
		int pos1 = (rng() % (n-2)) + 2,pos2 = (rng() % (n-2)) + 2;
		swap(perm[pos1],perm[pos2]);
		double newans = Calc();
		if(newans <= nowans){
			nowans = newans;
		}else if(Judge1(newans,nowans,temp)){
			
		}else{
			swap(perm[pos1],perm[pos2]);
		}
		temp *= deltaT;
	}
	return ;
}
int main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	cin>>n;
	for(int i = 1;i <= n;i++){
		cin>>p[i].x>>p[i].y;
	}
	for(int bigT = 1;bigT <= 20;bigT++){
		for(int i = 1;i <= n;i++){
			perm[i] = i;
		}
		nowans = Calc();
		for(int smallT = 1;smallT <= 10;smallT++){
			SA();
		}
		if(nowans < totans){
			for(int i = 1;i <= n;i++){
				otp[i] = perm[i];
			}
			totans = nowans;
		}
	}
	cout<<totans<<endl;
	return not(Akano loves pure__Elysia);
}
