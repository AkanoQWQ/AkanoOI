#include "testlib.h"
#include<bits/stdc++.h>
using namespace std;
constexpr int MAXN = 106;
struct Position{
	int x,y;
}p[MAXN];
int n;
double stdans,oufans;
int perm[MAXN];
bool vis[MAXN];
inline double P(double x){
	return x * x;
}
inline double Dis(int u,int v){
	return sqrt(P(p[u].x - p[v].x) + P(p[u].y - p[v].y));
}
int main(int argc, char *argv[]){
    registerTestlibCmd(argc,argv);
	n = inf.readInt();
	for(int i = 1;i <= n;i++){
		p[i].x = inf.readInt(),p[i].y = inf.readInt();
	}
	stdans = ans.readDouble() * 1.1;
    for(int i = 1;i <= n;i++){
		perm[i] = ouf.readInt(1,n);
		if(vis[perm[i]]){
			quitf(_wa,"You have visited %d twice",perm[i]);
		}
		vis[perm[i]] = true;
	}
	if(perm[1] != 1){
		quitf(_wa,"Your first point is %d instead of 1",perm[1]);
	}
	if(perm[n] != n){
		quitf(_wa,"Your last point is %d instead of n",perm[n]);
	}
	for(int i = 1;i < n;i++){
		oufans += Dis(perm[i],perm[i+1]);
	}
	double rate = (2 * stdans - oufans) / stdans * 100;
	if(rate <= 0){
		quitf(_wa,"Sorry!Your answer %.2lf compared to %.2lf can't get any score",oufans,stdans);
	}else if(rate < 100){
		quitp(rate/100,"Your answer %.2lf compared to %.2lf get score %.2lf %%",oufans,stdans,rate);
	}else if(100 <= rate){
		quitf(_ok,"Wow!Your answer %.2lf is better than stdans %.2lf",oufans,stdans);
	}
	return not(10181108);
}
