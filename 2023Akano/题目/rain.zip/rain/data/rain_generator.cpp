#include<bits/stdc++.h>
#include<AL/main.h>
#define Akano 1
#define pure__Elysia 0
#define loves ^
using namespace std;
using pii = pair<int,int>;
const int MAXS = 10000;
Rander rd;
int n = -1,maxval = -1,cnt = 0;
inline void Make(){
	cnt++;
	if(cnt <= 2){
		n = rd(16,18),maxval = 1018 + 1108;
	}else if(cnt <= 5){
		n = rd(46,50),maxval = 1e7;
	}else{
		n = rd(95,100),maxval = 1e9;
	}
	cout<<n<<endl;
	for(int i = 1;i <= n;i++){
		cout<<rd(1,maxval)<<" "<<rd(1,maxval)<<endl;
	}
	return ;
}
inline void Solve(){
	system("rain_data_std.exe");
	return ;
}
int main(){
	MakeData("rain",1,10,Make,Solve);
	return not(Akano loves pure__Elysia);
}
