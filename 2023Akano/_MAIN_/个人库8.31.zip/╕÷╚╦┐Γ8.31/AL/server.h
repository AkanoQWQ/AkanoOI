#pragma once
#include<bits/stdc++.h>
#include<Windows.h>
using namespace std;

template<int BUFSIZE>
class Reader{
	private:
		char buffer[BUFSIZE];
	public:
		istringstream iss;
		HANDLE _pipe;
		inline bool Read(){
			bool mainSuccess = false;
			string str;
			do{
				DWORD len = 0;
				bool fSuccess = ReadFile(_pipe,buffer,BUFSIZE * sizeof(char),&len,NULL);
				mainSuccess |= fSuccess;
				char buffer2[BUFSIZE + 1] = {0};//����0?����char�������Բ�֪������ʲô 
				memcpy(buffer2, buffer, len);
				str.append(buffer2);
				if(!fSuccess || len < BUFSIZE)break;
			}while(true);
			iss.str(str);
			iss.clear();
			return mainSuccess;
		}
		Reader& operator>>(auto& content){//Ҫ������...��Ȼ����� 
			iss>>content;
			return *this;
		}
};
class Writer{
	private:
		
	public:
		ostringstream oss;
		HANDLE _pipe;
		inline void Clear(){
			oss.str("");
			return ;
		}
		Writer& operator<<(const auto& content){
			oss<<content;
			return *this;
		}
		inline bool WriteWithoutClear(){
			string now = oss.str();
			DWORD dwWrite;
			bool success = WriteFile(_pipe, now.c_str(), strlen(now.c_str()), &dwWrite, NULL);
			return success;
		}
		inline bool Write(){
			bool success = WriteWithoutClear();
			Clear();
			return success;
		}
		inline string Content(){
			return oss.str();
		}
};
inline bool TryConnect(const LPCSTR& name,int maxTime,int waitingTime){
	for(int t = 1;t <= maxTime;t++){
		if(WaitNamedPipe(name, NMPWAIT_WAIT_FOREVER) == FALSE){
			cout<<"û���ҵ�����,���Ե�"<<endl; 
		}else{
			return true;
		}
		Sleep(waitingTime);
	}
	return false;
}
