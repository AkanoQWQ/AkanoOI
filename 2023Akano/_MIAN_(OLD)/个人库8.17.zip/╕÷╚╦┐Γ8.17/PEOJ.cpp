//PE Offline Judge Version 2023.8.17
//BASE ON AL ver2023.8.17
//��ҪAL ver2023.8.17������ 
#include<bits/stdc++.h>
#include<io.h>
#include<AL/comp.h>//��Ҫʹ��install.cmd��װAL 
using namespace std;
const int MAX_TIME = 1000;//ʱ��Ĭ��1000,��λms 
const int MAX_SCORE = 100;//������,Ĭ��100pts 
const int TOT_BLK = 20;//�������� 
inline void ShowBlock(int now,int up){
	int blk = TOT_BLK * now / up;
	SetColor("lightgreen");
	for(int i = 1;i <= blk;i++){
		cout<<"�~"; 
	}
	SetColor("red");
	for(int i = blk+1;i <= TOT_BLK;i++){
		cout<<"�~";
	}
	cout<<endl;
	return ;
}
struct WaitingList{
	string name;
	int maxTurn,maxScore,maxTime;
	WaitingList(){}
	WaitingList(string _name,int _t,int _mx,int _mt){
		name = _name,maxTurn = _t,maxScore = _mx,maxTime = _mt;
	}
};
vector<WaitingList> waiting;
int totAC,totWA,totTLE,totCE,totRE,totSUM,totScore,totMaxScore;
int main(){
	SetFontConsolas(20);
	SetDefaultGCC();
	if(CheckGCC() == false){
		cout<<"GCCû���ҵ�Ĭ��·��!���ֶ�����GCC·��(./.../g++.exe):"<<endl;
		string path = "DEF";
		do{
			if(path != "DEF")cout<<"GCC·������!����������:"<<endl;
			getline(cin,path);
			SetGCC("\"" + path + "\"");
		}while(CheckGCC() == false);
	}
	if(_access("config.txt",00) == 0){
		cout<<"�������ļ�����,���ļ�����������Ŀ:"<<endl;
		IO::Open("config.txt");
		WaitingList nowList;
		while(cin>>nowList.name>>nowList.maxTurn>>nowList.maxTime>>nowList.maxScore){
			cout<<"��Ŀ : "<<nowList.name<<" ; ���ݵ��� : "<<nowList.maxTurn<<" ; ";
			cout<<"ʱ�� : "<<nowList.maxTime<<" ; ������ : "<<nowList.maxScore<<endl;
			waiting.push_back(nowList);
		}
	}else{
		cout<<"�����ǿ��ģʽ,�������ֺ��������,Ĭ��ʱ�� : "<<MAX_TIME<<" ; Ĭ�������� : "<<MAX_SCORE<<endl;
		WaitingList nowList;
		cin>>nowList.name>>nowList.maxTurn;
		nowList.maxTime = MAX_TIME,nowList.maxScore = MAX_SCORE;
		waiting.push_back(nowList);
	}
	for(auto now : waiting){
		SetColor("white");
		cout<<"��ǰ���� : "<<now.name<<endl;
		JudgeResult result = Judge(now.name,1,now.maxTurn,now.maxTime);
		int score = result.ac * now.maxScore / result.Sum();
		if(score == now.maxScore){
			SetColor("lightgreen");
		}else{
			SetColor("lightred");
		}
		cout<<"SCORE : "<<score<<"pts / "<<now.maxScore<<"pts"<<endl;
		ShowBlock(score,now.maxScore);
		string nowStat = "AC";
		if(result.ac){
			SetColor("lightgreen");
			cout<<"AC : "<<result.ac<<" / "<<result.Sum()<<endl;
		}
		if(result.wa){
			SetColor("lightred");
			cout<<"WA : "<<result.wa<<" / "<<result.Sum()<<endl;
			nowStat = "WA";
		}
		if(result.tle){
			SetColor("lightpurple");
			cout<<"TLE : "<<result.tle<<" / "<<result.Sum()<<endl;
			if(nowStat != "WA")nowStat = "TLE";//WA > TLE
		}
		if(result.ce){
			SetColor("lightyellow");
			cout<<"CE : "<<result.ce<<" / "<<result.Sum()<<endl;
			nowStat = "CE";//CE > ALL
		}
		if(result.re){
			SetColor("gray");
			cout<<"RE : "<<result.re<<" / "<<result.Sum()<<endl;
			nowStat = "RE";//RE > WA
		}
		if(nowStat == "AC"){
			totAC++;
		}else if(nowStat == "WA"){
			totWA++;
		}else if(nowStat == "TLE"){
			totTLE++;
		}else if(nowStat == "CE"){
			totCE++;
		}else if(nowStat == "RE"){
			totRE++;
		}
		totMaxScore += now.maxScore,totScore += score;
		SetColor("lightwhite");
		for(auto i : result.returnList){
			cout<<i<<endl;
		}
		BR();
	}
	totSUM = totAC + totWA + totTLE + totCE + totRE;
	SetColor("white");
	cout<<"���ܹ� "<<totSUM<<" ����Ŀ��"<<endl;
	if(totAC){
		SetColor("lightgreen");
		cout<<totAC<<" ����ĿAC"<<endl; 
	}
	if(totWA){
		SetColor("lightred");
		cout<<totWA<<" ����ĿWA"<<endl; 
	}
	if(totTLE){
		SetColor("lightpurple");
		cout<<totTLE<<" ����ĿTLE"<<endl; 
	}
	if(totCE){
		SetColor("lightyellow");
		cout<<totCE<<" ����ĿCE"<<endl; 
	}
	if(totRE){
		SetColor("gray");
		cout<<totRE<<" ����ĿRE"<<endl; 
	}
	if(totScore == totMaxScore){
		SetColor("lightgreen");
	}else{
		SetColor("lightred");
	}
	cout<<"�ܵ÷� : "<<totScore<<" / "<<totMaxScore<<endl;
	SetColor("white");
	Error::OutputFile("PEOJ_err");
	cout<<endl;
	cout<<"����������˳�����"<<endl;
	getchar();
	return 0;
}
