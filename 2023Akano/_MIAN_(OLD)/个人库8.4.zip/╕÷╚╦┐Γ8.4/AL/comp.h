#pragma once
#include<bits/stdc++.h>
#include<Windows.h>
#include "basic.h"//����������
#include "IO.h"//IO�� 
using namespace std;
//��ֵ���� 
const string pre_file = ".\\__MAIN__\\";//�ļ�ִ��Ŀ¼,ִ�����Զ�ɾ��
const string in_name = "data.in";
const string out_name = "code.out"; 
const string ans_name = "std.ans";
const string code_name = "code.exe";
const string std_name = "std.exe";
const string data_name = "data.exe";
//�ɱ���� 
string compileOption = "-lm -O2 -std=c++14 -Wl,--stack=998244353 -Wall";
//��Ҫ����
inline void Compile(string Fname,string EXEname){//�����ļ� 
	const string str = "g++ "+Fname+" -o "+EXEname+" "+compileOption;
	system(str.c_str());
	return ;
}
inline void PreCompile(const string name){//Ԥ�ȱ���data,std,code����exe 
	CreateDirectory(pre_file.c_str(),NULL);
	Compile(name+".cpp",pre_file + code_name);
	Compile(name+"_std.cpp",pre_file + std_name);
	Compile(name+"_data.cpp",pre_file + data_name);
	return ;
}
inline long long Execute(const string& name){//ִ��ĳһ����,�������ķ���ֵ 
	long long result = system(name.c_str());
	if(result == 0){
		//the code runs correctly
	}else if(result == 1){
		cout<<name<<" didnt runs correctly.Return with value 1"<<endl; 
	}else if(result == -1073741819){
		result = 3221225477ll;
		cout<<name<<" access illegal memory.Return with value 3221225477"<<endl;
	}else if(result == -1073741571){
		result = 3221225725ll;
		cout<<name<<" leads to stack overflow.Return with value 3221225725"<<endl;
	}else if(result == -1073741676){
		result = 3221225620ll;
		cout<<name<<" try to divide zero.Return with value 3221225620"<<endl;
	}else{
		cout<<name<<" Return with undefined value "<<result<<endl;
	}
	return result;
}
inline long long Run(){//ִ��data,std,code����exe 
	long long result = 0;
	IO::Write(pre_file + in_name);
	result |= Execute(pre_file + data_name);//data
	IO::Open(pre_file + in_name);
	IO::Write(pre_file + out_name);
	result |= Execute(pre_file + code_name);//main
	IO::Open(pre_file + in_name);
	IO::Write(pre_file + ans_name);
	result |= Execute(pre_file + std_name);//std
	IO::Open("CON");
	IO::Write("CON");
	return result;
}
inline int FileIntoArray(string name,auto _in[]){//���ļ��ڵ�����д�������� 
	int tail = 0;
	cin.clear();
	IO::Open(name);
	while(cin>>_in[++tail]);
	IO::Open("CON");
	return tail-1;
}
inline pair<int,vector<string> > Compare(auto _ouf[],auto _ans[],int comp_length){//�Ƚ����������� 
	pair<int,vector<string> > ret;
	int len = min(GetLength(_ouf),GetLength(_ans));
	if(len < comp_length){
		cout<<"WARNING : Your compArray is too short!"<<endl;
	}
	comp_length = min(comp_length,len);
	for(int i = 0;i <= comp_length;i++){
		if(_ouf[i] != _ans[i]){
			++ret.first;
			string errInf = "In the "+TransToString(i);
			errInf += " element,read " + TransToString(_ouf[i]);
			errInf += " but expected "+ TransToString(_ans[i]);
			ret.second.push_back(errInf);
		}
	}
	return ret;
}
inline void Delete(){//ɾ��data,std,code�����ļ� 
	DeleteFile((pre_file + code_name).c_str());
	DeleteFile((pre_file + std_name).c_str());
	DeleteFile((pre_file + data_name).c_str());
	DeleteFile((pre_file + in_name).c_str());
	DeleteFile((pre_file + out_name).c_str());
	DeleteFile((pre_file + ans_name).c_str());
	RemoveDirectory(pre_file.c_str());
	return ;
}
