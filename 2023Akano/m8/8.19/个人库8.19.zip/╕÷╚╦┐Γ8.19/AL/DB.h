#pragma once
#include<bits/stdc++.h>
using namespace std;
namespace ADB{
	const vector<string> names = {
		"Norii",
		"Nafuu",
		"Ilana",
		"Miffiice"
	};
	const vector<string> GCC_PATH = {
		"\"C:\\Program Files (x86)\\Dev-Cpp\\MinGW64\\bin\\g++.exe\""
	};
}
