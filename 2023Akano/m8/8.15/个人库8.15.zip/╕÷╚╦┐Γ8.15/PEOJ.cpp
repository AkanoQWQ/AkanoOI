//PE Offline Judge Version 2023.8.12
//BASE ON AL ver2023.8.15
//��ҪAL ver2023.8.15������ 
#include<bits/stdc++.h>
#include<AL/comp.h>//��Ҫʹ��install.cmd��װAL 
using namespace std;
const int MAX_TIME = 1000;//ʱ��Ĭ��1000,��λms 
const int MAX_SCORE = 100;//������,Ĭ��100pts 
string main_name;
int t;
const int TOT_BLK = 20;//�������� 
inline void ShowBlock(int now,int up){
	int blk = TOT_BLK * now / up;
	SetColor("lightgreen");
	for(int i = 1;i <= blk;i++){
		cout<<"��";
	}
	SetColor("red");
	for(int i = blk+1;i <= TOT_BLK;i++){
		cout<<"��";
	}
	cout<<endl;
	return ;
}
int main(){
	cin>>main_name>>t;
	JudgeResult result = Judge(main_name,1,t,MAX_TIME);
	int score = result.ac * MAX_SCORE / result.Sum();
	if(score == MAX_SCORE){
		SetColor("lightgreen");
	}else{
		SetColor("lightred");
	}
	cout<<"SCORE : "<<score<<"pts / "<<MAX_SCORE<<"pts"<<endl;
	ShowBlock(score,MAX_SCORE);
	if(result.ac){
		SetColor("lightgreen");
		cout<<"AC : "<<result.ac<<" / "<<result.Sum()<<endl;
	}
	if(result.wa){
		SetColor("lightred");
		cout<<"WA : "<<result.wa<<" / "<<result.Sum()<<endl;
	}
	if(result.tle){
		SetColor("lightpurple");
		cout<<"TLE : "<<result.tle<<" / "<<result.Sum()<<endl;
	}
	SetColor("lightwhite");
	for(auto i : result.returnList){
		cout<<i<<endl;
	}
	Error::OutputFile("PEOJ_err");
	return 0;
}
