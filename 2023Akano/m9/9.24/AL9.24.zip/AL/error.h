#pragma once
#include<bits/stdc++.h>
#include "IO.h"
#include "basic.h"
#include "DB.h"
using namespace std;
namespace Error{
	struct AkanoErrorStream{
		string content;
	}aerr;
	struct AkanoErrorStreamEndFlag{
		
	}enderr;;
	struct Data{
		string position,inf,worldTime;
		int runningTime;
	};
	vector<Data> data;
	inline void PushError(const string& pos,const string& inf){
		Data newdata;
		newdata.position = pos,newdata.inf = inf;
		newdata.runningTime = clock(),newdata.worldTime = GetClock();
		data.push_back(newdata);
		return ;
	}
	inline void PE(const string& pos,const string& inf){//��д���� 
		PushError(pos,inf);
	}
	inline bool Empty(){
		return data.empty();
	}
	inline void Clear(){
		data.clear();
		return ;
	}
	inline void Output(ostream& os){
		if(!aerr.content.empty()){
			PushError("AkanoErrorStream",aerr.content);
			aerr.content = "";
		}
		os<<"һ���� "<<data.size()<<" ������"<<endl;
		for(auto err : data){
			os<<"�� "<<err.position<<" ��,���������´���:"<<endl;
			os<<err.inf<<endl;
			os<<"ʱ�� : ����ʱ�� "<<err.worldTime<<" ,����ʱ�� "<<err.runningTime<<endl;
			os<<"---------------------------------------------------------------"<<endl;
		}
		return ;
	}
	inline void Output(){//Ĭ��cout
		Output(cout);
		return ;
	}
	//ע��ı�IO(�ɰ汾��ʾ)
	//�°汾,ʹ�� ofstream �Ƿ����?
	inline void OutputFile(const string& name){
		if(Empty())return ;
		ofstream ofs((name + ".err").c_str());
		Output(ofs);
		ofs.close();
		return ;
	}
	inline void OutputFile(){
		OutputFile("AL_error");
		return ;
	}
	
	AkanoErrorStream& operator<<(AkanoErrorStream& aes,AkanoErrorStreamEndFlag _flag){
		PushError("AkanoErrorStream",aes.content);
		aes.content = "";
		return aes;
	}
	AkanoErrorStream& operator<<(AkanoErrorStream& aes,string content){
		aes.content += content;
		return aes;
	}
	AkanoErrorStream& operator<<(AkanoErrorStream& aes,const char* content){
		aes.content += content;
		return aes;
	}
	template<typename T>
	AkanoErrorStream& operator<<(AkanoErrorStream& aes,T content){
		aes.content += to_string(content);
		return aes;
	}
}
using Error::aerr;
using Error::enderr;
