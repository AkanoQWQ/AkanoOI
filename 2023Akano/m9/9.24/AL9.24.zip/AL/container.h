#pragma once
#include<bits/stdc++.h>
using namespace std;

namespace Container{
	
	//SegmentTree : ֧������Ӽ�,��ѯ����͵��߶��� 
	//T : ��ֵ����,ֻ������������
	//SIZE : �߶����Ĵ�С 
	//Build() : ��ʼ�����ó�ֵΪ 0
	//Build(T arr) : ������Ϊ��ʼ���ݳ�ʼ��
	//Change(int l,int r,int val) : �� [l,r] ������� val ���������
	//Query(int l,int r) : ѯ�� [l,r] ����ĺ�
	//SegmentTree() : ��ʼ���յ��߶���
	//SegmentTree(T arr) : ������Ϊ��ʼ���ݳ�ʼ���߶��� 
	template<typename T>
	struct SegmentTreeNode{
		T val,lazy;
		int len;
		SegmentTreeNode(){val = lazy = len = 0;}
	};
	template<typename T,int SIZE>
	class SegmentTree{
		private:
			SegmentTreeNode<T> node[(SIZE + 4) * 4];
			int OBJL,OBJR,_val;
			T* arr;
			inline void PushUp(int p){
				node[p].val = node[p*2].val + node[p*2+1].val;
				return ;
			}
			inline void PushDown(int p){
				if(node[p].lazy == 0)return ;
				node[p*2].val += node[p*2].len * node[p].lazy;
				node[p*2+1].val += node[p*2+1].len * node[p].lazy;
				node[p*2].lazy += node[p].lazy,node[p*2+1].lazy += node[p].lazy;
				node[p].lazy = 0;
				return ;
			}
			void Build(int p,int l,int r){
				node[p].len = r - l + 1;
				if(l == r){
					if(arr != nullptr){
						node[p].val = arr[l];
					}
					return ;
				}
				const int mid = (l + r) >> 1;
				Build(p*2,l,mid),Build(p*2+1,mid+1,r); 
				PushUp(p);
				return ;
			}
			void ChangeInner(int p,int l,int r){
				if(OBJL <= l && r <= OBJR){
					node[p].val += _val * node[p].len;
					node[p].lazy += _val;
					return ;
				}
				const int mid = (l + r) >> 1;
				PushDown(p);
				if(mid >= OBJL)ChangeInner(p*2,l,mid);
				if(mid < OBJR)ChangeInner(p*2+1,mid+1,r);
				PushUp(p);
				return ;
			}
			T Query(int p,int l,int r){
				if(OBJL <= l && r <= OBJR){
					return node[p].val;
				}
				const int mid = (l + r) >> 1;
				T ret = 0;
				PushDown(p);
				if(mid >= OBJL)ret = Query(p*2,l,mid);
				if(mid < OBJR)ret += Query(p*2+1,mid+1,r);
				return ret;
			}
		public:
			inline void Build(){
				Build(1,1,SIZE);
				return ;
			}
			inline void Build(T* _arr){
				arr = _arr;
				Build(1,1,SIZE);
				arr = nullptr;
				return ;
			}
			inline void Change(int l,int r,int inval){
				OBJL = l,OBJR = r,_val = inval;
				ChangeInner(1,1,SIZE);
				return ;
			}
			inline T Query(int l,int r){
				OBJL = l,OBJR = r;
				return Query(1,1,SIZE);
			}
			SegmentTree(){
				Build();
				return ;
			}
			SegmentTree(T* _arr){
				Build(_arr);
				return ;
			}
	};
	
	//BIT : ֧�ֵ����޸�,�����ѯ����״����
	//T : ���ݵ�����,Ҫ��������
	//SIZE : ������С
	//Change(int x,T val) : �� x λ�ü��� val
	//Query(int l,int r) : ѯ�� [l,r] ����� 
	template<typename T,int SIZE>
	class BIT{
		private:
			T val[SIZE];
			inline int Lowbit(int x){
				return x & (-x);
			}
			inline T QueryPre(int x){
				T ret = 0;
				while(x){
					ret += val[x];
					x -= Lowbit(x);
				}
				return ret;
			}
		public:
			inline void Change(int x,T _val){
				while(x <= SIZE){
					val[x] += _val;
					x += Lowbit(x);
				}
				return ;
			}
			inline T Query(int l,int r){
				return QueryPre(r) - QueryPre(l-1);
			}
			inline void Clear(){
				memset(val,0,sizeof(val));
				return ;
			}
			BIT(){Clear();}
	};
	
	//ClearableArray : ֧����ղ�������Ԫ�صĿ��������
	//T : ��������,������
	//SIZE : ������С
	//operator[x] : ���±��������
	//at(int x) :  �����Խ������±��������
	//Clear() : ��մ��ϴ��������������������,���� T �Ĺ��캯�� 
	template<typename T,int SIZE>
	class ClearableArray{
		private:
			T _content[SIZE];
			bool _vis[SIZE];
			queue<int> clearQueue;
		public:
			T& operator[](int _x){
				if(!_vis[_x]){
					_vis[_x] = true,clearQueue.push(_x);
				}
				return _content[_x];
			}
			inline T& at(int _x){
				assert(_x < SIZE && _x >= 0);
				return operator[](_x);
			}
			inline void Clear(){
				while(!clearQueue.empty()){
					const int _u = clearQueue.front();
					clearQueue.pop();
					_vis[_u] = false;
					_content[_u] = T();
				}
				return ;
			}
			inline int Size(){
				return clearQueue.size();
			}
			ClearableArray(){
				memset(_content,0,sizeof(_content));
				memset(_vis,0,sizeof(_vis));
				return ;
			}
	};
	
	//HashMap : ��ϣ��,ʵ�� unordered_map ��Ч��,��Ȼò���������������Ч�ʻ����� unordered_map 
	//Key : ��ֵ,���±������
	//Val : ֵ,�洢ֵ������  ���߶�����
	//HashClass : ʹ�÷º�����ʽ�������Ĺ�ϣ����
	//SIZE : ������ϣֵ�Ĵ�С,��˼��˵��ϣֵ��ȡֵ��Χ
	//SIZEԽ��,Խ�����ײ�����ϣ��ײ,Ȼ��������Խ��Խ��
	//operator[key] : ���ʶ�Ӧ��ֵ��ֵ,���û�����½�
	//HashMap(int size) : ����һ���յ� HashMap,��Ԥ���� size ��С�Ŀռ� 
	template<typename Key,typename Val>
	struct HashMapNode{
		Key key;
		Val val;
		int nxt;//������Χint,Ҳ����Ҫʹ�ø��淶������
		HashMapNode(){key = Key(),val = Val(),nxt = 0;}
		HashMapNode(Key _key){key = _key,val = Val(),nxt = 0;}
	};
	template<typename Key,typename Val,typename HashClass,int SIZE>//SIZEһ����С��int��,������Ҫװ���� 
	class HashMap{
		typedef HashMapNode<Key,Val> Node;
		typedef typename vector<Node>::iterator iterator;//Ϊ�˺���ͨ��������һ�� 
		private:
			HashClass hasher = HashClass();
			ClearableArray<int,SIZE> head;
			int tot;
			vector<Node> content;
			inline int FindIndex(const Key& key){
				const int hashVal = hasher(key) % SIZE;
				for(int i = head[hashVal];i;i = content[i].nxt){
					if(content[i].key == key)return i;
				}
				return 0;
			}
			inline int Insert(const Key& key){
				const int hashVal = hasher(key) % SIZE;
				int lst = head[hashVal];
				head[hashVal] = ++tot;
				content.emplace_back(key);
				content[tot].nxt = lst;
				return tot;
			}
		public:
			iterator begin(){//���� for(auto) ���� 
				return ++content.begin();//��ʼ��0,Ҫ��һ��Ԫ�� 
			}
			iterator end(){
				return content.end();
			}
			Val& operator[](const Key& key){
				int idx = FindIndex(key);
				if(idx == 0)idx = Insert(key);
				return content[idx].val;
			}
			inline bool Find(const Key& key){
				int idx = FindIndex(key);
				return (idx != 0);
			}
			inline void Clear(){
				content.clear();
				content.emplace_back();//��ʼһ����Ԫ��,�±�Ϊ0,�ǳ���Ҫ 
				head.Clear();
				tot = 0;
				return ;
			}
			HashMap(){
				Clear();
				return ;
			}
			HashMap(int initVal){
				content.reserve(initVal);
				Clear();
				return ;
			}
	};
	
	//HashSet : ��ϣ��,ʵ�� unordered_set �Ĺ���
	//Val,HashClass,SIZE : ͬ HashMap 
	//Insert(Val val) : ����ֵ,���ز����Ƿ�ɹ�(�Ƿ����и�Ԫ��) 
	//Find(Val val) : ��ѯ�Ƿ����и�Ԫ��
	template<typename Val>
	struct HashSetNode{
		Val val;
		int nxt;
		HashSetNode(){val = Val(),nxt = 0;}
		HashSetNode(Val _val){val = _val,nxt = 0;}
	};
	template<typename Val,typename HashClass,int SIZE>
	class HashSet{
		typedef HashSetNode<Val> Node;
		typedef typename vector<Node>::iterator iterator;
		private:
			HashClass hasher = HashClass();
			ClearableArray<int,SIZE> head;
			int tot;
			vector<Node> content;
			inline int FindIndex(const Val& val){
				const int hashVal = hasher(val) % SIZE;
				for(int i = head[hashVal];i;i = content[i].nxt){
					if(content[i].val == val)return i;
				}
				return 0;
			}
			inline int InsertContent(const Val& val){
				const int hashVal = hasher(val) % SIZE;
				int lst = head[hashVal];
				head[hashVal] = ++tot;
				content.emplace_back(val);
				content[tot].nxt = lst;
				return tot;
			}
		public:
			iterator begin(){//���� for(auto) ���� 
				return ++content.begin();//��ʼ��0,Ҫ��һ��Ԫ�� 
			}
			iterator end(){
				return content.end();
			}
			inline bool Insert(const Val& val){
				int idx = FindIndex(val);
				if(idx)return false;
				InsertContent(val);
				return true;
			}
			inline bool Find(const Val& val){
				int idx = FindIndex(val);
				return (idx != 0);
			}
			inline void Clear(){
				content.clear();
				content.emplace_back();//��ʼһ����Ԫ��,�±�Ϊ0,�ǳ���Ҫ 
				head.Clear();
				tot = 0;
				return ;
			}
			HashSet(){//��ʼһ����Ԫ��,�±�Ϊ0,�ǳ���Ҫ 
				Clear();
				return ;
			}
			HashSet(int initVal){//��ʼһ����Ԫ��,�±�Ϊ0,�ǳ���Ҫ 
				content.reserve(initVal);
				Clear();
				return ;
			}
	};
	
	//�Զ���Vector,��������ʲô��?�±��1��ʼ,����()(ӲҪ˵�Ļ��������۵Ĵ���ϰ��)
	//PushBack,Empty,Reserve,Resize,Clear,operator[] ͬ vector
	//Free = Resize(1),shink_to_fit (�ͷ��ڴ�)
	template<typename T>
	class Vector{
		private:
			const static int Exsize = 2;
			T* content;
			inline void SetCapacity(size_t newSize){
				T* newContent = new T[newSize+1];
				memcpy(newContent,content,sizeof(T) * min((size+1),newSize));
				swap(newContent,content);
				delete[] newContent;
				capacity = newSize;
				size = min(size,capacity);
				return ;
			}
			inline void Shift(int x){
				if(size + x > capacity){
					SetCapacity(size + x); 
				}
				if(x > 0){
					for(size_t i = size;i >= 1;i--){
						content[i+x] = content[i];
					}
					for(size_t i = 1;i <= size_t(x);i++)content[i] = T();
					size += x;
				}
				if(x < 0){
					x = -x;
					for(size_t i = size_t(x+1);i <= size;i++){
						content[i-x] = content[i];
					}
					for(size_t i = size_t(size-x+1);i <= size;i++)content[i] = T();
					size -= x;
				}
				return ;
			}
		public:
			size_t capacity,size;
			typedef T* iterator;
			inline iterator begin(){
				return &content[1];
			}
			inline iterator end(){
				return &content[size+1];
			}
			inline void PushBack(const T& newContent){
				if(size + 1 > capacity){
					SetCapacity(capacity * Exsize); 
				}
				content[++size] = newContent;
				return ;
			}
			inline void PopBack(){
				if(size >= 1)size--;
				return ;
			}
			inline void PushFront(const T& newContent){//O(n)......
				Shift(1);
				content[1] = newContent;
				return ;
			}
			inline void PopFront(){//O(n)......
				Shift(-1);
				return ;
			}
			inline bool Empty(){
				return (size == 0);
			}
			inline void Reserve(size_t newSize){
				if(newSize > capacity)SetCapacity(newSize);
				return ;
			}
			inline void Resize(size_t newSize){
				if(capacity < newSize)SetCapacity(newSize);
				size = newSize;
				return ;
			}
			inline void Clear(){
				size = 0;
				return ;
			}
			inline void Free(){
				SetCapacity(1);
				size = 0;
				return ;
			}
			T& operator[](size_t x){
				return content[x];
			}
			Vector(){
				content = new T[2];
				content[0] = T();
				capacity = 1,size = 0;
				return ;
			}
	};
	
	//�����޴�� Treap ƽ����,�����Ա� set(ʵ������multiste)
	//Ȼ�����������,�д��Ż�
	//Insert ����ĳֵ
	//Delete ɾ��ĳֵ 
	//GetRank ���ֵ������
	//GetVal ���������ֵ (������) 
	//GetPre ���ǰ�� (������) 
	//GetNext ���ǰ�� (������)
	//Range �������������� (�ȼ��� O(n) �� for auto)
	//begin �� O(logn) �� 
	template<typename T>
	class Treap{
		public:
			struct Node{
				int key;
				size_t tot,sz;
				T val;
				Node *l,*r;
				inline int Lsize(){
					if(l == nullptr)return 0;
					return l->sz;
				}
				inline int Rsize(){
					if(r == nullptr)return 0;
					return r->sz;
				}
				inline int Lkey(){
					if(l == nullptr)return -1;
					return l->key;
				}
				inline int Rkey(){
					if(r == nullptr)return -1;
					return r->key;
				}
				Node(T _val,int _key){
					val = _val;
					key = _key;
					tot = sz = 1;
					l = r = nullptr;
				}
				Node(){
					key = tot = sz = 0;
					val = T();
					l = nullptr,r = nullptr;
				}
			};
			
			struct iterator{
				Node* node;
				Treap* belong;
				T& operator*(){
					return node->val;
				}
				bool operator==(nullptr_t npt){
					return node == npt;
				}
				bool operator!=(nullptr_t npt){
					return !(this == npt);
				}
				bool operator==(iterator it){
					return node == it.node;
				}
				bool operator!=(iterator it){
					return !(*this == it);
				}
				iterator& operator++(){
					node = belong->GetNext(belong->root,node->val).node;
					return *this;
				}
				iterator operator++(int){//������ôд��?? 
					iterator old = *this;
					operator++();
					return old;
				}
				iterator(Node* _node,Treap* _belong){
					belong = _belong;
					node = _node;
					return ;
				}
				iterator(){
					belong = nullptr;
					node = nullptr;
					return ;
				}
			};
		private:
			const static int keyINF = 1e9;
			mt19937 rander;
			
			typedef Node* NodeItor;
			NodeItor root;
			
			inline void PushUp(NodeItor& p){
				if(p == nullptr)return ;
				p->sz = p->Lsize() + p->Rsize() + p->tot;
				return ;
			}
			inline void Zag(NodeItor& p){//���� 
				NodeItor q = p->r;
				p->r = q->l;
				q->l = p;
				p = q;
				PushUp(p);
				PushUp(p->l);
				return ;
			}
			inline void Zig(NodeItor& p){//���� 
				NodeItor q = p->l;
				p->l = q->r;
				q->r = p;
				p = q;
				PushUp(p);
				PushUp(p->r);
				return ;
			}
			void Insert(NodeItor& p,T val){
				if(p == nullptr){
					p = new Node(val,rander() % keyINF);
					return ;
				}
				if(val == p->val){
					p->tot++;
				}else if(val < p->val){
					Insert(p->l,val);
					if(p->key < p->Lkey()){
						Zig(p);
					}
				}else{
					Insert(p->r,val);
					if(p->key < p->Rkey()){
						Zag(p);
					}
				}
				PushUp(p);
				return ;
			}
			void Delete(NodeItor& p,T val){
				if(p == nullptr)return ;
				if(p->val == val){
					if(p->tot >= 2){
						--p->tot;
					}else if(p->l != nullptr || p->r != nullptr){
						if(p->Lkey() > p->Rkey()){
							Zig(p);
							Delete(p->r,val);
						}else{
							Zag(p);
							Delete(p->l,val);
						}
					}else{
						delete p;
						p = nullptr;
					}
				}else if(val < p->val){
					Delete(p->l,val); 
				}else if(val > p->val){
					Delete(p->r,val);
				}
				PushUp(p);
				return ;
			}
			size_t GetRank(NodeItor p,T val){
				if(p == nullptr)return 1;
				if(val == p->val){
					return p->Lsize() + 1;
				}else if(val < p->val){
					return GetRank(p->l,val);
				}else if(val > p->val){
					return GetRank(p->r,val) + p->tot + p->Lsize();
				}
				return 10181108;
			}
			iterator GetVal(NodeItor p,T k){
				if(k <= p->Lsize()){
					return GetVal(p->l,k);
				}else if(k <= int(p->Lsize() + p->tot)){
					return iterator(p,this);
				}
				return GetVal(p->r,k - p->Lsize() - p->tot);
			}
			iterator GetPre(NodeItor p,T val){
				if(p == nullptr)return iterator(nullptr,this);
				if(val <= p->val){
					return GetPre(p->l,val);
				}else{
					iterator ret = GetPre(p->r,val);
					if(ret.node == nullptr)ret = iterator(p,this);
					return ret;
				}
			}
			iterator GetNext(NodeItor p,T val){
				if(p == nullptr)return iterator(nullptr,this);
				if(val < p->val){
					iterator ret = GetNext(p->l,val);
					if(ret.node == nullptr)ret = iterator(p,this);
					return ret;
				}else{
					return GetNext(p->r,val);
				}
			}
			void dfs(NodeItor u,vector<T>& vec){
				if(u->l != nullptr)dfs(u->l,vec);
				vec.push_back(u->val);
				if(u->r != nullptr)dfs(u->r,vec);
				return ;
			}
		public:
			inline void Insert(T val){
				Insert(root,val);
				return ;
			}
			inline void Delete(T val){
				Delete(root,val);
				return ;
			}
			inline size_t GetRank(T val){
				return GetRank(root,val); 
			}
			inline iterator GetVal(T k){
				return GetVal(root,k);
			}
			inline iterator GetPre(T val){
				return GetPre(root,val);
			}
			inline iterator GetNext(T val){
				return GetNext(root,val);
			}
			inline iterator begin(){//logn ���Ӷ�! 
				NodeItor itor = root;
				while(itor != nullptr && itor->l != nullptr)itor = itor->l;
				return iterator(itor,this);
			}
			inline iterator end(){
				return iterator(nullptr,this);
			}
			vector<T> Range(){
				vector<T> ret;
				dfs(root,ret);
				return ret;
			}
			Treap(){
				rander.seed(time(0));
				return ;
			}
	};
	
	//���� Treap,��Ϊ������ Treap......
	//��� Treap ��˵������С,Ȼ�����Ǻܴ�
	//Ψһ������ȡ���˵�����,ǰ����̷��ص��� pair<T,bool> ��ʾǰ�����ֵ���Ƿ��ҵ�(�п���û�ҵ�) 
	template<typename T>
	class BasicTreap{
		private:
			const static int keyINF = 1e9;
			mt19937 rander;
			struct Node{
				int key;
				size_t tot,sz;
				T val;
				Node *l,*r;
				inline int Lsize(){
					if(l == nullptr)return 0;
					return l->sz;
				}
				inline int Rsize(){
					if(r == nullptr)return 0;
					return r->sz;
				}
				inline int Lkey(){
					if(l == nullptr)return -1;
					return l->key;
				}
				inline int Rkey(){
					if(r == nullptr)return -1;
					return r->key;
				}
				Node(T _val,int _key){
					val = _val;
					key = _key;
					tot = sz = 1;
					l = r = nullptr;
				}
				Node(){
					key = tot = sz = 0;
					val = T();
					l = nullptr,r = nullptr;
				}
			};
			
			typedef Node* iterator;
			iterator root;
			
			inline void PushUp(iterator& p){
				if(p == nullptr)return ;
				p->sz = p->Lsize() + p->Rsize() + p->tot;
				return ;
			}
			inline void Zag(iterator& p){//���� 
				iterator q = p->r;
				p->r = q->l;
				q->l = p;
				p = q;
				PushUp(p);
				PushUp(p->l);
				return ;
			}
			inline void Zig(iterator& p){//���� 
				iterator q = p->l;
				p->l = q->r;
				q->r = p;
				p = q;
				PushUp(p);
				PushUp(p->r);
				return ;
			}
			void Insert(iterator& p,T val){
				if(p == nullptr){
					p = new Node(val,rander() % keyINF);
					return ;
				}
				if(val == p->val){
					p->tot++;
				}else if(val < p->val){
					Insert(p->l,val);
					if(p->key < p->Lkey()){
						Zig(p);
					}
				}else{
					Insert(p->r,val);
					if(p->key < p->Rkey()){
						Zag(p);
					}
				}
				PushUp(p);
				return ;
			}
			void Delete(iterator& p,T val){
				if(p == nullptr)return ;
				if(p->val == val){
					if(p->tot >= 2){
						--p->tot;
					}else if(p->l != nullptr || p->r != nullptr){
						if(p->Lkey() > p->Rkey()){
							Zig(p);
							Delete(p->r,val);
						}else{
							Zag(p);
							Delete(p->l,val);
						}
					}else{
						delete p;
						p = nullptr;
					}
				}else if(val < p->val){
					Delete(p->l,val); 
				}else if(val > p->val){
					Delete(p->r,val);
				}
				PushUp(p);
				return ;
			}
			size_t GetRank(iterator p,T val){
				if(p == nullptr)return 1;
				if(val == p->val){
					return p->Lsize() + 1;
				}else if(val < p->val){
					return GetRank(p->l,val);
				}else if(val > p->val){
					return GetRank(p->r,val) + p->tot + p->Lsize();
				}
				return 10181108;
			}
			T GetVal(iterator p,T k){
				if(k <= p->Lsize()){
					return GetVal(p->l,k);
				}else if(k <= int(p->Lsize() + p->tot)){
					return p->val;
				}
				return GetVal(p->r,k - p->Lsize() - p->tot);
			}
			pair<T,bool> GetPre(iterator p,T val){
				if(p == nullptr)return make_pair(T(),false);
				if(val <= p->val){
					return GetPre(p->l,val);
				}else{
					pair<T,bool> ret = GetPre(p->r,val);
					if(ret.second == false){
						ret = make_pair(p->val,true);
					}else if(p->val > ret.first){
						ret = make_pair(p->val,true);
					}
					return ret;
				}
			}
			pair<T,bool> GetNext(iterator p,T val){
				if(p == nullptr)return make_pair(T(),false);
				if(val < p->val){
					pair<T,bool> ret = GetNext(p->l,val);
					if(ret.second == false){
						ret = make_pair(p->val,true);
					}else if(p->val < ret.first){
						ret = make_pair(p->val,true);
					}
					return ret;
				}else{
					return GetNext(p->r,val);
				}
			}
			void dfs(iterator u,vector<T>& vec){
				if(u->l != nullptr)dfs(u->l,vec);
				vec.push_back(u->val);
				if(u->r != nullptr)dfs(u->r,vec);
				return ;
			}
		public:
			inline void Insert(T val){
				Insert(root,val);
				return ;
			}
			inline void Delete(T val){
				Delete(root,val);
				return ;
			}
			inline size_t GetRank(T val){
				return GetRank(root,val); 
			}
			inline T GetVal(T k){
				return GetVal(root,k);
			}
			inline pair<T,bool> GetPre(T val){//�����ҵ���ֵ���Ƿ��ҵ��ɹ�(���ܸ���û���ҵ�) 
				return GetPre(root,val);
			}
			inline pair<T,bool> GetNext(T val){
				return GetNext(root,val);
			}
			vector<T> Range(){
				vector<T> ret;
				dfs(root,ret);
				return ret;
			}
	};
}
