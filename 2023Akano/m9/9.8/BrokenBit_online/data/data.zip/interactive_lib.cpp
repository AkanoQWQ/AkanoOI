#define Akano 1
#define pure__Elysia 0
#define loves ^
