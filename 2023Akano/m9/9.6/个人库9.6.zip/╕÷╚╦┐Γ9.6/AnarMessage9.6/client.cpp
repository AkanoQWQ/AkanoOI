//AnarMessage Ver 2023.9.6
//based on AL 2023.9.6
//�ͻ��˰汾 
#include<bits/stdc++.h>
#include<conio.h>
#include<Windows.h>
#include<AL/main.h>
using namespace std;

const int queryTime = 1000;
const int showRefreshTime = 10;//ˢ��ʱ�� 
const int readSize = 1024;

string pre = "\\\\.\\Pipe\\";
string serverName;
LPCSTR pipe_name = "";

Writer sendWriter;

vector<string> localMessages;
string nowMessage,lastMessage,userName;
inline void Query(HANDLE pipe){
	Reader<readSize> queryReader;
	Writer queryWriter;
	queryReader._pipe = pipe,queryWriter._pipe = pipe;
	while(true){
		lastMessage = "";//��Ϊˢ������Ϣ,���lastMessage 
		queryWriter<<"query "<<localMessages.size()<<" ";//�첽�ᵼ�������� 
		queryWriter.Write();
		queryReader.Read();
		int stp = -2;
		queryReader>>stp;
		for(int i = localMessages.size();i < stp;i++){
			string str;
			queryReader>>str;
			localMessages.push_back(Decode(str));
		}
		Sleep(queryTime);
	}
	return ;
}
inline void Show(){
	while(true){
		Refresh();
		for(auto i : localMessages){
			cout<<i<<endl;
		}
		if(!localMessages.empty() && localMessages.back() != lastMessage && lastMessage != ""){
			cout<<lastMessage<<endl;
		}
		cout<<"------------------------------"<<endl;
		cout<<nowMessage<<endl;
		Sleep(showRefreshTime);
	}
	return ;
}
char name_save[1018]; 
int main(){
	SetConsoleTitle("AnarMessage client");
	cout<<"������Ự����:"<<flush;
	cin>>serverName;
	cout<<"�������û�����:"<<flush;
	cin>>userName;
	RefreshInit();//������˫����ģʽ 
	
	
	strcpy(name_save,(pre + serverName).c_str());
	pipe_name = TEXT(name_save);
	
	cout<<"�ͻ�����������"<<endl; 
	bool connectedSuccess = TryConnect(pipe_name,100,2000); 
	if(connectedSuccess == false){
		cout<<"�ͻ�������ʧ��,δ���ҵ�����"<<endl;
		return 0;
	}
	cout<<"���ӳɹ�"<<endl;
	HANDLE pipe = CreateFile(pipe_name, GENERIC_READ | GENERIC_WRITE, 0,
		NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	
	thread queryThread(Query,pipe);
	queryThread.detach();
	
	thread showThread(Show);
	showThread.detach();
	
	sendWriter._pipe = pipe;
	while(true){
		char ch = getch();
		if(int(ch) == 8){
			if(!nowMessage.empty())nowMessage.pop_back();
		}else if(int(ch) == 13){//�س� 
			if(nowMessage == "")continue;//�����Ϳ���Ϣ: 
			lastMessage = userName+" : "+nowMessage;
			sendWriter<<"send "<<Encode(lastMessage)<<" ";
			sendWriter.Write();
			nowMessage = "";
		}else if(int(ch) == 32){//�ո� 
			nowMessage += " ";
		}else{
			nowMessage += ch;
		}
	}
	
	FlushFileBuffers(pipe);
	DisconnectNamedPipe(pipe);
	CloseHandle(pipe);
	system("pause");
	return 0;
}
