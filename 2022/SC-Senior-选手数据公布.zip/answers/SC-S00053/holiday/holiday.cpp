#include<bits/stdc++.h>
using namespace std;
typedef pair<int, int> pii;
typedef long long ll;

inline int rd()
{
	int s = 0;
	char ch = getchar();
	while(!isdigit(ch)) ch = getchar();
	while(isdigit(ch)) s = (s << 3) + (s << 1) + ch - '0', ch = getchar();
	return s;
}

const int MAXN = 2600;
int n, m, k;
ll score[MAXN], ans, mmax = -1;
//vector<int> G[MAXN];
int head[MAXN], cnt;
struct node{
	int to, nxt;
}edge[10100];

void add_edge(int u, int v)
{
	edge[++cnt].to = v;
	edge[cnt].nxt = head[u];
	head[u] = cnt;
}

priority_queue<pii, vector<pii>, greater<pii> > que;
int dist[MAXN], done[MAXN];
void dijkstra()
{
	for(int i = 1; i <= n; ++i) dist[i] = 0x3f3f3f3f;
	dist[1] = 0;
	que.push(make_pair(0, 1));
	while(!que.empty())
	{
		pii t = que.top(); que.pop();
		if(done[t.second]) continue;
		done[t.second] = 1;
//		for(int i = 0; i < G[t.second].size(); ++i)
		for(int i = head[t.second]; i; i = edge[i].nxt)
		{
//			int y = G[t.second][i];
			int y = edge[i].to;
			if(dist[y] > t.first + 1)
			{
				dist[y] = t.first + 1;
				que.push(make_pair(dist[y], y));
			}
		}
	}
}

int vis[MAXN];
void dfs(int now, int num, int stp, ll res)
{
	if(stp < -1) return;
	if(num == 4)
	{
		if(dist[now] <= k + 1)
		{
			ans = max(ans, res);
		}
		return;
	}
	if(stp == -1 || dist[now] > (4 - num) * (k + 1) + 1) return;
	if(res + (4 - num) * mmax < ans) return;
//	for(int i = 0; i < G[now].size(); ++i)
	for(int i = head[now]; i; i = edge[i].nxt)
	{
//		int y = G[now][i];
		int y = edge[i].to;
		
		//ѡ��ǰ�ڵ�
		if(vis[y] == 0 && y != 1)
		{
			vis[y] = 1;
			dfs(y, num + 1, k, res + score[y]);
			vis[y] = 0;
		}
		
		//��ѡ��ǰ�ڵ�
		dfs(y, num, stp - 1, res);
	}
}

int main()
{
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	n = rd(), m = rd(), k = rd();
	for(int i = 2; i <= n; ++i) score[i] = rd(), mmax = max(mmax, score[i]);
	for(int i = 1; i <= m; ++i)
	{
		int x = rd(), y = rd();
//		G[x].push_back(y);
//		G[y].push_back(x);
		add_edge(x, y);
		add_edge(y, x);
	}
	
	dijkstra();

	dfs(1, 0, k, 0);
	printf("%d", ans);
	return 0;
}
