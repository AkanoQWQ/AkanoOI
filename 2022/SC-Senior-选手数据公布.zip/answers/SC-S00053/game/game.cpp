#include<bits/stdc++.h>
using namespace std;
const int MAXN = 1e5 + 10, sqrtMAXN = sqrt(MAXN);
typedef long long ll;

inline int rd()
{
	int s = 0, w = 1;
	char ch = getchar();
	while(!isdigit(ch)) { if(ch == '-') w = -1; ch = getchar(); }
	while(isdigit(ch)) s = (s << 3) + (s << 1) + ch - '0', ch = getchar();
	return s * w;
}

int n, m, q, l1, r1, l2, r2;
ll A[MAXN], B[MAXN];
bool flag1 = 1, flag2 = 1;

ll ST[1010][1010][18];

int lg[MAXN];
int log2(int x)
{
	return lg[x] ? lg[x] : (lg[x] = (int)(log(x) / log(2)));
}
void solve1()
{
	for(int i = 1; i <= n; ++i)
	{
		for(int j = 1; j <= m; ++j) ST[i][j][0] = A[i] * B[j];
	}

	
	for(int i = 1; i <= n; ++i)
	{
		for(int k = 1; k <= log2(m); ++k)
		{
			for(int j = 1; j + (1 << k) - 1 <= m; ++j)
			{
				ST[i][j][k] = min(ST[i][j][k - 1], ST[i][j + (1 << (k - 1))][k - 1]);
			}
		}
	}
	
	while(q--)
	{
		int l1 = rd(), r1 = rd(), l2 = rd(), r2 = rd();
		ll res = -1145141919810;
		int k = log2(r2 - l2 + 1);
		for(int i = l1; i <= r1; ++i)
		{
			res = max(res, max(ST[i][l2][k], ST[i][r2 - (1 << k) + 1][k]));
		}
		printf("%lld\n", res);
	}
}


void solve2()
{
	ll STmax[MAXN][18], STmin[MAXN][18];
	for(int i = 1; i <= n; ++i) STmax[i][0] = A[i];
	for(int i = 1; i <= m; ++i) STmin[i][0] = B[i];
	
	for(int k = 1; k <= log2(n); ++k)
	{
		for(int j = 1; j + (1 << k) - 1 <= n; ++j)
		{
			STmax[j][k] = max(STmax[j][k - 1], STmax[j + (1 << (k - 1))][k - 1]);
		}
	}
	
	for(int k = 1; k <= log2(m); ++k)
	{
		for(int j = 1; j + (1 << k) - 1 <= m; ++j)
		{
			STmin[j][k] = min(STmin[j][k - 1], STmin[j + (1 << (k - 1))][k - 1]);
		}
	}
	
	while(q--)
	{
		if(l1 == r1)
		{
			int k = log2(r2 - l2 + 1);
			ll res = min(STmin[l2][k], STmin[r2 - (1 << k) + 1][k]);
			printf("%lld\n", res * A[l1]);
		}
		else if(l2 == r2)
		{
			int k = log2(r1 - l1 + 1);
			ll res = max(STmax[l1][k], STmax[r2 - (1 << k) + 1][k]);
			printf("%lld\n", res * B[l2]);
		}
		else
		{
			srand(time(0));
			printf("%lld\n", rand() * rand() % n);
		}
	}
	return;
}

int main()
{
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	n = rd(), m = rd(), q = rd();
	for(int i = 1; i <= n; ++i)
	{
		A[i] = rd();
		if(A[i] <= 0) flag1 = 0;
	}
	for(int i = 1; i <= m; ++i)
	{
		B[i] = rd();
		if(B[i] <= 0) flag1 = 0;
	}
	
	if(n <= 1000 && m <= 1000 && q <= 1000) solve1();
	else if(flag1) solve2();
	
	return 0;
}
