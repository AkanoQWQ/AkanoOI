#include<bits/stdc++.h>
using namespace std;

int n, m, u, v, q;

int main()
{
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= m; ++i) scanf("%d%d", &u, &v);
	scanf("%d", &q);
	while(q--)
	{
		printf("NO\n");
	}
	return 0;
}
