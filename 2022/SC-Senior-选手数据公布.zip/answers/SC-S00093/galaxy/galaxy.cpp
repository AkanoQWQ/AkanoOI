#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
inline int read(){
	int f = 0; char ch = getchar();
	while(ch < '0' || ch > '9') ch = getchar();
	while(ch >= '0' && ch <= '9'){
		f = f * 10 + ch - '0';
		ch = getchar();
	}
	return f;
}

const int N = 5e5 + 10;

int n, m;

int head[N], ver[N], Next[N], edge[N], tot;
void add(int x, int y){ ver[++tot] = y; Next[tot] = head[x]; head[x] = tot;}

vector<pair<int, int>> inedge[N];

int dout[N], din[N];
int cnt;
int camp[N];
bool check(){
	if(cnt != n) return false;
	queue<int> q; int sum = 0, x;
	for(int i = 1; i <= n; ++i){
		if(din[i] == 0) q.emplace(i);
		camp[i] = din[i];
	}
	while(!q.empty()){
		++sum;
		x = q.front(); q.pop();
		for(int i = head[x]; i; i = Next[i]){
			int y = ver[i];
			if(edge[i]) continue;
			--din[y];
			if(din[y] == 0) q.emplace(y);
		}
	}
	for(int i = 1; i <= n; ++i) din[i] = camp[i];
	return sum != n;
}

inline void change(int u, int v, bool type){
	for(int i = head[u]; i; i = Next[i]){
		if(ver[i] == v){
			edge[i] = type;
			break;
		}
	}
}

int main(){
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	n = read(), m = read();
	for(int i = 1, u, v; i <= m; ++i){
		u = read(), v = read();
		add(u, v); ++dout[u], ++din[v];
		inedge[v].emplace_back(make_pair(tot, u));
	}
	for(int i = 1; i <= n; ++i) if(dout[i] == 1) ++cnt;
	int q = read();
	int t, u, v;
	while(q--){
		t = read(), u = read();
		if(t == 1 || t == 3) v = read(); 
		if(t == 1){
			change(u, v, true);
			if(dout[u] == 1) --cnt;
			--dout[u];
			if(dout[u] == 1) ++cnt;
			
			--din[v];
		}
		else if(t == 2){
			din[u] = 0;
			for(pair<int, int> i : inedge[u]){
				if(edge[i.first]) continue;
				edge[i.first] = true;
				if(dout[i.second] == 1) --cnt;
				--dout[i.second];
				if(dout[i.second] == 1) ++cnt;
			}
		}
		else if(t == 3){
			change(u, v, false);
			if(dout[u] == 1) --cnt;
			++dout[u];
			if(dout[u] == 1) ++cnt;
			
			++din[v];
		}
		else{
			for(pair<int, int> i : inedge[u]){
				if(!edge[i.first]) continue;
				edge[i.first] = false; ++din[u];
				if(dout[i.second] == 1) --cnt;
				++dout[i.second];
				if(dout[i.second] == 1) ++cnt;
			}
		}
		if(check()) printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
