#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
inline ll read(){
	ll f = 0; char ch = getchar();
	while(ch < '0' || ch > '9') ch = getchar();
	while(ch >= '0' && ch <= '9'){
		f = f * 10 + ch - '0';
		ch = getchar();
	}
	return f;
}

const int N = 2510, M = 1e4 + 10;

int n, m, k;
ll c[N];
int head[N], ver[M << 1], Next[M << 1], tot;
void add(int x, int y){
	ver[++tot] = y; Next[tot] = head[x]; head[x] = tot;
}
bool vis[N];
ll ans = 0;
void dfs(int x, int cnt, ll dis){
	vis[x] = true;
	if(cnt == 5){
		ans = max(ans, dis);
		return;
	}
	for(int i = head[x]; i; i = Next[i]){
		int y = ver[i];
		if(cnt == 4){
			if(y == 1) dfs(y, cnt + 1, dis);
		}
		else{
			if(vis[y]) continue;
			dfs(y, cnt + 1, dis + c[y]);
		}
	}
	vis[x] = false;
}
vector<int> ne[N];
int dis[N][N];
void spfa(int s){
	memset(vis, 0, sizeof vis);
	if(dis[s][s] == 0) return;
	queue<int> q;
	q.emplace(s); int x;
	dis[s][s] = 0;
	while(!q.empty()){
		x = q.front(); q.pop();
		vis[x] = false;
		if(dis[s][x] == k + 1) continue;
		for(int y : ne[x]){
			if(dis[s][x] + 1 < dis[s][y]){
				dis[s][y] = dis[s][x] + 1;
				if(!vis[y]){
					vis[y] = true; q.emplace(y);
				}
			}
		}
	}
}
int cnt;
struct pp{
	ll val;
	int i1, i2;
} a[N];
bool cmp(pp a, pp b){ return a.val > b.val;}
vector<int> st;

int main(){
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	n = read(), m = read(), k = read();
	for(int i = 2; i <= n; ++i) c[i] = read();
	for(int i = 1, u, v; i <= m; ++i){
		u = read(), v = read();
		add(u, v); add(v, u); 
		ne[u].emplace_back(v); ne[v].emplace_back(u);
	}
	if(k == 0) dfs(1, 0, 0);
	else{
		for(int i = 2; i <= n; ++i)
		for(int j = i + 1; j <= n; ++j) a[++cnt] = {c[i] + c[j], i, j};
	sort(a + 1, a + cnt + 1, cmp);
	memset(dis, 0x3f, sizeof dis);
	for(int i = 1; i <= n; ++i) spfa(i);
	for(int i = 2; i <= n; ++i) if(dis[1][i] != dis[0][0]) st.emplace_back(i);
	for(int i = 0; i < st.size(); ++i)
		for(int j = i + 1; j < st.size(); ++j){
			int x = st[i], y = st[j];
			for(int ad = 1; ad <= cnt; ++ad){
				int l = a[ad].i1, r = a[ad].i2;
				if(x == l || y == l || x == r || y == r) continue;
				if(dis[x][l] != dis[0][0] && dis[y][r] != dis[0][0]){
					if(dis[r][l] != dis[0][0]){
						ans = max(ans, c[x] + c[y] + c[l] + c[r]);
						break;
					}
				}
				else if(dis[x][r] != dis[0][0] && dis[y][l] != dis[0][0]){
					if(dis[l][r] != dis[0][0]){
						ans = max(ans, c[x] + c[y] + c[l] + c[r]);
						break;
					}
				}
			}
		}
	}
	cout << ans; 
	return 0;
}
