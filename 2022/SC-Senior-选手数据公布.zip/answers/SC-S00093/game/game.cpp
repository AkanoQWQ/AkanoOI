#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
inline int read(){
	int f = 0, x = 1; char ch = getchar();
	while(ch < '0' || ch > '9'){
		if(ch == '-') x = -1;
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9'){
		f = f * 10 + ch - '0';
		ch = getchar();
	}
	return f * x;
}

const int N = 1e5 + 10, INF = 0x3f3f3f3f;
const ll MINN = LLONG_MIN;

int n, m, q;
int a[N], b[N];
struct pp{ ll fin, fax, zin, zax; bool fl0;};

struct sgt{
	int l, r;
	int fmin, fmax, zmin, zmax;
	bool flag0;
	#define l(x, p) tr[p][x].l
	#define r(x, p) tr[p][x].r
	#define fmin(x, p) tr[p][x].fmin
	#define fmax(x, p) tr[p][x].fmax
	#define zmin(x, p) tr[p][x].zmin
	#define zmax(x, p) tr[p][x].zmax
	#define flag0(x, p) tr[p][x].flag0
}tr[N << 2][2];
inline void pushup(int ty, int p){
	fmin(ty, p) = min(fmin(ty, p << 1), fmin(ty, p << 1 | 1));
	fmax(ty, p) = max(fmax(ty, p << 1), fmax(ty, p << 1 | 1));
	zmin(ty, p) = min(zmin(ty, p << 1), zmin(ty, p << 1 | 1));
	zmax(ty, p) = max(zmax(ty, p << 1), zmax(ty, p << 1 | 1));
	flag0(ty, p) = flag0(ty, p << 1) || flag0(ty, p << 1 | 1);
}
void Build(int l, int r, int ty, int p){
	l(ty, p) = l, r(ty, p) = r;
	if(l == r){
		fmin(ty, p) = zmin(ty, p) = INF;
		fmax(ty, p) = zmax(ty, p) = -INF;
		flag0(ty, p) = false;
		if(ty == 0){
			if(a[l] == 0) flag0(ty, p) = true;
			else if(a[l] > 0) zmin(ty, p) = zmax(ty, p) = a[l];
			else fmin(ty, p) = fmax(ty, p) = a[l];
		}
		else{
			if(b[l] == 0) flag0(ty, p) = true;
			else if(b[l] > 0) zmin(ty, p) = zmax(ty, p) = b[l];
			else fmin(ty, p) = fmax(ty, p) = b[l];
		}
		return;
	}
	int mid = l + r >> 1;
	Build(l, mid, ty, p << 1);
	Build(mid + 1, r, ty, p << 1 | 1);
	pushup(ty, p); 
}
pp query(int l, int r, int ty, int p){
	if(l <= l(ty, p) && r(ty, p) <= r) return (pp){fmin(ty, p), fmax(ty, p), zmin(ty, p), zmax(ty, p), flag0(ty, p)};
	int mid = l(ty, p) + r(ty, p) >> 1;
	if(r <= mid) return query(l, r, ty, p << 1);
	if(l >  mid) return query(l, r, ty, p << 1 | 1);
	pp ls = query(l, r, ty, p << 1), rs = query(l, r, ty, p << 1 | 1);
	return (pp){min(ls.fin, rs.fin), max(ls.fax, rs.fax), min(ls.zin, rs.zin), max(ls.zax, rs.zax), (ls.fl0 || rs.fl0)};
}

int main(){
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	n = read(), m = read(), q = read();
	for(int i = 1; i <= n; ++i) a[i] = read();
	for(int i = 1; i <= m; ++i) b[i] = read();
	Build(1, n, 0, 1); Build(1, m, 1, 1);
	int l1, r1, l2, r2;
	pp a_ans, b_ans;
	while(q--){
		l1 = read(), r1 = read(), l2 = read(), r2 = read();
		a_ans = query(l1, r1, 0, 1);
		b_ans = query(l2, r2, 1, 1);
		ll ans = MINN;
		if(a_ans.zin != INF){
			if(b_ans.fin != INF) ans = max(ans, a_ans.zin * b_ans.fin);
			else if(b_ans.zin != INF) ans = max(ans, a_ans.zax * b_ans.zin);
		}
		if(a_ans.fin != INF){
			if(b_ans.zin != INF) ans = max(ans, a_ans.fax * b_ans.zax);
			else if(b_ans.fin != INF) ans = max(ans, a_ans.fin * b_ans.fax);
		}
		if(ans == MINN) ans = 0;
		if(ans > 0 && b_ans.fl0) ans = 0;
		if(ans < 0 && a_ans.fl0) ans = 0;
		printf("%lld\n", ans);
	}
	return 0;
}
