#include<bits/stdc++.h>
using namespace std;
template <typename T>inline void re(T &x) {
	x=0;
	int f=1;
	char c=getchar();
	for(;!isdigit(c);c=getchar()) if(c=='-') f=-f;
	for(;isdigit(c);c=getchar()) x=(x<<3)+(x<<1)+(c^48);
	x*=f;
	return;
}
template <typename T>void wr(T x) {
	if(x<0) putchar('-'),x=-x;
	if(x>9) wr(x/10);
	putchar(x%10^'0');
	return;
}
const int N=5e5+5;
int n,m,q;
int in[N],out[N];
int num;
vector<int>to[N];
bool vis[1005][1005];
int z=0;
signed main() {
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	re(n),re(m);
	num=m;
	for(int i=1;i<=m;++i) {
		int u,v;
		re(u),re(v);
		to[v].push_back(u);
		++in[v],++out[u];
	}
	for(int i=1;i<=n;++i) if(out[i]==0) ++z;
	re(q);
	while(q--) {
		int opt;
		re(opt);
		if(opt==1) {
			int u,v;
			re(u),re(v);
			if(out[u]==1) ++z;
			--in[v],--out[u];
			--num;
			if(n<=1000) vis[u][v]=1;
		}
		if(opt==2) {
			int v;
			re(v);
			for(auto u:to[v]) {
				if(n<=1000) {
					if(vis[u][v]==0) {
						vis[u][v]=1;
						if(out[u]==1) ++z;
						--in[v],--out[u];
						--num;
					}
				}
			}
		}
		if(opt==3) {
			int u,v;
			re(u),re(v);
			if(out[u]==0) --z;
			++in[v],++out[u];
			++num;
			if(n<=1000) vis[u][v]=0;
		}
		if(opt==4) {
			int v;
			re(v);
			for(auto u:to[v]) {
				if(n<=1000) {
					if(vis[u][v]==1) {
						vis[u][v]=0;
						if(out[u]==0) --z;
						++in[v],++out[u];
						++num;
					}
				}
			}
		}
		if(num!=n||z) puts("NO");
		else puts("YES");
	}
	return 0;
}
