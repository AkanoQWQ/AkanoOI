#include<bits/stdc++.h>
using namespace std;
template <typename T>inline void re(T &x) {
	x=0;
	int f=1;
	char c=getchar();
	for(;!isdigit(c);c=getchar()) if(c=='-') f=-f;
	for(;isdigit(c);c=getchar()) x=(x<<3)+(x<<1)+(c^48);
	x*=f;
	return;
}
template <typename T>void wr(T x) {
	if(x<0) putchar('-'),x=-x;
	if(x>9) wr(x/10);
	putchar(x%10^'0');
	return;
}
//#define int long long
const long N=2e5+5,M=19;
int n,q,k;
int val[N];
vector<int>to[N];
long long dis[N];
int dep[N];
int pare[N][M];
void dfs(int x,int fa) {
	dep[x]=dep[fa]+1;
	pare[x][0]=fa;
	for(int i=1;pare[x][i-1];++i) pare[x][i]=pare[pare[x][i-1]][i-1];
	dis[x]=dis[fa]+val[x];
	for(auto v:to[x]) {
		if(v==fa) continue;
		dfs(v,x);
	}
	return;
}
inline int lca(int u,int v) {
	if(dep[u]<dep[v]) swap(u,v);
	for(int i=M-1;i>=0;--i) {
		if(dep[pare[u][i]]>=dep[v]) u=pare[u][i];
	}
	if(u==v) return u;
	for(int i=M-1;i>=0;--i) {
		if(pare[u][i]!=pare[v][i]) {
			u=pare[u][i];
			v=pare[v][i];
		}
	}
	return pare[u][0];
}
int a[N],b[N],cnta,cntb;
long long dp[N];
int mins[N];
signed main() {
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	re(n),re(q),re(k);
	for(int i=1;i<=n;++i) re(val[i]);
	for(int i=1;i<n;++i) {
		int u,v;
		re(u),re(v);
		to[u].push_back(v);
		to[v].push_back(u);
	}
	dfs(1,0);
	for(int x=1;x<=n;++x) {
		mins[x]=1e9+10;
		for(auto v:to[x]) mins[x]=min(mins[x],val[v]);
	}
	while(q--) {
		int u,v;
		re(u),re(v);
		if(k==1) {
			int LCA=lca(u,v);
			wr(dis[u]+dis[v]-dis[LCA]-dis[pare[LCA][0]]);
		} else {
			cnta=cntb=0;
			int LCA=lca(u,v);
			while(u!=LCA) {
				a[++cnta]=u;
				u=pare[u][0];
			}
			a[++cnta]=LCA;
			while(v!=LCA) {
				b[++cntb]=v;
				v=pare[v][0];
			}
			for(int i=cntb;i>=1;--i) {
				a[++cnta]=b[i];
			}
			dp[1]=val[a[1]];
			for(int i=1;i<k;++i) {
				dp[i+1]=val[a[i+1]]+val[a[1]];
			}
			for(int i=k+1;i<=cnta;++i) {
				dp[i]=1e18;
				for(int j=1;j<=k;++j) {
					dp[i]=min(dp[i],dp[i-j]+val[a[i]]);
				}
				if(k==3&&i>4) {
					dp[i]=min(dp[i],dp[i-4]+val[a[i]]+mins[a[i-2]]);
					dp[i]=min(dp[i],dp[i-1]-val[a[i-1]]+val[a[i]]+mins[a[i-2]]);
				}
			}
			wr(dp[cnta]);
		}
		putchar('\n');
	}
	return 0;
}
