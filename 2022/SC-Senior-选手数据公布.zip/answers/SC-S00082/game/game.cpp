#include<bits/stdc++.h>
using namespace std;
template <typename T>inline void re(T &x) {
	x=0;
	int f=1;
	char c=getchar();
	for(;!isdigit(c);c=getchar()) if(c=='-') f=-f;
	for(;isdigit(c);c=getchar()) x=(x<<3)+(x<<1)+(c^48);
	x*=f;
	return;
}
template <typename T>void wr(T x) {
	if(x<0) putchar('-'),x=-x;
	if(x>9) wr(x/10);
	putchar(x%10^'0');
	return;
}
const int N=1e5+5,M=19;
int n,m,q;
int A[N],B[N];
int LOG[N];
int sta[5][N][M];//min,<0 max,>0 min,max,0?(max)
int stb[2][N][M];//min,max
const int inf=1e9+2;
inline int ask(bool f,int opt,int l,int r) {
	int len=LOG[r-l+1];
	if(f==0) {
		if(opt==1||opt==3||opt==4) {
			return max(sta[opt][l][len],sta[opt][r-(1<<len)+1][len]);
		} else {
			return min(sta[opt][l][len],sta[opt][r-(1<<len)+1][len]);
		}
	} else {
		if(opt==0) {
			return min(stb[opt][l][len],stb[opt][r-(1<<len)+1][len]);
		} else {
			return max(stb[opt][l][len],stb[opt][r-(1<<len)+1][len]);
		}
	}
}
signed main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	re(n),re(m),re(q);
	LOG[1]=0;
	for(int i=2;i<=max(n,m);++i) LOG[i]=LOG[i>>1]+1;
	for(int i=1;i<=n;++i) re(A[i]);
	for(int i=1;i<=m;++i) re(B[i]);
	for(int i=1;i<=n;++i) {
		sta[0][i][0]=sta[3][i][0]=A[i];
		if(A[i]==0) sta[4][i][0]=1,sta[1][i][0]=-inf,sta[2][i][0]=inf;
		if(A[i]>0) sta[4][i][0]=0,sta[1][i][0]=-inf,sta[2][i][0]=A[i];
		if(A[i]<0) sta[4][i][0]=0,sta[1][i][0]=A[i],sta[2][i][0]=inf;
	}
	for(int i=1;i<=m;++i) {
		stb[0][i][0]=stb[1][i][0]=B[i];
	}
	for(int j=1;j<M;++j) {
		for(int i=1;i+(1<<j)-1<=n;++i) {
			sta[0][i][j]=min(sta[0][i][j-1],sta[0][i+(1<<j-1)][j-1]);
			sta[2][i][j]=min(sta[2][i][j-1],sta[2][i+(1<<j-1)][j-1]);
			sta[3][i][j]=max(sta[3][i][j-1],sta[3][i+(1<<j-1)][j-1]);
			sta[1][i][j]=max(sta[1][i][j-1],sta[1][i+(1<<j-1)][j-1]);
			sta[4][i][j]=sta[4][i][j-1]|sta[4][i+(1<<j-1)][j-1];
		}
		for(int i=1;i+(1<<j)-1<=m;++i) {
			stb[0][i][j]=min(stb[0][i][j-1],stb[0][i+(1<<j-1)][j-1]);
			stb[1][i][j]=max(stb[1][i][j-1],stb[1][i+(1<<j-1)][j-1]);
		}
	}
	while(q--) {
		long long ans=-2e18;
		int l1,r1,l2,r2;
		re(l1),re(r1),re(l2),re(r2);
		long long maxs=ask(1,1,l2,r2);
		long long mins=ask(1,0,l2,r2);
		long long n0=ask(0,0,l1,r1);
		long long n1=ask(0,1,l1,r1);
		long long n2=ask(0,2,l1,r1);
		long long n3=ask(0,3,l1,r1);
		long long n4=ask(0,4,l1,r1);
		ans=max(ans,min(maxs*n0,mins*n0));
		if(n1>-inf) ans=max(ans,min(maxs*n1,mins*n1));
		if(n2<inf) ans=max(ans,min(maxs*n2,mins*n2));
		ans=max(ans,min(maxs*n3,mins*n3));
		if(n4) ans=max(ans,0ll);
		wr(ans),putchar('\n');
	}
	return 0;
}
