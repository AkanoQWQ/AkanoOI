#include<bits/stdc++.h>
using namespace std;
template <typename T>inline void re(T &x) {
	x=0;
	int f=1;
	char c=getchar();
	for(;!isdigit(c);c=getchar()) if(c=='-') f=-f;
	for(;isdigit(c);c=getchar()) x=(x<<3)+(x<<1)+(c^48);
	x*=f;
	return;
}
template <typename T>void wr(T x) {
	if(x<0) putchar('-'),x=-x;
	if(x>9) wr(x/10);
	putchar(x%10^'0');
	return;
}
const int N=2505;
int n,m,k;
vector<int>to[N],t[N];
long long a[N];
int q[N];
int dis[N][N];
inline void bfs(int sx) {
	int st=1,en=1;
	q[en++]=sx;
	dis[sx][sx]=0;
	while(st<en) {
		int x=q[st++];
		for(auto v:to[x]) {
			if(v==sx||dis[sx][v]) continue;
			dis[sx][v]=dis[sx][x]+1;
			q[en++]=v;
		}
	}
	return;
}
bool vis[N];
long long ans1[N];
long long ans2[N];
long long ans3[N];
int pre1[N];
int pre2[N];
signed main() {
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	re(n),re(m),re(k);
	for(int i=2;i<=n;++i) re(a[i]);
	for(int i=1;i<=m;++i) {
		int u,v;
		re(u),re(v);
		to[u].push_back(v);
		to[v].push_back(u);
	}
	for(int i=1;i<=n;++i) {
		bfs(i);
	}
	for(int i=2;i<=n;++i) {
		for(int j=2;j<=n;++j) {
			if(i==j) continue;
			if(dis[1][i]&&dis[1][i]<=k+1&&dis[i][j]&&dis[i][j]<=k+1) {
				if(ans1[j]<a[i]+a[j]) ans1[j]=a[i]+a[j],pre1[j]=i;
			}
		}
	}
	for(int i=2;i<=n;++i) {
		if(!pre1[i]) continue;
		for(int j=2;j<=n;++j) {
			if(i==j) continue;
			if(j==pre1[i]) continue;
			if(dis[i][j]&&dis[i][j]<=k+1) {
				if(ans2[j]<ans1[i]+a[j]) ans2[j]=ans1[i]+a[j],pre2[j]=i;
			}
		}
	}
	for(int i=2;i<=n;++i) {
		if(!pre2[i]) continue;
		for(int j=2;j<=n;++j) {
			if(i==j) continue;
			if(j==pre2[i]) continue;
			if(j==pre1[pre2[i]]) continue;
			if(dis[i][j]&&dis[i][j]<=k+1) {
				if(ans3[j]<ans2[i]+a[j]) ans3[j]=ans2[i]+a[j];
			}
		}
	}
	long long maxs=0;
	for(int i=2;i<=n;++i) {
		if(!ans3[i]) continue;
		if(dis[1][i]>k+1) continue;
		maxs=max(maxs,ans3[i]);
	}
	wr(maxs);
	return 0;
}
