#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;
const int maxn = 2e5 + 10;
#define mid ((l + r) >> 1)
#define lson rt << 1, l, mid
#define rson rt << 1 | 1, mid + 1, r 
#define ll long long
struct Edge {
	int v, nxt;
} e[maxn << 1];

int n, q, k, lst[maxn], cntedge, a[maxn];
int son[maxn], fa[maxn], dep[maxn], topfa[maxn], dfn[maxn], tot, sz[maxn];
ll tree[maxn * 8];

void Add(int u, int v) {
	e[++cntedge] = {v, lst[u]};
	lst[u] = cntedge;
}

void dfs1(int now, int Fa, int deep) {
	fa[now] = Fa;
	dep[now] = deep;
	dfn[now] = ++tot;
	sz[now] = 1;
	
	for(int i = lst[now]; i; i = e[i].nxt) {
		int v = e[i].v;
		if(v == Fa) continue;
		dfs1(v, now, deep + 1);
		sz[now] += sz[v];
		if(sz[son[now]] < sz[v]) son[now] = v;
	}
	return;
}

void dfs2(int now, int Top) {
	if(!now) return;
	topfa[now] = Top;
	dfs2(son[now], Top);
	for(int i = lst[now]; i; i = e[i].nxt) {
		int v = e[i].v;
		if(v == fa[now] || v == son[now]) continue;
		dfs2(v, v);
	}
	return;
}

void update(int rt, int l, int r, int pos, int val) {
	if(l == r) {
		tree[rt] = val;
		return;
	}
	if(pos <= mid) update(lson, pos, val);
	if(pos > mid) update(rson, pos, val);
	tree[rt] = tree[rt << 1] + tree[rt << 1 | 1];
}

ll query(int rt, int l, int r, int L, int R) {
	if(L <= l && R >= r) return tree[rt];
	ll res = 0;
	if(L <= mid) res += query(lson, L, R);
	if(R > mid) res += query(rson, L, R);
	return res;
}

ll query_range(int x, int y) {
	ll res = 0;
	while(topfa[x] != topfa[y]) {
		int fax = topfa[x], fay = topfa[y];
		if(dep[fax] < dep[fay]) {
			swap(x, y);
			swap(fax, fay);
		}
		res += query(1, 1, n, dfn[fax], dfn[x]);
		x = fa[fax];
	}
	if(dep[x] < dep[y]) swap(x, y);
	res += query(1, 1, n, dfn[y], dfn[x]);
	return res;
}

int Lca(int x, int y) {
	while(topfa[x] != topfa[y]) {
		int fax = topfa[x], fay = topfa[y];
		if(dep[fax] < dep[fay]) {
			swap(fax, fay);
			swap(x, y);
		}
		x = fa[fax];
	}
	return (dep[x] < dep[y] ? x : y);
}

void solve1() {
	for(int i = 1; i <= q; i++) {
		int s, t; cin >> s >> t;
		cout << query_range(s, t) << '\n';
	}
	return;
}

void solve2() {
	for(int i = 1; i <= q; i++) {
		int s, t; cin >> s >> t;
		int lca = Lca(s, t);
		
		if(dep[s] - dep[lca] + dep[t] - dep[lca] == 2) {
			cout << a[s] + a[t] << '\n';
			continue;
		}
		
		ll res = 0;
		int s1 = s, s2 = t;
		while(true) {
			res += a[s1];
			if(s1 == lca) break;
			if(a[fa[fa[s1]]] != 0 && dep[fa[fa[s1]]] >= dep[lca]) s1 = (a[fa[s1]] < a[fa[fa[s1]]] ? fa[s1] : fa[fa[s1]]);
			else s1 = fa[s1];
		}
		while(true) {
			res += a[s2];
			if(s2 == lca) break;
			if(a[fa[fa[s2]]] != 0 && dep[fa[fa[s2]]] >= dep[lca]) s2 = (a[fa[s2]] < a[fa[fa[s2]]] ? fa[s2] : fa[fa[s2]]);
			else s2 = fa[s2];
		}
		
		if(s1 == s2) res -= a[lca];
		cout << res << '\n';
	}
	return;
}

void solve3() {
	
}
/*
8 6 2
1 2 3 4 5 6 7 8
1 2
1 3
1 4
2 5
2 6
4 7
4 8
5 8
5 3
1 7
2 6
6 7
5 6
*/

int main() {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	cin.tie(0); cout.tie(0); 
	ios::sync_with_stdio(false);
	cin >> n >> q >> k;
	for(int i = 1; i <= n; i++) cin >> a[i];
	
	for(int i = 1; i < n ;i++) {
		int u, v; cin >> u >> v;
		Add(u, v); Add(v, u);
	}
	
	dfs1(1, 0, 1); dfs2(1, 1);
	
	for(int i = 1; i <= n; i++) update(1, 1, n, dfn[i], a[i]);
	
	if(k == 1) solve1();
	else if(k == 2) solve2();
	else if(k == 3) solve3();
	return 0;
}
