#include <iostream>
#include <cstdio>
using namespace std;
const int maxn = 2510, maxm = 1e4 + 10;
#define ll long long

struct Edge {
	int v, nxt;
} e[maxm * 2];

int n, m, k;
ll a[maxn], ans;
int lst[maxn], cntedge;

void Add(int u, int v) {
	e[++cntedge] = {v, lst[u]};
	lst[u] = cntedge;
}

bool vis[maxn];
void dfs(int now, int dep, ll val) {
	if(dep == 5) {
		if(now == 1) ans = max(val, ans);
		return;
	}
	
	for(int i = lst[now]; i; i = e[i].nxt) {
		int v = e[i].v;
		if(vis[v] || (v == 1 && dep < 4)) continue;
		vis[v] = true;
		dfs(v, dep + 1, val + a[v]);
		vis[v] = false;
	}
	return;
}

void solve1() {
	dfs(1, 0, 0);
	cout << ans << '\n';
	return;
}

int main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	
	cin.tie(0); cout.tie(0);
	ios::sync_with_stdio(false);
	cin >> n >> m >> k;
	for(int i = 2; i <= n; i++) cin >> a[i];
	
	for(int i = 1; i <= m; i++) {
		int u, v; cin >> u >> v;
		Add(u, v); Add(v, u);
	}
	
	if(k == 0) solve1();
	return 0;
}
