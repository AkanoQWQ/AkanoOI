#include<iostream>
#include<cmath>
#include<cstdio> 
#include<algorithm>
using namespace std;
int n,m,q;
int a[1001],b[1001],c[1001][1001],a2[1001],b2[1001];
int l1,r1,l2,r2,A,B;	
int yes[2]={1},yes2[2]={1};
int max1,min1;
int max2,min2;	
bool comp(int a,int b){
	return a<b;
}
int zy_a(int l1,int r1);
int zy_b(int l2,int r2);
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++){
		    cin>>a[i];
	    a2[i]=a[i];
	    if(a[i]==0)yes[0]=0,yes[1]=i;
	}
	for(int i=1;i<=m;i++){
		cin>>b[i];
		b2[i]=b[i];
		if(b[i]==0)yes2[0]=0,yes2[1]=i;
	}
	sort(a2+1,a2+n+1,comp);
	sort(b2+1,b2+m+1,comp);
	
	for(int i=1;i<=q;i++){
		cin>>l1>>r1>>l2>>r2;
//		if(a2[1]>=0&&b2[1]>=0){
//			cout<<a2[n]*b2[1];
//		}
		min1=a2[n];
		min2=b2[m];
		max1=a2[1];
		max2=b2[1];
		for(int j=l1;j<=r1;j++){
			if(a[j]>max1)max1=a[j];
			if(a[j]<min1)min1=a[j];
		}
		for(int j=l2;j<=r2;j++){
			if(b[j]>max2)max2=b[j];
			if(b[j]<min2)min2=b[j];
		}
		A=zy_a(l1,r1);
		B=zy_b(l2,r2);
		cout<<A*B<<endl; 
	}
	
	return 0;
}int zy_a(int l1,int r1){
	if(max2<=0)return min1;
	else if(min2>=0)return max1;
	
	else{
		if(yes[0]==0&&yes[1]>=l1&&yes[1]<=r1)return 0;
		else{
			if(min1>=0)return min1;
		    else if(max1<=0)return max1;
			else{
				if(a2[yes[1]-1]*max2>a2[yes[1]+1]*min2)return a2[yes[1]-1];
				else return a2[yes[1]+1];
			}
		}
	
	}
}
int zy_b(int l2,int r2){
	if(max1<=0)return max2;
	else if(min1>=0)return max2;
	else{
		if(yes2[0]==0&&yes2[1]>=l2&&yes2[1]<=r2)return 0;
		else{
			if(min2>=0)return min2;
		    else if(max2<=0)return max2;
			else{
				if(min2*min1>=max2*max1)return max2;
				else return min2;
			}
		}
	
	}
}
