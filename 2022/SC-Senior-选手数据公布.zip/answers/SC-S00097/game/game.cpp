#include<bits/stdc++.h>
using namespace std;
const int NN=1e5+4;
struct segment_tree
{
	int minn,maxx,minup,maxdown;
	segment_tree()
	{
		minn=minup=2e9,maxx=maxdown=-2e9;
	}
	segment_tree(int _minn,int _maxx,int _minup,int _maxdown)
	{
		minn=_minn,maxx=_maxx,minup=_minup,maxdown=_maxdown;
	}
	segment_tree operator+(const segment_tree&it)
	{
		return {min(minn,it.minn),max(maxx,it.maxx),min(minup,it.minup),max(maxdown,it.maxdown)};
	}
}tr1[NN<<2],tr2[NN<<2];
int a[NN],b[NN];
void build(segment_tree tr[],int v[],int u,int l,int r)
{
	if(l==r)
	{
		tr[u].minn=tr[u].maxx=v[l];
		if(v[l]<=0)
			tr[u].maxdown=v[l];
		if(v[l]>=0)
			tr[u].minup=v[l];
		return;
	}
	int mid=l+(r-l)/2;
	build(tr,v,u<<1,l,mid);
	build(tr,v,u<<1|1,mid+1,r);
	tr[u]=tr[u<<1]+tr[u<<1|1];
}
segment_tree query(segment_tree tr[],int u,int l,int r,int trl,int trr)
{
	if(trl>=l&&trr<=r)
		return tr[u];
	int mid=trl+(trr-trl)/2;
	segment_tree res;
	if(l<=mid)
		res=res+query(tr,u<<1,l,r,trl,mid);
	if(r>mid)
		res=res+query(tr,u<<1|1,l,r,mid+1,trr);
	return res;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q;
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)
		scanf("%d",&b[i]);
	build(tr1,a,1,1,n);
	build(tr2,b,1,1,m);
	while(q--)
	{
		int l1,r1,l2,r2;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		segment_tree x=query(tr1,1,l1,r1,1,n),y=query(tr2,1,l2,r2,1,m);
		if(x.minn>=0)
		{
			if(y.minn>=0)
				printf("%lld\n",1ll*x.maxx*y.minn);
			else
				printf("%lld\n",1ll*x.minn*y.minn);
		}
		else if(x.maxx<=0)
		{
			if(y.maxx<=0)
				printf("%lld\n",1ll*x.minn*y.maxx);
			else
				printf("%lld\n",1ll*x.maxx*y.maxx);
		}
		else
		{
			if(y.minn>=0)
				printf("%lld\n",1ll*x.maxx*y.minn);
			else if(y.maxx<=0)
				printf("%lld\n",1ll*x.minn*y.maxx);
			else
				printf("%lld\n",max(1ll*x.minup*y.minn,1ll*x.maxdown*y.maxx));
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
