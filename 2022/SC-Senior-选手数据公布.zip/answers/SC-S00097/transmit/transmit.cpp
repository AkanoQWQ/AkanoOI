#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int NN=2e5+4;
int up[NN][21],v[NN],d[NN];
ll upv[NN][21];
vector<int>g[NN];
void dfs(int u,int fa)
{
	d[u]=d[fa]+1;
	up[u][0]=fa;
	upv[u][0]=v[u];
	for(int i=1;i<=20;i++)
	{
		up[u][i]=up[up[u][i-1]][i-1];
		upv[u][i]=upv[u][i-1]+upv[up[u][i-1]][i-1];
	}
	for(int i=0;i<g[u].size();i++)
	{
		int v=g[u][i];
		if(v==fa)
			continue;
		dfs(v,u);
	}
}
ll lca(int u,int v)
{
	if(d[u]<d[v])
		swap(u,v);
	ll res=0;
	for(int i=20;~i;i--)
		if(d[up[u][i]]>=d[v])
		{
			res+=upv[u][i];
			u=up[u][i];
		}
	if(u==v)
		return res+upv[u][0];
	for(int i=20;~i;i--)
		if(up[u][i]!=up[v][i])
		{
			res+=upv[u][i]+upv[v][i];
			u=up[u][i],v=up[v][i];
		}
	return res+upv[u][1]+upv[v][0];
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int n,q,t;
	scanf("%d%d%d",&n,&q,&t);
	for(int i=1;i<=n;i++)
		scanf("%d",&v[i]);
	for(int i=1;i<n;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		g[u].push_back(v);
		g[v].push_back(u);
	}
	dfs(1,0);
	while(q--)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		printf("%lld\n",lca(x,y));
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
