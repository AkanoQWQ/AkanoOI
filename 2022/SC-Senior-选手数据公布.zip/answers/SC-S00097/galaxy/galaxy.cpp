#include<bits/stdc++.h>
using namespace std;
const int NN=5e5+4;
int du[NN];
vector<pair<int,bool> >g[NN];
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		g[v].push_back({u,true});
		du[u]++;
	}
	int cnt=0;
	for(int i=1;i<=n;i++)
	{
		sort(g[i].begin(),g[i].end());
		if(du[i]==1)
			cnt++;
	}
	int q;
	scanf("%d",&q);
	while(q--)
	{
		int opt;
		scanf("%d",&opt);
		if(opt==1)
		{
			int u,v;
			scanf("%d%d",&u,&v);
			du[u]--;
			if(!du[u])
				cnt--;
			if(du[u]==1)
				cnt++;
			g[v][lower_bound(g[v].begin(),g[v].end(),make_pair(u,false))-g[v].begin()].second=false;
		}
		else if(opt==2)
		{
			int u;
			scanf("%d",&u);
			for(int i=0;i<g[u].size();i++)
				if(g[u][i].second)
				{
					g[u][i].second=false;
					int v=g[u][i].first;
					du[v]--;
					if(!du[v])
						cnt--;
					if(du[v]==1)
						cnt++;
				}
		}
		else if(opt==3)
		{
			int u,v;
			scanf("%d%d",&u,&v);
			du[u]++;
			if(du[u]==2)
				cnt--;
			if(du[u]==1)
				cnt++;
			g[v][lower_bound(g[v].begin(),g[v].end(),make_pair(u,false))-g[v].begin()].second=true;
		}
		else
		{
			int u;
			scanf("%d",&u);
			for(int i=0;i<g[u].size();i++)
				if(!g[u][i].second)
				{
					g[u][i].second=true;
					int v=g[u][i].first;
					du[v]++;
					if(du[v]==2)
						cnt--;
					if(du[v]==1)
						cnt++;
				}
		}
		puts(cnt==n?"YES":"NO");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
