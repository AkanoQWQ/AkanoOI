#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int NN=2504;
vector<int>g[NN];
int d[NN][NN],maxk[3][NN];
ll v[NN],maxx[3][NN];
void bfs(int s,int d[])
{
	queue<int>q;
	q.push(s);
	d[s]=-1;
	while(q.size())
	{
		int u=q.front();
		q.pop();
		for(int i=0;i<g[u].size();i++)
		{
			int v=g[u][i];
			if(d[v]>d[u]+1)
			{
				d[v]=d[u]+1;
				q.push(v);
			}
		}
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int n,m,k;
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++)
		scanf("%lld",&v[i]);
	for(int i=1;i<=m;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		g[u].push_back(v);
		g[v].push_back(u);
	}
	memset(d,0x3f,sizeof(d));
	for(int i=1;i<=n;i++)
		bfs(i,d[i]);
	for(int i=2;i<=n;i++)
		for(int j=2;j<=n;j++)
			if(i!=j&&d[i][j]<=k)
			{
				if(v[j]>=maxx[0][i])
				{
					maxk[2][i]=maxk[1][i];
					maxk[1][i]=maxk[0][i];
					maxk[0][i]=j;
					maxx[2][i]=maxx[1][i];
					maxx[1][i]=maxx[0][i];
					maxx[0][i]=v[j];
				}
				else if(v[j]>=maxx[1][i])
				{
					maxk[2][i]=maxk[1][i];
					maxk[1][i]=j;
					maxx[2][i]=maxx[1][i];
					maxx[1][i]=v[j];
				}
				else if(v[j]>=maxx[2][i])
				{
					maxk[2][i]=j;
					maxx[2][i]=v[j];
				}
			}
	ll ans=0;
	for(int i=2;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			if(d[1][i]<=k&&d[1][j]<=k)
				for(int x=0;x<3;x++)
					for(int y=0;y<3;y++)
						if(maxk[x][i]!=j&&maxk[y][j]!=i&&maxk[x][i]!=maxk[y][j]&&maxk[x][i]&&maxk[y][j]&&d[maxk[x][i]][maxk[y][j]]<=k)
							ans=max(ans,maxx[x][i]+maxx[y][j]+v[i]+v[j]);
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
