#include<bits/stdc++.h>
using namespace std;
int n,Q,k,x,y;
int flag[2010],a[2010][2010];
long long v[2010];
long long int mem[2010][2010];
void abc(){
	for(int mid=1;mid<=n;mid++){
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				if(a[i][j]<=k){
					mem[i][j]=min(mem[i][j],v[i]+v[j]);
				}
				if(a[i][mid]<=k&&a[mid][j]<=k){
					mem[i][j]=min(mem[i][j],v[i]+v[j]+v[mid]);
					mem[j][i]=mem[i][j];
				}
			}
		}
	}
}
void suan_yi_suan_zui_duan_lu(){
	for(int mid=1;mid<=n;mid++){
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				if(a[i][mid]!=0&&a[mid][j]!=0){
					if(a[i][j]==0)a[i][j]=a[i][mid]+a[mid][j];
					else a[i][j]=min(a[i][j],a[i][mid]+a[mid][j]);
					a[j][i]=a[i][j];
				}
			}
		}
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	memset(a,0,sizeof(a));
	memset(mem,7,sizeof(mem));
	scanf("%d%d%d",&n,&Q,&k);
	for(int i=1;i<=n;i++) scanf("%lld",&v[i]);
	for(int i=1;i<n;i++){
		scanf("%d%d",&x,&y);
		a[x][y]=1;
		a[y][x]=1;
		mem[x][y]=v[x]+v[y];
		mem[y][x]=v[x]+v[y];
	}
	suan_yi_suan_zui_duan_lu();
	abc();
	for(int i=1;i<=Q;i++){
		scanf("%d%d",&x,&y);
		printf("%lld\n",mem[x][y]); 
	}
	
	return 0;
}
/*
7 3 3
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7
4 7
5 6
1 2
*/

