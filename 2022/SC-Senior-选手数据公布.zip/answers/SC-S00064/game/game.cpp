#include<bits/stdc++.h>
using namespace std;
int n,m,q,a[100001],b[100001],teli1=1,teli2=1,l1[100001],r1[100001],l2[100001],r2[100001];
int qmaxa[100001],qmina[100001],qmaxb[100001],qminb[100001];
long long int ans;
void qz(){
	qmina[0]=0x3f3f3f3f;
	qminb[0]=0x3f3f3f3f;
	for(int i=1;i<=n;i++){
		qmaxa[i]=max(qmaxa[i-1],a[i]);
		qmina[i]=min(qmina[i-1],a[i]);
		qmaxb[i]=max(qmaxb[i-1],b[i]);
		qminb[i]=min(qminb[i-1],b[i]);
	}
	return ;
}
int zhao_max(int l,int r,int x[],int qmax[]){
	if(qmax[l]!=qmax[r]) return qmax[r];
	else{
		int max_m=0;
		for(int j=l;j<=r;j++) max_m=max(max_m,x[j]);
		return max_m;
	}
}
int zhao_min(int l,int r,int x[],int qmin[]){
	if(qmin[l]!=qmin[r]) return qmin[r];
	else{
		int min_m=0x3f3f3f3f;
		for(int j=l;j<=r;j++) min_m=min(min_m,x[j]);
		return min_m;
	}
}
void xuanze1(){
	for(int i=1;i<=q;i++){
		ans=1;
		ans*=zhao_max(l1[i],r1[i],a,qmaxa);
		ans*=zhao_min(l2[i],r2[i],b,qminb);
		printf("%d\n",ans);
	}
}
void xuanze2(){
	for(int i=1;i<=q;i++){
		ans=1;
		if(l1[i]==r1[i]){
			ans*=a[l1[i]];
			if(a[l1[i]]<0){
				ans*=zhao_max(l2[i],r2[i],b,qmaxb);
			}else if(a[l1[i]]==0){
				printf("0");continue;
			}else if(a[l1[i]]>0){
				ans*=zhao_min(l2[i],r2[i],b,qminb);
			}
		}else if(l2[i]==r2[i]){
			ans*=b[l2[i]];
			if(b[l2[i]]<0){
				ans*=zhao_min(l1[i],r1[i],a,qmina);
			}else if(b[l2[i]]==0){
				printf("0");
				continue;
			}else if(b[l2[i]]>0){
				ans*=zhao_max(l1[i],r1[i],a,qmaxa);
			}
		}
		printf("%lld\n",ans);
	}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		if(a[i]<0)teli1=0;
	}
	for(int i=1;i<=m;i++){
		scanf("%d",&b[i]);
		if(b[i]<0)teli1=0;
	}
	for(int i=1;i<=q;i++){
		scanf("%d%d%d%d",&l1[i],&r1[i],&l2[i],&r2[i]);
		if(l1[i]!=r1[i]&&l2[i]!=r2[i]){
			teli2=0;
			cout<<i<<endl;
		}
			
	}
	qz();
	if(teli1==1){
		xuanze1();
	}else if(teli2==1){
		xuanze2();
	}
	return 0;
} 
/*

*/
