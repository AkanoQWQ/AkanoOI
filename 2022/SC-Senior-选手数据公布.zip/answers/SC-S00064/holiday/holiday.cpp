#include<bits/stdc++.h>
using namespace std;
int n,m,k,x,y;
int a[2510][2510];
long long int mem[2510][2510],valu[2510],ans=0;
int flag[2510];
void key1_if_k_is_0(int now,int js,long long int value){
	if (js>5||(js>0&&js<5&&now==1)) return ;
	if(mem[now][js]>=value&&(now!=1||js!=0)) return ;
	else mem[now][js]=value;
	for(int i=1;i<=n;i++){
		if(a[now][i]<=k+1&&a[now][i]!=0&&flag[i]==0){
			flag[i]=1;
			key1_if_k_is_0(i,js+1,value+valu[i]);
			flag[i]=0;
		}
	}
	return ;
}
void suan_yi_suan_zui_duan_lu(){
	for(int mid=1;mid<=n;mid++){
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				if(a[i][mid]!=0&&a[mid][j]!=0){
					if(a[i][j]==0)a[i][j]=a[i][mid]+a[mid][j];
					else a[i][j]=min(a[i][j],a[i][mid]+a[mid][j]);
					a[j][i]=a[i][j];
				}
			}
		}
	}
} 
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	memset(flag,0,sizeof(flag));
	memset(a,0,sizeof(a));
	memset(mem,0,sizeof(mem));
	scanf("%d%d%d",&n,&m,&k);
	valu[1]=0; 
	for(int i=2;i<=n;i++) scanf("%lld",&valu[i]);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&x,&y);
		a[x][y]=1;
		a[y][x]=1;
	}
	if(k==0){
		key1_if_k_is_0(1,0,0);
	}else{
		suan_yi_suan_zui_duan_lu();
		key1_if_k_is_0(1,0,0);
	}
	printf("%lld",mem[1][5]);
	return 0;
}

