#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=1e5+10;
int n,m,q,k,lg[N],a,b,lc;
int mo[N][20],dep[N],cnt[N];
int h[N],ne[N<<1],e[N<<1],idx;
ll v[N],ans[N];
void add(int a,int b)
{
    e[++idx]=b;
    ne[idx]=h[a];
    h[a]=idx;
}
void tolca(int x,int fa)
{
    dep[x]=dep[fa]+1;
    mo[x][0]=fa;
    for(int i=0;(1<<i)<n;i++)
        mo[x][i+1]=mo[mo[x][i]][i];
    for(int i=h[x];i;i=ne[i])
    if(e[i]!=fa)
        tolca(e[i],x);
}
int lca(int a,int b)
{
    if(dep[b]<dep[a]) swap(a,b);//b deeper
    while(dep[b]>dep[a])
        b=mo[b][lg[dep[b]-dep[a]]];
    if(a==b) return a;
    for(int i=lg[n];i>=0;i--)
    if(mo[a][i]!=mo[b][i])
        a=mo[a][i],b=mo[b][i];
    return mo[a][0];
}
int main()
{
    freopen("transmit.in","r",stdin);
    freopen("transmit.out","w",stdout);
    scanf("%d%d%d",&n,&q,&k);
    for(int i=1;i<=n;i++)
        scanf("%lld",&v[i]);
    for(int i=1;i<n;i++)
    {
        scanf("%d%d",&a,&b);
        add(a,b),add(b,a);
    }
    for(int i=2;i<=n;i++)
        lg[i]=lg[i/2]+1;
    tolca(1,0);
    while(q--)
    {
        scanf("%d%d",&a,&b);
        int f=lca(a,b);
        lc=0;
        if(dep[b]<dep[a]) swap(a,b);//b deeper
        while(b!=f)
        {
            cnt[++lc]=b;
            b=mo[b][0];
        }
        cnt[++lc]=f;
        int las=dep[a]-dep[f];
        lc+=las;
        for(int i=0;i<las;i++)
        {
            cnt[lc-i]=a;
            a=mo[a][0];
        }
        ans[1]=v[cnt[1]];
        for(int i=2;i<=lc;i++)
        {
            ans[i]=2e12;
            for(int j=1;j<=k&&i>j;j++)
            if(ans[i-j]+v[cnt[i]]<ans[i])
                ans[i]=ans[i-j]+v[cnt[i]];
        }
        printf("%lld\n",ans[lc]);
    }
    return 0;
}
/*
10 10 3
835701672 912572995 368308854 156367225 251245604 788978650 385396264 960190423 51944511 479806606
2 1
3 2
4 2
5 3
6 3
7 2
8 7
9 1
10 9

10 5
*/
