#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=2510,M=2e4+10,N2=6250010;
int  n,m,k;
int a,b,ne[N][2];
ll ans,v[N];
bool vis[N];
int h1[N],ne1[M],e1[M],idx1;
void add1(int a,int b)
{
    e1[++idx1]=b;
    ne1[idx1]=h1[a];
    h1[a]=idx1;
}
int h2[N],ne2[N2],e2[N2],idx2;
void add2(int a,int b)
{
    e2[++idx2]=b;
    ne2[idx2]=h2[a];
    h2[a]=idx2;
}
int Q[N],st,ed,S[N];
void Get_map(int now)
{
    st=1,ed=1;
    Q[st]=now,S[st]=-1;
    while(st<=ed)
    {
        for(int i=h1[Q[st]];i;i=ne1[i])
        if(!vis[e1[i]])
        {
            int y=e1[i],kk=S[st]+1;
            vis[y]=1;
            if(kk<k)
                S[++ed]=kk,Q[ed]=y;
        }
        st++;
    }
}
void Ans(int x,int y,int s1,int s2,int d1,int d2)
{
    int fi=d1,se=s1;
    if(d1!=s1)
    {
        if(d1==x)
        {
            if(d2!=0) fi=d2;
            else return ;
        }
        if(s1==y)
        {
            if(s2!=0) se=s2;
            else return ;
        }
    }
    else if(d1==s1)
    {
        if((d2==x||d2==0)&&(s2==y||s2==0)) return ;
        else if(d2==x||d2==0) se=s2;
        else if(s2==y||s2==0) se=d2;
        else if(v[d2]>v[s2]) se=d2;
        else se=s2;
    }
    ans=max(ans,v[x]+v[y]+v[fi]+v[se]);
}
int main(){
    freopen("holiday.in","r",stdin);
    freopen("holiday.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    for(int i=2;i<=n;i++)
        scanf("%lld",&v[i]);
    for(int i=1;i<=m;i++)
    {
        scanf("%d%d",&a,&b);
        add1(a,b),add1(b,a);
    }

    for(int i=n;i>1;i--)
    {
        Get_map(i);
        for(int j=2;j<=n;j++)
        if(vis[j])
        {
            if(i!=j) add2(i,j);
            vis[j]=0;
        }
    }
    Get_map(1);
    //1
    for(int x=2;x<=n;x++)
    if(vis[x]){
       // printf("%d: ",x);
        for(int i=h2[x];i;i=ne2[i])
        {
            int y=e2[i];
            if(y==1) continue;
         //   printf("%d ",y);
            if(v[x]>=v[ne[y][0]])
                ne[y][1]=ne[y][0],ne[y][0]=x;
            else if(v[x]>v[ne[y][1]])
                ne[y][1]=x;
        }
      //  printf("\n");
    }
    //2
    for(int x=2;x<=n;x++)
    if(ne[x][0])
    {
        int s1=ne[x][0],s2=ne[x][1];
        for(int i=h2[x];i;i=ne2[i])
        {
            int y=e2[i];
            if(ne[y][0]==0||y==1) continue;
            int d1=ne[y][0],d2=ne[y][1];
            Ans(x,y,s1,s2,d1,d2);
            }
    }
    printf("%lld",ans);
    return 0;
}
