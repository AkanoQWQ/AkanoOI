#include<cstdio>
#include<cmath>
#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;
int n,m,k,x,y,max_js,fs[2505],zd[2505][2505],zdjs[2505],jq[5];
bool zd_[2505][2505];
void zdlr(int jcd,int zzjcd,int k1){
	if(k1<0) return ;
	for(int i=1;i<=zdjs[zzjcd];i++){
		zd_[jcd][zd[zzjcd][i]]=1;
		zdlr(jcd,zd[zzjcd][i],k1-1);
	}
}
bool pd(int jcd_,int jqs){
	for(int i=1;i<=jqs;i++){
		if(jcd_==jq[i]){
			return 0;
		}
	}
	return 1;
}
void xz(int szd,int fs_,int jqs){
	if(jqs==4){
		if(zd_[szd][1]){
			if(fs_>max_js){
				max_js=fs_;
			}
		}
		return ;
	}
	for(int i=2;i<=n;i++){
		if(pd(i,jqs)){
			if(zd_[szd][i]){
				jq[jqs+1]=i;
				xz(i,fs_+fs[i],jqs+1);
			}
		}
	}
	return ;
}
int main(){
	freopen("holiday1.in","r",stdin);
	freopen("holiday1.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++) cin>>fs[i];
	for(int i=1;i<n;i++){
		cin>>x>>y;
		zd[x][zdjs[x]]=y;
		zd[y][zdjs[y]]=x;
	}
	for(int i=1;i<=n;i++){
		zdlr(i,i,k);
	}
	xz(1,0,0);
	
	cout<<max_js;
	
	return 0;
}
