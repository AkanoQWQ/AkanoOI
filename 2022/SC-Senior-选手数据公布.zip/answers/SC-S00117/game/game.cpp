#include<cstdio>
#include<cmath>
#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;
long long n,m,q,l1,r1,l2,r2,a[100005],b[100005],js1,js2,max_js;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=1;i<=m;i++) cin>>b[i];
	for(int i=1;i<=q;i++){
		cin>>l1>>r1>>l2>>r2;
		js2=a[l1]*a[l2];
		for(int k=l2;k<=r2;k++){
			js1=a[l1]*b[k];
			if(js1<js2) js2=js1;
		}
		max_js=js2;
		for(int j=l1+1;j<=r1;j++){
			js2=a[j]*b[l2];
			for(int k=l2+1;k<=r2;k++){
				js1=a[j]*b[k];
				if(js1<js2) js2=js1;
			}
			if(js2>max_js) max_js=js2;
		}
		cout<<max_js<<endl;
	}
	return 0;
}
