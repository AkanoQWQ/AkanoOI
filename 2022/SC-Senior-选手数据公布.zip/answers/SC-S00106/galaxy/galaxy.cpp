#include<bits/stdc++.h>
#define MAXN 500010
using namespace std;
int read()
{
    int x=0,f=1;
    char c=getchar();
    while(c<'0'||c>'9')
    {
        if(c=='-')f=-1;
        c=getchar();
    }
    while(c>='0'&&c<='9')
    {
        x=(x<<1)+(x<<3)+(c^48);
        c=getchar();
    }
    return x*f;
}
void write(int x)
{
    if(x<0)putchar('-'),x=-x;
    if(x>9)write(x/10);
    putchar(x%10+'0');
    return;
}
int n,m,q,x,y,op;
int head[MAXN],tot=0;
struct edge
{
    int to,nxt,state;
}ed[MAXN<<1];
void add(int u,int v)
{
    ed[++tot].to=v;
    ed[tot].nxt=head[u];
    ed[tot].state=1;
    head[u]=tot;
    return;
}
int cutp[MAXN];
bool flag;
void cut(int xx,int yy)
{
    for(int i=head[xx];i;i=ed[i].nxt)
    {
        if(ed[i].to==yy){ed[i].state=0;break;}
    }
}
void cutall(int xx)
{
    cutp[xx]=1;
}
void fix(int xx,int yy)
{
    for(int i=head[xx];i;i=ed[i].nxt)
    {
        if(ed[i].to==yy){ed[i].state=1;break;}
    }
}
void fixall(int xx)
{
    cutp[xx]=0;
}
bool check_chuan()
{
    for(int i=1;i<=n;i++)
    {
        int now=0;
        for(int j=head[i];j;j=ed[j].nxt)
            if((ed[j].state)&&(!cutp[ed[j].to]))now++;
        if(now!=1)return false;
    }
    return true;
}
int vis[MAXN]={0};
void dfs(int st)
{
    vis[st]=1;
    for(int i=head[st];i;i=ed[i].nxt)
    {
        int v=ed[i].to;
        if((!ed[i].state)||(!cutp[v]))continue;
        if(vis[v])flag=1;
        vis[v]=1;
        dfs(v);
    }
}
bool check_fan()
{
    flag=0;
    memset(vis,0,sizeof(vis));
    for(int i=1;i<=n;i++)
        if(!vis[i])
            dfs(i);
    return flag;
}
int main()
{
    freopen("galaxy.in","r",stdin);
    freopen("galaxy.out","w",stdout);
    n=read();
    m=read();
    for(int i=1;i<=m;i++)
    {
        x=read();
        y=read();
        add(x,y);
    }
    q=read();
    while(q--)
    {
        op=read();
        if(op==1)
        {
            x=read();
            y=read();
            cut(x,y);
        }
        else if(op==2)
        {
            x=read();
            cutall(x);
        }
        else if(op==3)
        {
            x=read();
            y=read();
            fix(x,y);
        }
        else if(op==4)
        {
            x=read();
            fixall(x);
        }
        //cout<<check_chuan()<<' '<<check_fan()<<endl;
        if(check_chuan()&&check_fan())puts("YES");
        else puts("NO");
    }
    return 0;
}
/*

*/
