#include<bits/stdc++.h>
#define int long long
#define INF 0x7ffffffffffffff
#define MAXN 200010
using namespace std;
int read()
{
    int x=0,f=1;
    char c=getchar();
    while(c<'0'||c>'9')
    {
        if(c=='-')f=-1;
        c=getchar();
    }
    while(c>='0'&&c<='9')
    {
        x=(x<<1)+(x<<3)+(c^48);
        c=getchar();
    }
    return x*f;
}
void write(int x)
{
    if(x<0)putchar('-'),x=-x;
    if(x>9)write(x/10);
    putchar(x%10+'0');
    return;
}
int n,q,k,a[MAXN],x,y,ans;
int head[MAXN],tot=0;
struct edge
{
    int to,nxt;
}ed[MAXN<<1];
void add(int u,int v)
{
    ed[++tot].to=v;
    ed[tot].nxt=head[u];
    head[u]=tot;
    return;
}
int dep[MAXN],sum[MAXN];
int fa[MAXN][20];
void dfs(int st,int fat,int de,int su)
{
    dep[st]=de;
    sum[st]=su;
    fa[st][0]=fat;
    for(int i=1;i<=19;i++)
        fa[st][i]=fa[fa[st][i-1]][i-1];
    for(int i=head[st];i;i=ed[i].nxt)
    {
        int v=ed[i].to;
        if(v==fat)continue;
        dfs(v,st,de+1,su+a[v]);
    }
}
int lca(int xx,int yy)
{
    if(dep[xx]<dep[yy])xx^=yy^=xx^=yy;
    for(int i=19;i>=0;i--)
    {
        if(dep[fa[xx][i]]>=dep[yy])xx=fa[xx][i];
    }
    if(xx==yy)return xx;
    for(int i=19;i>=0;i--)
    {
        if(fa[xx][i]!=fa[yy][i])xx=fa[xx][i],yy=fa[yy][i];
    }
    return fa[xx][0];
}
void dfs2(int st,int fat,int step,int tmp)
{
    if(st==y){ans=min(ans,tmp);return;}
    for(int i=head[st];i;i=ed[i].nxt)
    {
        int v=ed[i].to;
        if(v==fat)continue;
        if(step<k-1&&v!=y)dfs2(v,st,step+1,tmp);
        dfs2(v,st,0,tmp+a[v]);
    }
}
signed main()
{
    freopen("transmit.in","r",stdin);
    freopen("transmit.out","w",stdout);
    n=read();
    q=read();
    k=read();
    for(int i=1;i<=n;i++)
        a[i]=read();
    for(int i=1;i<n;i++)
    {
        x=read();
        y=read();
        add(x,y);
        add(y,x);
    }
    dfs(1,0,1,a[1]);
    while(q--)
    {
        x=read();
        y=read();
        if(k==1)
        {
            int lc=lca(x,y);
            write(sum[x]+sum[y]-2*sum[fa[lc][0]]-a[lc]);
            puts("");
        }
        else
        {
            ans=INF;
            dfs2(x,x,0,a[x]);
            write(ans);
            puts("");
        }
    }
    return 0;
}
/*
7 3 3
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7

7 3 1
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7
*/
