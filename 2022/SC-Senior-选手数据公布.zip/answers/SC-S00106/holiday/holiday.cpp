#include<bits/stdc++.h>
#define MAXN 3000
#define MAXM 20010
using namespace std;
long long read()
{
    long long x=0,f=1;
    char c=getchar();
    while(c<'0'||c>'9')
    {
        if(c=='-')f=-1;
        c=getchar();
    }
    while(c>='0'&&c<='9')
    {
        x=(x<<1)+(x<<3)+(c^48);
        c=getchar();
    }
    return x*f;
}
void write(long long x)
{
    if(x<0)putchar('-'),x=-x;
    if(x>9)write(x/10);
    putchar(x%10+'0');
    return;
}
int n,m,k,x,y;
long long a[MAXN],ans=0;
int head[MAXN],tot=0;
struct edge
{
    int to,nxt;
}ed[MAXM];
void add(int u,int v)
{
    ed[++tot].to=v;
    ed[tot].nxt=head[u];
    head[u]=tot;
    return;
}
int xuan[MAXN];
/*
void display()
{
    cout<<"ans:"<<ans<<endl;
    for(int i=1;i<=n;i++)
        if(xuan[i])cout<<i<<' ';
    cout<<endl;
}*/
void dfs(int st,int now,long long tmp,int nowstep)
{
    if(nowstep>k)return;
    if(now>4)return;
    for(int i=head[st];i;i=ed[i].nxt)
    {
        int v=ed[i].to;
        if((now==4)&&(v==1))
        {
            ans=max(ans,tmp);
            continue;
        }
        dfs(v,now,tmp,nowstep+1);//��ѡ��ǰ
        if(!xuan[v])
        {
            xuan[v]=1;
            dfs(v,now+1,tmp+a[v],0);//ѡ��ǰ
            xuan[v]=0;
        }
    }
    return;
}
int main()
{
    freopen("holiday.in","r",stdin);
    freopen("holiday.out","w",stdout);
    n=read();
    m=read();
    k=read();
    for(int i=2;i<=n;i++)
        a[i]=read();
    for(int i=1;i<=m;i++)
    {
        x=read();
        y=read();
        add(x,y);
        add(y,x);
    }
    xuan[1]=1;
    dfs(1,0,0,0);
    write(ans);
    return 0;
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1

5 5 0
2 3 4 5
1 2
2 3
3 4
4 5
5 1

7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4

*/
