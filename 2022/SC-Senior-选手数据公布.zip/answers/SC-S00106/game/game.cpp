#include<bits/stdc++.h>
#define MAXN 100010
using namespace std;
int read()
{
    int x=0,f=1;
    char c=getchar();
    while(c<'0'||c>'9')
    {
        if(c=='-')f=-1;
        c=getchar();
    }
    while(c>='0'&&c<='9')
    {
        x=(x<<1)+(x<<3)+(c^48);
        c=getchar();
    }
    return x*f;
}
void write(long long x)
{
    if(x<0)putchar('-'),x=-x;
    if(x>9)write(x/10);
    putchar(x%10+'0');
    return;
}
int n,m,q,a[MAXN],b[MAXN],la,ra,lb,rb;
int sta[MAXN][20],stb[MAXN][20];
int sta2[MAXN][20],stb2[MAXN][20];
bool flag;
void sta_init()
{
    for(int i=1;i<=n;i++)
        sta[i][0]=sta2[i][0]=a[i];
    for(int i=1;i<=19;i++)
        for(int j=1;j<=n;j++)
        {
            if(j+(1<<(i-1))>n)continue;
            sta[j][i]=max(sta[j][i-1],sta[j+(1<<(i-1))][i-1]);
            sta2[j][i]=min(sta2[j][i-1],sta2[j+(1<<(i-1))][i-1]);
        }
    return;
}
void stb_init()
{
    for(int i=1;i<=m;i++)
        stb[i][0]=stb2[i][0]=b[i];
    for(int i=1;i<=19;i++)
        for(int j=1;j<=m;j++)
        {
            if(j+(1<<(i-1))>m)continue;
            stb[j][i]=min(stb[j][i-1],stb[j+(1<<(i-1))][i-1]);
            stb2[j][i]=max(stb2[j][i-1],stb2[j+(1<<(i-1))][i-1]);
        }
    return;
}
int aska(int l,int r)//max
{
    int bb=log2(r-l+1);
    return max(sta[l][bb],sta[r-(1<<bb)+1][bb]);
}
int aska2(int l,int r)//min
{
    int bb=log2(r-l+1);
    return min(sta2[l][bb],sta2[r-(1<<bb)+1][bb]);
}
int askb(int l,int r)//min
{
    int bb=log2(r-l+1);
    return min(stb[l][bb],stb[r-(1<<bb)+1][bb]);
}
int askb2(int l,int r)//max
{
    int bb=log2(r-l+1);
    return max(stb2[l][bb],stb2[r-(1<<bb)+1][bb]);
}
int main()
{
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    n=read();
    m=read();
    q=read();
    flag=1;
    for(int i=1;i<=n;i++)
        a[i]=read(),flag&=(a[i]>0);
    for(int i=1;i<=m;i++)
        b[i]=read(),flag&=(b[i]>0);
    sta_init();
    stb_init();
    //cout<<"ok"<<endl;
    while(q--)
    {
        la=read();
        ra=read();
        lb=read();
        rb=read();
        if(flag==1)
        {
            write(1ll*aska(la,ra)*askb(lb,rb));
            puts("");
        }
        else if(la==ra)
        {
            if(a[la]<0)write(1ll*a[la]*askb2(lb,rb));
            else write(1ll*a[la]*askb(lb,rb));
            puts("");
        }
        else if(lb==rb)
        {
            if(b[lb]<0)write(1ll*b[lb]*aska2(la,ra));
            else write(1ll*b[lb]*aska(la,ra));
            puts("");
        }
        else puts("0");
    }
    return 0;
}
/*

*/
