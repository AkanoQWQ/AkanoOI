#include<bits/stdc++.h>
using namespace std;
using I=int;
using UI=unsigned int;
using LL=long long;
using ULL=unsigned long long;
FILE *in(fopen("transmit.in","r")),*out(fopen("transmit.out","w"));
const UI N(200001),LN(20);
UI k;
UI V[N];
unsigned char lg[N];
UI dep[N];
UI st[N][LN];
ULL f[N][LN][3][3];
vector<UI>e[N];
void dfs(const UI u,const UI fa){
//  fprintf(stderr,"(%u %u)\n",u,fa);
  for(UI v:e[u])
    if(v!=fa){
      dep[v]=dep[u]+1;
      st[v][0]=u;
      for(UI i(0);i<k;i++)
        f[v][0][i][k-1]=V[v];
      for(UI i(1);i<k;i++)
        f[v][0][i][i-1]=0;
      for(UI i(0);i<lg[dep[v]];i++){
        st[v][i+1]=st[st[v][i]][i];
        for(UI s(0);s<k;s++)
          for(UI mid(0);mid<k;mid++)
            if(~f[v][i][s][mid])
              for(UI e(0);e<k;e++)
                if(~f[st[v][i]][i][mid][e]&&f[v][i+1][s][e]>f[v][i][s][mid]+f[st[v][i]][i][mid][e])
                  f[v][i+1][s][e]=f[v][i][s][mid]+f[st[v][i]][i][mid][e];
      }
      dfs(v,u);
    }
}
inline ULL work(UI u,UI v){
  if(dep[u]<dep[v])
    swap(u,v);
  ULL uf[3][3],vf[3][3],tf[3][3];
  memset(uf,0xff,sizeof uf);
  memset(vf,0xff,sizeof vf);
  for(UI i(0);i<k;i++)
    uf[i][i]=vf[i][i]=0;
  while(dep[u]!=dep[v]){
    UI step(lg[dep[u]-dep[v]]);
    memset(tf,0xff,sizeof tf);
    for(UI s(0);s<k;s++)
      for(UI mid(0);mid<k;mid++)
        if(~uf[s][mid])
          for(UI e(0);e<k;e++)
            if(~f[u][step][mid][e]&&tf[s][e]>uf[s][mid]+f[u][step][mid][e])
              tf[s][e]=uf[s][mid]+f[u][step][mid][e];
    memcpy(uf,tf,sizeof uf);
    u=st[u][step];
  }
  if(u==v)
    switch(k){
      case 1:
        return uf[0][0]+V[v];
      case 2:
        return min(uf[0][0],uf[0][1])+V[v];
      case 3:
        return min(uf[0][0],min(uf[0][1],uf[0][2]))+V[v];
    }
  for(UI i(lg[dep[u]]);;i=min(i-1,lg[dep[u]])){
    if(st[u][i]!=st[v][i]){
      memset(tf,0xff,sizeof tf);
      for(UI s(0);s<k;s++)
        for(UI mid(0);mid<k;mid++)
          if(~uf[s][mid])
            for(UI e(0);e<k;e++)
              if(~f[u][i][mid][e]&&tf[s][e]>uf[s][mid]+f[u][i][mid][e])
                tf[s][e]=uf[s][mid]+f[u][i][mid][e];
      memcpy(uf,tf,sizeof uf);
      memset(tf,0xff,sizeof tf);
      for(UI s(0);s<k;s++)
        for(UI mid(0);mid<k;mid++)
          if(~vf[s][mid])
            for(UI e(0);e<k;e++)
              if(~f[v][i][mid][e]&&tf[s][e]>vf[s][mid]+f[v][i][mid][e])
                tf[s][e]=vf[s][mid]+f[v][i][mid][e];
      memcpy(vf,tf,sizeof vf);
      u=st[u][i],v=st[v][i];
    }
    if(!i)
      break;
  }
  memset(tf,0xff,sizeof tf);
  for(UI s(0);s<k;s++)
    for(UI mid(0);mid<k;mid++)
      if(~uf[s][mid])
        for(UI e(0);e<k;e++)
          if(~f[u][0][mid][e]&&tf[s][e]>uf[s][mid]+f[u][0][mid][e])
            tf[s][e]=uf[s][mid]+f[u][0][mid][e];
  memcpy(uf,tf,sizeof uf);
  memset(tf,0xff,sizeof tf);
  for(UI s(0);s<k;s++)
    for(UI mid(0);mid<k;mid++)
      if(~vf[s][mid])
        for(UI e(0);e<k;e++)
          if(~f[v][0][mid][e]&&tf[s][e]>vf[s][mid]+f[v][0][mid][e])
            tf[s][e]=vf[s][mid]+f[v][0][mid][e];
  memcpy(vf,tf,sizeof vf);
  u=st[u][0];
  ULL ans(-1);
  for(UI i(0);i<k;i++)
    if(~uf[0][i])
      for(UI j(0);j<k;j++)
        if(~vf[0][j])
          ans=min(ans,uf[0][i]+vf[0][j]+((i+j<=k)?V[u]:0));
  return ans;
}
I main(){
  memset(f,0xff,sizeof f);
  UI n,q;
  fscanf(in,"%u%u%u",&n,&q,&k);
  k++;
  for(UI i(2);i<n;i++)
    lg[i]=lg[i>>1]+1;
  for(UI i(1);i<=n;i++)
    fscanf(in,"%llu",&V[i]);
  for(UI i(1);i<n;i++){
    UI u,v;
    fscanf(in,"%u%u",&u,&v);
    e[u].push_back(v),e[v].push_back(u);
  }
  dfs(1,1);
//  for(UI i(2);i<=n;i++){
//    fprintf(stderr,"%u\n",i);
//    for(UI j(0);j<=lg[dep[i]];j++){
//      for(UI l(0);l<k;l++){
//        for(UI o(0);o<k;o++)
//          fprintf(stderr," %llu",f[i][j][l][o]);
//        fputc('\n',stderr);
//      }
//      fputc('\n',stderr);
//    }
//    fputc('\n',stderr);
//  }
  while(q--){
    UI u,v;
    fscanf(in,"%u%u",&u,&v);
//    fprintf(stderr,"%u %u\n",u,v);
    fprintf(out,"%llu\n",work(u,v));
  }
  fflush(out);
  fclose(in),fclose(out);
  return 0;
}

