#include<bits/stdc++.h>
using namespace std;
using I=int;
using UI=unsigned int;
using LL=long long;
using ULL=unsigned long long;
FILE *in(fopen("holiday.in","r")),*out(fopen("holiday.out","w"));
const UI N(2501);
UI k;
vector<UI>e[N];
UI dis[N][N];
queue<UI>q;
inline void get_dis(const UI x){
  while(!q.empty())
    q.pop();
  q.push(x);
  while(!q.empty()){
    UI u(q.front());
    q.pop();
    if(dis[x][u]==k)
      return;
    for(UI v:e[u])
      if(v!=x&&!dis[x][v]){
        dis[x][v]=dis[x][u]+1;
        q.push(v);
      }
  }
}
ULL mark[N];
UI f[N],s[N],t[N];//first, second, third
ULL ans;
inline void upd(const UI u1,const UI v1,const UI u2,const UI v2){
  if(v1&&v2&&u1!=u2&&u1!=v2&&v1!=u2&&v1!=v2&&ans<mark[u1]+mark[u2]+mark[v1]+mark[v2])
    ans=mark[u1]+mark[u2]+mark[v1]+mark[v2];
}
I main(){
  UI n,m;
  fscanf(in,"%u%u%u",&n,&m,&k);
  k++;
  for(UI i(1);i<n;i++)
    fscanf(in,"%llu",&mark[i]);
  for(UI i(0);i<m;i++){
    UI u,v;
    fscanf(in,"%u%u",&u,&v);
    u--,v--;
    e[u].push_back(v),e[v].push_back(u);
  }
  get_dis(0);
  for(UI i(1);i<n;i++){
    get_dis(i);
    if(dis[0][i])
      for(UI j(1);j<n;j++)
        if(dis[i][j])
          if(mark[i]>mark[f[j]])
            t[j]=s[j],s[j]=f[j],f[j]=i;
          else if(mark[i]>mark[s[j]])
            t[j]=s[j],s[j]=i;
          else if(mark[i]>mark[t[j]])
            t[j]=i;
  }
//  for(UI i(0);i<n;i++){
//    for(UI j(0);j<n;j++)
//      fprintf(stderr,"%u ",dis[i][j]);
//    fputc('\n',stderr);
//  }
//  for(UI i(0);i<n;i++)
//      fprintf(stderr,"%u %u %u\n",f[i],s[i],t[i]);
  for(UI i(1);i<n;i++)
    for(UI j(1);j<n;j++)
      if(dis[i][j]){
        upd(i,f[i],j,f[j]);
        upd(i,f[i],j,s[j]);
        upd(i,f[i],j,t[j]);
        upd(i,s[i],j,f[j]);
        upd(i,s[i],j,s[j]);
        upd(i,s[i],j,t[j]);
        upd(i,t[i],j,f[j]);
        upd(i,t[i],j,s[j]);
        upd(i,t[i],j,t[j]);
      }
  fprintf(out,"%llu",ans);
  fflush(out);
  fclose(in),fclose(out);
  return 0;
}

