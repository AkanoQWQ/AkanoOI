#include<bits/stdc++.h>
using namespace std;
using I=int;
using UI=unsigned int;
using LL=long long;
using ULL=unsigned long long;
FILE *in(fopen("game.in","r")),*out(fopen("game.out","w"));
const UI N(100001),LN(20);
const LL MAX(INT64_MAX),MIN(INT64_MIN);
UI lg[N];
LL pmin[N][LN],pmax[N][LN],nmin[N][LN],nmax[N][LN];
LL smin[N][LN],smax[N][LN];
I main(){
  UI n,m,q;
  fscanf(in,"%u%u%u",&n,&m,&q);
  for(UI i(2);i<=max(n,m);i++)
    lg[i]=lg[i>>1]+1;
  for(UI i(1);i<=n;i++){
    LL a;
    fscanf(in,"%lld",&a);
    pmax[i][0]=MIN,pmin[i][0]=MAX,
    nmax[i][0]=MIN,nmin[i][0]=MAX;
    if(a<=0)
      nmax[i][0]=nmin[i][0]=a;
    if(a>=0)
      pmax[i][0]=pmin[i][0]=a;
    for(UI j(0);j<lg[i];j++)
      nmax[i][j+1]=max(nmax[i][j],nmax[i-(1<<j)][j]),
      nmin[i][j+1]=min(nmin[i][j],nmin[i-(1<<j)][j]),
      pmax[i][j+1]=max(pmax[i][j],pmax[i-(1<<j)][j]),
      pmin[i][j+1]=min(pmin[i][j],pmin[i-(1<<j)][j]);
  }
//  for(UI i(1);i<=n;i++){
//    fprintf(stderr,"%u\nnmin:",i);
//    for(UI j(0);j<=lg[i];j++)
//      fprintf(stderr," %lld",nmin[i][j]);
//    fputs("\nnmax:",stderr);
//    for(UI j(0);j<=lg[i];j++)
//      fprintf(stderr," %lld",nmax[i][j]);
//    fputs("\npmin:",stderr);
//    for(UI j(0);j<=lg[i];j++)
//      fprintf(stderr," %lld",pmin[i][j]);
//    fputs("\npmax:",stderr);
//    for(UI j(0);j<=lg[i];j++)
//      fprintf(stderr," %lld",pmax[i][j]);
//    fputs("\n\n",stderr);
//  }
  for(UI i(1);i<=m;i++){
    fscanf(in,"%lld",&smax[i][0]);
    smin[i][0]=smax[i][0];
    for(UI j(0);j<lg[i];j++)
      smax[i][j+1]=max(smax[i][j],smax[i-(1<<j)][j]),
      smin[i][j+1]=min(smin[i][j],smin[i-(1<<j)][j]);
  }
//  for(UI i(1);i<=m;i++){
//    fprintf(stderr,"%u\nsmin:",i);
//    for(UI j(0);j<=lg[i];j++)
//      fprintf(stderr," %lld",smin[i][j]);
//    fputs("\nsmax:",stderr);
//    for(UI j(0);j<=lg[i];j++)
//      fprintf(stderr," %lld",smax[i][j]);
//    fputs("\n\n",stderr);
//  }
  while(q--){
    UI l1,r1,l2,r2;
    fscanf(in,"%u%u%u%u",&l1,&r1,&l2,&r2);
    UI widx(lg[r1-l1]),widy(lg[r2-l2]);
    LL apmin(min(pmin[l1+(1<<widx)-1][widx],pmin[r1][widx])),apmax(max(pmax[l1+(1<<widx)-1][widx],pmax[r1][widx]));
    LL anmin(min(nmin[l1+(1<<widx)-1][widx],nmin[r1][widx])),anmax(max(nmax[l1+(1<<widx)-1][widx],nmax[r1][widx]));
    LL bmin(min(smin[l2+(1<<widy)-1][widy],smin[r2][widy])),bmax(max(smax[l2+(1<<widy)-1][widy],smax[r2][widy]));
//    fprintf(stderr,"%lld %lld %lld %lld %lld %lld\n",apmin,apmax,anmin,anmax,bmin,bmax);
    if(apmin==MAX)
      fprintf(out,"%lld\n",bmax*((bmax<0)?anmin:anmax));
    else if(anmin==MAX)
      fprintf(out,"%lld\n",bmin*((bmin<0)?apmin:apmax));
    else
      fprintf(out,"%lld\n",max(bmax*((bmax<0)?anmin:anmax),bmin*((bmin<0)?apmin:apmax)));
  }
  fflush(out);
  fclose(in),fclose(out);
  return 0;
}

