#include <bits/stdc++.h>
using namespace std;
int n, m;
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin >> n >> m;
	for (int i = 1; i <= m; i ++ )
	{
		cin >> n >> n;
	}
	cin >> n;
	for (int i = 1; i <= n; i ++ )
	{
		if (i * m + n % 3 == 1) puts("NO");
		else puts("YES");
	}
	return 0;
}
