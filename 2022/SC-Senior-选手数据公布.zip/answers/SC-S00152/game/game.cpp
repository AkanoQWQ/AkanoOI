#include <bits/stdc++.h>
#define int long long
using namespace std;

const int N = 1e5 + 10, INF = 1e9;

int n, m, Q;
int a[N], b[N];

signed main()
{
	freopen("game","r",stdin);
	freopen("game","w",stdout);
	scanf("%lld%lld%lld", &n, &m, &Q);
	for (int i = 1; i <= n; i ++ ) scanf("%lld", &a[i]);
	for (int i = 1; i <= m; i ++ ) scanf("%lld", &b[i]);
	
	for (int i = 1; i <= Q; i ++ )
	{
		int l1, r1, l2, r2;
		scanf("%lld%lld%lld%lld", &l1, &r1, &l2, &r2);
		int p = -INF, q = -INF;
		for (int j = l1; j <= r1; j ++ )	// ���� 
		{
			if (a[j] >= 0) p = max(p, a[j]);
		} 
		for (int j = l2; j <= r2; j ++ )
		{
			if (b[j] >= 0) q = max(q, b[j]);
		}
		int p2 = INF, q2 = INF;
		for (int j = l2; j <= r2; j ++ )	// ��С 
		{
			if (b[j] <= 0) q2 = min(q2, b[j]);
		}
		for (int j = l1; j <= r1; j ++ )
		{
			if (a[j] <= 0) p2 = min(p2, a[j]);
		} 
		int p3 = -INF, q3 = -INF;
		for (int j = l2; j <= r2; j ++ )	// ���� 
		{
			if (b[j] <= 0) q3 = max(q3, b[j]);
		}
		for (int j = l1; j <= r1; j ++ )
		{
			if (a[j] <= 0) p3 = max(p3, a[j]);
		}
		int p4 = INF, q4 = INF;
		for (int j = l2; j <= r2; j ++ )	// ��С 
		{
			if (b[j] >= 0) q4 = min(q4, b[j]);
		}
		for (int j = l1; j <= r1; j ++ )
		{
			if (a[j] >= 0) p4 = min(p4, a[j]);
		}
		int ans;
		if (q2 == INF) // ���� 
		{
			if (p != -INF)	// ������� 
			{
				ans = p * q4;	
			}
			else	// �� 
			{
				ans = p2 * q4;
			}
			printf("%lld\n", ans);
			continue;
		}
		else if (q == -INF)	// �Ҹ� 
		{
			if (p2 == INF)	// ���� 
			{
				ans = q2 * p4;
			}
			else	// ����ڸ� 
			{
				ans = q3 * p2; 
			}
			printf("%lld\n", ans);
			continue;
		}
		else	// �������и� 
		{
			if (p2 == INF)	// ���� 
			{
				ans = q2 * p4;
			}
			else if (p == -INF)	// �� 
			{
				ans = p2 * q4;	
			} 
			else	// �������и� 
			{
				ans = max(p4 * q2, p3 * q);	
			} 
			printf("%lld\n", ans);
			continue;
		}
	} 
	return 0;
}

/*
belief2022
6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3


*/
