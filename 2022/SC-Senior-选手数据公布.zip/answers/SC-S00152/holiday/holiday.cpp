#include <bits/stdc++.h>
#define int long long
using namespace std;

const int N = 2510, M = 2501 * 2501, INF = 1e9;

int n, m, k;
int g[N][N];
int h[N], e[M], ne[M], idx;
long long ans, w[2510];
bool st[N];
long long vis[N][5];

void add(int a, int b)
{
	e[idx] = b, ne[idx] = h[a], h[a] = idx ++;
}

void dfs(int u, int fa, int num, long long res)
{
	if (num > 5) return;
	st[u] = true;
	if (res > vis[u][num]) vis[u][num] = res;
	else return;
	for (int i = h[u]; i != -1; i = ne[i])
	{
		int j = e[i];
		if (j == fa) continue;
		if (j == 1 && num == 5)
		{
			ans = max(ans, res);
			return;
		}
		else if (st[j] == true) continue;
		dfs(j, u, num + 1, res + w[j]);
		st[j] = false;
	}
}

void dfs2(int rt, int u, int fa)
{
	for (int i = h[u]; i != -1; i = ne[i])
	{
		int j = e[i];
		if (j == fa) continue;
		if (g[rt][j] < INF && g[rt][j] < g[rt][u] + g[u][j]) continue;
		if (g[rt][u] + g[u][j] > k) return;
		if (g[rt][j] >= INF) add(rt, j);
		if (g[j][rt] >= INF) add(j, rt);
		g[rt][j] = g[j][rt] = min(g[rt][j], g[rt][u] + g[u][j]);
		if (g[rt][j] == k) return;
		dfs2(rt, j, u);
	}	
} 

signed main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin >>n>>m>>k;
	k ++;
	memset(h, -1, sizeof h);
	memset(g, 0x3f, sizeof g);
	memset(vis, -0x3f, sizeof vis);
	for (int i = 2; i <= n; i ++ ) scanf("%lld", &w[i]);
	for (int i = 1; i <= m; i ++ )
	{
		int x, y;
		scanf("%lld%lld", &x, &y);
		if (g[x][y] >= INF) add(x, y);
		if (g[y][x] >= INF) add(y, x);
		g[x][y] = g[y][x] = 1;
	}
	for (int i = 1; i <= n; i ++ )
		for (int j = 1; j <= n; j ++ )
		{
			if (g[i][j] < INF) dfs2(i, j, i);
		}
	
	dfs(1, -1, 1, 0);
	printf("%lld", ans);
	return 0;
}

/*
7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4
*/
