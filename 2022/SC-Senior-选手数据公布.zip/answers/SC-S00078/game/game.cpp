#include <bits/stdc++.h>
#define lsn(id) (id << 1)
#define rsn(id) (id << 1 | 1)
using namespace std;
const long long N = 1000,Inf = 1e18;
long long n,m,q;
long long a[N + 5],b[N + 5],c[N + 5][N + 5];
long long tr[N + 5][4 * N + 5];
void Build(long long trid,long long id,long long l,long long r) {
	if (l == r){
		tr[trid][id] = c[trid][l];
		return ;
	}
	long long mid = (l + r) >> 1;
	Build(trid,lsn(id),l,mid);
	Build(trid,rsn(id),mid + 1,r);
	tr[trid][id] = min(tr[trid][lsn(id)],tr[trid][rsn(id)]);
}
long long Query(long long trid,long long id,long long l,long long r,long long x,long long y){
	if (x <= l && y >= r) return tr[trid][id];
	long long mid = (l + r) >> 1,res = Inf;
	if (x <= mid) res = min(res,Query(trid,lsn(id),l,mid,x,y));
	if (mid < y) res = min(res,Query(trid,rsn(id),mid + 1,r,x,y));
	return res;
}
int main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	for(long long i = 1;i <= n;i++) scanf("%lld",&a[i]);
	for(long long i = 1;i <= m;i++) scanf("%lld",&b[i]);
	for(long long i = 1;i <= n;i++){
		for(long long j = 1;j <= m;j++) {
			c[i][j] = a[i] * b[j];
		}
	}
	for(long long i = 1;i <= n;i++) Build(i,1,1,m);
	for(long long i = 1,l1,r1,l2,r2;i <= q;i ++) {
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		long long ans = -Inf;
		for(long long j = l1;j <= r1;j ++) {
			ans = max(ans,Query(j,1,1,m,l2,r2));
		}
		printf("%lld\n",ans);
	}
	return 0;
}
