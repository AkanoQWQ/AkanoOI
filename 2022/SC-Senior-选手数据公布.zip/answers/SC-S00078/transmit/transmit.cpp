#include <bits/stdc++.h>
using namespace std;
const long long N = 2e5,LogN = 18,Inf = 1e18;
long long n,Q,K;
long long v[N + 5]; 
vector<long long> G[N + 5];
long long father[N + 5][LogN + 5],deep[N + 5];
long long as[N + 5],acnt,dp[N + 5];
deque<long long> q;
void dfs(long long u,long long f) {
	deep[u] = deep[f] + 1;
	father[u][0] = f;
	for(long long i = 0;i < G[u].size();i ++) {
		long long v = G[u][i];
		if (v == f)continue;
		dfs(v,u);
	}
}
long long Lca(long long a,long long b) {
	if (deep[a] < deep[b]) swap(a,b);
	for(long long k = LogN;k >= 0;k --) {
		if (deep[father[a][k]] >= deep[b]) {
			a = father[a][k];
		}
	}
	if (a == b) return a;
	for(long long k = LogN;k >= 0;k --){
		if (father[a][k] != father[b][k]) {
			a = father[a][k];
			b = father[b][k];
		}
	}
	return father[a][0];
}
long long dis(long long a,long long b){
	return deep[a] + deep[b] - 2 * deep[Lca(a,b)];
}
void redfs1(long long u,long long ed) {
	while(u != ed) {
		as[++acnt] = v[u];
		u = father[u][0];
	} 
}
void redfs2(long long u,long long ed) {
	stack<long long> q;
	while(u != ed) {
		q.push(v[u]);
		u = father[u][0];
	}
	while(!q.empty()) {
		as[++acnt] = q.top();
		q.pop();
	}
}
int main() {
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout); 
	scanf("%lld%lld%lld",&n,&Q,&K);
	for(long long i = 1;i <= n;i++)scanf("%lld",&v[i]);
	for(long long i = 1,a,b;i < n;i++) {
		scanf("%lld%lld",&a,&b);
		G[a].push_back(b);
		G[b].push_back(a); 
	}
	dfs(1,0);
	for(long long k = 1;k <= LogN;k++){
		for(long long i = 1;i <= n;i++) {
			father[i][k] = father[father[i][k - 1]][k - 1];
		}
	}
	while(Q --) {
		long long s,t;
		scanf("%lld%lld",&s,&t);
		if (dis(s,t) <= K) printf("%lld\n",v[s] + v[t]);
		else {
			acnt = 0;
			long long lca = Lca(s,t); 
			redfs1(s,lca);
			as[++acnt] = v[lca];
			redfs2(t,lca);
//			for(int i = 1;i <= acnt;i++)cout << as[i] << " ";
//			cout << endl;
			dp[1] = as[1];
			q.clear();
			q.push_back(1);
//			for(long long i = 1;i <= acnt;i++) cout << a[i] << " ";
//			cout << endl;
			for(long long i = 2;i <= acnt;i++) {
				while(!q.empty() && q.front() < i - K) q.pop_front();
				dp[i] = dp[q.front()] + as[i];
				while(!q.empty() && dp[q.back()] >= dp[i]) q.pop_back();
				q.push_back(i);
//				for(long long j = max(1ll,i - K);j < i;j ++) {
//					dp[i] = min(dp[i],dp[j] + as[i]);
//				}
			}
			printf("%lld\n",dp[acnt]);
		}
	}
	return 0;
}
