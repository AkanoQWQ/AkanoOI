#include <bits/stdc++.h>
using namespace std;
const int N = 1e3,M = 1e4;
int n,m,q;
struct Edge {
	int v,w;
	/*
		w = 0: ���ݻ�
		w = 1: ���� 
	*/
};
vector<Edge> G[N + 5];
int vis[N + 5];
int circle[N + 5];
bool dfs(int u,int id) {
//	cout << u << " ";
	if (circle[u] != -1) return circle[u];
	for(int i = 0;i < G[u].size();i ++){
		if (G[u][i].w == 0) continue;
		int v = G[u][i].v;
		if (vis[v] != id) {
			vis[v] = id;
			if (dfs(v,id)) {
				circle[u] = 1;
				return true;
			}
			vis[v] = 0;
		} else {
			circle[u] = 1;
//			cout << v << " �ڵ���뻷" << endl; 
			return true;
		}
	}
	circle[u] = 0;
	return false;
}
int main() {
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i = 1,u,v;i <= m;i++) {
		scanf("%d%d",&u,&v);
		G[u].push_back({v,1});
	}
	scanf("%d",&q);
	for(int i = 1,t,u,v;i <= q;i++) {
		scanf("%d%d",&t,&u);
		if (t == 1 || t == 3) scanf("%d",&v);
		if (t == 1){
			for(int i = 0;i < G[u].size();i ++) {
				int ev = G[u][i].v;
				if (ev == v) {
					G[u][i].w = 0;
//					cout << "ɾ����" << u << " " << v << endl; 
					break;
				} 
			}
		} else if(t == 2) {
			for(int i = 1;i <= n;i++){
				for(int j = 0;j < G[i].size();j ++) {
					if (G[i][j].v == u) {
						G[i][j].w = 0;
//						cout << "ɾ����" << i << " " << u << endl; 
					}
				}
			}
		} else if(t == 3) {
			for(int i = 0;i < G[u].size();i ++) {
				int ev = G[u][i].v;
				if (ev == v) {
					G[u][i].w = 1;
//					cout << "�ָ��� " << u << " " << v << endl; 
					break;
				} 
			}
		} else {
			for(int i = 1;i <= n;i++){
				for(int j = 0;j < G[i].size();j ++) {
					if (G[i][j].v == u) {
						G[i][j].w = 1;
//						cout << "�ָ��� " << i << " " << u << endl; 
					}
				}
			}
		}
		bool flag = true;
		for(int i = 1;i <= n;i++) {
			circle[i] = -1;
			int cnt = 0;
			for(int j = 0;j < G[i].size();j ++) {
				if (G[i][j].w == 1){
					cnt ++;
				}
			}
			if (cnt > 1) {
				puts("NO");
				flag = false;
				break;
			}
		}
		if (flag) {
			for(int i = 1;i <= n;i++) {
				vis[i] = i;
				if (!dfs(i,i)){
					flag = false;
					puts("NO");
					break;
				}
			}
		}
		if (flag) puts("YES");
	}
	return 0;
} 
