#include <bits/stdc++.h>
using namespace std;
const int N = 2500,M = 10000;
int n,m,k;
long long ans;
struct Sc{
	int sor;
	int id;
	bool operator < (const Sc& other) const{
		return sor > other.sor;
	}
}score[N + 5];
long long dp[N + 5][4];
bool canto[N + 5][N + 5],vis[N + 5];
struct Data{
	int u;
	int step;
}frt,til;
queue<Data> q; 
struct Edge{
	int u,v,w;
	int nxt;
}e[2 * M + 5];
int head[N + 5],cnt;
void adde(int u,int v,int w) {
	e[++cnt].u = u;
	e[cnt].v = v;
	e[cnt].w = w;
	e[cnt].nxt = head[u];
	head[u] = cnt;
}
void bfs(int startp) {
	for(int i = 1;i <= n;i++) vis[i] = 0;
	frt.u = startp;
	frt.step = 0;
	vis[frt.u] = 1;
	q.push(frt);
	canto[startp][startp] = 1;
	while(!q.empty()) {
		frt = q.front();q.pop();
		if (frt.step >= k + 1) continue;
		for (int i = head[frt.u];i;i = e[i].nxt){
			int v = e[i].v,w = e[i].w;
			if (!vis[v]) {
				canto[startp][v] = 1;
				til.u = v;
				til.step = frt.step + w;
				q.push(til);
			}
		}
	}
}
void dfs(int u,int step,long long sum) {
	if (step == 4) {
		if (canto[u][1]) ans = max(ans,sum);
		return ;
	}
	if (dp[u][step] >= sum) return ;
	dp[u][step] = sum;
	for(int i = 2;i <= n;i++) {
		int v = score[i].id;
		if (canto[u][v] && !vis[v]) {
			vis[v] = 1;
			dfs(v,step + 1,sum + score[i].sor);
			vis[v] = 0;
		}
	}
}
int main() {
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i = 2;i <= n;i++) scanf("%d",&score[i].sor),score[i].id = i;
	sort(score + 2,score + 1 + n);
	for(int i = 1,x,y;i <= m;i++) {
		scanf("%d%d",&x,&y);
		adde(x,y,1);
		adde(y,x,1);
	}
	for(int i = 1;i <= n;i++) bfs(i);
	memset(dp,-1,sizeof dp);
	for(int i = 1;i <= n;i++)vis[i] = 0;
	vis[1] = 1;
	dfs(1,0,0);
	printf("%lld",ans);
	return 0;
}
