#include <bits/stdc++.h>
using namespace std;
const int N=1e5+5;
int n,m,Q;
int a[N],b[N];
int st1[N][18],st2[N][18];
void st1_pre()
{
	for(int i=1;i<=n;i++) st1[i][0]=b[i];
	int t=__lg(n);
	for(int j=1;j<=t;j++)
		for(int i=1;i+(1<<(j-1))<=n;i++)
			st1[i][j]=max(st1[i][j-1],st1[i+(1<<(j-1))][j-1]);
}
void st2_pre()
{
	for(int i=1;i<=n;i++) st2[i][0]=b[i];
	int t=__lg(n);
	for(int j=1;j<=t;j++)
		for(int i=1;i+(1<<(j-1))<=n;i++)
			st2[i][j]=min(st2[i][j-1],st2[i+(1<<(j-1))][j-1]);
}
int ask1(int l,int r)
{
	int t=__lg(r-l+1);
	return max(st1[l][t],st1[r-(1<<t)+1][t]);
}
int ask2(int l,int r)
{
	int t=__lg(r-l+1); 
	return min(st2[l][t],st2[r-(1<<t)+1][t]);
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&Q);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(int i=1;i<=m;i++)
	{
		scanf("%d",&b[i]);
	}
	st1_pre(); st2_pre();
	while(Q--)
	{
		int la,lb,ra,rb;
		scanf("%d%d%d%d",&la,&ra,&lb,&rb);
		long long ans=LLONG_MIN;
		for(int i=la;i<=ra;i++)
		{
			if(a[i]>=0) ans=max(ans,1ll*a[i]*ask2(lb,rb));
			else ans=max(ans,1ll*a[i]*ask1(lb,rb));
		}
		printf("%lld\n",ans);
	}
}
//60pts
