#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N=2505,M=1e4+10;
int n,m,k,h[N],cnt,dis[N][N],b[6];
queue <pair<int,int>> qu;
bool vis[N];
ll a[N],ans;
struct Edge{
	int v,nxt;
}e[M<<1];
void add(int u,int v)
{
	e[++cnt].v=v;
	e[cnt].nxt=h[u];
	h[u]=cnt;
}
void bfs(int fr)
{
	qu.push({fr,0});
	while(!qu.empty())
	{
		int u=qu.front().first,di=qu.front().second;
		qu.pop();
		for(int i=h[u];i;i=e[i].nxt)
		{
			if(vis[e[i].v]) continue;
			vis[e[i].v]=1;
			dis[fr][e[i].v]=di+1;
			qu.push({e[i].v,di+1});
		}
	}
}
void dfs(int u,int c,ll an)
{
	if(c==5)
	{
		if(dis[1][u]<=k) ans=max(ans,an);
		return;
	}
	for(int i=2;i<=n;i++)
	{
		bool fl=0;
		for(int j=1;j<c;j++)
			if(b[j]==i) fl=1;
		if(fl) continue;
		b[c]=i;
		if(dis[u][i]<=k)
		{
			dfs(i,c+1,an+a[i]);
		}
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	k++;
	for(int i=1;i<n;i++)
	{
		scanf("%lld",&a[i+1]);
	}
	for(int i=1;i<=m;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
	}
	for(int i=1;i<=n;i++)
	{
		memset(vis,0,sizeof vis);
		vis[i]=1;
		bfs(i);
	}
	dfs(1,1,0);
	printf("%lld",ans);
}
//40pts
