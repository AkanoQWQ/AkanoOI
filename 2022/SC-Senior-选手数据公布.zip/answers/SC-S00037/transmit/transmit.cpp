#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N=2e5+5;
int n,Q,m,a[N],cnt,h[N],fr;
ll dp[2005][2005][4];
struct Edge{
	int v,nxt;
}e[N<<1];
inline void add(int u,int v)
{
	e[++cnt].v=v;
	e[cnt].nxt=h[u];
	h[u]=cnt;
}
void dfs(int fa,int u,int c)
{
	for(int i=h[u];i;i=e[i].nxt)
	{
		if(e[i].v==fa) continue;
		if(c>1)
		{
			dp[fr][e[i].v][c-1]=min(dp[fr][u][c],dp[fr][e[i].v][c-1]);
			dfs(u,e[i].v,c-1);
		}
		dp[fr][e[i].v][m]=min(dp[fr][e[i].v][m],dp[fr][u][c]+a[e[i].v]);
		dfs(u,e[i].v,m);
	}
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&Q,&m);
	if(n>2000) return puts("0"),0;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(int i=1;i<n;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
	}
	memset(dp,127,sizeof dp);
	for(int i=1;i<=n;i++)
	{
		fr=i;
		dp[i][i][m]=a[i];
		dfs(0,i,m);
		for(int j=1;j<=n;j++)
			for(int k=1;k<=m;k++)
				printf("%d %d %d %lld\n",i,j,k,dp[i][j][k]);
	}
	while(Q--)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		printf("%lld\n",dp[x][y][m]);
	}
}
