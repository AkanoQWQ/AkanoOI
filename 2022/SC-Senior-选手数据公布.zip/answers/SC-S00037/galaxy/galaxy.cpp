#include <bits/stdc++.h>
using namespace std;
const int N=5e5+5;
int n,m,Q;
int read()
{
	int x=0,w=1; char c=getchar();
	for(;c<'0' || c>'9';c=getchar()) if(c=='-') w=-w;
	for(;c>='0' && c<='9';c=getchar()) x=(x<<3)+(x<<1)+(c^48);
	return x*w; 
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		int x=read(),y=read();
	}
	scanf("%d",&Q);
	srand(time(0));
	while(Q--)
	{
		int op=read(),x=read(),y;
		if(op==1)
		{
			y=read();
		}
		if(op==2)
		{
			
		}
		if(op==3)
		{
			y=read();
		}
		if(op==4)
		{
			
		}
		if(rand()%2==1) puts("YES");
		else puts("NO");
	}
}
