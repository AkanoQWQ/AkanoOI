#include<bits/stdc++.h>
#define ll long long
#define INF 2147483647
using namespace std;
struct tree
{
	ll l,r,maxf,maxz,minf,minz;
	//bool z,f,fz;
	tree()
	{
		maxf=-INF;minf=INF;
		minz=INF;maxz=-INF;
	}
}tr[400005][2];
ll a[100005][2],b[100005];
bool flag;
ll n,m,q;ll l1,r1,l2,r2;
void build(ll id,ll l,ll r,ll o)
{
	tr[id][o].l=l;
	tr[id][o].r=r;
	if(l==r)
	{
		if(a[l][o]>0)
		{
			tr[id][o].minz=tr[id][o].maxz=a[l][o];
			//tr[id][o].z=1;
		}
		//else if(a[id]<0)
			//tr[id][o].minf=tr[id][o].maxf=a[id];
		//else
			//tr[id][o].fz=1;
		return;
	}
	ll mid=(l+r)>>1;
	build(id*2,l,mid,o);
	build(id*2+1,mid+1,r,o);
	tr[id][o].maxz=max(tr[id*2][o].maxz,tr[id*2+1][o].maxz);
	tr[id][o].minz=min(tr[id*2][o].minz,tr[id*2+1][o].minz);
}

ll get_maxz(ll id,ll l,ll r,ll o)
{
	ll nl=tr[id][o].l,nr=tr[id][o].r;
	if(l<=nl&&nr<=r)
	{
		//cout<<tr[id][o].maxz<<"???\n";
		return tr[id][o].maxz;
	}
		
	if(nr<l||nl>r)
		return -INF;
	ll ans=-INF;
	ans=max(ans,get_maxz(id*2,l,r,o));
	ans=max(ans,get_maxz(id*2+1,l,r,o));
	return ans;
}
ll get_minz(ll id,ll l,ll r,ll o)
{
	ll nl=tr[id][o].l,nr=tr[id][o].r;
	if(l<=nl&&nr<=r)
		return tr[id][o].minz;
	if(nr<l||nl>r)
		return INF;
	ll ans=INF;
	ans=min(ans,get_minz(id*2,l,r,o));
	ans=min(ans,get_minz(id*2+1,l,r,o));
	return ans;
}
int main()
{
	freopen("game.in","r",stdin);freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	
	for(ll i=1;i<=n;++i)
	{
		scanf("%lld",&a[i][0]);
	}
		
	for(ll i=1;i<=m;++i)
	{
		scanf("%lld",&a[i][1]);
	}
	
	build(1,1,n,0);
	build(1,1,m,1);
	for(ll i=1;i<=q;++i)
	{
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		printf("%lld\n",get_maxz(1,l1,r1,0)*get_minz(1,l1,r1,1));
	}
	return 0;
}
/*

#include<bits/stdc++.h>
#define ll long long
#define INF 2147483647ll
using namespace std;
struct tree
{
	ll l,r,maxf,maxz,minf,minz;
	bool z,f,fz;
	tree()
	{
		maxf=-INF;minf=INF;
		minz=INF;maxz=-INF;
	}
}tr[400005][2];
ll a[100005][2];
ll n,m,q;ll l1,r1,l2,r2;
bool z1,f1,fz1,z2,f2,fz2;
void build(ll id,ll l,ll r,ll o)
{
	tr[id][o].l=l;
	tr[id][o].r=r;
	if(l==r)
	{
		if(a[l][o]>0)
		{
			tr[id][o].minz=tr[id][o].maxz=a[l][o];
			tr[id][o].z=1;
		}
		else if(a[l][o]<0)
		{
			tr[id][o].minf=tr[id][o].maxf=a[l][o];
			tr[id][o].f=1;
		}
		else
			tr[id][o].fz=1;
		return;
	}
	ll mid=(l+r)>>1;
	build(id*2,l,mid,o);
	build(id*2+1,mid+1,r,o);
	tr[id][o].maxz=max(tr[id*2][o].maxz,tr[id*2+1][o].maxz);
	tr[id][o].maxf=max(tr[id*2][o].maxf,tr[id*2+1][o].maxf);
	tr[id][o].minf=min(tr[id*2][o].minf,tr[id*2+1][o].minf);
	tr[id][o].minz=min(tr[id*2][o].minz,tr[id*2+1][o].minz);
	tr[id][o].z=tr[id*2][o].z|tr[id*2+1][o].z;
	tr[id][o].f=tr[id*2][o].f|tr[id*2+1][o].f;
	tr[id][o].fz=tr[id*2][o].fz|tr[id*2+1][o].fz;
}
ll get_minf(ll id,ll l,ll r,ll o)
{
	ll nl=tr[id][o].l,nr=tr[id][o].r;
	if(l<=nl&&nr<=r)
		return tr[id][o].minf;
	if(nr<l||nl>r)
		return INF;
	ll ans=INF;
	ans=min(ans,get_minf(id*2,l,r,o));
	ans=min(ans,get_minf(id*2+1,l,r,o));
	return ans;
}
ll get_maxf(ll id,ll l,ll r,ll o)
{
	ll nl=tr[id][o].l,nr=tr[id][o].r;
	if(l<=nl&&nr<=r)
	{
		//cout<<tr[id][o].maxf<<"????????\n";
		return tr[id][o].maxf;
	}
		
	if(nr<l||nl>r)
		return -INF;
	ll ans=-INF;
	ans=max(ans,get_maxf(id*2,l,r,o));
	ans=max(ans,get_maxf(id*2+1,l,r,o));
	return ans;
}
ll get_maxz(ll id,ll l,ll r,ll o)
{
	ll nl=tr[id][o].l,nr=tr[id][o].r;
	if(l<=nl&&nr<=r)
		return tr[id][o].maxz;
	if(nr<l||nl>r)
		return -INF;
	ll ans=-INF;
	ans=max(ans,get_maxz(id*2,l,r,o));
	ans=max(ans,get_maxz(id*2+1,l,r,o));
	
	return ans;
}
ll get_minz(ll id,ll l,ll r,ll o)
{
	ll nl=tr[id][o].l,nr=tr[id][o].r;
	if(l<=nl&&nr<=r)
		return tr[id][o].minz;
	if(nr<l||nl>r)
		return INF;
	ll ans=INF;
	ans=min(ans,get_minz(id*2,l,r,o));
	ans=min(ans,get_minz(id*2+1,l,r,o));
	return ans;
}
bool get_z(ll id,ll l,ll r,ll o)
{
	ll nl=tr[id][o].l,nr=tr[id][o].r;
	if(l<=nl&&nr<=r)
		return tr[id][o].z;
	if(nr<l||nl>r)
		return 0;
	bool ans=0;
	ans|=get_z(id*2,l,r,o);
	ans|=get_z(id*2+1,l,r,o);
	return ans;
}
bool get_f(ll id,ll l,ll r,ll o)
{
	ll nl=tr[id][o].l,nr=tr[id][o].r;
	if(l<=nl&&nr<=r)
		return tr[id][o].f;
	if(nr<l||nl>r)
		return 0;
	bool ans=0;
	ans|=get_f(id*2,l,r,o);
	ans|=get_f(id*2+1,l,r,o);
	return ans;
}
bool get_fz(ll id,ll l,ll r,ll o)
{
	ll nl=tr[id][o].l,nr=tr[id][o].r;
	if(l<=nl&&nr<=r)
		return tr[id][o].fz;
	if(nr<l||nl>r)
		return 0;
	bool ans=0; 
	ans|=get_fz(id*2,l,r,o);
	ans|=get_fz(id*2+1,l,r,o);
	return ans;
}
int main()
{
	freopen("game.in","r",stdin);freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	
	for(ll i=1;i<=n;++i)
		scanf("%lld",&a[i][0]);
	for(ll i=1;i<=m;++i)
	scanf("%lld",&a[i][1]);
	build(1,1,n,0);
	build(1,1,m,1);
	//cout<<get_f(1,1,2,1)<<"?????????????\n";
	for(ll i=1;i<=q;++i)
	{
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		z1=f1=fz1=z2=f2=fz2=0;
		z1=get_z(1,l1,r1,0);f1=get_f(1,l1,r1,0);fz1=get_fz(1,l1,r1,0);
		z2=get_z(1,l2,r2,1);
		f2=get_f(1,l2,r2,1);
		fz2=get_fz(1,l2,r2,1);
		
		//cout<<z1<<' '<<f1<<' '<<fz1<<' '<<z2<<' '<<f2<<' '<<fz2<<'\n';
		if(z1)
		{
			if(f1)
			{
				if(fz1)
				{
					if(z2)
					{
						if(f2)
						{
							if(fz2)
								printf("%lld\n",0ll);
							else
								printf("%lld\n",0ll);
						}
						else
						{
							if(fz2)
								printf("%lld\n",0ll);
							else
								printf("%lld\n",get_maxz(1,l1,r1,0)*get_minz(1,l2,r2,1));
						}
					}
					else
					{
						if(f2)
						{
							if(fz2)
								printf("%lld\n",0ll);
							else
								printf("%lld\n",get_minf(1,l1,r1,0)*get_maxf(1,l2,r2,1));
						}
						else
								printf("%lld\n",0ll);
					}	
				}
				else
				{
				if(z2)
					{
						if(f2)
						{
							printf("%lld\n",max(get_minz(1,l1,r1,0)*get_minf(1,l2,r2,1),get_maxf(1,l1,r1,0)*get_maxz(1,l2,r2,1)));
							//printf("%lld %lld %lld %lld???\n",get_minz(1,l1,r1,0),get_minf(1,l1,r1,1),get_maxf(1,l1,r1,0),get_maxz(1,l1,r1,1));
						}
							 
						else
						{
							if(fz2)
								printf("%lld\n",0ll);
							else
							{
								printf("%lld\n",get_maxz(1,l1,r1,0)*get_minz(1,l2,r2,1));
								//printf("%lld %lld\n",get_maxz(1,l1,r1,0),get_minz(1,l2,r2,1));
							}
								
						}
					}
					else
					{
						if(f2)
						{
							if(fz2)
								printf("%lld\n",0ll);
							else
								printf("%lld\n",get_minf(1,l1,r1,0)*get_maxf(1,l2,r2,1));
						}
						else
								printf("%lld\n",0ll);
					}	
				}	
			}
			else
			{
				if(fz1)
				{
					if(z2)
					{
						if(f2)
								printf("%lld\n",0ll);
						else
						{
							if(fz2)
								printf("%lld\n",0ll);
							else
								printf("%lld\n",get_maxz(1,l1,r1,0)*get_minz(1,l2,r2,1));
						}
					}
					else
							printf("%lld\n",0ll);	
				}
				else
				{
				if(z2)
					{
						if(f2)
							printf("%lld\n",get_minz(1,l1,r1,0)*get_minf(1,l2,r2,1)); 
						else
						{
							if(fz2)
								printf("%lld\n",0ll);
							else
								printf("%lld\n",get_maxz(1,l1,r1,0)*get_minz(1,l2,r2,1));
						}
					}
					else
					{
						if(f2)
								printf("%lld\n",get_minz(1,l1,r1,0)*get_minf(1,l2,r2,1));
						else
								printf("%lld\n",0ll);
					}	
				}
			}
		}
		else if(f1)
		{
			if(fz1)
				{
					if(f2)
					{
						if(z2)
								printf("%lld\n",0ll);
						else
						{
							if(fz2)
								printf("%lld\n",0ll);
							else
								printf("%lld\n",get_minf(1,l1,r1,0)*get_maxf(1,l2,r2,1));
						}
					}
					else
							printf("%lld\n",0ll);	
				}
				else
				{
				if(f2)
					{
						if(z2)
							printf("%lld\n",get_maxf(1,l1,r1,0)*get_maxz(1,l2,r2,1)); 
						else
						{
							if(fz2)
								printf("%lld\n",0ll);
							else
								printf("%lld\n",get_minf(1,l1,r1,0)*get_maxf(1,l2,r2,1));
						}
					}
					else
					{
						if(z2)
								printf("%lld\n",get_maxf(1,l1,r1,0)*get_maxz(1,l2,r2,1));
						else
								printf("%lld\n",0ll);
					}	
				}
		}
		else
		printf("%lld\n",0ll);
	}
	return 0;
}*/
