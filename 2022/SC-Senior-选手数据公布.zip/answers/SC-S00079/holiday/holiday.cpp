#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,m,head[2505],cnt,k,a[2505],ans;
vector<ll>f[2505];
bool vis[2505];
struct ed
{
	ll v,next;
}edge[20005];
void add(ll u,ll v)
{
	edge[++cnt].v=v;
	edge[cnt].next=head[u];
	head[u]=cnt;
}
void dfs(ll rt,ll id,ll fa,ll cs)
{
	if(!cs||f[id].size()==n)
		return;
	for(ll i=head[id];i;i=edge[i].next)
	{
		ll v=edge[i].v;
		if(v==fa||vis[v])continue;
		vis[v]=1;
		f[rt].push_back(v);
		dfs(rt,v,id,cs-1);
	}
}
void dfs2(ll id,ll sum,ll cn)
{
	if(cn==4)
	{
		for(ll i=0;i<f[id].size();++i)
		{
			ll v=f[id][i];
			if(v==1)
				ans=max(ans,sum);
		}
		return;
	}
	for(ll i=0;i<f[id].size();++i)
		{
			ll v=f[id][i];
			if(vis[v])
				continue;
			vis[v]=1;
			dfs2(v,sum+a[v],cn+1);
			vis[v]=0;
		}
}
int main()
{
	freopen("holiday.in","r",stdin);freopen("holiday.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	ll u,v;
	for(ll i=2;i<=n;++i)
		scanf("%lld",&a[i]);
	for(ll i=1;i<=m;++i)
		scanf("%lld%lld",&u,&v),add(u,v),add(v,u);
	for(ll i=1;i<=n;++i)
	{
		dfs(i,i,0,k+1);memset(vis,0,sizeof(vis));
	}
		
	vis[1]=1;
	dfs2(1,0,0);
	printf("%lld",ans);
	return 0;
}
