#include<bits/stdc++.h>
#define ll long long
#define INF 2147483647
using namespace std;
ll n,k,q,head[200005],cnt,a[200005],dept[200005],f[200005][35],sum[200005],lg[200005],dp[200005];
queue<ll>p;
struct ed
{
	ll v,next;
}edge[400005];
void add(ll u,ll v)
{
	edge[++cnt].v=v;
	edge[cnt].next=head[u];
	head[u]=cnt;
}
void dfs(ll id,ll fa)
{
	for(ll i=head[id];i;i=edge[i].next)
	{
		ll v=edge[i].v;
		if(v==fa)continue;
		f[v][0]=id;
		dept[v]=dept[id]+1;
		sum[v]=sum[id]+a[v];
		for(ll j=1;j<=lg[dept[v]];++j)
			f[v][j]=f[f[v][j-1]][j-1];
		dfs(v,id);
	}
}
ll lca(ll a,ll b)
{
	if(dept[a]<dept[b])swap(a,b);
	for(ll i=lg[dept[a]];i>-1;--i)
		if(dept[f[a][i]]>=dept[b])
			a=f[a][i];
	if(a==b)
		return b;
	for(ll i=lg[dept[a]];i>=-1;--i)
		if(f[a][i]!=f[b][i])
		{
			a=f[a][i];b=f[b][i];
		}
	return f[a][0];
}
void dfs2(ll id,ll to)
{
	p.push(id);
	if(id==to)return;
	for(ll i=head[id];i;i=edge[i].next)
	{
		ll v=edge[i].v;
		if(dept[v]==dept[id]-1)
			dfs2(v,to);
	}
}
void dfs3(ll id,ll to)
{
	if(id==to)return;
	for(ll i=head[id];i;i=edge[i].next)
	{
		ll v=edge[i].v;
		if(dept[v]==dept[id]-1)
			dfs3(v,to);
	}
	p.push(id);
}
int main()
{
	freopen("transmit.in","r",stdin);freopen("transmit.out","w",stdout);
	scanf("%lld%lld%lld",&n,&q,&k);
	ll u,v;
	for(ll i=1;i<=n;++i)
		scanf("%lld",&a[i]),lg[i]=lg[i>>1]+1;
	for(ll i=1;i<n;++i)
		scanf("%lld%lld",&u,&v),add(u,v),add(v,u);
	sum[1]=a[1];
	dept[1]=1;
	dfs(1,0);
	dp[0]=INF;
	if(k==1)
	{
		ll ar,b;
		for(ll i=1;i<=q;++i)
		{
			scanf("%lld%lld",&ar,&b);
			ll c=lca(ar,b);
			printf("%lld\n",sum[ar]+sum[b]-2*sum[c]+a[c]);
		}
	}
	else if(k==2)
	{
		ll ar,b,size;
		for(ll i=1;i<=q;++i)
		{
			scanf("%lld%lld",&ar,&b);
			ll c=lca(ar,b);
			ll pd=dept[ar]+dept[b]-2*dept[c]+1;
			//if(pd<=3)
			//{
				//printf("%lld\n",sum[ar]+sum[b]-2*sum[c]+a[c]);continue;
			//}
			dfs2(ar,c);
			dfs3(b,c);
			dp[ar]=a[ar];
			p.pop();
			ll fi=ar,sc=0;
			while(!p.empty())
			{
				ll id=p.front();p.pop();
				dp[id]=INF;
				dp[id]=min(dp[fi],dp[sc])+a[id];
				sc=fi;
				fi=id;
			}
			printf("%lld\n",dp[b]);
		}
	}
	else
	{
		ll ar,b,size;
		for(ll i=1;i<=q;++i)
		{
			scanf("%lld%lld",&ar,&b);
			ll c=lca(ar,b);
			ll pd=dept[ar]+dept[b]-2*dept[c]+1;
			//if(pd<=4)
			//{
				//printf("%lld\n",sum[ar]+sum[b]-2*sum[c]+a[c]);continue;
			//}
			dfs2(ar,c);
			dfs3(b,c);
			dp[ar]=a[ar];
			p.pop();
			ll fi=ar,sc=0,td=0;
			while(!p.empty())
			{
				ll id=p.front();p.pop();
				dp[id]=INF;
				dp[id]=min(dp[fi],min(dp[sc],dp[td]))+a[id];
				td=sc;
				sc=fi;
				fi=id;
			}
			printf("%lld\n",dp[b]);
		}
	}
	return 0;
}
