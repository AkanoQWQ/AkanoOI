#include<bits/stdc++.h>
#define ll long long
using namespace std;
int read(){
	int s=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		s=(s<<1)+(s<<3)+(ch^48);
		ch=getchar();
	}
	return s*f;
}
ll readll(){
	ll s=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		s=(s<<1)+(s<<3)+(ch^48);
		ch=getchar();
	}
	return s*f;
}
int n,m,k;
ll a[2505];
int head[2505],ver[20005],nxt[20005];
int tot;
void add(int x,int y){
	ver[++tot]=y;
	nxt[tot]=head[x],head[x]=tot;
	return;
}
int dist[2505][2505];
struct node{
	int x,y;
	bool operator < (const node &w) const{
		return y>w.y;
	}
}tmp;
priority_queue <node> q;
bool vis[2505];
void dijkstra(int s){
	memset(vis,0,sizeof(vis));
	dist[s][s]=0;
	q.push((node){s,0});
	while(!q.empty()){
		tmp=q.top();
		q.pop();
		int x=tmp.x;
		if(vis[x]) continue;
		vis[x]=1;
		for(int i=head[x];i;i=nxt[i]){
			int y=ver[i];
			if(dist[s][y]>dist[s][x]+1){
				dist[s][y]=dist[s][x]+1;
				if(!vis[y]) q.push((node){y,dist[s][y]});
			}
		}
	}
	for(int i=1;i<=n;++i){
		if(i==s) continue;
		--dist[s][i];
	}
	return;
}
ll mx[2505][4];
int fr[2505][4];

ll res,ans;

int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;++i){
		a[i]=readll();
	}
	for(int i=1;i<=m;++i){
		int x,y;
		x=read(),y=read();
		add(x,y);
		add(y,x);
	}
	
	memset(dist,0x3f,sizeof(dist));
	for(int i=1;i<=n;++i){
		dijkstra(i);
	}
	
	for(int i=2;i<=n;++i){
		if(dist[1][i]>k) continue;
		for(int j=2;j<=n;++j){
			if(i==j||dist[i][j]>k) continue;
			if(a[i]+a[j]>=mx[j][1]){
				mx[j][3]=mx[j][2];
				fr[j][3]=fr[j][2];
				
				mx[j][2]=mx[j][1];
				fr[j][2]=fr[j][1];
				
				mx[j][1]=a[i]+a[j];
				fr[j][1]=i;
			}
			else if(a[i]+a[j]>=mx[j][2]){
				mx[j][3]=mx[j][2];
				fr[j][3]=fr[j][2];
				
				mx[j][2]=a[i]+a[j];
				fr[j][2]=i;
			}
			else if(a[i]+a[j]>=mx[j][3]){
				mx[j][3]=a[i]+a[j];
				fr[j][3]=i;
			}
		}
	}
	
//	for(int i=2;i<=n;++i){
//		cout<<i<<":"<<mx[i]<<" "<<fr1[i]<<"--"<<se[i]<<" "<<fr2[i]<<endl;
//	}
	
	for(int i=2;i<=n;++i){
		for(int j=2;j<=n;++j){
			if(i==j||dist[i][j]>k) continue;
			res=0;
			
			for(int u=1;u<=3;++u){
				for(int v=1;v<=3;++v){
					if(fr[i][u]==j||fr[i][u]==fr[j][v]||fr[j][v]==i) continue;
					res=max(res,mx[i][u]+mx[j][v]);
					break;
				}
			}
			
			ans=max(ans,res);
		}
	}
	
	cout<<ans;
	return 0;
}
