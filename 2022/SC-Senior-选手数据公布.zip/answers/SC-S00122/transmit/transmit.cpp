#include<bits/stdc++.h>
#define ll long long
using namespace std;
int read(){
	int s=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		s=(s<<1)+(s<<3)+(ch^48);
		ch=getchar();
	}
	return s*f;
}
void write_(ll x){
	if(x<0){
		putchar('-');
		x=-x;
	}
	if(x>9) write_(x/10);
	putchar((x%10)^48);
	return;
}
void write(ll x){
	write_(x);
	puts("");
	return;
}
int n,Q,k;
int head[200005],ver[400005],nxt[400005];
int tot;
void add(int x,int y){
	ver[++tot]=y;
	nxt[tot]=head[x],head[x]=tot;
	return;
}
int v[200005];
int dep[200005];
ll dist[200005];
int an[200005][20];
ll minn[200005];
void dfs(int x,int fa){
	dep[x]=dep[fa]+1;
	dist[x]=dist[fa]+1ll*v[x];
	minn[x]=1e18;
	an[x][0]=fa;
	for(int i=1;i<=19;++i) an[x][i]=an[an[x][i-1]][i-1];
	for(int i=head[x];i;i=nxt[i]){
		int y=ver[i];
		if(y==fa) continue;
		dfs(y,x);
		minn[x]=min(minn[x],1ll*v[y]);
	}
	return;
}
int getlca(int x,int y){
	if(dep[x]<dep[y]) swap(x,y);
	for(int i=19;i>=0;--i){
		if(dep[an[x][i]]>=dep[y]) x=an[x][i];
	}
	if(x==y) return x;
	for(int i=19;i>=0;--i){
		if(an[x][i]!=an[y][i]) x=an[x][i],y=an[y][i];
	}
	return an[x][0];
}
int lca;
int s,t;
int len;
int pos[200005];
void deal(){
	int p=s;
	len=0;
	while(p!=lca){
		pos[++len]=p;
		p=an[p][0];
	}
	pos[++len]=lca;
	
	p=t;
	int ret=0;
	while(p!=lca){
		++ret;
		p=an[p][0];
	}
	
	p=t;
	int rett=0;
	while(p!=lca){
		++rett;
		pos[len+ret-rett+1]=p;
		p=an[p][0];
	}
	return;
}
int getdis(int x,int y){
	return dep[x]+dep[y]-2*dep[lca];
}
ll f[200005];
ll ff[200005];

int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>Q>>k;
	for(int i=1;i<=n;++i){
		v[i]=read();
	}
	for(int i=1;i<n;++i){
		int x,y;
		x=read(),y=read();
		add(x,y);
		add(y,x);
	}
	dfs(1,0);
	
	if(k==1){
		while(Q--){
			s=read(),t=read();
			lca=getlca(s,t);
			write(dist[s]+dist[t]-dist[lca]-dist[an[lca][0]]);
		}
		return 0;
	}
	
	if(k==2||k==3){
		while(Q--){
			s=read(),t=read();
			lca=getlca(s,t);
			deal();
			len=getdis(s,t)+1;
			for(int i=1;i<=len;++i){
//				cout<<pos[i]<<" ";
				f[i]=1e18;
				if(i==1) f[i]=v[pos[i]];
				for(int j=1;j<=k;++j){
					if(i>j) f[i]=min(f[i],f[i-j]+v[pos[i]]);
				}
			}
//			cout<<endl;
	//		for(int i=1;i<=len;++i) cout<<f[i]<<" ";
	//		cout<<endl;
			write(f[len]);
		}
		return 0;
	}
	
//	if(k==3){
//		while(Q--){
//			s=read(),t=read();
//			lca=getlca(s,t);
//			deal();
//			len=getdis(s,t)+1;
//			for(int i=1;i<=len;++i){
//				cout<<pos[i]<<" ";
//				f[i]=1e18;
//				ff[i]=1e18;
//				if(i==1) f[i]=v[pos[i]];
//				for(int j=1;j<=k;++j){
//					if(i>j) f[i]=min(f[i],f[i-j]+v[pos[i]]);
//				}
//				for(int j=1;j<=k-1;++j){
//					if(i>j) f[i]=min(f[i],ff[i-j]+v[pos[i]]);
//				}
//				for(int j=1;j<=k-1;++j){
//					if(i>j) ff[i]=min(ff[i],f[i-j]+minn[i]);
//				}
//			}
//			cout<<endl;
//			for(int i=1;i<=len;++i) cout<<f[i]<<" ";
//			cout<<endl;
//			for(int i=1;i<=len;++i) cout<<ff[i]<<" ";
//			cout<<endl;
//			write(f[len]);
//		}
//	}
//	
	
	return 0;
}
/*
7 3 1
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7
4 7
5 6
1 2



*/
