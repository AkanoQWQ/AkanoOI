#include<bits/stdc++.h>
using namespace std;
int read(){
	int s=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		s=(s<<1)+(s<<3)+(ch^48);
		ch=getchar();
	}
	return s*f;
}
int n,m;
int head[500005],ver[500005],nxt[500005];
int tot;
void add(int x,int y){
	ver[++tot]=y;
	nxt[tot]=head[x],head[x]=tot;
	return;
}
int head2[500005],ver2[500005],nxt2[500005];
int tot2;
void add2(int x,int y){
	ver2[++tot2]=y;
	nxt2[tot2]=head2[x],head2[x]=tot2;
	return;
}
int Q;
bool mp[2005][2005],mp2[2005][2005];
bool g[2005],g2[2005];

bool flag;

int dfn[2005],low[2005];
int tim;
int top;
int stk[1005];
bool instk[1005];
bool huan[1005];
void tarjan(int x){
	dfn[x]=low[x]=++tim;
	stk[++top]=x;
	instk[x]=1;
	for(int i=head[x];i;i=nxt[i]){
		int y=ver[i];
		if(mp[x][y]) continue;
		if(!dfn[y]){
			tarjan(y);
			low[x]=min(low[x],low[y]);
		}
		else if(!instk[y]) low[x]=min(low[x],dfn[y]);
	}
	if(dfn[x]==low[x]){
		int y=stk[top];
		while(top>0&&x!=y){
			instk[y]=0;
			huan[y]=1;
			y=stk[--top];
		}
		instk[y]=0;
		huan[y]=1;
		--top;
	}
	return;
}

void dfs(int x){
	for(int i=head2[x];i;i=nxt2[i]){
		int y=ver2[i];
		if(mp2[x][y]) continue;
		if(!huan[y]){
			huan[y]=1;
			dfs(y);
		}
		
	}
	return;
}

int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;++i){
		int x,y;
		x=read(),y=read();
		add(x,y);
		add2(y,x);
	}
	cin>>Q;
	while(Q--){
		memset(huan,0,sizeof(huan));
		int opt;
		int x,y;
		opt=read();
		if(opt==1){
			x=read(),y=read();
			mp[x][y]=mp2[y][x]=1;
		}
		else if(opt==2){
			x=read();
			for(int i=head2[x];i;i=nxt2[i]){
				int y=ver2[i];
				mp2[x][y]=1;
				mp[y][x]=1;
			}
		}
		else if(opt==3){
			x=read(),y=read();
			g[y]=0;
			mp[x][y]=mp2[y][x]=0;
		}
		else{
			x=read();
			for(int i=head2[x];i;i=nxt2[i]){
				int y=ver2[i];
				mp2[x][y]=0;
				mp[y][x]=0;
			}
		}
		
		flag=1;
		for(int i=1;i<=n;++i){
			int cnt=0;
			for(int j=head[i];j;j=nxt[j]){
				int y=ver[j];
				if(!mp[i][y]){
					++cnt;
					if(cnt>1){
						flag=0;
						break;
					}
				}
			}
			if(cnt!=1){
				flag=0;
				break;
			}
			if(!flag) break;
		}
		if(!flag){
			puts("NO");
			continue;
		}
		top=0;
		memset(instk,0,sizeof(instk));
		memset(dfn,0,sizeof(dfn));
		tim=0;
		for(int i=1;i<=n;++i){
			if(!dfn[i]){
				tarjan(i);
			}
		}
		
		for(int i=1;i<=n;++i){
			if(huan[i]) dfs(i);
		}
		
		for(int i=1;i<=n;++i){
			if(!huan[i]){
				flag=0;
				break;
			}
		}
		if(!flag){
			puts("NO");
			continue;
		}
		
		puts("YES");
	}
	
	
	return 0;
}
