#include<bits/stdc++.h>
#define ll long long
using namespace std;
int read(){
	int s=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		s=(s<<1)+(s<<3)+(ch^48);
		ch=getchar();
	}
	return s*f;
}
void write_(ll x){
	if(x<0){
		putchar('-');
		x=-x;
	}
	if(x>9) write_(x/10);
	putchar((x%10)^48);
	return;
}
void write(ll x){
	write_(x);
	puts("");
	return;
}
int n,m,T;
ll a[100005],b[100005];

int LG[100005];

ll amx[100005][20],amn[100005][20];
ll bmx[100005][20],bmn[100005][20];

ll amxz[100005][20],amnz[100005][20];
ll amxf[100005][20],amnf[100005][20];

bool flag2=1;

ll getamxz(int l,int r){
	int len=LG[r-l+1];
	return max(amxz[l][len],amxz[r-(1<<len)+1][len]);
}
ll getamnz(int l,int r){
	int len=LG[r-l+1];
	return min(amnz[l][len],amnz[r-(1<<len)+1][len]);
}

ll getamxf(int l,int r){
	int len=LG[r-l+1];
	return max(amxf[l][len],amxf[r-(1<<len)+1][len]);
}
ll getamnf(int l,int r){
	int len=LG[r-l+1];
	return min(amnf[l][len],amnf[r-(1<<len)+1][len]);
}

ll getamx(int l,int r){
	int len=LG[r-l+1];
	return max(amx[l][len],amx[r-(1<<len)+1][len]);
}
ll getamn(int l,int r){
	int len=LG[r-l+1];
	return min(amn[l][len],amn[r-(1<<len)+1][len]);
}
ll getbmx(int l,int r){
	int len=LG[r-l+1];
	return max(bmx[l][len],bmx[r-(1<<len)+1][len]);
}
ll getbmn(int l,int r){
	int len=LG[r-l+1];
	return min(bmn[l][len],bmn[r-(1<<len)+1][len]);
}

int cnta[100005];
int cntb[100005];

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>T;
	for(int i=1;i<=n;++i){
		a[i]=read();
		if(a[i]<=0) flag2=0;
		cnta[i]=cnta[i-1]+(a[i]==0);
	}
	for(int i=1;i<=m;++i){
		b[i]=read();
		if(b[i]<=0) flag2=0;
		cntb[i]=cntb[i-1]+(b[i]==0);
	}
	
	if(n<=200&&m<=200&&T<=200){
		while(T--){
			int la,ra,lb,rb;
			la=read(),ra=read(),lb=read(),rb=read();
			ll res=-9e18;
			for(int i=la;i<=ra;++i){
				ll minn=9e18;
				for(int j=lb;j<=rb;++j){
					minn=min(minn,1ll*a[i]*b[j]);
				}
				res=max(res,minn);
			}
			cout<<res<<endl;
		}
		return 0;
	}
	
	for(int i=0;(1<<i)<=max(n,m);++i){
		LG[1<<i]=i;
	}
	for(int i=1;i<=max(n,m);++i){
		if(!LG[i]) LG[i]=LG[i-1];
	}
	
	for(int i=n;i>=1;--i){
		amx[i][0]=amn[i][0]=a[i];
		for(int j=1;j<=18;++j){
			if((i+(1<<j-1))<=n) amx[i][j]=max(amx[i][j-1],amx[i+(1<<j-1)][j-1]);
			else amx[i][j]=amx[i][j-1];
			
			if((i+(1<<j-1))<=n) amn[i][j]=min(amn[i][j-1],amn[i+(1<<j-1)][j-1]);
			else amn[i][j]=amn[i][j-1];
			
		}
		
	}
	
	for(int i=m;i>=1;--i){
		bmx[i][0]=bmn[i][0]=b[i];
		for(int j=1;j<=18;++j){
			if((i+(1<<j-1))<=m) bmx[i][j]=max(bmx[i][j-1],bmx[i+(1<<j-1)][j-1]);
			else bmx[i][j]=bmx[i][j-1];
			
			if((i+(1<<j-1))<=m) bmn[i][j]=min(bmn[i][j-1],bmn[i+(1<<j-1)][j-1]);
			else bmn[i][j]=bmn[i][j-1];
			
		}
	}
	
	//
	
	for(int i=n;i>=1;--i){
		if(a[i]>0) amxz[i][0]=amnz[i][0]=a[i];
		else amxz[i][0]=-9e18,amnz[i][0]=9e18;
		for(int j=1;j<=18;++j){
			if((i+(1<<j-1))<=n) amxz[i][j]=max(amxz[i][j-1],amxz[i+(1<<j-1)][j-1]);
			else amxz[i][j]=amxz[i][j-1];
			
			if((i+(1<<j-1))<=n) amnz[i][j]=min(amnz[i][j-1],amnz[i+(1<<j-1)][j-1]);
			else amnz[i][j]=amnz[i][j-1];
			
		}
		
	}
	
	
	//
	
	for(int i=n;i>=1;--i){
		if(a[i]<0) amxf[i][0]=amnf[i][0]=a[i];
		else amxf[i][0]=-9e18,amnf[i][0]=9e18;
		for(int j=1;j<=18;++j){
			if((i+(1<<j-1))<=n) amxf[i][j]=max(amxf[i][j-1],amxf[i+(1<<j-1)][j-1]);
			else amxf[i][j]=amxf[i][j-1];
			
			if((i+(1<<j-1))<=n) amnf[i][j]=min(amnf[i][j-1],amnf[i+(1<<j-1)][j-1]);
			else amnf[i][j]=amnf[i][j-1];
			
		}
		
	}
	
	//
	
	
	if(flag2){
		while(T--){
			int la,ra,lb,rb;
			la=read(),ra=read(),lb=read(),rb=read();
//			cout<<getamx(la,ra)<<" "<<getbmn(lb,rb)<<endl;
			ll res=getbmn(lb,rb)*getamx(la,ra);
			write(res);
		}
		return 0;
	}
	
	while(T--){
		int la,ra,lb,rb;
		la=read(),ra=read(),lb=read(),rb=read();
		
		if(la==ra){
			if(a[la]>0){
				ll res=a[la]*getbmn(lb,rb);
				write(res);
			}
			else{
				ll res=a[la]*getbmx(lb,rb);
				write(res);
			}
			continue;
		}
		else if(lb==rb){
			if(b[lb]>0){
				ll res=getamx(la,ra)*b[lb];
				write(res);
			}
			else{
				ll res=getamn(la,ra)*b[lb];
				write(res);
			}
			continue;
		}
		
		ll minnb=getbmn(lb,rb);
		ll res=-9e18;
		
		
		
		if(getamxz(la,ra)>0){
			if(minnb>0){
				res=max(res,getamxz(la,ra)*minnb);
			}
			else if(minnb<0){
				res=max(res,getamnz(la,ra)*minnb);
			}
			else res=max(res,0ll);
		}
		
		ll maxnb=getbmx(lb,rb);
		if(getamnf(la,ra)<0){
			if(maxnb>0){
				res=max(res,getamxf(la,ra)*maxnb);
			}
			else if(maxnb<0){
				res=max(res,getamnf(la,ra)*maxnb);
			}
			else res=max(res,0ll);
		}
		
		if(res>0&&cntb[rb]-cntb[lb-1]>0) res=0;
		if(res<0&&cnta[ra]-cnta[la-1]>0) res=0;
		
		
		write(res);
		
		
	}
	
	return 0;
}
