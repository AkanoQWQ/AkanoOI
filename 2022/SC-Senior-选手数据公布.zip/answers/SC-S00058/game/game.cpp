#include<bits/stdc++.h>
#define int long long 
using namespace std;
int n,m,q;
const int N=1e5+10;
int a[2][N];
struct Seg1{
	int mx,mi,zm,fm;
}tr[2][N<<2];
#define ls(x) (x<<1)
#define rs(x) (x<<1|1)
#define l0 dlp0
#define r0 dlp01
#define l1 dlp1
#define r1 dlp011
#define up kkka
#define INF pou



const int INF=1e9+1;
void up(int op,int x)
{
	tr[op][x].mx=max(tr[op][ls(x)].mx,tr[op][rs(x)].mx);
	tr[op][x].mi=min(tr[op][ls(x)].mi,tr[op][rs(x)].mi);
	tr[op][x].zm=min(tr[op][ls(x)].zm,tr[op][rs(x)].zm);
	tr[op][x].fm=max(tr[op][ls(x)].fm,tr[op][rs(x)].fm);
}
void bui(int op,int x,int l,int r)
{
	if(l==r)
	{
		tr[op][x].mx=tr[op][x].mi=a[op][l];
		if(a[op][l]>0) tr[op][x].zm=a[op][l],tr[op][x].fm=-INF;
		if(a[op][l]<0) tr[op][x].zm=INF,tr[op][x].fm=a[op][l];
		if(a[op][l]==0)tr[op][x].zm=INF,tr[op][x].fm=-INF;
		return ;
	}
	int mid=(l+r)>>1;
	bui(op,ls(x),l,mid);bui(op,rs(x),mid+1,r);
	up(op,x);
}
int askmx(int op,int x,int l,int r,int ml,int mr)
{
	if(ml<=l&&r<=mr)
	{
		return tr[op][x].mx;
	}
	int mid=(l+r)>>1;
	int ans=-INF;
	if(ml<=mid)ans=askmx(op,ls(x),l,mid,ml,mr);
	if(mr>mid)ans=max(ans,askmx(op,rs(x),mid+1,r,ml,mr));
	return ans;
}
int askmi(int op,int x,int l,int r,int ml,int mr)
{
	if(ml<=l&&r<=mr)
	{
		return tr[op][x].mi;
	}
	int mid=(l+r)>>1;
	int ans=INF;
	if(ml<=mid)ans=askmi(op,ls(x),l,mid,ml,mr);
	if(mr>mid)ans=min(ans,askmi(op,rs(x),mid+1,r,ml,mr));
	return ans;
}
int askzm(int op,int x,int l,int r,int ml,int mr)
{
	if(ml<=l&&r<=mr)
	{
		return tr[op][x].zm;
	}
	int mid=(l+r)>>1;
	int ans=INF;
	if(ml<=mid)ans=askzm(op,ls(x),l,mid,ml,mr);
	if(mr>mid)ans=min(ans,askzm(op,rs(x),mid+1,r,ml,mr));
	return ans;
}
int askfm(int op,int x,int l,int r,int ml,int mr)
{
	if(ml<=l&&r<=mr)
	{
		return tr[op][x].fm;
	}
	int mid=(l+r)>>1;
	int ans=-INF;
	if(ml<=mid)ans=askfm(op,ls(x),l,mid,ml,mr);
	if(mr>mid)ans=max(ans,askfm(op,rs(x),mid+1,r,ml,mr));
	return ans;
}
int s[2][N];
bool h0(int op,int l,int r) 
{
	if(s[op][r]-s[op][l-1]!=0)return 1;
	else return 0;
}
signed main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&a[0][i]);
		if(a[0][i]==0) s[0][i]=1;
		s[0][i]+=s[0][i-1];
	}
	for(int i=1;i<=m;i++)
	{
		scanf("%lld",&a[1][i]);
		if(a[1][i]==0) s[1][i]=1;
		s[1][i]+=s[1][i-1];
	}
	bui(0,1,1,n);bui(1,1,1,m);
	while(q--)
	{
		int l0,l1,r0,r1;
		scanf("%lld%lld%lld%lld",&l0,&r0,&l1,&r1);
		long long ans=0;
		if(askfm(0,1,1,n,l0,r0)==-INF)
		{
//			cout<<"one";
			if(askfm(1,1,1,m,l1,r1)==-INF)
				ans=askmx(0,1,1,n,l0,r0)*1ll*askmi(1,1,1,m,l1,r1);
			else
				ans=askmi(0,1,1,n,l0,r0)*1ll*askmi(1,1,1,m,l1,r1);
			if(h0(0,l0,r0))ans=max(ans,0ll);
			if(h0(1,l1,r1))ans=min(ans,0ll);
			printf("%lld\n",ans);
			continue;
		}
		if(askzm(0,1,1,n,l0,r0)==INF)
		{
//			cout<<"two";
			if(askzm(1,1,1,m,l1,r1)==INF)
				ans=askmi(0,1,1,n,l0,r0)*1ll*askmx(1,1,1,m,l1,r1);
			else
				ans=askmx(0,1,1,n,l0,r0)*1ll*askmx(1,1,1,m,l1,r1);
			if(h0(0,l0,r0))ans=max(ans,0ll);
			if(h0(1,l1,r1))ans=min(ans,0ll);
			printf("%lld\n",ans);
			continue;
		} 
//		cout<<"three";
		if(askfm(1,1,1,m,l1,r1)==-INF)
		{
			ans=askmx(0,1,1,n,l0,r0)*1ll*askmi(1,1,1,m,l1,r1);
		}else if(askzm(1,1,1,m,l1,r1)==INF){
			ans=askmi(0,1,1,n,l0,r0)*1ll*askmx(1,1,1,m,l1,r1);
		}else{
			ans=max(askzm(0,1,1,n,l0,r0)*1ll*askmi(1,1,1,m,l1,r1),askfm(0,1,1,n,l0,r0)*1ll*askmx(1,1,1,m,l1,r1));
		}
		if(h0(0,l0,r0))ans=max(ans,0ll);
		if(h0(1,l1,r1))ans=min(ans,0ll);
		printf("%lld\n",ans);
	}
	
	
	return 0;
}
