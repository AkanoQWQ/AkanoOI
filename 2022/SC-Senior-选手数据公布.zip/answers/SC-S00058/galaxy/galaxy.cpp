#include<bits/stdc++.h>
using namespace std;
int n,m;
const int N=1e3+10;
int f[N][N];
int num[N];
vector<int>in[N];
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		in[v].push_back(u);
		f[u][v]=1;
		num[u]++;
	}
	int q;cin>>q;
	while(q--)
	{
		int op,u,v;
		scanf("%d%d",&op,&u);
		if(op==1)
		{
			cin>>v;
			if(f[u][v]==0)continue;
			f[u][v]=0;
			num[u]--;
			m--;
		}
		if(op==2)
		{
			
			for(int i=0;i<in[u].size();i++)
			{
				if(f[in[u][i]][u]==1)num[in[u][i]]--,m--;
				f[in[u][i]][u]=0;
			}
		}
		if(op==3)
		{
			cin>>v;
			if(f[u][v]==1)continue;
			f[u][v]=1;
			num[u]++;
			m++;
		}
		if(op==4)
		{
			m+=in[u].size();
			for(int i=0;i<in[u].size();i++)
			{
				if(f[in[u][i]][u]==0)num[in[u][i]]++,m++;
				f[in[u][i]][u]=1;
			}
		}
		if(m!=n)
		{
			puts("NO");
		}else{
			bool o=0;
			for(int i=1;i<=n;i++)
			{
				if(num[i]!=1)
				{
					o=1;
					puts("NO");break;
				}
			}
			if(!o)
			puts("YES");
		} 
		
	}
	return 0;
}
