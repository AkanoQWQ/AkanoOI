#include<bits/stdc++.h>
using namespace std;
const int N=2510,M=1e4+10;
int dis[N][N],n,m,k;
struct ll{
	int len,a[30];
	ll(){
		memset(a,0,sizeof(a));
		len=0;
	}
};
const ll operator +(ll x,ll y)
{
	ll ans;
	int len=max(x.len,y.len)+1;
	for(int i=1;i<=len;i++)
	{
		ans.a[i]+=x.a[i]+y.a[i];
		if(ans.a[i]>=10)ans.a[i]-=10,ans.a[i+1]+=1;
	}
	if(ans.a[len]==0)len--;
	ans.len=len;
	return ans;
}
const int operator <(ll x,ll y)
{
	if(x.len!=y.len)return x.len<y.len;
	for(int i=x.len;i>=1;i--)
	{
		if(x.a[i]!=y.a[i])return x.a[i]<y.a[i];
	}
	return 0;
}
ll rev(long long x)
{
	ll ans;
	while(x)ans.a[++ans.len]=x%10,x/=10;
	return ans;
}
void out(ll x)
{
	for(int i=x.len;i>=1;i--)
	{
		printf("%d",x.a[i]);
	}
	puts("");
}



struct EDGE{
	int to,nex;
}ed[M*2];
int idx,head[N];
ll a[N];
void add(int x,int y)
{
	ed[++idx].to=y,ed[idx].nex=head[x],head[x]=idx;
}
void Add(int x,int y){add(x,y),add(y,x);}
void getdis(int st)
{
	queue<int>q;
	q.push(st);
	while(!q.empty())
	{
		int x=q.front();q.pop();
		for(int i=head[x];i;i=ed[i].nex)
		{
			int y=ed[i].to;
			if(dis[st][y])continue;
			dis[st][y]=dis[st][x]+1;
			q.push(y);
		}
	}
}	
ll dp[N][5];
struct node{
	int x,jin;
	ll sum;
	int an[4];
	node(){};
	node(int xx,int jj,ll ss,int aa[4])
	{
		x=xx,jin=jj,sum=ss,an[1]=aa[1],an[2]=aa[2],an[3]=aa[3];
	}
};
const bool operator <(const node x,const node y)
{
	return x.sum<y.sum;
}
int ze[4];
ll oo;
void bfs()
{
	priority_queue<node>q;
	q.push(node(1,0,oo,ze));
	while(!q.empty())
	{
		node now=q.top();q.pop();
		int x=now.x;
		if(dp[x][now.jin].len||now.jin>4)continue;
		dp[x][now.jin]=now.sum;
		for(int y=2;y<=n;y++)
		{
			if(dis[x][y]<=k&&y!=x)
			{
				bool ch=0;
				for(int j=1;j<=now.jin;j++)
				{
					if(now.an[j]==y)
					{
						ch=1;break;
					}	
				}
				if(ch)continue;
				now.an[now.jin+1]=y;
				q.push(node(y,now.jin+1,now.sum+a[y],now.an));
			}
		}
		
		
	}
}


int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;k++;
	for(int i=2;i<=n;i++)
	{
		long long x;
		scanf("%lld",&x);
		a[i]=rev(x);
	}
//	out(a[n]+a[n]);
	for(int i=1;i<=m;i++)
	{
		int x,y;scanf("%d%d",&x,&y);
		Add(x,y);
	}
	for(int i=1;i<=n;i++)getdis(i);
	bfs();
	ll ans=oo;
	for(int i=2;i<=n;i++)
	{
		if(dis[1][i]<=k)
		{
			if(ans<dp[i][4])ans=dp[i][4];
		}
	}
	out(ans);
	return 0;
}
