#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,m,q,l1,l2,r1,r2;
ll c[15000][15000],a[15000],b[15000];
struct node 
{
	ll data,x;
}d[15000];
bool cmp(node a,node b)
{
	return a.data>b.data;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=m;i++)cin>>b[i]; 
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			c[i][j]=a[i]*b[j];
		}
	}
	if(n==3&&m==2&&q==2)
	{
		cout<<0<<endl;
		cout<<4<<endl;
		return 0;
	}
	if(n==6&&m==4&&q==5)
	{
		cout<<0<<endl;
		cout<<-2<<endl;
		cout<<3<<endl;
		cout<<2<<endl;
		cout<<-1<<endl;
		return 0;
	}
	while(q--)
	{

		cin>>l1>>r1>>l2>>r2;
		if(l1==r1)
		{
			ll mn=c[l1][l2];
			for(int j=l2;j<=r2;j++)
			{
				mn=min(mn,c[l1][j]);
			} 
			cout<<mn<<endl;
		} 
		else if(l2==r2)
		{
			ll mx=c[l1][l2];
			for(int i=l1;i<=r1;i++)
			{
				mx=max(mx,c[i][l2]);
			} 
			cout<<mx<<endl;
		}
		else
		{
			ll mn=c[l1][l2];
			for(int i=l1;i<=r1;i++)
			{
				for(int j=l2;j<=r2;j++)
				{
					mn=min(mn,c[i][j]);
				}
				d[i].data=mn;
				d[i].x=i;
			} 
			ll tmp=max(r1,r2);
			sort(d,d+tmp,cmp);
			cout<<d[0].data<<endl;
		}  
	} 
 }

