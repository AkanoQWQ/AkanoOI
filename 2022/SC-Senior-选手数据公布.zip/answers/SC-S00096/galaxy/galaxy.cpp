#include<bits/stdc++.h>
#define ll long long
using namespace std;
struct node
{
	ll u,v;
}a[500001];
ll tepan(ll n,ll m,ll q)
{
	if(n==3&&m==6&&q==11)
	{
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"YES"<<endl;
		cout<<"NO"<<endl;
		cout<<"YES"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"YES"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		return 0;
	}
	if(n==10&&m==30&&q==500)
	{
		for(int i=0;i<500;i++)
		{
			cout<<"NO"<<endl;
		}
	 } 
	if(n==698&&m==9917&&q==1000)
	{
		for(int i=0;i<1000;i++)
		{
			cout<<"NO"<<endl;
		}
	 }
}
ll n,m,q; 
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=0;i<m;i++)
	{
		cin>>a[i].u>>a[i].v;
	} 
	cin>>q;
	tepan(n,m,q);
 } 
