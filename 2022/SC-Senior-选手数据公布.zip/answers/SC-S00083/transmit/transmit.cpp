#include<bits/stdc++.h>
#define rep(i,a,b) for(int i=(a);i<=(b);i++)
#define per(i,a,b) for(int i=(a);i>=(b);i--)
#define ll long long
#define sz(x) ((int)x.size())
using namespace std;
const int N=200005;
int n,q,k,v[N],F[N],mnv[N],d[N];
vector<int> G[N];
struct M{
	ll a[5][5];
	M(){rep(i,1,3) rep(j,1,3) a[i][j]=4e18;}
	M operator*(const M&o)const{
		M res;
		rep(i,1,k) rep(K,1,k){
			ll tmp=a[i][K];
			rep(j,1,k) res.a[i][j]=min(res.a[i][j],tmp+o.a[K][j]);
		}
		return res;
	} 
}p[N];
void dfs(int u,int fa){
	F[u]=fa,d[u]=d[fa]+1;
	for(auto v:G[u]) if(v^fa) dfs(v,u);
}
void cmin(ll&x,ll y){
	if(x>y) x=y;
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	rep(i,1,n) scanf("%d",&v[i]),mnv[i]=1e9;
	rep(i,2,n){
		int x,y;
		scanf("%d%d",&x,&y);
		mnv[x]=min(mnv[x],v[y]),mnv[y]=min(mnv[y],v[x]);
		G[x].push_back(y),G[y].push_back(x);
	}
	rep(i,1,n){
		rep(j,1,k){
			cmin(p[i].a[j][k],v[i]);
			if(j>1) cmin(p[i].a[j][j-1],0);
			if(j>=2){
				cmin(p[i].a[j][k-1],mnv[i]);
			}
		}
	}
	dfs(1,0);
	vector<int> v1,v2;
	rep(i,1,q){
		int x,y,xx;
		scanf("%d%d",&x,&y);
		if(d[x]<d[y]) swap(x,y);
		v1.clear(),v2.clear(),xx=x,x=F[x];
		while(x!=y){
			if(d[x]>=d[y]) v1.push_back(x),x=F[x];
			else v2.push_back(y),y=F[y];
		}
		v1.push_back(x);
		per(i,sz(v2)-1,0) v1.push_back(v2[i]);
//		for(auto x:v1) printf("%d ",x);
//		puts("");
		M res=p[v1[0]];
		rep(i,1,sz(v1)-1) 
			res=res*p[v1[i]];
		ll ans=4e18;
		rep(i,1,k) ans=min(ans,res.a[i][k]);
		printf("%lld\n",ans+v[xx]);
	}
}
/*
7 3 3
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7
4 7
5 6
1 2
*/
