#include<bits/stdc++.h>
#define rep(i,a,b) for(int i=(a);i<=(b);i++)
#define per(i,a,b) for(int i=(a);i>=(b);i--)
using namespace std;
const int N=1005;
int n,m,q,vis[N][N],fa[N],d[N];
vector<int> G[N];
int find(int x){
	return fa[x]==x?x:fa[x]=find(fa[x]);
}
void unionn(int x,int y){
	if(find(x)!=find(y)) fa[find(x)]=find(y);
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	rep(i,1,m){
		int x,y;
		scanf("%d%d",&x,&y);
		G[y].push_back(x),vis[x][y]=1;
	}
	scanf("%d",&q);
	rep(i,1,q){
		int t,u,v;
		scanf("%d%d",&t,&u);
		if(t==1){
			scanf("%d",&v);
			vis[u][v]=0;
		}
		if(t==2){
			for(auto v:G[u]) vis[v][u]=0;
		}
		if(t==3){
			scanf("%d",&v);
			vis[u][v]=1;
		}
		if(t==4){
			for(auto v:G[u]) vis[v][u]=1;
		}
		rep(i,1,n) fa[i]=i,d[i]=0;
		rep(i,1,n) for(auto v:G[i]) if(vis[v][i]) d[v]++,unionn(v,i);
		int fl=0;
		rep(i,1,n) if(d[i]!=1) fl=1;
		if(fl) puts("NO");
		else puts("YES"); 
	}
}
/*
3 6
2 3
2 1
1 2
1 3
3 1
3 2
11
1 3 2
1 2 3
1 1 3
1 1 2
3 1 3
3 3 2
2 3
1 3 1
3 1 3
4 2
1 3 2
*/
