#include<bits/stdc++.h>
#define rep(i,a,b) for(int i=(a);i<=(b);i++)
#define per(i,a,b) for(int i=(a);i>=(b);i--)
#define ll long long
using namespace std;
const int N=2505;
int n,m,k,dis[N],id[N][3],c[N];
ll v[N],f[N][N];
bool b[N][N];
vector<int> G[N];
void bfs(int x){
	rep(i,1,n) dis[i]=1e9;
	queue<int> q;
	dis[x]=-1,q.push(x);
	while(!q.empty()){
		int u=q.front();
		q.pop();
		for(auto v:G[u]) if(dis[v]>dis[u]+1){
			dis[v]=dis[u]+1;
			q.push(v);
		}
	}
	rep(i,1,n) if(i!=x&&dis[i]<=k) b[x][i]=1;  
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	rep(i,2,n) scanf("%lld",&v[i]);
	rep(i,1,m){
		int x,y;
		scanf("%d%d",&x,&y);
		G[x].push_back(y),G[y].push_back(x);
	}
	rep(i,1,n) bfs(i);
	rep(i,2,n) rep(j,2,n) if(b[i][j]&&b[1][i]) f[j][i]=v[i]+v[j];
	rep(i,2,n){
		id[i][0]=id[i][1]=id[i][2]=0;
		rep(j,2,n){
			if(f[i][j]>=f[i][id[i][0]]){
				id[i][2]=id[i][1],id[i][1]=id[i][0],id[i][0]=j;
			}
			else if(f[i][j]>=f[i][id[i][1]]){
				id[i][2]=id[i][1],id[i][1]=j;
			}
			else if(f[i][j]>f[i][id[i][2]]){
				id[i][2]=j;
			}
		}
	}
	ll ans=0;
	rep(i,2,n) rep(j,i+1,n) if(b[i][j]){
		rep(k,0,2) rep(l,0,2){
			if(id[i][k]==0) continue;
			if(id[j][l]==0) continue;
			c[i]++,c[j]++,c[id[i][k]]++,c[id[j][l]]++;
			int fl=0;
			if(c[i]>1||c[j]>1||c[id[i][k]]>1||c[id[j][l]]>1) fl=1;
			c[i]--,c[j]--,c[id[i][k]]--,c[id[j][l]]--;
			if(fl) continue;
			ans=max(ans,f[i][id[i][k]]+f[j][id[j][l]]);
//			printf("%d %d %d %d %lld\n",i,j,k,l,f[i][id[i][k]]+f[j][id[j][l]]);
		} 
	}
	printf("%lld\n",ans);
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1
*/
