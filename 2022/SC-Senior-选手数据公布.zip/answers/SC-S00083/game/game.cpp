#include<bits/stdc++.h>
#define rep(i,a,b) for(int i=(a);i<=(b);i++)
#define per(i,a,b) for(int i=(a);i>=(b);i--)
#define ll long long
using namespace std;
const int N=100005;
int n,m,q,a[N],b[N],lg[N],c[2][N];
struct ST1{
	int p[N][20];
	void pre(){
		rep(i,1,20) rep(j,1,n) if(j+(1<<i)-1<=n) p[j][i]=min(p[j][i-1],p[j+(1<<(i-1))][i-1]); 
	} 
	int get(int l,int r){
		int k=lg[r-l+1];
		return min(p[l][k],p[r-(1<<k)+1][k]);
	}
}mn[2][2];
struct ST2{
	int p[N][20];
	void pre(){
		rep(i,1,20) rep(j,1,n) if(j+(1<<i)-1<=n) p[j][i]=max(p[j][i-1],p[j+(1<<(i-1))][i-1]); 
	} 
	int get(int l,int r){
		int k=lg[r-l+1];
		return max(p[l][k],p[r-(1<<k)+1][k]);
	}
}mx[2][2];
vector<int> v[2];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
//	clock_t st=clock();
	scanf("%d%d%d",&n,&m,&q);
	rep(i,1,n) scanf("%d",&a[i]);
	rep(i,1,m) scanf("%d",&b[i]);
	rep(i,2,n) lg[i]=lg[i>>1]+1;
	rep(i,1,n) mn[0][0].p[i][0]=(a[i]>0?a[i]:2e9),mn[0][1].p[i][0]=(a[i]<0?a[i]:2e9);
	rep(i,1,m) mn[1][0].p[i][0]=(b[i]>0?b[i]:2e9),mn[1][1].p[i][0]=(b[i]<0?b[i]:2e9);
	rep(i,1,n) mx[0][0].p[i][0]=(a[i]>0?a[i]:-2e9),mx[0][1].p[i][0]=(a[i]<0?a[i]:-2e9);
	rep(i,1,m) mx[1][0].p[i][0]=(b[i]>0?b[i]:-2e9),mx[1][1].p[i][0]=(b[i]<0?b[i]:-2e9);
	rep(i,0,1) rep(j,0,1) mn[i][j].pre(),mx[i][j].pre();
	rep(i,1,n) c[0][i]+=c[0][i-1]+(a[i]==0);
	rep(i,1,m) c[1][i]+=c[1][i-1]+(b[i]==0);
	rep(i,1,q){
		int l[2],r[2];
		scanf("%d%d%d%d",&l[0],&r[0],&l[1],&r[1]);
		v[0].clear(),v[1].clear();
		rep(j,0,1){
			int t=mn[j][0].get(l[j],r[j]);
			if(t!=2e9) v[j].push_back(t);
			t=mn[j][1].get(l[j],r[j]);
			if(t!=2e9) v[j].push_back(t);
			t=mx[j][0].get(l[j],r[j]);
			if(t!=-2e9) v[j].push_back(t);
			t=mx[j][1].get(l[j],r[j]);
			if(t!=-2e9) v[j].push_back(t);
			if(c[j][r[j]]-c[j][l[j]-1]>0) v[j].push_back(0);
		}
		ll ans=-4e18;
		for(auto x:v[0]){
			ll tmp=4e18;
			for(auto y:v[1]) tmp=min(tmp,1ll*x*y);
			ans=max(ans,tmp);
		}
		printf("%lld\n",ans);
	} 
//	cerr<<clock()-st;
}
/*
6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3

*/
