#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	long long n,m,q,l1,r1,l2,r2;
	cin>>n>>m>>q;
	long long a[n]={},b[m]={},c[m][n]={};
	for(int i = 0;i<n;i++){
		cin>>a[i];
	}
	for(int i = 0;i<m;i++){
		cin>>b[i];
	}
	for(int i = 0;i<n;i++){
		for(int j = 0;j<m;j++){
			c[i][j]=a[i]*b[j];
		}
	}
	for(int i = 0;i<q;i++){
		cin>>l1>>r1>>l2>>r2;
		if(l1==r1){
			long long mi=1e9;
			for(int i = l2-1;i<r2;i++){
				mi=min(mi,c[l1-1][i]);
			}
			cout<<mi<<endl;
			continue;
		}
		if(l2==r2){
			long long ma=-1e9;
			for(int i = l1-1;i<r1;i++){
				ma=max(ma,c[l1-1][i]);
			}
			cout<<ma<<endl;
			continue;
		}
		long long d[r1-l1+1]={},f=0;
		for(int i = l1-1;i<r1;i++){
			long long mi=1e9;
			for(int j = l2-1;j<r2;j++){
				mi=min(mi,c[i][j]);
			}
			d[f++]=mi;
		}
		long long ma=-1e9;
		for(int i = 0;i<f;i++){
			ma=max(ma,d[i]);
		}
		cout<<ma<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

