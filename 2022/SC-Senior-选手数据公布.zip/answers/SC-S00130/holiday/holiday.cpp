#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int n,m,k;
	cin>>n>>m>>k;
	int li[n-1]={};
	bool li2[n][n]={};
	for(int i = 0;i<n-1;i++){
		cin>>li[i];
	}
	int st,en;
	for(int i = 0;i<m;i++){
		cin>>st>>en;
	}
	if(k==0 && n==5){
		cout<<li[0]+li[1]+li[2]+li[3];
	}
	
	
	
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}

