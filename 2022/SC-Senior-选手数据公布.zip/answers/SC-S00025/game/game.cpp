#include<iostream>
#define int long long
using namespace std;
const int N = 1e5 + 10;
int n,m,q;
int a[N],b[N];
void work(int l1,int r1,int l2,int r2)
{
	int tmp = -1;
	for(int i = l1; i <= r1; i++)
	{
		tmp = max(tmp,a[i]);
	}
	int cnt = 0x3f3f3f;
	for(int i = l2; i <= r2; i++)
	{
		cnt = min(cnt,b[i]);
	}
	cout << cnt * tmp << endl;
}
signed main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	std::ios::sync_with_stdio(false);
	cin >> n >> m >> q;
	for(int i = 1; i <= n; i++) cin >> a[i];
	for(int i = 1; i <= m; i++) cin >> b[i];
	while(q--)
	{
		int l1,r1,l2,r2;
		cin >> l1 >> r1 >> l2 >> r2;
		if(l1 != r1 && l2 != r2) 
		{
			work(l1,r1,l2,r2);
			continue;
		}
		if(l1 == r1) swap(l1,l2),swap(r1,r2); 
		int cnt = 0x3f3f3f3f,tmp = -1;
		for(int i = l1; i <= r1; i++)
		{
			tmp = max(tmp,a[i]);
			cnt = min(cnt,a[i]);
		}
		int opt = b[l2];
		if(opt > 0) cout << tmp * opt << endl;
		else cout << cnt * opt << endl;
	}
	
	return 0;
}
