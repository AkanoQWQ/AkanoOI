#include<iostream>
#include<queue>
#define int long long
using namespace std;
const int N = 1e3 + 10;
int n,m,k;
int head[N],tot,dis[N][N],dep[N],a[N][N];
int val[N],ans;
struct node{
	int to;
	int nxt;
}e[N * 2];
int _abs(int x)
{
	return (x > 0 ? x : -x);
}
void add(int u,int v)
{
	e[++tot] = node{v,head[u]};
	head[u] = tot;
}
void dfs(int u,int fa,int d,int w)
{
	if(d == 4)
	{
		if(a[u][1] == 1) ans = max(ans,w);
		return ;
	}
	for(int i = head[u]; i; i = e[i].nxt)
	{
		int v = e[i].to;
		if(v == fa || v == 1) continue;
		dfs(v,u,d + 1,w + val[v]);
	}
}
void dist()
{
	for(int l = 1; l <= n; l++)
	{
		for(int i = 1; i <= n; i++)
		{
			for(int j = 1; j <= n; j++)
			{
				if(i != j && j != l && l != i && !a[i][j] && dis[i][l] && dis[l][j])
				{
					dis[i][j] = min(dis[i][j],dis[i][l] + dis[l][j]);
				}
			}
		}
	}
	
	for(int l = 1; l <= n; l++)
	{
		for(int i = 1; i <= n; i++)
		{
			for(int j = 1; j <= n; j++)
			{
				if(i != j && j != l && l != i && !a[i][j] && dis[i][l] + dis[l][j] == k + 1)
				{
				     add(i,j),add(j,i),a[i][j] = a[j][i] = 1;
				}
			}
		}
	} 
}
signed main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin >> n >> m >> k;
	for(int i = 2; i <= n; i++) cin >> val[i];
	for(int i = 1; i <= n; i++)
	{
		for(int j = 1; j <= n; j++)
		{
			dis[i][j] = 0x3f3f3f3f;
		}
	}
	for(int i = 1; i <= m; i++)
	{
		int u,v;
		cin >> u >> v;
		add(u,v);
		add(v,u);
		a[u][v] = a[v][u] = 1;
		dis[u][v] = dis[v][u] = 1;
	}
	dist();
	dfs(1,0,0,0);
	cout << ans << endl;
	return 0;
}
