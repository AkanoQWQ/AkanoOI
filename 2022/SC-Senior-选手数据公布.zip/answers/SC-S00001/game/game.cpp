#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=1e3+10;
const ll inf=1e18+100;
int n,m,q;
int a[N],b[N];
ll c[N][N];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
    scanf("%d%d%d",&n,&m,&q);
    for(int i=1;i<=n;i++)
    	scanf("%d",&a[i]);
    for(int i=1;i<=m;i++)
    	scanf("%d",&b[i]);
    for(int i=1;i<=n;i++)
    	for(int j=1;j<=m;j++)
    		c[i][j]=(ll)a[i]*(ll)b[j];
	while(q--)
	{
		int l1,r1,l2,r2;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		ll maxx=-inf;
		for(int i=l1;i<=r1;i++)
		{
			ll minn=inf;
			for(int j=l2;j<=r2;j++)
			{
				minn=min(minn,c[i][j]);
			}
			maxx=max(maxx,minn);
		}
		printf("%lld\n",maxx);
	}
	return 0;
}
