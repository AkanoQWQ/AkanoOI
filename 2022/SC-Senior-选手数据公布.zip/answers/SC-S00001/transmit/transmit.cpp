#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=2e5+10;
const ll inf=1e18;
int n,qq,kk,v[N],h[N],ne[N],e[N],cnt;
int f[N][5];
int a,b;
vector<int> q;
void add(int a,int b)
{
	e[++cnt]=b,ne[cnt]=h[a],h[a]=cnt;
}
int fa[N];
void build_tree(int x)
{
	if(fa[b])  return;
	for(int i=h[x];i;i=ne[i])
	{
		int y=e[i];
		if(y==fa[x])  continue;
		fa[y]=x;
		build_tree(y);
	}
	return;
}
void qwe()
{
	q.clear();
	int z=b;
	q.push_back(-1);
	q.push_back(z);
	do{
		z=fa[z];
		q.push_back(z);
	}while(z!=a);
	return;
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
    scanf("%d%d%d",&n,&qq,&kk);
    for(int i=1;i<=n;i++)
    	scanf("%d",&v[i]);
    for(int i=1;i<n;i++)
    {
    	int a,b;
    	scanf("%d%d",&a,&b);
    	add(a,b);
    	add(b,a);
	}
	while(qq--)
	{
		memset(fa,0,sizeof(fa));
		scanf("%d%d",&a,&b);
		build_tree(a);
		qwe();
		int n=q.size()-1;
		for(int i=0;i<=n;i++)
			f[i][0]=f[i][1]=f[i][2]=f[i][3]=f[i][4]=inf;
		for(int i=0;i<=kk;i++)
			f[1][i]=0;
		f[1][4]=0;
		for(int i=2;i<=n;i++)
		{
			f[i][4]=f[i][kk]=f[i-1][4]+(ll)v[q[i]];
			for(int j=kk;j>=1;j--)
			{
				f[i][j-1]=min(f[i-1][j],f[i][j]),f[i][4]=min(f[i][4],f[i][j-1]);
			}
		}
		printf("%lld\n",f[n][4]+(ll)v[a]+(ll)v[b]);
	}
	return 0;
}
