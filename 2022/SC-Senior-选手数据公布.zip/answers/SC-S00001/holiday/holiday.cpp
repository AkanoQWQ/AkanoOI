#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=320;
int n,m,k,p[N][N];
ll a[N];
int g[90007][2],cnt;
ll ans=0;
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    memset(p,0x3f,sizeof(p));
    p[1][1]=0;
    for(int i=2;i<=n;i++)
    	scanf("%lld",&a[i]),p[i][i]=0;
    for(int i=1;i<=m;i++)
    {
    	int x,y;
    	scanf("%d%d",&x,&y);
    	p[x][y]=p[y][x]=0;
	}
	for(int kk=1;kk<=n;kk++)
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
			{
				p[i][j]=min(p[i][j],p[i][kk]+p[kk][j]+1);
			}
	for(int i=2;i<=n;i++)
	{
		if(p[1][i]>k)  continue;
		for(int j=2;j<=n;j++)
		{
			if(i==j||p[i][j]>k)  continue;
			g[++cnt][0]=i,g[cnt][1]=j;
		}
	}
	for(int i=1;i<=cnt;i++)
	{
		for(int j=i+1;j<=cnt;j++)
		{
			if(g[i][0]==g[j][0]||g[i][0]==g[j][1]||g[i][1]==g[j][0]||g[i][1]==g[j][1])  continue;
			if(p[g[i][1]][g[j][1]]>k)  continue;
			ans=max(ans,a[g[i][0]]+a[g[i][1]]+a[g[j][0]]+a[g[j][1]]);
		}
	}
	printf("%lld",ans);
	return 0;
}
