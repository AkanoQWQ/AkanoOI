#include<bits/stdc++.h>
using namespace std;
#define int long long
inline int rd(){
	int f=1,j=0;
	char w=getchar();
	while(w>'9'||w<'0'){
		if(w=='-')f=-1;
		w=getchar();
	}
	while(w>='0'&&w<='9'){
		j=(j<<3)+(j<<1)+w-'0';
		w=getchar();
	}
	return f*j;
}
const int N=100010;
struct node{
	int ma,mi,z_ma,z_mi;
	inline void cle(){
		ma=z_ma=INT_MIN;
		mi=z_mi=INT_MAX;
		return ;
	}
}tr[3][N*4];
int n[3],q;
int sum[3][N];
inline node merge(node a,node b){
	node c;
	c.cle();
	c.ma=max(a.ma,b.ma),c.mi=min(a.mi,b.mi);
	c.z_ma=max(a.z_ma,b.z_ma),c.z_mi=min(a.z_mi,b.z_mi);
	return c; 
}
inline void update(int k,int u){
	tr[k][u]=merge(tr[k][u*2],tr[k][u*2+1]);
	return ;
}
void built(int k,int u,int l,int r){
	if(l==r){
		tr[k][u].cle();
		tr[k][u].ma=tr[k][u].mi=sum[k][l];
		if(sum[k][l]>=0)tr[k][u].z_mi=sum[k][l];
		if(sum[k][l]<=0)tr[k][u].z_ma=sum[k][l];
		return ;
	}
	int mid=(l+r)/2;
	built(k,u*2,l,mid),built(k,u*2+1,mid+1,r);
	update(k,u);
	return ;
}
node query(int k,int u,int l,int r,int L,int R){
	if(L<=l&&r<=R)return tr[k][u];
	int mid=(l+r)/2;
	node ansn;ansn.cle();
	if(L<=mid)ansn=merge(ansn,query(k,u*2,l,mid,L,R));
	if(R>mid)ansn=merge(ansn,query(k,u*2+1,mid+1,r,L,R));
	return ansn;
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
//	freopen("game.out","w",stdout);
	n[1]=rd(),n[2]=rd(),q=rd();
	for(int i=1;i<=2;i++)for(int j=1;j<=n[i];j++)sum[i][j]=rd();
	for(int i=1;i<=2;i++)built(i,1,1,n[i]);
//	debug(2,1,1,n[2]);
	while(q--){
		int l[3],r[3];
		l[1]=rd(),r[1]=rd(),l[2]=rd(),r[2]=rd();
		node x=query(1,1,1,n[1],l[1],r[1]),y=query(2,1,1,n[2],l[2],r[2]);
//		cout<<x.ma<<" "<<x.mi<<" "<<x.z_mi<<" "<<x.z_ma<<"-----   ";
//		cout<<y.ma<<" "<<y.mi<<" "<<y.z_mi<<" "<<y.z_ma<<"\n";
		long long ans=-1e18;
		if(x.ma<=0&&y.mi>=0)ans=1ll*x.ma*y.ma;
		else if(x.ma>=0&&y.mi>=0)ans=max(ans,1ll*x.ma*y.mi);
		if(x.mi>=0&&y.ma<=0)ans=max(ans,1ll*x.mi*y.mi);
		else if(x.mi<=0&&y.ma<=0)ans=max(ans,1ll*x.mi*y.ma);
		if(x.ma>=0&&y.mi<=0)ans=max(ans,1ll*x.z_mi*y.mi);
		if(x.mi<=0&&y.ma>=0)ans=max(ans,1ll*x.z_ma*y.ma);
		printf("%lld\n",ans);
	}
	return 0;
}
/*
-143561089457415
3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2
*/
