#include<bits/stdc++.h>
using namespace std;
inline long long rd(){
	long long f=1,j=0;
	char w=getchar();
	while(w>'9'||w<'0'){
		if(w=='-')f=-1;
		w=getchar();
	}
	while(w>='0'&&w<='9'){
		j=(j<<3)+(j<<1)+w-'0';
		w=getchar();
	}
	return f*j;
}
const int N=2510,M=10010;
int head[N],to[M*2],fro[M*2],tail;
int lin[N][N];
int n,m,K;
int walk[N],bac[N];
long long val[N],ans;
inline void addline(int x,int y){
	to[++tail]=y;
	fro[tail]=head[x];
	head[x]=tail;
	return ;
}
struct node{
	int x,y;
	bool operator <(const node &a)const{return y>a.y;}
};
bool cmp(int x,int y){return val[x]>val[y];}
void deal(int u){
	for(int i=1;i<=n;i++)walk[i]=INT_MAX;
	walk[u]=0;
	priority_queue<node>p;
	p.push((node){u,0});
	while(!p.empty()){
		int x=p.top().x,y=p.top().y;p.pop();
		if(y!=walk[x]||y==K+1)continue;
		for(int k=head[x];k;k=fro[k]){
			int z=to[k];
			if(walk[z]>walk[x]+1){
				walk[z]=walk[x]+1;
				p.push((node){z,walk[z]});
			}
		}
	}
	for(int i=1;i<=n;i++){
		if(walk[i]<=K+1&&i!=u&&i!=1){
			lin[u][++lin[u][0]]=i;
			if(u==1)bac[i]=true;
		}
	}
	sort(lin[u]+1,lin[u]+1+lin[u][0],cmp);
	return ;
}
void dfs(int u,int dep,long long ansn){
	ansn+=val[u];
	for(int k=1;k<=lin[u][0];k++){
		int x=lin[u][k];
		if(walk[x])continue;
		if(dep==4&&bac[x])ans=max(ansn+val[x],ans);
		else if(dep<4)walk[x]=true,dfs(x,dep+1,ansn),walk[x]=false;
	}
	return ;
}
signed main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=rd(),m=rd(),K=rd();
	for(int i=2;i<=n;i++)val[i]=rd();
	for(int i=1;i<=m;i++){
		int x=rd(),y=rd();
		addline(x,y),addline(y,x);
	}
	for(int i=1;i<=n;i++)deal(i);
	for(int i=1;i<=n;i++)walk[i]=0;
	walk[1]=true;
	dfs(1,1,0);
	printf("%lld",ans);
	return 0;
}
/*
7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4

8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1
*/
