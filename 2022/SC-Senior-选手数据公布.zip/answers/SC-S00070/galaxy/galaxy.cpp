#include<bits/stdc++.h>
using namespace std;
inline int rd(){
	int f=1,j=0;
	char w=getchar();
	while(w>'9'||w<'0'){
		if(w=='-')f=-1;
		w=getchar();
	}
	while(w>='0'&&w<='9'){
		j=(j<<3)+(j<<1)+w-'0';
		w=getchar();
	}
	return f*j;
}
const int N=500010,mod=1000000007;
int head[N],to[N],fro[N],tail,tag[N];
unordered_map<unsigned long long,int>p;
int n,m,q,siz[N],ans;
inline unsigned long long cal(int x,int y){
	return (unsigned long long)x*mod+(unsigned long long )y;
}
inline void addline(int x,int y){
	to[++tail]=y;
	fro[tail]=head[x];
	head[x]=tail;
	siz[y]++;
	p[cal(x,y)]=tail;
	tag[tail]=true;
	return ;
}
signed main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=rd(),m=rd();
	for(int i=1;i<=m;i++){
		int x=rd(),y=rd();
		addline(y,x);
	}
	for(int i=1;i<=n;i++)if(siz[i]!=1)ans++;
	q=rd();
	while(q--){
		int t=rd();
		if(t==1){
			int y=rd(),x=rd();
			tag[p[cal(x,y)]]=false;
			siz[y]--;
			if(siz[y]==1)ans--;
			else if(siz[y]==0)ans++;
		}
		else if(t==2){
			int u=rd();
			for(int k=head[u];k;k=fro[k]){
				int x=to[k];
				if(!tag[k])continue;
				tag[k]=false;
				siz[x]--;
				if(siz[x]==1)ans--;
				else if(siz[x]==0)ans++;
			}
		}
		else if(t==3){
			int y=rd(),x=rd();
			tag[p[cal(x,y)]]=true;
			siz[y]++;
			if(siz[y]==1)ans--;
			else if(siz[y]==2)ans++;
		}
		else if(t==4){
			int u=rd();
			for(int k=head[u];k;k=fro[k]){
				int x=to[k];
				if(tag[k])continue;
				tag[k]=true;
				siz[x]++;
				if(siz[x]==1)ans--;
				else if(siz[x]==2)ans++;
			}
		}
//		for(int i=1;i<=n;i++)cout<<siz[i]<<" ";
//		cout<<"\n";
		if(!ans)printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
