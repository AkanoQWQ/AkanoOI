#include<bits/stdc++.h>
using namespace std;
inline int rd(){
	int f=1,j=0;
	char w=getchar();
	while(w>'9'||w<'0'){
		if(w=='-')f=-1;
		w=getchar();
	}
	while(w>='0'&&w<='9'){
		j=(j<<3)+(j<<1)+w-'0';
		w=getchar();
	}
	return f*j;
}
const int N=200010;
int head[N],to[N*2],fro[N*2],tail;
inline void addline(int x,int y){
	to[++tail]=y;
	fro[tail]=head[x];
	head[x]=tail;
	return ;
}
int n,q,K,v[N];
int dep[N],fa[N],siz[N],top[N],son[N],p[N],dfn[N],cnt;
namespace K1{
	struct node{
		long long s;
		node operator *(node a){
			return ((node){s+a.s});
		}
	}poi[N],tr[N*4],yuan;
	void built(int u,int l,int r){
		if(l==r){
			tr[u]=poi[p[l]];
			return ;
		}
		int mid=(l+r)/2;
		built(u*2,l,mid),built(u*2+1,mid+1,r);
		tr[u]=tr[u*2]*tr[u*2+1];
		return ;
	}
	node get(int u,int l,int r,int L,int R){
		if(L<=l&&r<=R)return tr[u];
		node ansn=yuan;
		int mid=(l+r)/2;
		if(L<=mid)ansn=ansn*get(u*2,l,mid,L,R);
		if(R>mid)ansn=ansn*get(u*2+1,mid+1,r,L,R);
		return ansn;
	}
	node getfa(int x,int y){
		node ansn=yuan;
		while(top[x]!=top[y]){
			if(dep[top[x]]<dep[top[y]])swap(x,y);
			ansn=ansn*get(1,1,n,dfn[top[x]],dfn[x]);
			x=fa[top[x]];
		}
//		cout<<"kk:"<<x<<" "<<y<<"\n";
		if(dfn[x]>dfn[y])swap(x,y);
		ansn=ansn*get(1,1,n,dfn[x],dfn[y]);
		return ansn;
	}
	void work(){
		for(int i=1;i<=n;i++)poi[i].s=v[i];
		built(1,1,n);
		yuan.s=0;
		while(q--){
			int x=rd(),y=rd();
			node ans=getfa(x,y);
			printf("%lld\n",ans.s);
		}
		return ;
	}
}
void dfs1(int u,int Fa){
	dep[u]=dep[Fa]+1;
	fa[u]=Fa;
	siz[u]=1;
	for(int k=head[u];k;k=fro[k]){
		int x=to[k];
		if(x==Fa)continue;
		dfs1(x,u);
		siz[u]+=siz[x];
		if(siz[x]>siz[son[u]])son[u]=x;
	}
	return ;
}
void dfs2(int u){
	dfn[u]=++cnt;
	p[cnt]=u;
	if(son[fa[u]]!=u)top[u]=u;
	else top[u]=top[fa[u]];
	if(son[u])dfs2(son[u]);
	for(int k=head[u];k;k=fro[k]){
		int x=to[k];
		if(x==fa[u]||x==son[u])continue;
		dfs2(x);
	}
	return ;
}
signed main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=rd(),q=rd(),K=rd();
	for(int i=1;i<=n;i++)v[i]=rd();
	for(int i=1;i<=n-1;i++){
		int x=rd(),y=rd();
		addline(x,y),addline(y,x);
	}
	dfs1(1,0),dfs2(1);
//	for(int i=1;i<=n;i++)cout<<i<<":"<<dfn[i]<<" "<<top[i]<<" "<<fa[i]<<"\n";
	if(K==1)K1::work();
	return 0;
}
/*
6 10000 1
1 2 3 4 5 6
1 2
2 3
2 4
4 5
4 6

1 5
*/
