#include<bits/stdc++.h>
using namespace std;
int n,m,k;
long long a[2505];
vector<int>v[2505];
long long ans;
bool vis[2505][2505];
void dfs(int x,int step,long long sc)
{
	if(step==5)
	{
//		cout<<x<<" "<<step<<" "<<sc<<endl;
		if(x==1)
		{
			ans=max(ans,sc);
			return;
		}
		else
		{
			return;
		}
	}
//	cout<<x<<" "<<step<<" "<<sc<<endl;
//	puts(""); 
	for(int i=0;i<v[x].size();++i)
	{
		if(vis[x][v[x][i]]==0)
		{
			vis[v[x][i]][x]=vis[x][v[x][i]]=1;
			dfs(v[x][i],step+1,sc+a[v[x][i]]);
			vis[v[x][i]][x]=vis[x][v[x][i]]=0;
		}	
	}
}
signed main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	a[1]=0;
	for(int i=2;i<=n;++i)
	{
		scanf("%lld",&a[i]);
	}
	for(int i=1;i<=m;++i)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		v[x].push_back(y);
		v[y].push_back(x);
	}
	dfs(1,0,a[1]);
	printf("%lld",ans);
}
