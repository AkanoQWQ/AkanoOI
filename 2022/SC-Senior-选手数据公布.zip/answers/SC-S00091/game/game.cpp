#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m,q;
const int N=1e5+7;
int a[100090],b[100003];
signed main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	
	for(int i=1;i<=n;++i)
	{
		scanf("%lld",&a[i]);
	}
	
	for(int i=1;i<=m;++i)
	{
		scanf("%lld",&b[i]);
	}
	
	while(q--)
	{
		int l1,r1,l2,r2;
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		int maxl=-1e9-1,minl=1e9+1,maxq=-1e9-1,minq=1e9+1,maxl_z=-1e9-1,minl_n=1e9+1;
		for(int i=l1;i<=r1;++i)
		{
			if(a[i]<minl)minl=a[i];
			if(a[i]>maxl)maxl=a[i];
			if(a[i]>maxl_z&&a[i]<=0)maxl_z=a[i];
			if(a[i]<minl_n&&a[i]>=0)minl_n=a[i];
		}
		for(int i=l2;i<=r2;++i)
		{
			if(b[i]<minq)minq=b[i];
			if(b[i]>maxq)maxq=b[i];	
		}
		int opl,opq;
		if(maxl<=0)opl=2;//l1-r1:<0
		if(minl>0)opl=1;//l1-r1:>0
		if(minl<=0&&maxl>=0)opl=3;
		if(maxq<=0)opq=2;//l2-r2:<0
		if(minq>0)opq=1;//l2-r2:>0
		if(minq<=0&&maxq>=0)opq=3;
		long long ans;
		if(opl==1&&opq==1)
		{
			ans=minq*maxl;
		}
		if(opl==1&&(opq==2||opq==3))
		{
			ans=minl*minq;
		}
		if(opl==2&&opq==1)
		{
			ans=maxl*maxq;
		}
		if(opl==2&&opq==2)
		{
			ans=minl*maxq;
		}
		if(opl==2&&opq==3)
		{
			ans=maxl*maxq;
		}
		if(opl==3&&opq==1)
		{
			ans=maxl*minq;
		}
		if(opl==3&&opq==2)
		{
			ans=minl*maxq;
		}
		if(opl==3&&opq==3)
		{
			ans=max(maxl_z*maxq,minl_n*minq);	
		}
//		cout<<maxl<<" "<<minl<<" "<<maxl_z<<" "<<minl_n<<" "<<maxq<<" "<<minq<<" "<<opl<<" "<<opq<<" "; 
		printf("%lld\n",ans);
	}
}
/*
3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2
*/
