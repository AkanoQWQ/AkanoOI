#include <bits/stdc++.h>

using namespace std;

const int N = 2e5 + 5;
int n, m, k, a[N], b[N]; long long v[N];
vector<int> son[N], q[N];
int lca[N], dep[N], fath[N]; long long wgt[N];
int ufs[N];

void init() {
	int i;
	for(i = 1; i <= n; i++)
		ufs[i] = i;
	return;
}

int find(int x) {
	return x == ufs[x] ? x : ufs[x]  = find(ufs[x]);
}

void build_tree(int now, int fa) {
	int i, siz = son[now].size();
	wgt[now] = wgt[fa] + v[now];
	dep[now] = dep[fa] + 1;
	fath[now] = fa;
	for(i = 0; i < siz; i++)
		if(son[now][i] != fa)
			build_tree(son[now][i], now);
	return;
}

void get_lca(int now, int fa) {
	int i, siz = q[now].size();
	for(i = 0; i < siz; i++)
		if(lca[q[now][i]] != 0)
			lca[q[now][i]] = find(lca[q[now][i]]);
		else
			lca[q[now][i]] = now;
	siz = son[now].size();
	for(i = 0; i < siz; i++)
		if(son[now][i] != fa)
			get_lca(son[now][i], now);
	ufs[now] = fa;
	return;
}

namespace sqrn {
	int roat[N];
	
	void work() {
		int i, j;
		for(i = 1; i <= m; i++) {
			int x = a[i], y = b[i], all = dep[x] + dep[y] - 2 * dep[lca[i]] + 1;
			memset(roat, 0, sizeof(roat));
			for(j = 1; x != lca[i]; j++) {
				roat[j] = x;
				x = fath[x];
			}
			roat[j] = lca[i];
			for(j = all; y != lca[i]; j--) {
				roat[j] = y;
				y = fath[y];
			}
			priority_queue<pair<long long, int>, vector<pair<long long, int> >, greater<pair<long long, int> > > que;
			que.push(make_pair(v[roat[1]], 1));
			for(j = 2; j <= all; j++) {
				while(!que.empty() && j - que.top().second > k)
					que.pop();
				que.push(make_pair(que.top().first + v[roat[j]], j));
			}
			while(que.top().second != all)
				que.pop();
			printf("%lld\n", que.top().first);
		}
		return;
	}
}

namespace spj {
	void work() {
		int i;
		for(i = 1; i <= m; i++)
			printf("%lld\n", wgt[a[i]] + wgt[b[i]] - 2 * wgt[lca[i]] + v[lca[i]]);
		return;
	}
}

int main() {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	int i;
	scanf("%d%d%d", &n, &m, &k);
	for(i = 1; i <= n; i++)
		scanf("%lld", v + i);
	for(i = 1; i < n; i++) {
		int u, v;
		scanf("%d%d", &u, &v);
		son[u].push_back(v);
		son[v].push_back(u);
	}
	build_tree(1, 0);
	for(i = 1; i <= m; i++) {
		int u, v;
		scanf("%d%d", &u, &v);
		q[u].push_back(i);
		q[v].push_back(i);
		a[i] = u;
		b[i] = v;
	}
	init();
	get_lca(1, 0);
	if(k == 1)
		spj::work();
	else
		sqrn::work();
	return 0;
}
