#include <bits/stdc++.h>

const int N = 1e5 + 5;
int n, m, q; long long a[N], b[N];
long long ans;

int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	int i;
	scanf("%d%d%d", &n, &m, &q);
	for(i = 1; i <= n; i++)
		scanf("%lld", a + i);
	for(i = 1; i <= m; i++)
		scanf("%lld", b + i);
	while(q--) {
		int l1, r1, l2, r2;
		long long maxx = -1e9, minn = 1e9;
		scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
		for(i = l2; i <= r2; i++) {
			maxx = std::max(maxx, b[i]);
			minn = std::min(minn, b[i]);
		}
		ans = -1e18;
		for(i = l1; i <= r1; i++) {
			if(a[i] <= 0)
				ans = std::max(ans, a[i] * maxx);
			if(a[i] >= 0)
				ans = std::max(ans, a[i] * minn);
		}
		printf("%lld\n", ans);
	} 
	return 0;
}
