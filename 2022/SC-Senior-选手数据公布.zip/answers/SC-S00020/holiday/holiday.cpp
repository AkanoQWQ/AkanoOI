#include <bits/stdc++.h>

using namespace std;

const int N = 305, K = 105;
int n, m, k; long long v[N];
std::vector<int> e[N];
long long ans;
int vis[N], dist[N][N];

void work(int start) {
    int i;
    priority_queue<pair<int, int>, vector<pair<int, int> >, greater<pair<int, int> > > que;
    for(i = 1; i <= n; i++)
        if(i != start)
            dist[start][i] = 1e9;
    que.push(make_pair(0, start));
    while(!que.empty()) {
        int fr = que.top().second, siz = e[fr].size();
        que.pop();
        for(i = 0; i < siz; i++)
            if(dist[start][fr] + 1 < dist[start][e[fr][i]]) {
                dist[start][e[fr][i]] = dist[start][fr] + 1;
                que.push(make_pair(dist[start][e[fr][i]], e[fr][i]));
            }
    }
    return;
}

void dfs(int now, long long sum, int lst) {
    int i;
    if(now > 4) {
        if(dist[lst][1] <= k + 1)
            ans = std::max(ans, sum);
        return;
    }
    for(i = 2; i <= n - now + 1; i++) {
    	std::swap(vis[i], vis[n - now + 1]); 
    	if(dist[lst][vis[n - now + 1]] <= k + 1)
    		dfs(now + 1, sum + v[vis[n - now + 1]], vis[n - now + 1]);
    	std::swap(vis[i], vis[n - now + 1]);
	}
    return;
}

int main() {
    freopen("holiday.in", "r", stdin);
    freopen("holiday.out", "w", stdout);
    int i;
    scanf("%d%d%d", &n, &m, &k);
    for(i = 2; i <= n; i++)
        scanf("%lld", v + i);
    for(i = 1; i <= m; i++) {
        int u, v;
        scanf("%d%d", &u, &v);
        e[u].push_back(v);
        e[v].push_back(u);
    }
    for(i = 1; i <= n; i++)
        work(i);
    for(i = 1; i <= n; i++)
		vis[i] = i; 
    dfs(1, 0, 1);
    printf("%lld", ans);
    return 0;
}
