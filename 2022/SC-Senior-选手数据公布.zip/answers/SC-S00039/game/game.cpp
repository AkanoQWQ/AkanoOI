#include<bits/stdc++.h>
#define ls now<<1
#define rs now<<1|1
using namespace std;
inline int read()
{
	int wx=0,si=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
			si=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		wx=(wx<<3)+(wx<<1)+ch-'0';
		ch=getchar();
	}
	return wx*si;
}
const int INF=1e9+1;
int a[100005],b[100005];
int ana[400005],ani[400005],apa[400005],api[400005],ba[400005],bi[400005];
bool z[400005];
struct nodeb
{
	int ma,mi;
	nodeb(int x=0,int y=0)
	{
		ma=x;
		mi=y;
	}
	nodeb operator+(nodeb o)
	{
		return nodeb(max(ma,o.ma),min(mi,o.mi));
	}
};
struct nodea
{
	int ap,an,ip,in;
	bool z;
	nodea(int x1=0,int x2=0,int x3=0,int x4=0,bool fl=false)
	{
		ap=x1;
		an=x2;
		ip=x3;
		in=x4;
		z=fl;
	}
	nodea operator+(nodea o)
	{
		return nodea(max(ap,o.ap),max(an,o.an),min(ip,o.ip),min(in,o.in),z||o.z);
	}
};
void upa(int now)
{
	ana[now]=max(ana[ls],ana[rs]);
	apa[now]=max(apa[ls],apa[rs]);
	ani[now]=min(ani[ls],ani[rs]);
	api[now]=min(api[ls],api[rs]);
	z[now]=z[ls]||z[rs];
}
void builda(int now,int l,int r)
{
	if(l==r)
	{
		apa[now]=ana[now]=-INF;
		api[now]=ani[now]=INF;
		if(a[l]!=0)
		{
			if(a[l]>0)
				apa[now]=api[now]=a[l];
			else
				ana[now]=ani[now]=a[l];
		}
		else
			z[now]=true;
		return;
	}
	int mid=(l+r)>>1;
	builda(ls,l,mid);
	builda(rs,mid+1,r);
	upa(now);
}
void upb(int now)
{
	ba[now]=max(ba[ls],ba[rs]);
	bi[now]=min(bi[ls],bi[rs]);
}
void buildb(int now,int l,int r)
{
	if(l==r)
	{
		ba[now]=bi[now]=b[l];
		return;
	}
	int mid=(l+r)>>1;
	buildb(ls,l,mid);
	buildb(rs,mid+1,r);
	upb(now);
}
nodeb qub(int now,int l,int r,int L,int R)
{
	if(l>=L&&r<=R)
		return nodeb(ba[now],bi[now]);
	if(r<L||l>R)
		return nodeb(-INF,INF);
	int mid=(l+r)>>1;
	return qub(ls,l,mid,L,R)+qub(rs,mid+1,r,L,R);
}
nodea qua(int now,int l,int r,int L,int R)
{
	if(l>=L&&r<=R)
		return nodea(apa[now],ana[now],api[now],ani[now],z[now]);
	if(r<L||l>R)
		return nodea(-INF,-INF,INF,INF,false);
	int mid=(l+r)>>1;
	return qua(ls,l,mid,L,R)+qua(rs,mid+1,r,L,R);
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n=read(),m=read(),q=read();
	for(int i=1;i<=n;++i)
		a[i]=read();
	for(int i=1;i<=m;++i)
		b[i]=read();
	builda(1,1,n);
	buildb(1,1,m);
	for(int i=1;i<=q;++i)
	{
		int l1=read(),r1=read(),l2=read(),r2=read();
		nodeb qb=qub(1,1,m,l2,r2);
		nodea qa=qua(1,1,n,l1,r1);
		long long ans=-1e18-1;
		if(qa.in!=INF)
			ans=max(ans,max(1ll*qa.an*qb.ma,1ll*qa.in*qb.ma));
		if(qa.ip!=INF)
			ans=max(ans,max(1ll*qa.ap*qb.mi,1ll*qa.ip*qb.mi));
		if(qa.z)
			ans=max(ans,0ll);
		printf("%lld\n",ans);
	}
	return 0;
}
