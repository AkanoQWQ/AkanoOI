#include<bits/stdc++.h>
#define mk make_pair
using namespace std;
inline int read()
{
	int wx=0,si=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
			si=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		wx=(wx<<3)+(wx<<1)+ch-'0';
		ch=getchar();
	}
	return wx*si;
}
long long a[2505],vi[2505][3],ans;
int fi[2505],to[20005],ne[20005],cnt,dis[2505],n,m,k;
bool vis[2505][2505];
void add(int u,int v)
{
	to[++cnt]=v;
	ne[cnt]=fi[u];
	fi[u]=cnt;
}
void dj1()
{
	queue<int>q;
	q.push(1);
	vis[1][1]=true;
	while(!q.empty())
	{
		int u=q.front();
		q.pop();
		if(dis[u]==k+1)
			break;
		for(int i=fi[u];i;i=ne[i])
		{
			int v=to[i];
			if(!vis[1][v])
			{
				dis[v]=dis[u]+1;
				vis[1][v]=true;
				q.push(v);
			}
		}
	}
	vis[1][1]=false;
}
void dj(int now)
{
	queue<int>q;
	memset(dis,0,sizeof(dis));
	vis[now][now]=true;
	q.push(now);
	while(!q.empty())
	{
		int u=q.front();
		q.pop();
		if(vis[1][u]&&u!=now)
		{
			if(!vi[now][2]||a[u]>a[vi[now][2]])
				vi[now][2]=u;
			for(int i=2;i&&a[vi[now][i]]>a[vi[now][i-1]];--i)
				swap(vi[now][i],vi[now][i-1]);
		}
		if(dis[u]==k+1)
			continue;
		for(int i=fi[u];i;i=ne[i])
		{
			int v=to[i];
			if(!vis[now][v])
			{
				dis[v]=dis[u]+1;
				vis[now][v]=true;
				q.push(v);
			}
		}
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read();
	m=read();
	k=read();
	for(int i=2;i<=n;++i)
		a[i]=read();
	for(int i=1;i<=m;++i)
	{
		int u=read(),v=read();
		add(u,v);
		add(v,u);
	}
	dj1();
	for(int i=2;i<=n;++i)
		dj(i);
	for(int i=2;i<=n;++i)
	{
		for(int j=i+1;j<=n;++j)
		{
			if(!vis[i][j])
				continue;
			for(int ii=0;ii<=2&&vi[i][ii];++ii)
			{
				if(vi[i][ii]==j)
					continue;
				for(int jj=0;jj<=2&&vi[j][jj];++jj)
				{
					if(vi[j][jj]==i||vi[j][jj]==vi[i][ii])
						continue;
					ans=max(ans,a[i]+a[j]+a[vi[i][ii]]+a[vi[j][jj]]);
				}
			}
		}
	}
	printf("%lld\n",ans);
	return 0;
}
