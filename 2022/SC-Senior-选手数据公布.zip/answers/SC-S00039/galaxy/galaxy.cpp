#include<bits/stdc++.h>
#define mk make_pair
using namespace std;
inline int read()
{
	int wx=0,si=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
			si=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		wx=(wx<<3)+(wx<<1)+ch-'0';
		ch=getchar();
	}
	return wx*si;
}
bool MAP1[1005][1005],MAP2[1005][1005],inst[1005],vis[1005];
int cnt[1005],to[1005],st[1005],top;
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n=read(),m=read();
	for(int i=1;i<=m;++i)
	{
		int u=read(),v=read();
		MAP1[u][v]=MAP2[u][v]=true;
	}
	for(int i=1;i<=n;++i)
	{
		for(int j=1;j<=n;++j)
		{
			if(MAP1[i][j])
			{
				++cnt[i];
				to[i]=j;
			}
		}
		if(cnt[i]!=1)
			to[i]=0;
	}
	int q=read();
	for(int i=1;i<=q;++i)
	{
		int t=read();
		if(t==1)
		{
			int u=read(),v=read();
			MAP2[u][v]=false;
			--cnt[u];
			if(cnt[u]==1)
			{
				for(int j=1;j<=n;++i)
					if(MAP2[u][i])
						to[u]=j;
			}
			else
				to[u]=0;
		}
		else if(t==2)
		{
			int u=read();
			for(int j=1;j<=n;++j)
			{
				if(MAP2[j][u])
				{
					MAP2[j][u]=false;
					--cnt[j];
					to[j]=0;
				}
			}
		}
		else if(t==3)
		{
			int u=read(),v=read();
			MAP2[u][v]=true;
			++cnt[u];
			if(cnt[u]==1)
				to[u]=v;
			else
				to[u]=0;
		}
		else if(t==4)
		{
			int u=read();
			for(int j=1;j<=n;++j)
			{
				if(MAP2[j][u]^MAP1[j][u])
				{
					MAP2[j][u]=true;
					++cnt[j];
					if(cnt[j]==1)
						to[j]=u;
					else
						to[j]=0;
				}
			}
		}
		bool fl=true;
		for(int j=1;j<=n;++j)
		{
			if(cnt[j]!=1)
			{
				fl=false;
				break;
			}
		}
		if(fl)
		{
			for(int j=1;j<=n;++j)
			{
				if(to[j])
					continue;
				for(int k=1;k<=n;++k)
					if(MAP2[j][k])
						to[j]=k;
			}
			memset(vis,0,sizeof(vis));
			for(int j=1;j<=n;++j)
			{
				if(vis[j])
					continue;
				int now=j;
				while(1)
				{
					if(vis[to[now]])
					{
						while(top)
						{
							vis[st[top]]=true;
							--top;
						}
						break;
					}
				}
			}
		}
	}
	return 0;
}
