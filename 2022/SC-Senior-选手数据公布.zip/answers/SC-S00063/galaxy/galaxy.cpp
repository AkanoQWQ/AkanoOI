#include <cstdio>
#include <vector>

template <typename type> inline void read(type &x) {
    x = 0;
    type neg = 1;
    char c = getchar();
    while (c < '0' || '9' < c) {
        if (c == '-')
            neg = -1;
        c = getchar();
    }
    while ('0' <= c && c <= '9') {
        (x *= 10) += c - '0';
        c = getchar();
    }
    x *= neg;
}

using std :: vector;

const int maxn = 1e3 + 1;
const int maxm = 1e4 + 1;
const int maxbn = 5e5 + 1;

struct edge {
    int id, u;
};

int n, m, q;
int f[maxn][maxn];

bool flag[maxm];
int od[maxn];
int cnt0 = 0, sum = 0;

int main() {
    freopen("galaxy.in", "r", stdin);
    freopen("galaxy.out", "w", stdout);
    read(n), read(m);
    if (n < maxn) {
        for (int i = 1; i <= m; i++) {
            int u, v;
            read(u), read(v);
            f[u][v] = i;
            flag[i] = true;
            od[u]++;
        }
        read(q);
        while (q--) {
            int op, u, v;
            read(op);
            if (op == 1) {
                read(u), read(v);
                flag[f[u][v]] = false;
                od[u]--;
            } else if (op == 2) {
                read(u);
                for (int i = 1; i <= n; i++)
                    if (f[i][u] && flag[f[i][u]]) {
                        flag[f[i][u]] = false;
                        od[i]--;
                    }
            } else if (op == 3) {
                read(u), read(v);
                flag[f[u][v]] = true;
                od[u]++;
            } else if (op == 4) {
                read(u);
                for (int i = 1; i <= n; i++)
                    if (f[i][u] && !flag[f[i][u]]) {
                        flag[f[i][u]] = true;
                        od[i]++;
                    }
            }
            bool fflag = true;
            for (int i = 1; i <= n; i++)
                if (od[i] != 1) {
                    fflag = false;
                    break;
                }
            if (fflag)
                puts("YES");
            else
                puts("NO");
        }
    } else {
        for (int i = 1; i <= m; i++) {
            int u, v;
            read(u), read(v);
            od[u]++;
            sum++;
        }
        for (int i = 1; i <= n; i++)
            if (!od[i])
                cnt0++;
        read(q);
        while (q--) {
            int op, u, v;
            read(op);
            if (op == 1) {
                read(u), read(v);
                od[u]--;
                sum--;
                if (!od[u])
                    cnt0++;
            } else if (op == 3) {
                read(u), read(v);
                if (!od[u])
                    cnt0--;
                od[u]++;
                sum++;
            } else
                read(u);
            if (sum == n && !cnt0)
                puts("YES");
            else
                puts("NO");
        }
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}