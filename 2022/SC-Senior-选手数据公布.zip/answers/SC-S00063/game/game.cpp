#include <cstdio>

template <typename type> inline void read(type &x) {
    x = 0;
    type neg = 1;
    char c = getchar();
    while (c < '0' || '9' < c) {
        if (c == '-')
            neg = -1;
        c = getchar();
    }
    while ('0' <= c && c <= '9') {
        (x *= 10) += c - '0';
        c = getchar();
    }
    x *= neg;
}

typedef long long lld;

const int inf = 1e9 + 1;
const int maxn = 1e5 + 1;
const int max4n = 4e5 + 1;

int n, m, q;
lld a[maxn], b[maxn];
int l1, r1, l2, r2;
lld ans;

inline lld max(lld x, lld y) {
    return x > y ? x : y;
}

inline lld min(lld x, lld y) {
    return x < y ? x : y;
}

struct node {
    bool pos, neg;
    lld mxpos, mnpos, mxneg, mnneg;
} qa, qb;

inline node operator +(const node &x, const node &y) {
    return node{
        x.pos || y.pos,
        x.neg || y.neg,
        max(x.mxpos, y.mxpos),
        min(x.mnpos, y.mnpos),
        max(x.mxneg, y.mxneg),
        min(x.mnneg, y.mnneg)
    };
}

struct segtree {
#define lson(u) u << 1
#define rson(u) (u << 1) | 1
    bool pos[max4n], neg[max4n];
    lld mxpos[max4n], mnpos[max4n], mxneg[max4n], mnneg[max4n];
    inline void build(lld *a, int u, int l, int r) {
        if (l == r) {
            if (a[l] >= 0) {
                pos[u] = true, neg[u] = false;
                mxpos[u] = a[l];
                mnpos[u] = a[l];
                mxneg[u] = -inf;
                mnneg[u] = 0;
            } else {
                pos[u] = false, neg[u] = true;
                mxpos[u] = -1;
                mnpos[u] = inf;
                mxneg[u] = a[l];
                mnneg[u] = a[l];
            }
            return;
        }
        int mid = (l + r) >> 1;
        build(a, lson(u), l, mid);
        build(a, rson(u), mid + 1, r);
        pos[u] = pos[lson(u)] || pos[rson(u)];
        neg[u] = neg[lson(u)] || neg[rson(u)];
        mxpos[u] = max(mxpos[lson(u)], mxpos[rson(u)]);
        mnpos[u] = min(mnpos[lson(u)], mnpos[rson(u)]);
        mxneg[u] = max(mxneg[lson(u)], mxneg[rson(u)]);
        mnneg[u] = min(mnneg[lson(u)], mnneg[rson(u)]);
    }
    inline node query(int u, int l, int r, int st, int ed) {
        if (r < st || ed < l)
            return node{false, false, -1, inf, -inf, 0};
        else if (st <= l && r <= ed)
            return node{pos[u], neg[u], mxpos[u], mnpos[u], mxneg[u], mnneg[u]};
        int mid = (l + r) >> 1;
        return (query(lson(u), l, mid, st, ed) + query(rson(u), mid + 1, r, st, ed));
    }
} ta, tb;

int main() {
    freopen("game.in", "r", stdin);
    freopen("game.out", "w", stdout);
    read(n), read(m), read(q);
    for (int i = 1; i <= n; i++)
        read(a[i]);
    for (int i = 1; i <= m; i++)
        read(b[i]);
    ta.build(a, 1, 1, n);
    tb.build(b, 1, 1, m);
    while (q--) {
        read(l1), read(r1), read(l2), read(r2);
        qa = ta.query(1, 1, n, l1, r1);
        qb = tb.query(1, 1, m, l2, r2);
        if (!qa.pos && qa.neg && !qb.pos && qb.neg)
            ans = qa.mnneg * qb.mxneg;
        if (!qa.pos && qa.neg && qb.pos && !qb.neg)
            ans = qa.mxneg * qb.mxpos;
        if (!qa.pos && qa.neg && qb.pos && qb.neg)
            ans = qa.mxneg * qb.mxpos;
        if (qa.pos && !qa.neg && !qb.pos && qb.neg)
            ans = qa.mnpos * qb.mnneg;
        if (qa.pos && !qa.neg && qb.pos && !qb.neg)
            ans = qa.mxpos * qb.mnpos;
        if (qa.pos && !qa.neg && qb.pos && qb.neg)
            ans = qa.mnpos * qb.mnneg;
        if (qa.pos && qa.neg && !qb.pos && qb.neg)
            ans = qa.mnneg * qb.mxneg;
        if (qa.pos && qa.neg && qb.pos && !qb.neg)
            ans = qa.mxpos * qb.mnpos;
        if (qa.pos && qa.neg && qb.pos && qb.neg)
            ans = max(qa.mnpos * qb.mnneg, qa.mxneg * qb.mxpos);
        printf("%lld\n", ans);
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}