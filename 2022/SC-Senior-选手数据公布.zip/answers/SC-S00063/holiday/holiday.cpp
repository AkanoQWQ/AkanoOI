#include <cstdio>

template <typename type> inline void read(type &x) {
    x = 0;
    type neg = 1;
    char c = getchar();
    while (c < '0' || '9' < c) {
        if (c == '-')
            neg = -1;
        c = getchar();
    }
    while ('0' <= c && c <= '9') {
        (x *= 10) += c - '0';
        c = getchar();
    }
    x *= neg;
}

const int maxn = 2500 + 1;

int n, m, k;
long long s[maxn];

int f[maxn][maxn];
bool flag[maxn][maxn];
int t[4];
bool vis[maxn];
long long ans = 0;

inline int max(int x, int y) {
    return x > y ? x : y;
}

inline int min(int x, int y) {
    return x < y ? x : y;
}

void dfs(int cur) {
    if (cur == 4) {
        for (int i = 2; i <= n; i++)
            if (!vis[i] && flag[t[cur - 1]][i] && flag[i][1])
                ans = max(ans, s[t[1]] + s[t[2]] + s[t[3]] + s[i]);
        return;
    }
    for (int i = 2; i <= n; i++)
        if (!vis[i] && flag[t[cur - 1]][i]) {
            t[cur] = i;
            vis[i] = true;
            dfs(cur + 1);
            vis[i] = false;
        }
}

int main() {
    freopen("holiday.in", "r", stdin);
    freopen("holiday.out", "w", stdout);
    read(n), read(m), read(k);
    for (int i = 2; i <= n; i++)
        read(s[i]);
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
            f[i][j] = i == j ? 0 : maxn;
    for (int i = 1; i <= m; i++) {
        int u, v;
        read(u), read(v);
        f[u][v] = f[v][u] = 1;
    }
    for (int k = 1; k <= n; k++)
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= n; j++)
                f[i][j] = min(f[i][j], f[i][k] + f[k][j]);
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
            flag[i][j] = (f[i][j] <= k + 1);
    t[0] = 1;
    dfs(1);
    printf("%lld\n", ans);
    fclose(stdin);
    fclose(stdout);
    return 0;
}