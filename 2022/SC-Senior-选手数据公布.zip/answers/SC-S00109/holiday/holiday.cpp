#include<bits/stdc++.h>
using namespace std;
struct side
{
	int to,nt;
	side(){to=nt=0;}
}edge[10001];
deque<int> q;
int n,m,k,ans=0,a[2501]={},head[2501]={},ei=0,d[2501]={};
bool vis[2501]={};
void add(int x,int y)
{
	edge[++ei].to=y;
	edge[ei].nt=head[x];
	head[x]=ei;
}
void dfs(int r,int kk,int f,int temp,int be)
{
	if(f==4)
	{
		if((d[r]+kk)>k)return;
		if(ans<temp)ans=temp;
		return;
	}
	for(register int i=head[r];i;i=edge[i].nt)
	if(edge[i].to!=be)
		{
			if(r!=1)
			{
				vis[r]=1;
				if(!vis[edge[i].to]||(edge[i].to==1&&kk+1<=k))dfs(edge[i].to,0,f+1,temp+a[r],r);
				vis[r]=0;
			}
			if(kk!=k)dfs(edge[i].to,kk+1,f,temp,r);
		}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(register int i=2;i<=n;i++)scanf("%d",&a[i]);
	for(register int i=1;i<=m;i++)
	{
		int a,b;
		scanf("%d%d",&a,&b);
		add(a,b);
		add(b,a);
	}
	vis[1]=1;
	q.push_back(1);
	int dd=0,num=1;
	while(!q.empty())
	{
		int temp=0;
		for(register int i=1;i<=num;i++)
		{
			int t=q.front();
			q.pop_front();
			for(register int j=head[t];j;j=edge[j].nt)
			{
				if(!vis[edge[j].to])
				{
					q.push_back(edge[j].to);
					d[edge[j].to]=dd;
					vis[edge[j].to]=1;
					temp++;
				}
			}
		}
		num=temp;
		dd++;
	}
	memset(vis,0,sizeof(vis));
	dfs(1,-1,0,0,1);
	printf("%d",ans);
	return 0;
}
