#include<bits/stdc++.h>
using namespace std;
long long a[100001]={},b[100001]={},af[100001]={},bf[100001]={},an[100001]={},bn[100001]={};
int n,m,q;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(register int i=1;i<=n;i++)scanf("%lld",&a[i]);
	for(register int i=1;i<=m;i++)scanf("%lld",&b[i]);
	while(q--)
	{
		int l1,r1,l2,r2,minmax=-0x7fffffff,maxmin=0x7fffffff,ai,bi;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		for(register int i=l1;i<=r1;i++)
		{
			if(af[i])
			{
				if(minmax<an[i])
				{
					minmax=an[i];
					ai=i;
				}
			}
			else
			{
				an[i]=0x7fffffff;
				for(register int j=1;j<=m;j++)
				{
					if(a[i]*b[j]<an[i])
					{
						an[i]=a[i]*b[j];
						af[i]=j;
					}
				}
				if(minmax<an[i])
				{
					minmax=an[i];
					ai=i;
				}
			}
		}
		for(register int i=l2;i<=r2;i++)
		{
			if(bf[i])
			{
				if(maxmin>bn[i])
				{
					maxmin=bn[i];
					bi=i;
				}
			}
			else
			{
				bn[i]=-0x7fffffff;
				for(register int j=1;j<=n;j++)
				{
					if(b[i]*a[j]>bn[i])
					{
						bn[i]=b[i]*a[j];
						bf[i]=j;
					}
				}
				if(maxmin>bn[i])
				{
					maxmin=bn[i];
					bi=i;
				}
			}
		}
		printf("%lld\n",a[ai]*b[bi]);	
	}
	return 0;
}
