//��long long 
#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N = 1e5+9;
const int M = 2e1+0;
int n,m,a[N],b[N],T;
ll mi1,mi2,ma1,ma2 ;
int p1[N],p2[N],t1,t2;
ll smi1[N][M],smi2[N][M];
ll sma1[N][M],sma2[N][M];
int l1,l2,r1,r2,p[M];ll ans;
int read()
{
	int x=0,f=1;char c=getchar();
	while(c< '0'||c> '9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9')x=x*10+c-48,c=getchar();
	return x*f;
}
void gmi1(int l,int r)
{
	if(l>=r){mi1=min(mi1,1ll*a[r]);return;}
	int k=upper_bound(p,p+M,r-l)-p-1;
	mi1=min(mi1,smi1[l][k]);
	gmi1(l+p[k]+1,r);
}
void gma1(int l,int r)
{
	if(l>=r){ma1=max(ma1,1ll*a[r]);return;}
	int k=upper_bound(p,p+M,r-l)-p-1;
	ma1=max(ma1,sma1[l][k]);
	gma1(l+p[k]+1,r);
}
void gmi2(int l,int r)
{
	if(l>=r){mi2=min(mi2,1ll*b[r]);return;}
	int k=upper_bound(p,p+M,r-l)-p-1;
	mi2=min(mi2,smi2[l][k]);
	gmi2(l+p[k]+1,r);
}
void gma2(int l,int r)
{
	if(l>=r){ma2=max(ma2,1ll*b[r]);return;}
	int k=upper_bound(p,p+M,r-l)-p-1;
	ma2=max(ma2,sma2[l][k]);
	gma2(l+p[k]+1,r);
}
int main()
{
	freopen("game.in" ,"r",stdin );
	freopen("game.out","w",stdout);
	n=read(),m=read(),T=read();p[0]=1;
	for(int i=1;i< M;++i)p[i]=p[i-1]*2;
	for(int i=1;i<=n;++i){a[i]=read();if(!a[i])p1[++t1]=i;}
	for(int i=1;i<=m;++i){b[i]=read();if(!b[i])p2[++t2]=i;}
	for(int i=1;i< n;++i)smi1[i][0]=min(a[i],a[i+1]),sma1[i][0]=max(a[i],a[i+1]);
	for(int i=1;i< m;++i)smi2[i][0]=min(b[i],b[i+1]),sma2[i][0]=max(b[i],b[i+1]);
	//ST�� 
	for(int i=1;i< M;++i)
	{
		
		for(int j=1;j+p[i]<=n;++j)
		smi1[j][i]=min(smi1[j][i-1],smi1[j+p[i-1]][i-1]),
		sma1[j][i]=max(sma1[j][i-1],sma1[j+p[i-1]][i-1]);
		for(int j=1;j+p[i]<=m;++j)
		smi2[j][i]=min(smi2[j][i-1],smi2[j+p[i-1]+1][i-1]),
		sma2[j][i]=max(sma2[j][i-1],sma2[j+p[i-1]+1][i-1]);
	}
	/*
	for(int i=0;i<=M;++i)
	for(int j=1;j+p[i]<=n;++j)
	cout<<j<<" "<<j+p[i]<<" "<<smi1[j][i]<<" "<<sma1[j][i]<<endl;
	*/
//	gmi1(9,9),cout<<mi1<<endl;
	while(T--)
	{
		mi2=mi1= 2000000000;
		ma1=ma2=-2000000000;
		l1=read(),r1=read(),l2=read(),r2=read();
		if(l1==r1)ma1=mi1=a[l1];
		else gmi1(l1,r1),gma1(l1,r1);
		if(l2==r2)ma2=mi2=b[l2];
		else gmi2(l2,r2),gma2(l2,r2);
		ma2=max(ma2,1ll*b[r2]);
		//if(mi1<0&&ma1<0)ma1*ma2;
		int pos1=lower_bound(p1+1,p1+t1+1,l1)-p1;
		int pos2=lower_bound(p2+1,p2+t2+1,l2)-p2;
		if(mi2< 0&&ma2< 0)ans=1ll*mi1*ma2;
		else if(mi2> 0&&ma2> 0)ans=1ll*ma1*mi2;		
		else
		{
			if(mi1> 0&&ma1> 0)ans=1ll*mi1*mi2;
			else if(mi1< 0&&ma1< 0)ans=1ll*ma1*ma2;
			else
			{
				ll T1=2000000000,T2=-2000000000;
				for(int i=l1;i<=r1;++i)
				{
					if(a[i]>=0)T1=min(T1,1ll*a[i]);
					if(a[i]<=0)T2=max(T2,1ll*a[i]);
				}
				//cout<<T1<<" "<<T2<<endl;
				ans=max(T1*mi2,T2*ma2);
			}
		}
		//cout<<pos1<<" "<<pos2<<endl;
		if(p1[pos1]>=l1&&p1[pos1]<=r1)ans=max(ans,1ll*0);
		if(p2[pos2]>=l2&&p2[pos2]<=r2)ans=min(ans,1ll*0);
		//0?
		printf("%lld\n",ans);
	}
	return 0;
}
/*
3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2

6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3

3 1 1
0 1 -2
0
1 1 1 1
*/
