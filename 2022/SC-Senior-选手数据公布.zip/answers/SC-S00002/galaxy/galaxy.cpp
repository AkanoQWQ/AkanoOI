//��long long
#include<bits/stdc++.h>
#define lowbit(x) (x&-x)
using namespace std;
const int N = 1e5+9;
int n,m,T;
int read()
{
	int x=0,f=1;char c=getchar();
	while(c< '0'||c> '9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9')x=x*10+c-48,c=getchar();
	return x*f;
}
int main()
{
	freopen("galaxy.in" ,"r",stdin );
	freopen("galaxy.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=m;++i)int u=read(),v=read();
	T=read();
	while(T--)puts("NO");
	return 0;
}

