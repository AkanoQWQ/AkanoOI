//��long long
#include<bits/stdc++.h>
using namespace std;
const long long N = 5e2+9;
long long n,m,k,a[N],d[N],f[N][N];
long long p[N],tot,vis[N],ans;
long long read()
{
	long long x=0,f=1;char c=getchar();
	while(c< '0'||c> '9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9')x=x*10+c-48,c=getchar();
	return x*f;
}
void dfs(long long u,long long c,long long step)
{
	if(step==2)
	{
		for(long long i=1;i<=tot;++i)
		{
			if(vis[p[i]])continue;
			if(f[u][p[i]]>k)continue;
			ans=max(ans,c+a[p[i]]);
		}
		return; 
	}
	for(long long i=1;i<=n;++i)
	{
		if(vis[i])continue;
		if(f[u][i]>k)continue;
		vis[i]=1;
		dfs(i,c+a[i],step+1);
		vis[i]=0;
	}
}
int main()
{
	freopen("holiday.in" ,"r",stdin );
	freopen("holiday.out","w",stdout);
	n=read(),m=read(),k=read();++k;
	memset(f,0x3f,sizeof(f));
	for(long long i=2;i<=n;++i)a[i]=read();
	for(long long i=1;i<=m;++i)
	{
		long long u=read(),v=read();
		f[u][v]=f[v][u]=1;
	}
	for(long long K=1;K<=n;++K)
	for(long long i=1;i<=n;++i)
	{
		f[i][i]=0;
		if(i==K)continue;
		for(long long j=1;j<=n;++j)
		{
			if(j==K||j==i)continue;
			f[i][j]=min(f[i][j],f[i][K]+f[K][j]);
		}
	}
	for(long long i=2;i<=n;++i)if(f[1][i]<=k)p[++tot]=i;
	vis[1]=1;
	for(long long i=1;i<=tot;++i)
	{
		//cout<<"?"<<p[i]<<" "<<a[p[i]]<<endl;
		vis[p[i]]=1;
		dfs(p[i],a[p[i]],0);
		vis[p[i]]=0;
	}
	cout<<ans<<endl;
	return 0;
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1

7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4

*/
