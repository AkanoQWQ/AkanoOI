#include<bits/stdc++.h>
using namespace std;
int n, m, k;
const int N = 2510, M = 3e4 + 10;

int e[M], ne[M], h[N], tot, w[N];
int v[N], d[N];
int sum[7][N];
int vis[7][N];
vector<int> vec[N];
int ans;
void add(int a, int b)
{
	e[tot] = b, ne[tot] = h[a], h[a] = tot++;
}
void dfs(int u)
{
	memset(d, 0x3f, sizeof d);
	memset(v, 0, sizeof v);
	queue<int> q;
	q.push(u);
	v[u] = 1;
	d[u] = 0;
	while(q.size())
	{
		int x = q.front(); q.pop();
		v[x] = 0;
		for(int i = h[x]; ~i; i = ne[i])
		{
			int y = e[i];
			if(d[y] > d[x] + 1)
			{
				d[y] = d[x] + 1;
				if(v[y]) continue;
				v[y] = 1;
				q.push(y);
			}
		}
	}
	for(int i = 1; i <= n; i++)
	{
		if(i == u) continue;
		if(d[i] - 1 <= k) vec[u].push_back(i);
	}
}
int ANS;
int b[N];
void dfs2(int cnt, int u)
{
//	cout << cnt << " " << u << endl;
	if(cnt == 6)
	{
		if(u == 1) ANS = max(ans, ANS);
		return ;
	}
	ans += w[u];
	b[u] = 1;
	for(int i = 0; i < vec[u].size(); i++)
	{
		if(b[vec[u][i]] == 1 && vec[u][i] != 1) continue;
		dfs2(cnt + 1, vec[u][i]);
	}
	ans -= w[u];
	b[u] = 0;
}
int main()
{
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	memset(h, -1, sizeof h);
	cin >> n >> m >> k;
	for(int i = 2; i <= n; i++) cin >> w[i];
	w[1] = 0;
	for(int i = 1; i <= m; i++)
	{
		int a, b;
		cin >> a >> b;
		add(a, b);
		add(b, a);
	}
	for(int i = 1; i <= n; i++)
	{
		dfs(i);
	}
	
	dfs2(1, 1);
	cout << ANS;
	return 0;
}
