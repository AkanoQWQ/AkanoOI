#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N = 1e5 + 10, M = 25;
int n, m, q;
long long a[N], b[N];
long long f1[N][M], f2[N][M], f3[N][M], dp1[N][M], dp2[N][M], dp3[N][M];

void prework1()
{
	for(int i = 1; i <= n; i++) f1[i][0] = a[i];
	int t = log(n) / log(2) + 1;
	for(int j = 1; j < t; j++)
	{
		for(int i = 1; i + (1 << j) - 1 <= n; i++)
		{
			f1[i][j] = max(f1[i][j - 1], f1[i + (1 << (j - 1))][j - 1]);
		}
	}
}
void prework2()
{
	for(int i = 1; i <= n; i++) f2[i][0] = a[i];
	int t = log(n) / log(2) + 1;
	for(int j = 1; j < t; j++)
	{
		for(int i = 1; i + (1 << j) - 1 <= n; i++)
		{
			f2[i][j] = min(f2[i][j - 1], f2[i + (1 << (j - 1))][j - 1]);
		}
	}
}
void prework3()
{
	for(int i = 1; i <= n; i++) dp1[i][0] = b[i];
	int t = log(n) / log(2) + 1;
	for(int j = 1; j < t; j++)
	{
		for(int i = 1; i + (1 << j) - 1 <= n; i++)
		{
			dp1[i][j] = max(dp1[i][j - 1], dp1[i + (1 << (j - 1))][j - 1]);
		}
	}
}
void prework4()
{
	for(int i = 1; i <= n; i++) dp2[i][0] = b[i];
	int t = log(n) / log(2) + 1;
	for(int j = 1; j < t; j++)
	{
		for(int i = 1; i + (1 << j) - 1 <= n; i++)
		{
			dp2[i][j] = min(dp2[i][j - 1], dp2[i + (1 << (j - 1))][j - 1]);
		}
	}
}
void prework5()
{
	for(int i = 1; i <= n; i++) f3[i][0] = (a[i] >= 0 ? a[i] : INT_MAX);
	int t = log(n) / log(2) + 1;
	for(int j = 1; j < t; j++)
	{
		for(int i = 1; i + (1 << j) - 1 <= n; i++)
		{
			f3[i][j] = min(f3[i][j - 1], f3[i + (1 << (j - 1))][j - 1]);
		}
	}
}
void prework6()
{
	for(int i = 1; i <= n; i++) dp3[i][0] = (a[i] <= 0 ? a[i] : INT_MIN);
	int t = log(n) / log(2) + 1;
	for(int j = 1; j < t; j++)
	{
		for(int i = 1; i + (1 << j) - 1 <= n; i++)
		{
			dp3[i][j] = max(dp3[i][j - 1], dp3[i + (1 << (j - 1))][j - 1]);
		}
	}
}
int query1(int l, int r)
{
	int len = r - l + 1;
	int t = log(len) / log(2) + 1;
	return max(f1[l][t - 1], f1[r - (1 << (t - 1)) + 1][t - 1]);
}
int query2(int l, int r)
{
	int len = r - l + 1;
	int t = log(len) / log(2) + 1;
	return min(f2[l][t - 1], f2[r - (1 << (t - 1)) + 1][t - 1]);
}
int query3(int l, int r)
{
	int len = r - l + 1;
	int t = log(len) / log(2) + 1;
	return max(dp1[l][t - 1], dp1[r - (1 << (t - 1)) + 1][t - 1]);
}
int query4(int l, int r)
{
	int len = r - l + 1;
	int t = log(len) / log(2) + 1;
	return min(dp2[l][t - 1], dp2[r - (1 << (t - 1)) + 1][t - 1]);
}
int query5(int l, int r)
{
	int len = r - l + 1;
	int t = log(len) / log(2) + 1;
	return min(f3[l][t - 1], f3[r - (1 << (t - 1)) + 1][t - 1]);
}
int query6(int l, int r)
{
	int len = r - l + 1;
	int t = log(len) / log(2) + 1;
	return max(dp3[l][t - 1], dp3[r - (1 << (t - 1)) + 1][t - 1]);
}
int main()
{
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	cin >> n >> m >> q;
	for(int i = 1; i <= n; i++) cin >> a[i];
	for(int i = 1; i <= m; i++) cin >> b[i];
	prework1();
	prework2();
	prework3();
	prework4();
	prework5();
	prework6();
	for(int i = 1; i <= q; i++)
	{
		int l1, r1, l2, r2;
		cin >> l1 >> r1 >> l2 >> r2;
//		cout << endl;
		int a1 = query1(l1, r1);
		int b1 = query2(l1, r1);
		int a2 = query3(l2, r2);
		int b2 = query4(l2, r2);
		if(a2 >= 0 && b2 >= 0)
		{
			cout << a1 * b2 << endl;
		}
		else if(a2 >= 0 && b2 <= 0)
		{
			if(a1 >= 0 && b1 >= 0) cout << b1 * b2 << endl;
			else if(a1 >= 0 && b1 <= 0)
			{
//				cout << endl << endl;
//				cout << query5(l1, r1) << " " << b2 << " " << query6(l1, r1) << " " << a2 << endl;
				cout << max(query5(l1, r1) * b2, query6(l1, r1) * a2) << endl;
//				cout << endl << endl;
			}
			else if(a1 <= 0 && b1 <= 0) cout << a1 * a2 << endl;
		}
		else if(a2 <= 0 && b2 <= 0)
		{
			if(a1 >= 0 && b1 >= 0) cout << b1 * b2 << endl;
			else if(a1 >= 0 && b1 <= 0) 
			{
				cout << b1 * a2 << endl;
			//	cout << b1 << ' ' << a2 << endl;
			}
			else if(a1 <= 0 && b1 <= 0) cout << b1 * a2 << endl;
		}
	}
	return 0;
}
