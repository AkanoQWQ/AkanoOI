#include<bits/stdc++.h>
using namespace std;
int n,m,u[500001],v[500001],p;
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
		cin>>u[i]>>v[i];
	cin>>p;
	for(int i=1;i<=p;i++)
	{
		int t,a,b,c;
		cin>>t;
		if(t==2||t==4)
			cin>>a>>b;
		else
			cin>>a>>b>>c;
		cout<<"NO"<<endl;
	}
}
