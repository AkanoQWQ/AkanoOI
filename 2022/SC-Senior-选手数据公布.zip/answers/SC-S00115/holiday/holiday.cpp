#include<bits/stdc++.h>
using namespace std;
int n,m,k,le[301][1001],tail[301],road[301][301],heap[301][2],las;
long long s[301],ans;
bool res[301],dj[301];
void putin(int num)
{
	while(heap[num][0]<heap[num/2][0]&&num!=1)
	{
		swap(heap[num][0],heap[num/2][0]);
		swap(heap[num][1],heap[num/2][1]);
		num/=2;
	}
}
void putout(int num)
{
	while(num*2+1<=las)
	{
		int rs=false;
		if(heap[num*2][0]<=heap[num*2+1][0])
			if(heap[num*2][0]<heap[num][0])
			{
				swap(heap[num][0],heap[num*2][0]);
				swap(heap[num][1],heap[num*2][1]);
				num*=2;
				rs=true;
			}
		else
			if(heap[num*2+1][0]<heap[num][0])
			{
				swap(heap[num][0],heap[num*2+1][0]);
				swap(heap[num][1],heap[num*2+1][1]);
				num=num*2+1;
				rs=true;
			}
		if(rs==false)
			break;
	}
	if(num*2==las)
		if(heap[num][0]>heap[num*2][0])
		{
			swap(heap[num][0],heap[num*2][0]);
			swap(heap[num][1],heap[num*2][1]);			
		}
}
void djk(int now)
{
	heap[1][1]=now;
	heap[1][0]=0;
	dj[now]=true;
	las++;
	while(las!=0)
	{
		int a=heap[1][1],b=heap[1][0];
		swap(heap[1][0],heap[las][0]);
		swap(heap[1][1],heap[las][1]);
		las--;
		putout(1);
		for(int i=1;i<=tail[a];i++)
		{
			if(dj[le[a][i]]==true)
				continue;
			las++;
			heap[las][0]=b+1;
			heap[las][1]=le[a][i];
			dj[le[a][i]]=true;
			road[now][le[a][i]]=heap[las][0];		
			putin(las); 
		}
	}
}
void find(int l,int t,long long  sum)
{
	if(t==4)
	{
		if(road[l][1]<=k+1)
			ans=max(ans,sum);
		return;
	}
	for(int i=2;i<=n;i++)
	{
		if(res[i]==true)
			continue;
		if(road[l][i]>k+1)
			continue;
		res[i]=true;
		find(i,t+1,sum+s[i]);
		res[i]=false;
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++)
		cin>>s[i];
	for(int i=1;i<=m;i++)
	{
		int a,b;
		cin>>a>>b;
		tail[a]++;
		le[a][tail[a]]=b;
		tail[b]++;
		le[b][tail[b]]=a;
	}
	for(int i=1;i<=n;i++)
	{	
		for(int j=1;j<=n;j++)	
			dj[j]=false;
		las=0;
		djk(i);	
	}
	res[1]=true;
	find(1,0,0ll);
	cout<<ans;
}
