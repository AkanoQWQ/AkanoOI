#include<bits/stdc++.h>
using namespace std;
int n,m,k;
int a[100001],b[100001],amax[100001][20],amin[100001][20],amid[100001][20][2],bmax[100001][20],bmin[100001][20];
long long ans[100001];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		amax[i][0]=a[i];
		amin[i][0]=a[i];
		amid[i][0][0]=a[i];		
	}
	for(int i=1;i<=m;i++)
	{
		cin>>b[i];	
		bmax[i][0]=b[i];
		bmin[i][0]=b[i];	
	}
	for(int i=1;(1<<i)<=n;i++)
	{
		for(int j=1;j+(1<<i)-1<=n;j++)
		{
			amax[j][i]=max(amax[j][i-1],amax[j+(1<<(i-1))][i-1]);
			amin[j][i]=min(amin[j][i-1],amin[j+(1<<(i-1))][i-1]);
			long long p=amid[j][i-1][0],q=amid[j+(1<<(i-1))][i-1][0];
			if(abs(p)<abs(q))
			{
				amid[j][i][0]=p;
				amid[j][i][1]=amid[j][i-1][1];
			}
			if(abs(p)>abs(q))
			{
				amid[j][i][0]=q;
				amid[j][i][1]=amid[j+(1<<(i-1))][i-1][1];
			}
			if(abs(p)==abs(q))
			{
				amid[j][i][0]=p;
				amid[j][i][1]=amid[j][i-1][1];
				if(q==-p)
					amid[j][i][1]=-p;
				if(amid[j+(1<<(i-1))][i-1][1]+p==0)
					amid[j][i][1]=-p;
			}
		}
	}
	for(int i=1;(1<<i)<=m;i++)
	{
		for(int j=1;j+(1<<i)-1<=m;j++)
		{
			bmax[j][i]=max(bmax[j][i-1],bmax[j+(1<<(i-1))][i-1]);
			bmin[j][i]=min(bmin[j][i-1],bmin[j+(1<<(i-1))][i-1]);
		}
	}
	for(int i=1;i<=k;i++)
	{
		int l1,r1,l2,r2;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		long long a1,a2,b1,b2,a3,a4=0;
		int la=r1-l1,lb=r2-l2,al=0,bl=0;
		while(la!=0)
		{
			la=la>>1;
			al++;
		}
		while(lb!=0)
		{
			lb=lb>>1;
			bl++;
		}
		if(bl!=0)
		{
			b1=min(bmin[l2][bl-1],bmin[r2-(1<<(bl-1))+1][bl-1]);
			b2=max(bmax[l2][bl-1],bmax[r2-(1<<(bl-1))+1][bl-1]);			
		}
		else
		{
			b1=b[l2];
			b2=b[l2];
		}
		if(al!=0)
		{
			a1=min(amin[l1][al-1],amin[r1-(1<<(al-1))+1][al-1]);
			a2=max(amax[l1][al-1],amax[r1-(1<<(al-1))+1][al-1]);
			long long p=amid[l1][al-1][0],q=amid[r1-(1<<(al-1))+1][al-1][0];
			if(abs(p)<abs(q))
			{
				a3=p;
				a4=amid[l1][al-1][1];
			}
			if(abs(p)>abs(q))
			{
				a3=q;
				a4=amid[r1-(1<<(al-1))+1][al-1][1];
			}
			if(abs(p)==abs(q))
			{
				a3=p;
				a4=amid[l1][al-1][1];
				if(q==-p)
					a4=-p;
				if(amid[r1-(1<<(al-1))+1][al-1][1]==-p)
					a4=-p;
			}			
		}
		else
		{
			a1=a[l1];
			a2=a[l1];
			a3=a[l1];
			a4=0;
		}
		if(b1>=0&&b2>=0)
		{
			if(a2>=0)
				ans[i]=b1*a2;
			if(a2<0)
				ans[i]=b2*a2;	
			continue;		
		}
		if(b1<=0&&b2<=0)
		{
			if(a1<=0)
				ans[i]=a1*b2;
			if(a1>0)
				ans[i]=a1*b1;
			continue;
		}
		if(b1*b2<0)
		{
			long long  ans1=min(a3*b1,a3*b2);
			if(a4==0)
				ans[i]=ans1;
			else
			{
				long long ans2=min(a4*b1,a4*b2);
				ans[i]=max(ans1,ans2);
			}
			continue;
		}	
	}
	for(int i=1;i<=k;i++)
		printf("%lld\n",ans[i]);
}
