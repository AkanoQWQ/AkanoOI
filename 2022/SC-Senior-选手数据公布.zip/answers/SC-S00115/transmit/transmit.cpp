#include<bits/stdc++.h>
using namespace std;
int n,q,k,v[200001];
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++)
		cin>>v[i];
	for(int i=1;i<=n-1;i++)
	{
		int a,b;
		cin>>a>>b;
	}
	for(int i=1;i<=q;i++)
	{
		int a,b;
		cin>>a>>b;
		cout<<"0"<<endl;
	}
}
