#include<bits/stdc++.h>
#define llg long long
#define reg register
#define maxn 2510
#define maxm 10100
using namespace std;
int n,m,k,cnt,a,b,ans;
struct node
{
	int to,nxt;
}eds[2*maxm];
int head[maxn],vis[maxn];
llg v[maxn];
inline void add(int fr,int to)
{
	eds[++cnt].to=to,eds[cnt].nxt=head[fr],head[fr]=cnt;
}
void dfs(int now,int rest,int has)
{
	vis[now]=1;
	for(reg int i=head[now];i;i=eds[i].nxt)
	{
		int u=eds[i].to;
		
		if(u==1&&rest==0)
		{
			ans=max(ans,has);
			return;
		}
		if(rest&&!vis[u])
			dfs(u,rest-1,has+v[u]);
		
	}
	vis[now]=0;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	ios_base::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>n>>m>>k;
	for(reg int i=2;i<=n;i++)cin>>v[i];
	for(reg int i=1;i<=m;i++)
	{
		cin>>a>>b;
		add(a,b);
		add(b,a);
	}
	dfs(1,4,0);
	cout<<ans;
	return 0;
}
