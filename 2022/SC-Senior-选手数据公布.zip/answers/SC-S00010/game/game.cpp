#include<bits/stdc++.h>
#define ls now<<1
#define rs now<<1|1
#define llg long long
#define in64f 0x3f3f3f3f3f3f3f3f
#define maxn 500100
using namespace std;
int n,m,q,l1,l2,r1,r2;
llg an1,an2;
struct node
{
	llg mv[6];
	node()
	{
		mv[1]=in64f,mv[2]=-in64f,mv[3]=in64f,mv[4]=0;
	}
}mx,my;
class st
{
	public:
	llg as;
	node val[maxn];
	void pushup(node& r,node& a,node& b)
	{
		r.mv[1]=min(a.mv[1],b.mv[1]);
		r.mv[2]=max(a.mv[2],b.mv[2]);
		if((llg)abs(a.mv[3])<(llg)abs(b.mv[3]))r.mv[3]=a.mv[3];
			else r.mv[3]=b.mv[3];
		if((llg)abs(a.mv[4])>(llg)abs(b.mv[4]))r.mv[4]=a.mv[4];
			else r.mv[4]=b.mv[4];
	}
	void build(int now,int l,int r)
	{
		if(l==r)
		{
			cin>>as;
			for(int i=1;i<=4;i++)val[now].mv[i]=as;
			return;
		}
		int mid=l+r>>1;
		build(ls,l,mid);
		build(rs,mid+1,r);
		pushup(val[now],val[ls],val[rs]);
	}
	node ask(int now,int gl,int gr,int l,int r)
	{		
		if(gl<=l&&r<=gr)return val[now];
		node m0,m1,m2;
		int mid=l+r>>1;
		if(gl<=mid)m1=ask(ls,gl,gr,l,mid);
		if(mid<gr)m2=ask(rs,gl,gr,mid+1,r);
		pushup(m0,m1,m2);
		return m0;
	}
}x,y;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	ios_base::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>n>>m>>q;
	x.build(1,1,n);
	y.build(1,1,m);
	while(q--)
	{
		an2=-in64f;
		cin>>l1>>r1>>l2>>r2;
		mx=x.ask(1,l1,r1,1,n);
		my=y.ask(1,l2,r2,1,m);
		for(int i=1;i<=4;i++)
		{
			an1=in64f;
			for(int j=1;j<=4;j++)
				an1=min(an1,mx.mv[i]*my.mv[j]);
			an2=max(an2,an1);
		}
		cout<<an2<<endl;
	}
	return 0;
}
