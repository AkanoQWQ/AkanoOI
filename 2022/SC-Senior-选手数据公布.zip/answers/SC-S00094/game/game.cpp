#include <bits/stdc++.h>
using namespace std;
#define ll long long 
#define mid (l+r)/2
#define lson l,mid,rt<<1
#define rson mid+1,r,rt<<1|1

const int maxn=1e5+10;
int n,m,q,lx,rx,ly,ry;
ll a[2][maxn],ans=0;
struct node{
  ll mx,mn,zheng,fu;
  bool vis_zh=false,vis_f=false;
}t[2][maxn*4],ita,itb;

int read(){
  int x=0,f=1;char ch=getchar();
  while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
  while(isdigit(ch)){x=(x<<3)+(x<<1)+ch-'0';ch=getchar();}
  return x*f;
}

ll llread(){
  ll x=0,f=1ll;char ch=getchar();
  while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
  while(isdigit(ch)){x=(x<<3)+(x<<1)+ch-'0';ch=getchar();}
  return x*f;
}

void pushup(int op,int rt){
  t[op][rt].mx=max(t[op][rt<<1].mx,t[op][rt<<1|1].mx);
  t[op][rt].mn=min(t[op][rt<<1].mn,t[op][rt<<1|1].mn);
  if(t[op][rt<<1].vis_zh||t[op][rt<<1|1].vis_zh){
    t[op][rt].vis_zh=true;
    if(t[op][rt<<1].vis_zh){
      t[op][rt].zheng=t[op][rt<<1].zheng;
      if(t[op][rt<<1|1].vis_zh) t[op][rt].zheng=min(t[op][rt<<1|1].zheng,t[op][rt].zheng);
    }
    else t[op][rt].zheng=t[op][rt<<1|1].zheng;
  }
  else t[op][rt].vis_zh=false;
  if(t[op][rt<<1].vis_f||t[op][rt<<1|1].vis_f){
    t[op][rt].vis_f=true;
    if(t[op][rt<<1].vis_f){
      t[op][rt].fu=t[op][rt<<1].fu;
      if(t[op][rt<<1|1].vis_f) t[op][rt].fu=max(t[op][rt<<1|1].fu,t[op][rt].fu);
    }
    else t[op][rt].fu=t[op][rt<<1|1].fu;
  }
  else t[op][rt].vis_f=false;
}

void build(int op,int l,int r,int rt){
  if(l==r){
    t[op][rt].mx=t[op][rt].mn=a[op][l];
    if(a[op][l]>=0) t[op][rt].vis_zh=true,t[op][rt].zheng=a[op][l];
    if(a[op][l]<=0) t[op][rt].vis_f=true,t[op][rt].fu=a[op][l];
    return;
  }
  build(op,lson);
  build(op,rson);
  pushup(op,rt);
}

node query(int op,int l,int r,int rt,int X,int Y){
  if(X<=l&&Y>=r) return t[op][rt];
  node res,it;
  if(X<=mid&&Y<=mid) res=query(op,lson,X,Y);
  if(Y>mid&&X>mid) res=query(op,rson,X,Y);
  if(X<=mid&&Y>mid){
    res=query(op,lson,X,Y);
    it=query(op,rson,X,Y);
    res.mx=max(res.mx,it.mx);res.mn=min(res.mn,it.mn);
    if(res.vis_zh||it.vis_zh){
      if(!res.vis_zh&&it.vis_zh) res.zheng=it.zheng;
      else if(it.vis_zh) res.zheng=min(res.zheng,it.zheng);
      res.vis_zh=true;
    }
    else res.vis_zh=false;
    if(res.vis_f||it.vis_f){
      if(!res.vis_f&&it.vis_f) res.fu=it.fu;
      else if(it.vis_f) res.fu=max(res.fu,it.fu);
      res.vis_f=true;
    }
    else res.vis_f=false;
  }
  return res; 
}

void print(ll x){
  if(x==0){putchar('0'),putchar('\n');return;}
  if(x<0) putchar('-'),x=-x;
  int cnt=0,p[20];
  while(x) p[++cnt]=x%10,x/=10;
  while(cnt) putchar(p[cnt--]+'0');
  putchar('\n');
}

int main(){
  freopen("game.in","r",stdin);
  freopen("game.out","w",stdout);
  n=read();m=read();q=read();
  for(int i=1;i<=n;i++) a[0][i]=llread();
  for(int j=1;j<=m;j++) a[1][j]=llread();
  build(0,1,n,1);build(1,1,m,1);
  for(int i=1;i<=q;i++){
    lx=read(),rx=read();ly=read();ry=read();
    ita=query(0,1,n,1,lx,rx);
    itb=query(1,1,m,1,ly,ry);
    //cout<<ita.mx<<' '<<ita.mn<<' '<<ita.zheng<<' '<<ita.fu<<endl;
    //cout<<itb.mx<<' '<<itb.mn<<' '<<itb.zheng<<' '<<itb.fu<<endl;
	if(itb.mn>=0){
      if(ita.mx<0) ans=1ll*ita.mx*itb.mx;
      else ans=1ll*ita.mx*itb.mn;
    }
    else{
      if(itb.mx<=0){
        if(ita.mn>=0) ans=1ll*ita.mn*itb.mn;
        else ans=1ll*ita.mn*itb.mx;
      }
      else{
        if(ita.vis_zh&&ita.zheng==0) ans=0ll;
        else{
          if(ita.mn>=0) ans=1ll*ita.mn*itb.mn;
          else{
            if(ita.mx<=0) ans=1ll*ita.mx*itb.mx;
            else ans=max(1ll*ita.zheng*itb.mn,1ll*ita.fu*itb.mx);
          }
        }
      }
    }
    print(ans);
  }
  return 0;
}
