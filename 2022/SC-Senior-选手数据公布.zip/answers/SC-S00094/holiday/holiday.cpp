#include <bits/stdc++.h>
using namespace std;
#define ull unsigned long long

const int maxn=1e4+10;
int n,m,k,tot=0,head[maxn],pp[maxn][5][5],num[maxn][5];
ull s[maxn],dp[maxn][6],ans=0ull;
bool vis[2505][2505],f[maxn];
struct edge{
  int v,nxt;
}e[maxn*2];

int read(){
  int x=0,l=1;char ch=getchar();
  while(!isdigit(ch)){if(ch=='-') l=-1;ch=getchar();}
  while(isdigit(ch)){x=(x<<3)+(x<<1)+ch-'0';ch=getchar();}
  return x*l;
}

ull ullread(){
  ull x=0,l=1ll;char ch=getchar();
  while(!isdigit(ch)){if(ch=='-') l=-1;ch=getchar();}
  while(isdigit(ch)){x=(x<<3)+(x<<1)+ch-'0';ch=getchar();}
  return x*l;
}

void add(int u,int v){
  e[++tot]=(edge){v,head[u]};
  head[u]=tot;
}

void build(int x){
  queue<pair<int,int> >q;
  for(int i=1;i<=n;i++) f[i]=false;
  q.push(make_pair(x,-1));
  f[x]=true;
  while(!q.empty()){
  	int u=q.front().first,numb=q.front().second;q.pop();
  	vis[x][u]=vis[u][x]=true;
  	if(numb==k) continue;
  	for(int i=head[u];i;i=e[i].nxt){
  	  int v=e[i].v;
	  if(f[v]) continue;
	  f[v]=true;
	  q.push(make_pair(v,numb+1));	
	}
  }
}

void print(ull X){
  if(X==0ull){putchar('0'),putchar('\n');return;}
  int cnt=0,p[20];
  while(X) p[++cnt]=X%10,X/=10;
  while(cnt) putchar(p[cnt--]+'0');
  putchar('\n');
}

bool check(int x,int y,int q){
  for(int i=1;i<=y;i++) if(pp[x][y][i]==q) return false;
  return true;
}

int main(){
  freopen("holiday.in","r",stdin);
  freopen("holiday.out","w",stdout);
  n=read();m=read();k=read();
  for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) vis[i][j]=false;
  for(int i=2;i<=n;i++) s[i]=ullread();
  for(int i=1,u,v;i<=m;i++){
  	u=read(),v=read();
  	add(u,v),add(v,u);
  }
  for(int i=1;i<=n;i++) build(i);
  for(int i=2;i<=n;i++){
  	if(vis[1][i]) dp[i][1]=s[i],pp[i][1][1]=i,num[i][1]=1;
  }
  for(int j=2;j<=4;j++)
    for(int i=2;i<=n;i++){
      for(int p=2;p<=n;p++){
        if(vis[i][p]&&check(p,j-1,i)&&p!=1&&num[p][j-1]==j-1)
          if(dp[p][j-1]+s[i]>dp[i][j]){
          	dp[i][j]=dp[p][j-1]+s[i];
          	for(int q=1;q<=j-1;q++) pp[i][j][q]=pp[p][j-1][q];
          	pp[i][j][j]=i;num[i][j]=j;
		  }       	
	  }
	}
  for(int i=2;i<=n;i++) if(vis[1][i]&&num[i][4]==4) ans=max(ans,dp[i][4]);
  print(ans);
  return 0;
}
