#include <bits/stdc++.h>
using namespace std;

long long ans;
long long i, j;
long long n, m, q;
long long l[3], r[3];
long long xiao, da;
long long a[100005], b[100005];

int main()
{
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	
	cin >> n >> m >> q;
	
	for(i = 1; i <= n; i++)
		cin >> a[i];
	for(i = 1; i <= m; i++)
		cin >> b[i];

	for(i = 1; i <= q; i++)
	{
		cin >> l[1] >> r[1] >> l[2] >> r[2];
		xiao = 1e10;
		ans = -1e18;
		da = -1e10;
		
		for(j = l[2]; j <= r[2]; j++)
		{
			xiao = min(xiao, b[j]);
			da = max(da, b[j]);
		}
		
		for(j = l[1]; j <= r[1]; j++)
			ans = max(ans, min(a[j] * da, a[j] * xiao));
		
		cout << ans << "\n";
	}
	return 0;
}
//rp++
