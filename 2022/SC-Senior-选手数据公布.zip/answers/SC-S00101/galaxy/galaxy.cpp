#include <bits/stdc++.h>
using namespace std;

int q;
int bj;
int jsq;
int i, j;
int n, m;
bool bjd[50005];
bool mem[50005];
int t, x, y;

map < int, bool > zh[50005];
set < int > ni[50005];

bool dfs(int cur)
{
	bool ans = 0;
	bjd[cur] = 1;
	
	if(mem[cur] != -1)
		return mem[cur];

	for(map < int, bool >::iterator it = zh[cur].begin(); it != zh[cur].end(); it++)
	{
		if((*it).second)
		{
			
			if(bjd[(*it).first])
				return mem[cur] = 1;
			ans = (ans || dfs((*it).first)); 
		}
	}
	
	return mem[cur] = ans;
}

int main()
{
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	
	scanf("%d %d", &n, &m);
	
	for(i = 1; i <= m; i++)
	{
		scanf("%d %d", &x, &y);
		ni[y].insert(x);
		zh[x].insert(make_pair(y, 1));
	}
	
	scanf("%d %d", &q);
	
	for(i = 1; i <= q; i++)
	{
		bj = 0;
		scanf("%d", &t);
		
		if(t == 1)
		{
			scanf("%d %d", &x, &y);
			zh[x][y] = 0;
		}
		if(t == 2)
		{
			scanf("%d", &x);
			
			for(set < int >::iterator it = ni[x].begin(); it != ni[x].end(); it++)
				zh[(*it)][x] = 0;
		}
		if(t == 3)
		{
			scanf("%d %d", &x, &y);
			zh[x][y] = 1;
		}
		if(t == 4)
		{
			scanf("%d", &x);

			for(set < int >::iterator it = ni[x].begin(); it != ni[x].end(); it++)
				zh[(*it)][x] = 1;
		}
		
		for(j = 1; j <= n; j++)
		{
			jsq = 0;

			for(map < int, bool >::iterator it = zh[j].begin(); it != zh[j].end(); it++)
				jsq += int((*it).second);

			if(jsq != 1)
			{
				bj = 1;
				printf("NO\n");
				break;
			}
		}
		
		if(bj == 1)
			continue;
		
		for(j = 1; j <= n; j++)
			mem[j] = -1;
		
		for(j = 1; j <= n; j++)
		{
			memset(bjd, 0, sizeof(bjd));

			if(!dfs(j))
			{
				bj = 1;
				printf("NO\n");
				break;
			}
		}

		if(bj == 1)
			continue;
		
		printf("YES\n");
	}
	return 0;
}
//rp++
