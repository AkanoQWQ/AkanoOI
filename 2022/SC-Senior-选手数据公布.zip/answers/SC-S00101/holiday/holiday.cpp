#include <bits/stdc++.h>
using namespace std;

long long sum;
long long ansd = -1e18;
long long x, y;
long long s[305];
long long n, m, p;
long long bj[305];
long long dis[305][305];

void dfs(long long dk, long long dn)
{
	long long i;
	
	if(dk == 7)
	{
		if(dn == 1)
			ansd = max(ansd, sum);
		return;
	}
	
	for(i = 1; i <= n; i++)
	{
		if(bj[i] == 0 && dis[dn][i] - 1 <= p && i != dn)
		{
			bj[i] = 1;
			bj[1] = 0;
			sum += s[i];
			dfs(dk + 1, i);
			sum -= s[i];
			bj[i] = 0;
		}
	}
	
	return;
}

int main()
{
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	
	long long i, j, k;
	cin >> n >> m >> p;
	
	for(i = 2; i <= n; i++)
		cin >> s[i];
	
	for(i = 1; i <= n; i++)
		for(j = 1; j <= n; j++)
			dis[i][j] = 1e18;
	
	for(i = 1; i <= m; i++)
	{
		cin >> x >> y;
		dis[x][y] = dis[y][x] = 1;
	}

	for(k = 1; k <= n; k++)
		for(i = 1; i <= n; i++)
			for(j = 1; j <= n; j++)
				dis[i][j] = min(dis[i][j], dis[i][k] + dis[k][j]);
	
	memset(bj, 0, sizeof(bj));

	dfs(2, 1);

	cout << ansd;
	return 0;
}
//rp++
