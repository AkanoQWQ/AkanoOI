#include <cstdio>
#include <vector>
#include <algorithm>
using std :: vector;
typedef long long ll;

const int MAXN = 2 * 1e5 + 5;
int n, Q, k;
int v[MAXN], p[MAXN][22], dep[MAXN];
int path[MAXN], top, path1[MAXN], top1;
ll dis[MAXN];
vector <int> g[MAXN];

void dfs(int u, int fa){
	p[u][0] = fa;
	dis[u] = dis[fa] + v[u];
	dep[u] = dep[fa] + 1;
	for(int i = 1; i <= 20; i++) p[u][i] = p[p[u][i - 1]][i - 1];
	for(int v : g[u]){
		if(v == fa) continue;
		dfs(v, u);
	}
}

int lca(int u, int v){
	if(dep[u] < dep[v]) std :: swap(u, v);
	for(int i = 20; i >= 0; i--){
		if(dep[p[u][i]] >= dep[v]) u = p[u][i];
	}
	if(u == v) return u;
	for(int i = 20; i >= 0; i--){
		if(p[u][i] != p[v][i]){
			u = p[u][i];
			v = p[v][i];
		}
	}
	return p[u][0];
}

int main(){
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	scanf("%d%d%d", &n, &Q, &k);
	for(int i = 1; i <= n; i++) scanf("%d", &v[i]);
	for(int i = 1; i < n; i++){
		int u, v; scanf("%d%d", &u, &v);
		g[u].push_back(v);
		g[v].push_back(u);
	}
	dfs(1, 0);
	if(k == 1){
		while(Q--){
			int s, t; scanf("%d%d", &s, &t);
			int lc = lca(s, t);
			printf("%lld\n", dis[s] + dis[t] - 2 * dis[lc] + v[lc]);	
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
