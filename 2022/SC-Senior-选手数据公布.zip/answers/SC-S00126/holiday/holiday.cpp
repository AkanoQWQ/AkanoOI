#include <queue>
#include <cstdio>
#include <vector>
#include <cstring>
using std :: queue;
using std :: vector;
typedef long long ll;

const int MAXN = 2500;
int n, m, k;
ll a[MAXN], ans;
int to1[MAXN][MAXN];
queue <int> q;
vector <int> g[MAXN];

void dfs(int fin, int u, int dep){
//	printf("u = %d, dep = %d\n", u, dep);
	q.push(u);
	to1[fin][u] = -1;
	while(!q.empty()){
		int tu = q.front(); q.pop();
		if(to1[fin][tu] == k) continue;
		for(int v : g[tu]){
			if(to1[fin][v] == 0x3f3f3f3f){
				q.push(v);
				to1[fin][v] = to1[fin][tu] + 1;
			}
		}
	}
}

int main(){
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	for(int i = 2; i <= n; i++) scanf("%lld", &a[i]);
	for(int i = 1; i <= m; i++){
		int u, v; scanf("%d%d", &u, &v);
		g[u].push_back(v);
		g[v].push_back(u);
	}
	memset(to1, 0x3f, sizeof(to1));
	for(int i = 1; i <= n; i++) dfs(i, i, -1);
	for(int i = 1; i <= n; i++){
		g[i].clear();
		for(int j = 1; j <= n; j++){
			if(to1[i][j] != 0x3f3f3f3f){
				g[i].push_back(j);
			}
		}
	}
	for(int i : g[1]){
		if(i == 1) continue;
		for(int j : g[i]){
			if(i == j) continue;
			if(j == 1) continue;
			for(int p : g[j]){
				if(p == 1) continue;
				if(i == p || j == p) continue;
				for(int q : g[p]){
					if(q == 1) continue;
					if(i == q || j == q || p == q) continue;
					if(to1[q][1] != 0x3f3f3f3f)
					ans = std :: max(ans, a[i] + a[j] + a[p] + a[q]);
				}	
			}
		}
	}
	printf("%lld\n", ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
