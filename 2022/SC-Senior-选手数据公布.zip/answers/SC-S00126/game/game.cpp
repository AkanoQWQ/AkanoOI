#include <cstdio>
#include <cstring>
#include <algorithm>
typedef long long ll;

const int MAXN = 1e5 + 5;
const int MAXN1 = 1e3 + 5;
int n, m, q;
int A[MAXN], B[MAXN], lg2[MAXN], num[MAXN][2];

struct Node{
	int mx, mn, fmx, fmn;
};

namespace Segment_Tree{
	int mx[MAXN << 2][2], mn[MAXN << 2][2];
	int fmx[MAXN << 2][2], fmn[MAXN << 2][2];
	int ls(int p){ return p << 1; }
	int rs(int p){ return p << 1 | 1; }
	void push_up(int p, int flag){
		mx[p][flag] = std :: max(mx[ls(p)][flag], mx[rs(p)][flag]);
		mn[p][flag] = std :: min(mn[ls(p)][flag], mn[rs(p)][flag]);
		fmx[p][flag] = std :: max(fmx[ls(p)][flag], fmx[rs(p)][flag]);
		fmn[p][flag] = std :: min(fmn[ls(p)][flag], fmn[rs(p)][flag]);
	}
	void build(int p, int l, int r, int flag){
		if(l == r){
			mx[p][flag] = num[l][flag];
			mn[p][flag] = num[l][flag];
			if(num[l][flag] > 0) fmn[p][flag] = num[l][flag], fmx[p][flag] = -1e9;
			else if(num[l][flag] < 0) fmx[p][flag] = num[l][flag], fmn[p][flag] = 1e9;
			else fmx[p][flag] = fmn[p][flag] = 0;
			return;
		}
		int mid = (l + r) >> 1;
		build(ls(p), l, mid, flag);
		build(rs(p), mid + 1, r, flag);
		push_up(p, flag);
	}
	Node query(int p, int l, int r, int ql, int qr, int flag){
		if(ql <= l && r <= qr){
			return (Node){mx[p][flag], mn[p][flag], fmx[p][flag], fmn[p][flag]};
		}
		int mid = (l + r) >> 1;
		Node res = (Node){-1000000000, 1000000000, -1000000000, 1000000000};
		Node res1 = (Node){-1000000000, 1000000000, -1000000000, 1000000000};
		bool flag1 = false;
		if(ql <= mid){
			flag1 = true;
			res1 = query(ls(p), l, mid, ql, qr, flag);
		}
		if(qr > mid){
			Node res2 = query(rs(p), mid + 1, r, ql, qr, flag);
			if(!flag1) return res2;
			else{
				res.mx = std :: max(res1.mx, res2.mx);
				res.mn = std :: min(res1.mn, res2.mn);
				res.fmn = std :: min(res1.fmn, res2.fmn);
				res.fmx = std :: max(res1.fmx, res2.fmx);
				return res;
			}
		}
		return res1;
	}
}using namespace Segment_Tree;

int main(){
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &q);
	for(int i = 1; i <= n; i++){
		scanf("%d", &A[i]);
		num[i][0] = A[i];
	}
	for(int i = 1; i <= m; i++){
		scanf("%d", &B[i]);
		num[i][1] = B[i];
	}
	memset(mx, 0xcf, sizeof(mx));
	memset(mn, 0x3f, sizeof(mn));
	memset(fmx, 0xcf, sizeof(mx));
	memset(fmn, 0x3f, sizeof(mn));
	build(1, 1, n, 0);
	build(1, 1, m, 1);
	for(int i = 1; i <= q; i++){
		int l1, r1, l2, r2; scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
		ll ans = -1e18;
		Node res1 = query(1, 1, n, l1, r1, 0);
		Node res2 = query(1, 1, m, l2, r2, 1);
		if(res2.mx < 0){
			if(res1.mx < 0){
				ans = 1ll * res1.mn * res2.mx;
			}else{
				if(res1.mn > 0){
					ans = 1ll * res1.mn * res2.mn;
				}else{
					ans = 1ll * res1.mn * res2.mx;
				}
			}
		}else{
			if(res2.mn > 0){
				if(res1.mx < 0){
					ans = 1ll * res1.mx * res2.mx;
				}else{
					if(res1.mn > 0){
						ans = 1ll * res1.mx * res2.mn;
					}else{
						ans = 1ll * res1.mx * res2.mn;
					}
				}
			}else{
				if(res1.mx < 0){
					ans = 1ll * res1.mx * res2.mx;
				}else{
					if(res1.mn > 0){
						ans = 1ll * res1.mn * res2.mn;
					}else{
						ans = std :: max(1ll * res1.fmn * res2.mn, 1ll * res1.fmx * res2.mx);
					}
				}
			}
		}
		printf("%lld\n", ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
3 6 -3 -9
-1 -2 1 3
-2 -4 2 6
1 2 -1 -3
2 4 -2 -6
0 0 0 0
*/
