#include <bits/stdc++.h>
using namespace std;
const int N = 5010;
int n,m,q,a[N],b[N],f[N][N];
inline int read(){
	int f = 1,k = 0;
	char c = getchar();
	while(c != '-'&&(c < '0'||c > '9'))c = getchar();
	if(c == '-')f = -1,c = getchar();
	while(c >= '0'&&c <= '9')k = (k << 1) + (k << 3) + c - '0',c = getchar();
	return f * k;
}

int query(int l,int r,int s,int t){
	priority_queue<int>q;
	for(int i = l;i <= r;i ++){
		int mnx = 0x3f,mxx = 0;
		for(int j = s;j <= t;j ++){
			if(f[i][j] < mnx)mnx = f[i][j];
		}
		q.push(mnx);
	}
	return q.top();
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n = read(),m = read(),q = read();
	for(int i = 1;i <= n;i ++) a[i] = read();
	for(int i = 1;i <= m;i ++) b[i] = read();
	for(int i = 1;i <= n;i ++){
		for(int j = 1;j <= m;j ++){
			f[i][j] = a[i] * b[j];
		} 
	}
	while(q --){
		int l = read(),r = read(),s = read(),t = read();
		printf("%d\n",query(l,r,s,t));
	}
	return 0;
}
