#include <bits/stdc++.h>
#define ll long long
using namespace std;
const ll N = 5e5 + 10; 
int n,q2,k,idx,head[N],v[N],dis1[N],dis2[N];
bool st[N];
typedef pair<int,int> pii;
inline ll read(){
	int f = 1,k = 0;
	char c = getchar();
	while(c != '-'&&(c < '0'||c > '9'))c = getchar();
	if(c == '-')f = -1,c = getchar();
	while(c >= '0'&&c <= '9')k = (k << 1) + (k << 3) + c - '0',c = getchar();
	return f * k;
}
struct edge{
	ll len,u;
	bool operator < (const edge&a) const {
		return len > a.len;
	}
};
struct node{
	int v,w,nxt;
}e[N];
void add(int u,int v,int w){
	e[idx].v = v;
	e[idx].w = w;
	e[idx].nxt = head[u];
	head[u] = idx ++;
}
void dijkstra(int s,int* dis){
	memset(dis,0x3f,sizeof dis);
	memset(st,false,sizeof st);
	priority_queue<edge>q1;
	dis[s] = 0;
	q1.push(edge{dis[s],s});
	while(!q1.empty()){
		edge top = q1.top();q1.pop();
		int u = top.u;
		if(st[u]) continue;
		st[u] = 1;
		for(int i = head[u];i != -1;i = e[i].nxt){
			int t = e[i].v;
			if(dis[t] > dis[u] + e[i].w){
				dis[t] = dis[u] + e[i].w;
				q1.push(edge{dis[t],t});
			}
		}
	}
}
ll query(int x,int y){
	memset(dis1,0x3f,sizeof dis1);
	memset(dis2,0x3f,sizeof dis2);
	dijkstra(x,dis1),dijkstra(y,dis2);
	if(dis1[y] <= k&&dis2[x] <= k){
		return v[x] + v[y];
	}
	ll ans = 0x3f;
	for(int i = 1;i <= n;i ++){
		if(dis1[i] <= k&&dis2[i] <= k){
			if(v[x] + v[y] + v[i] < ans)ans = v[x] + v[y] + v[i];
		}
	}
	return ans;
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	memset(head,-1,sizeof head);
	scanf("%d %d %d",&n,&q2,&k);
	for(int i = 1;i <= n;i ++) scanf("%d",&v[i]);
	for(int i = 1;i <= n - 1;i ++){
		int x = read(),y = read();
		add(x,y,1);add(y,x,1);
	}
	while(q2 --){
		int x = read(),y = read();
		printf("%lld\n",query(x,y));
	}
	return 0;
}
