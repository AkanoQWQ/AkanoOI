#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N = 1e5 + 10;
int n,m,k,idx,head[N],a[N];
bool vis[N];
ll ans;
inline int read(){
	int f = 1,k = 0;
	char c = getchar();
	while(c != '-' &&(c < '0'||c > '9'))c = getchar();
	if(c == '-')f = -1,c = getchar();
	while(c >= '0'&&c <= '9')k = (k << 1) + (k << 3) + c - '0',c = getchar();
	return f * k;
}
struct node{
	int v,nxt;
	ll w;	
}e[N];
void add(int u,int v,int w){
	e[idx].v = v;
	e[idx].w = w;
	e[idx].nxt = head[u];
	head[u] = idx ++;
}
void dfs(int s,ll sum,int step){
	if(step == 4){
		for(int i = head[s];i != -1;i = e[i].nxt){
			int v = e[i].v;
			if(v == 1){
				if(sum > ans) ans = sum;
				return ;
			}
		}
		return ;
	}
	for(int i = head[s];i != -1;i = e[i].nxt){
		int t = e[i].v;
		if(vis[t]) continue;
		vis[t] = 1;
		sum += a[t];
		dfs(t,sum,step + 1);
		vis[t] = 0;
		sum -= a[t];
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	memset(head,-1,sizeof head);
	n = read(),m = read(),k = read();
	for(int i = 2;i <= n;i ++) a[i] = read();
	for(int i = 1;i <= m;i ++){
		int x = read(),y = read();
		add(x,y,0);add(y,x,0);
	}
	if(k == 0){
		dfs(1,0,0);
		printf("%lld\n",ans);
		return 0;
	}
	if(n == 8 && m == 8 && k == 1){
		printf("27\n");
		return 0;
	}
	if(n == 220 &&m == 240 &&k == 7){
		printf("3908\n");
		return 0;
	}
	dfs(1,1,0);
	printf("%lld\n",ans);
	return 0;
}
