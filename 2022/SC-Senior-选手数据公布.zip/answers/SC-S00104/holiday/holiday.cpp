#include<cstdio>
#include<cctype>
#include<cstdlib>
typedef long long LL;
namespace FastIo{
	#define gc getchar()
	#define pc(ch) putchar(ch)
	#define P(A) A=-~A
	#define fione_i(begin,end) for(register int i=begin;i<=end;P(i))
	struct QIO{
		char ch;
		int st[40];
		bool pd;
		template<class T>inline void read(T &x){
			ch=gc,x=0,pd=false;
			while(!isdigit(ch)){pd=ch=='-'?true:false;ch=gc;}
			while(isdigit(ch)){x=(x<<3)+(x<<1)+(ch^48);ch=gc;}
			if(pd)x=-x;
		}
		template<class T>inline void write(T a){
			if(a<0)a=-a,pc('-');
			do{st[++st[0]]=a%10;a/=10;}while(a);
			while(st[0])pc(st[st[0]--]^48);
		}
	}qrw;
}
using namespace FastIo;
#include<vector>
#include<queue>
#include<algorithm>
using std::max;
using std::vector;
using std::priority_queue;
#define NUMBER1 2500
#define NUMBER2 100
struct EDGE{
	int v,k,len;
	LL point;
	bool pd[NUMBER1+5];
	bool operator<(const EDGE &A)const{return point<A.point;}
};
vector<EDGE>e[NUMBER1+100];
priority_queue<EDGE>s;
int a[NUMBER1+5];
signed main(){
	LL ans(0);
	EDGE A,B;
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int n,m,u,v,k;
	qrw.read(n);
	qrw.read(m);
	qrw.read(k);
	A.len=B.len=4,A.k=B.k=k;
	fione_i(2,n)qrw.read(a[i]);
	while(m--){
		qrw.read(u);
		qrw.read(v);
		A.v=v,A.point=a[v],B.v=u,B.point=a[u];
		e[u].push_back(A),e[v].push_back(B);
	}
	A.v=1,A.point=0;
	s.push(A);
	while(!s.empty()){
		A=s.top();
		s.pop();
		if(!A.len){
			if(A.k>0)ans=max(ans,A.point); 
			else
				fione_i(0,e[A.v].size()-1)
					if(e[A.v][i].v==1){
						ans=max(ans,A.point);
						break;
					}
			continue;
		}
		B=A;
		--B.len;
		fione_i(0,e[A.v].size()-1){
			B.v=e[A.v][i].v;
			if(!A.pd[B.v]){
				B.pd[B.v]=true; 
				B.point+=e[A.v][i].point;	
				s.push(B);
				B.point-=e[A.v][i].point;
				B.pd[B.v]=false;
			}else s.push(B);
		}
		--B.k;
		if(B.k>0){
			fione_i(1,n){
				if(i==A.v)continue;
				B.v=i;
				if(!B.pd[i]){
					B.pd[i]=true;
					B.point+=a[i];
				s.push(B);
					B.point-=a[i];
					B.pd[i]=false;
				}else s.push(B);
			}
		}
	}
	qrw.write(ans);
	exit(0);
	return 0;
}
