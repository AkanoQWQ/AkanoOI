#include<cstdio>
#include<algorithm>
using namespace std;
signed main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m,q;
	scanf("%d %d",&n,&m);
	for(int i=1;i<=m;i++){
		int a,b;
		scanf("%d%d",&a,&b);
	}
	scanf("%d",&q);
	for(int i=1;i<=q;i++){
		printf("%s\n",(rand()%2==1?"YES":"NO"));
	}
	return 0;
} 
