#include<cstdio>
#include<algorithm>
using std::max;
using std::min;
#include<cctype>
#include<cstdlib>
typedef long long LL;
namespace FastIo{
	#define gc getchar()
	#define pc(ch) putchar(ch)
	#define P(A) A=-~A
	#define fione_i(begin,end) for(register int i=begin;i<=end;P(i))
	struct QIO{
		char ch;
		int st[40];
		bool pd;
		template<class T>inline void read(T &x){
			ch=gc,x=0,pd=false;
			while(!isdigit(ch)){pd=ch=='-'?true:false;ch=gc;}
			while(isdigit(ch)){x=(x<<3)+(x<<1)+(ch^48);ch=gc;}
			if(pd)x=-x;
		}
		template<class T>inline void write(T a){
			if(a<0)a=-a,pc('-');
			do{st[++st[0]]=a%10;a/=10;}while(a);
			while(st[0])pc(st[st[0]--]^48);
			pc('\n');
		}
	}qrw;
}
using namespace FastIo;
#define NUMBER1 10000
#define INF 1e18
LL a[NUMBER1+5],b[NUMBER1+5];
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q;
	qrw.read(n);
	qrw.read(m);
	qrw.read(q);
	fione_i(1,n)qrw.read(a[i]);
	fione_i(1,m)qrw.read(b[i]);
	while(q--){
		bool pd1(false),pd2(false);
		int l1,l2,r1,r2;
		LL max1=-INF,max2=-INF,min1=INF,min2=INF,x(INF),y(INF),max11=-INF,min11=INF,max22=-INF,min22=INF;
		qrw.read(l1);
		qrw.read(r1);
		qrw.read(l2);
		qrw.read(r2);
		fione_i(l1,r1){
			pd1|=(!a[i]),max1=max(max1,a[i]),min1=min(min1,a[i]);
			if(a[i]>0)min11=min(min11,a[i]);
			if(a[i]<0)max11=max(max11,a[i]);
		}
		fione_i(l2,r2){
			pd2|=(!b[i]),max2=max(max2,b[i]),min2=min(min2,b[i]);
			if(b[i]>0)min22=min(min22,b[i]);
			if(b[i]<0)max22=max(max22,b[i]);
		}
		if(pd1&&pd2){
			qrw.write(0);
			continue;
		}
		if(pd1){
			if((min1>=0&&max2<0)||(max1<=0&&min2>0)||(min2<0&&max2>0)){
				qrw.write(0);
				continue;
			}
			if(min1>=0&&min2>0){
				qrw.write(max1*min2);
				continue;
			}
			qrw.write(min1*max2);
			continue;
		}
		if(pd2){
			if((min2>=0&&min1>0)||(max2<=0&&max2<0)||(max1>0&&min1<0)){
				qrw.write(0);
				continue;
			}
			if(min1>0&&max2<=0){
				qrw.write(max1*min2);
				continue;
			}
			qrw.write(min1*max2);
			continue;
		}
		if(min1>0&&min2>0){
			qrw.write(max1*min2);
			continue;
		}
		if(max1>0&&min2>0){
			qrw.write(max1*min2);
			continue;
		}
		if(max1>0&&max2<0){
			qrw.write(min1*min2);
			continue;
		}
		if(max1<0&&min2>0){
			qrw.write(max2*max1);
			continue;
		}
		if(max1<0&&max2<0){
			qrw.write(max1*min2);
			continue;
		}
		//printf("%d %d %d %d",max11,min11,max22,min22);
		LL ans=min(max11*min22,max22*min11);
		qrw.write(ans);
	}
	exit(0);
	return 0;
}
