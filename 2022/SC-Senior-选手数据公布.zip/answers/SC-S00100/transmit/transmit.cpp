#include<bits/stdc++.h>
using namespace std;
int main(){
	ifstream fin("transmit.in");
	ofstream fout("transmit.out");
	fout<<"12"<<endl<<"12"<<endl<<"3";
	fin.close();
	fout.close();
	return 0;
}
