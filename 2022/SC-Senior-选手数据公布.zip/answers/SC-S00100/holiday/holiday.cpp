#include<bits/stdc++.h>
using namespace std;
int n,m,k0,u,v,w1;
int sco[350];
int vit[350]={0},ans[350]={0},avit=0;
int stp=0;
int main(){
	ifstream fin("holiday.in");
	ofstream fout("holiday.out");
	fin>>n>>m>>k0;
	sco[1]=0;
	for(int i=2;i<=n;i++){
		fin>>sco[i];
	}
	sort(sco+1,sco+1+n);
	fout<<sco[n]+sco[n-1]+sco[n-2]+sco[n-3];
	return 0;
	fin.close();
	fout.close();
} 

