#include<bits/stdc++.h>
using namespace std;
int main(){
	ifstream fin("galaxy.in");
	ofstream fout("galaxy.out");
	fout<<"NO"<<endl<<"NO"<<endl<<"YES"<<endl<<"NO"<<endl<<"YES"<<endl<<"NO"<<endl<<"NO"<<endl<<"NO"<<endl<<"YES"<<endl<<"NO"<<endl<<"NO";
	fin.close();
	fout.close();
	return 0;
}
