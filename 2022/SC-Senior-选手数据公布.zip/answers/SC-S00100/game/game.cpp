#include<bits/stdc++.h>
using namespace std;
#include<bits/stdc++.h>
using namespace std;
int A[100005],B[100005];
ifstream fin("game.in");
ofstream fout("game.out");
int zmax(int l,int r,bool pw){
	if(pw){
		sort(A+1+l,A+1+r);
		return A[r];
	}else{
		sort(B+1+l,B+1+r);
		return B[r];
	}
}
int zmin(int l,int r,bool pw){
	if(pw){
		sort(A+1+l,A+1+r);
		return A[l];
	}else{
		sort(B+1+l,B+1+r);
		return B[l];
	}
}
int main(){
	int n,m,q;
	fin>>n>>m>>q;
	for(int i=1;i<=n;i++){
		fin>>A[i];
	}
	for(int i=1;i<=m;i++){
		fin>>B[i];
	}
	int l1,l2,r1,r2;
	for(int i=1;i<=q;i++){
		fin>>l1>>r1>>l2>>r2;
		fout<<zmax(l1,r1,1)*zmin(l2,r2,0)<<endl;
	}
	fin.close();
	fout.close();
	return 0;
}
