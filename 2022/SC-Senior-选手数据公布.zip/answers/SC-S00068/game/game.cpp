#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
inline void read_(int &x)
{
	x=0;
	int f=1;
	char c=getchar();
	while(c!='-'&&(c>'9'||c<'0')) c=getchar();
	if(c=='-') f=-1,c=getchar();
	while(c>='0'&&c<='9') x=x*10+(c^48),c=getchar();
	x*=f;
}
inline void read_(long long &x)
{
	x=0;
	int f=1;
	char c=getchar();
	while(c!='-'&&(c>'9'||c<'0')) c=getchar();
	if(c=='-') f=-1,c=getchar();
	while(c>='0'&&c<='9') x=x*10+(c^48),c=getchar();
	x*=f;
}
#define lkmem cerr<<(&yyy-&xxx)/1024.0/1024.0<<'\n'
char xxx;

namespace mysol
{

const int N=1e5+5,M=2e6+5;
int n,m,q;
int a[N],b[N];
class node
{
	public:
		int c[2];
		int val;
}; node s[M]; int cnt;
#define ls(x) s[x].c[0]
#define rs(x) s[x].c[1]
#define mid ((l+r)>>1)
#define L(x) ls(x),l,mid
#define R(x) rs(x),mid+1,r
void build(int &x,int l,int r)
{
	if(!x) x=++cnt;
	if(l==r) return;
	build(L(x)),build(R(x));
}
inline void pushup(int x,bool tp)
{
	if(tp) s[x].val=max(s[ls(x)].val,s[rs(x)].val);
	else s[x].val=min(s[ls(x)].val,s[rs(x)].val);
}
inline void insert(int x,int l,int r,int p,int k,bool tp)
{
	if(l==r&&l==p) {
		s[x].val=k;
		return;
	}
	if(p<=mid) insert(L(x),p,k,tp);
	else       insert(R(x),p,k,tp);
	pushup(x,tp);
}
inline int merge(int x,int y,bool tp)
{
	if(tp) return max(x,y);
	else return min(x,y);
}
const int inf=2e9;
inline int query(int x,int l,int r,int ql,int qr,bool tp)
{
	if(!x||l>qr||r<ql) return tp?-inf:inf;
	if(l>=ql&&r<=qr) return s[x].val;
	return merge(query(L(x),ql,qr,tp),query(R(x),ql,qr,tp),tp);
}
class segtree
{
	public:
		int rt,L,R;
		bool mx;
		inline void make(int l,int r)
		{
			L=l,R=r;
			build(rt,L,R);
		}
		inline int ask(int l,int r)
		{
			return query(rt,L,R,l,r,mx);
		}
		inline void ins(int p,int k)
		{
//			if(p>R) p=R;
//			if(p<L) p=L;
			insert(rt,L,R,p,k,mx);
		}
}; segtree amx,amn,bmx,bmn,aamx,aamn,bbmx,bbmn;

inline void work()
{
	int l1,r1,l2,r2;
	ll as;
	for(int i=1,ax,bx,an,bn,aax,bbx,aan,bbn;i<=q;++i)
	{
		as=LLONG_MIN;
		read_(l1),read_(r1),read_(l2),read_(r2);
		ax=amx.ask(l1,r1);
		aax=aamx.ask(l1,r1);
		an=amn.ask(l1,r1);
		aan=aamn.ask(l1,r1);
		bx=bmx.ask(l2,r2);
		bbx=bbmx.ask(l2,r2);
		bn=bmn.ask(l2,r2);
		bbn=bbmn.ask(l2,r2);//<0 
//		cerr<<ax<<' '<<aax<<' '<<an<<' '<<aan<<'\n';
//		cerr<<bx<<' '<<bbx<<' '<<bn<<' '<<bbn<<'\n'; 
		if(ax!=-inf)
		{
			if(bbn!=inf) as=max(as,1ll*ax*bbn);
			else as=max(as,1ll*ax*bn);
		}
		if(aax!=-inf)
		{
			if(bx!=-inf) as=max(as,1ll*aax*bx);
			else as=max(as,1ll*aax*bbx);
		}
		if(an!=inf)
		{
			if(bbn!=inf) as=max(as,1ll*an*bbn);
			else as=max(as,1ll*an*bn);
		}
		if(aan!=inf)
		{
			if(bx!=-inf) as=max(as,1ll*aan*bx);
			else as=max(as,1ll*aan*bbx);
		}
		cout<<as<<'\n';
	}
}

inline void init()
{
	amx.make(1,n),amn.make(1,n);
	amx.mx=1,amn.mx=0;
	bmx.make(1,m),bmn.make(1,m);
	bmx.mx=1,bmn.mx=0;
	aamx.make(1,n),aamn.make(1,n);
	aamx.mx=1,aamn.mx=0;
	bbmx.make(1,m),bbmn.make(1,m);
	bbmx.mx=1,bbmn.mx=0;
	for(int i=1;i<=n;++i)
	{
		if(a[i]>=0) amx.ins(i,a[i]),amn.ins(i,a[i]),aamx.ins(i,-inf),aamn.ins(i,inf);
		else        amx.ins(i,-inf),amn.ins(i,inf),aamx.ins(i,a[i]),aamn.ins(i,a[i]);
	}
	for(int i=1;i<=m;++i)
	{
		if(b[i]>=0) bmx.ins(i,b[i]),bmn.ins(i,b[i]),bbmx.ins(i,-inf),bbmn.ins(i,inf);
		else        bmx.ins(i,-inf),bmn.ins(i,inf),bbmx.ins(i,b[i]),bbmn.ins(i,b[i]);
	}
}

inline void solmain()
{
	read_(n),read_(m),read_(q);
	for(int i=1;i<=n;++i) read_(a[i]);
	for(int i=1;i<=m;++i) read_(b[i]);
	init();
	work();
}
	
}

char yyy;
signed main()
{
//	lkmem;
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	mysol::solmain();
	
	
	return 0;
}
