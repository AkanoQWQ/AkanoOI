#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
inline void read_(int &x)
{
	x=0;
	int f=1;
	char c=getchar();
	while(c!='-'&&(c>'9'||c<'0')) c=getchar();
	if(c=='-') f=-1,c=getchar();
	while(c>='0'&&c<='9') x=x*10+(c^48),c=getchar();
	x*=f;
}
inline void read_(long long &x)
{
	x=0;
	int f=1;
	char c=getchar();
	while(c!='-'&&(c>'9'||c<'0')) c=getchar();
	if(c=='-') f=-1,c=getchar();
	while(c>='0'&&c<='9') x=x*10+(c^48),c=getchar();
	x*=f;
}
#define lkmem cerr<<(&yyy-&xxx)/1024.0/1024.0<<'\n'
char xxx;

namespace mysol
{

const int N=2505,M=25005;
bool ach[N][N];
int n,m,k;
int to[M],nex[M],head[N],cnt;
vector<int> r[N];
ll v[N];
inline void link(int u,int v)
{
	nex[++cnt]=head[u],to[head[u]=cnt]=v;
}

inline bool cmp(const int x,const int y)
{ return v[x]>v[y]; }
int d[N],q[N],top,fr;
bool r1[N];//���Ե�1�� 
inline void init()
{
	for(int u,i=1;i<=n;++i)
	{
		for(int j=1;j<=n;++j) d[j]=n+1;
		d[i]=fr=0;
		q[top=1]=i;
		while(fr<top)
		{
			u=q[++fr];
			if(d[u]>k+1) break;
			else if(u!=i) r[i].emplace_back(u);
			for(int t=head[u],v=to[t];t;v=to[t=nex[t]])
				if(d[u]+1<d[v])
					d[v]=d[u]+1,
					q[++top]=v; 
		}
//		sort(r[i].begin(),r[i].end(),cmp);
	}
	for(unsigned i=0;i<r[1].size();++i) r1[r[1][i]]=1;
	for(int i=1;i<=n;++i)
		for(int x:r[i])
			ach[i][x]=1;
}

int id[5];
inline bool legal(int x,int tot)
{
	if(x==1) return false;
	for(int i=1;i<=tot;++i) if(x==id[i]) return false;
	return true;
}
inline ll calc() { return v[id[1]]+v[id[2]]+v[id[3]]+v[id[4]]; }
inline ll bf(int tot)
{
	if(tot==4)
	{
		if(r1[id[4]]) return calc();
		return -1;
	}
	int u=id[tot]; ll tmp,as=-1;
	for(unsigned i=0;i<r[u].size();++i)
	{
		if(legal(r[u][i],tot))
		{
			id[tot+1]=r[u][i];
			tmp=bf(tot+1);
			as=max(as,tmp);
		}
	} return as;
}

class tri
{
	public:
		int a[3];	
		int num;
		tri() {
			num=0;
			a[0]=a[1]=a[2]=0;
		}
		inline void make()
		{
			if(v[a[0]]<v[a[1]]) swap(a[0],a[1]);
			if(v[a[0]]<v[a[2]]) swap(a[0],a[2]);
			if(v[a[1]]<v[a[2]]) swap(a[1],a[2]);
		}
}; tri t[N];
inline ll work(int x,int y)
{
	if(x==y||!ach[x][y]) return -1;
	ll tmp=-1;
	for(int i=0;i<t[x].num;++i)
		if(t[x].a[i]!=y)
			for(int j=0;j<t[y].num;++j)
				if(t[x].a[i]!=t[y].a[j]&&x!=t[y].a[j])
					tmp=max(tmp,v[x]+v[y]+v[t[x].a[i]]+v[t[y].a[j]]);
	return tmp;
}

inline void solmain()
{
	read_(n),read_(m),read_(k);
	for(int i=2;i<=n;++i) read_(v[i]);
	for(int i=1,u,v;i<=m;++i)
		read_(u),read_(v),
		link(u,v),link(v,u);
	init();
//	for(int i=1;i<=n;++i)
//	{
//		cerr<<i<<":\n";
//		for(int x:r[i]) cerr<<x<<' ';
//		cerr<<'\n';
//	}
	for(int i:r[1])
	{
		if(i==1) continue;
		for(int j:r[i])
		{
			if(j==1) continue;
			if(t[j].num<3) t[j].a[t[j].num++]=i;
			else
			{
				t[j].make();
				if(v[i]>v[t[j].a[2]]) t[j].a[2]=i,t[j].make();
			}
		}
	}
//	for(int i=2;i<=n;++i)
//	{
//		cerr<<i<<":\n";
//		for(int j=0;j<t[i].num;++j) cerr<<t[i].a[j]<<' ';
//		cerr<<'\n';
//	}
	ll as=-1;
	for(int i=1;i<=n;++i)
	{
		for(int j=1;j<=n;++j)
		{
			as=max(as,work(i,j)); 
		}
	} cout<<as<<'\n';
//	id[0]=1;
//	ll as=bf(0);
//	cout<<as<<'\n';
}

}

char yyy;
signed main()
{
//	lkmem;
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	
	mysol::solmain();


	return 0;
}
