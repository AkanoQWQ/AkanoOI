#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
inline void read_(int &x)
{
	x=0;
	int f=1;
	char c=getchar();
	while(c!='-'&&(c>'9'||c<'0')) c=getchar();
	if(c=='-') f=-1,c=getchar();
	while(c>='0'&&c<='9') x=x*10+(c^48),c=getchar();
	x*=f;
}
inline void read_(long long &x)
{
	x=0;
	int f=1;
	char c=getchar();
	while(c!='-'&&(c>'9'||c<'0')) c=getchar();
	if(c=='-') f=-1,c=getchar();
	while(c>='0'&&c<='9') x=x*10+(c^48),c=getchar();
	x*=f;
}
#define lkmem cerr<<(&yyy-&xxx)/1024.0/1024.0<<'\n'
char xxx;
/*
ddp......
*/
namespace ddp
{
	const int N=2e5+5,M=2e5+5;
	const ll inf=1e18;
	int n,Q,k;
	ll v[N];
	int fa[N],top[N],son[N],siz[N],dep[N];
	vector<int> e[N];
	ll f[N][3];
	class tri
	{
		public:
			int a[3];	
			int num;
			tri() {
				num=0;
				a[0]=a[1]=a[2]=0;
			}
			inline void make()
			{
				if(v[a[0]]<v[a[1]]) swap(a[0],a[1]);
				if(v[a[0]]<v[a[2]]) swap(a[0],a[2]);
				if(v[a[1]]<v[a[2]]) swap(a[1],a[2]);
			}
	}; tri t[N];
	inline void init()
	{
		f[0][0]=f[0][1]=f[0][2]=inf;
		for(int i=1;i<=n;++i)
			for(int to:e[i])
				if(t[i].num<3) t[i].a[t[i].num++]=to;
				else
				{
					t[i].make();
					if(v[to]<v[t[i].a[0]]) t[i].a[0]=to;
				}
	}
	int a[N],num;
	int q[N],tot;
	inline void dfs1(int u,int f)
	{
		fa[u]=f,dep[u]=dep[f]+1,siz[u]=1;
		for(int v:e[u])
			if(v!=f)
			{
				dfs1(v,u); siz[u]+=siz[v];
				if(siz[v]>=siz[son[u]]) son[u]=v;
			}
	}
	inline void dfs2(int u,int tp)
	{
		top[u]=tp;
		if(son[u]) dfs2(son[u],tp);
		for(int v:e[u])
			if(v!=fa[u]&&v!=son[u])
				dfs2(v,v);
	}
	inline int lca(int x,int y)
	{
		while(top[x]!=top[y])
		{
			if(dep[top[x]]<dep[top[y]]) swap(x,y);
			x=fa[top[x]];
		} return dep[x]<dep[y]?x:y;
	}
	inline void makearr(int x,int y)
	{
		int l=lca(x,y);
		num=0,tot=0;
		while(x!=l) a[++num]=x,x=fa[x];
		a[++num]=l;
		while(y!=l) q[++tot]=y,y=fa[y];
		while(tot) a[++num]=q[tot--];
	}
	inline ll justdp(int x,int y)
	{
		makearr(x,y);
		f[1][0]=v[x];
		f[1][1]=inf;
		f[1][2]=inf;
		ll tmp;
		for(int i=2;i<=num;++i)
		{
			tmp=1e18;
			for(int j=0;j<k;++j) tmp=min(tmp,f[i-1][j]);
			f[i][0]=tmp+v[a[i]];
			if(k>1)
			{
				f[i][1]=f[i-1][0];
				for(int u,tt=0;tt<t[a[i]].num;++tt)
				{
					u=t[a[i]].a[tt];
					if(u!=a[i-1]&&u!=a[i+1])
					{
						f[i][1]=min(f[i][1],f[i-1][0]+v[u]);
						if(k>2)
							f[i][1]=min(f[i][1],f[i-2][0]+v[u]),
							f[i][1]=min(f[i][1],f[i-1][1]+v[u]);
					}
				}
			}
			else f[i][1]=inf;
			if(k>2)
			{
				f[i][2]=f[i-1][1];
				
			}
			else f[i][2]=inf;
		} return f[num][0];
	}
	inline void solmain()
	{
		read_(n),read_(Q),read_(k);
		for(int i=1;i<=n;++i) read_(v[i]);
		for(int i=1,u,v;i<n;++i)
			read_(u),read_(v),
			e[u].emplace_back(v),
			e[v].emplace_back(u);
		dfs1(1,0); dfs2(1,1);
		init();
		ll as;
		for(int i=1,x,y;i<=Q;++i)
		{
			read_(x),read_(y);
			as=justdp(x,y);
			cout<<as<<'\n';
		}
	}
}//


char yyy;
signed main()
{
//	lkmem;
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	ddp::solmain();
	
	
	return 0;
}

