#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
inline void read_(int &x)
{
	x=0;
	int f=1;
	char c=getchar();
	while(c!='-'&&(c>'9'||c<'0')) c=getchar();
	if(c=='-') f=-1,c=getchar();
	while(c>='0'&&c<='9') x=x*10+(c^48),c=getchar();
	x*=f;
}
inline void read_(long long &x)
{
	x=0;
	int f=1;
	char c=getchar();
	while(c!='-'&&(c>'9'||c<'0')) c=getchar();
	if(c=='-') f=-1,c=getchar();
	while(c>='0'&&c<='9') x=x*10+(c^48),c=getchar();
	x*=f;
}
#define lkmem cerr<<(&yyy-&xxx)/1024.0/1024.0<<'\n'
char xxx;

const int N=5e5+5,M=5e5+5;
typedef pair<int,int> pii;
vector<int> from[15];
map<pii,int> mp;
#define mk make_pair
int to[M],nex[M],head[N],cnt;
int n,m,q;
bool des[N],down[M];

inline void link(int u,int v)
{ nex[++cnt]=head[u],to[head[u]=cnt]=v,mp[mk(u,v)]=cnt,from[v].emplace_back(cnt); }
inline void input()
{
	read_(n),read_(m);
	for(int i=1,u,v;i<=m;++i)
		read_(u),read_(v),
		link(u,v);
	read_(q);
}

bool inq[N];
int d[N],c[N];
queue<int> qq;
inline bool spfa(int u)
{
	while(!qq.empty()) qq.pop();
	for(int i=1;i<=n;++i) inq[i]=0,d[i]=0,c[i]=0;
	qq.push(u),inq[u]=1;
	while(!qq.empty())
	{
		u=qq.front(),qq.pop();
		inq[u]=0;
		++c[u];
		if(c[u]>n) return true;
		for(int i=head[u],v=to[i];i;v=to[i=nex[i]])
			if(!down[i])
			if(d[v]<d[u]+1)
			{
				d[v]=d[u]+1;
				qq.push(v),inq[v]=1;
			}
	} return false;
}
inline void bf()
{
	int num=0,ok=1;
	for(int t=1,op,x,y;t<=q;++t)
	{
		read_(op);
		if(op&1)
		{
			read_(x),read_(y);
			down[mp[mk(x,y)]]=op==1;
		}
		else
		{
			read_(x);
			for(int aaa:from[x])
				down[aaa]=op==2;
		}
		ok=1;
		for(int u=1;u<=n;++u)
		{
			num=0;
			for(int i=head[u],v=to[i];i;v=to[i=nex[i]]) if(!down[i]) ++num;
			if(num!=1) { ok=0; break; }
		} if(!ok) { cout<<"NO\n"; continue; }
		num=0;
		for(int u=1;u<=n;++u) num+=spfa(u);
		if(num==n) cout<<"YES\n";
		else cout<<"NO\n";
	}
}

char yyy;
signed main()
{
//	lkmem;
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	input();
	if(n<=10) bf();
	else
	{
		int c=0;
		for(int i=1,op,x,y;i<=q;++i)
		{
			read_(op);
			if(op&1)
			{
				read_(x),read_(y);
				if(op==1) --c;
				else ++c;
			}
			else
			{
				read_(x);
				if(op==2&&!des[x]) --c,des[x]=1;
				if(op==4&&des[x]) ++c,des[x]=0;
			}
			if(c==0) cout<<"YES\n";
			else cout<<"NO\n";
		}
	}


	return 0;
}

