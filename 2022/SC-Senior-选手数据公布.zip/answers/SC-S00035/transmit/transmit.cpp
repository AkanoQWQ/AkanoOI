#include<bits/stdc++.h>
using namespace std;
const int N=200005;
int n,Q,k,v[N],d[N],f[N],l[N],t;
long long dp[N];
vector<int>e[N];
void dfs(int x,int y){
	f[x]=y;d[x]=d[y]+1;
	int sz=e[x].size();
	for(int i=0;i<sz;i++)
		if(e[x][i]!=y)dfs(e[x][i],x);
}
void lik(int x,int y){
	int z=y,p=2;t=2;
	l[2]=x;
	while(x!=z){
		t++;
		if(d[x]<d[z])z=f[z];
		else{
			x=f[x];
			l[++p]=x;
		}
	}
	for(int i=t;i>p;i--){
		l[i]=y;
		y=f[y];
	}
}
void work(){
	for(int i=3;i<=t;i++)
		if(k==1)dp[i]=dp[i-1]+v[l[i]];
		else if(k==2)dp[i]=min(dp[i-1],dp[i-2])+v[l[i]];
		else dp[i]=min(dp[i-1],min(dp[i-2],dp[i-3]))+v[l[i]];
	cout<<dp[t]+v[l[2]]<<'\n';
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int x,y;
	cin>>n>>Q>>k;
	for(int i=1;i<=n;i++)
		scanf("%d",&v[i]);
	for(int i=1;i<n;i++){
		scanf("%d%d",&x,&y);
		e[x].push_back(y);
		e[y].push_back(x);
	}
	dfs(1,0);
	while(Q--){
		scanf("%d%d",&x,&y);
		lik(x,y);
		work();
	}
	return 0;
} 
