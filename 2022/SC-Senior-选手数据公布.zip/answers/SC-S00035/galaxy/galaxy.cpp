#include<bits/stdc++.h>
using namespace std;
int read(){
	int x=0;char c;
	while(!isdigit(c))c=getchar();
	do x=x*10+c-'0';while(isdigit(c=getchar()));
	return x;
}
const int N=500005;
int n,m,q,c[N],p[N],s;
vector<int>v[N],op[N];
void add(int x,int y){
	if(c[x]==1)s--;
	c[x]+=y;
	if(c[x]==1)s++;
}
void ope(int x){
	if(x>0)add(x,-1);
	else add(-x,1);
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int t,x,y;
	n=read();
	m=read();
	for(int i=0;i<m;i++){
		y=read();
		x=read();
		v[x].push_back(y);
		c[y]++;
	}
	for(int i=1;i<=n;i++)
		p[i]=1,s+=c[i]==1;
	for(q=read();q;q--){
		t=read();
		if(t==1){
			y=read();
			x=read();
			op[x].push_back(-y);
			add(y,-1);
		}
		if(t==2){
			x=read();
			if(p[x]==1){
				int sz=v[x].size();
				for(int i=0;i<sz;i++)
					add(v[x][i],-1);
				p[x]=0;
			}
			int sz=op[x].size();
			for(int i=0;i<sz;i++)
				ope(op[x][i]);
			op[x].clear();
		}
		if(t==3){
			y=read();
			x=read();
			op[x].push_back(y);
			add(y,1);
		}
		if(t==4){
			x=read();
			if(p[x]==0){
				int sz=v[x].size();
				for(int i=0;i<sz;i++)
					add(v[x][i],1);
				p[x]=1;
			}
			int sz=op[x].size();
			for(int i=0;i<sz;i++)
				ope(op[x][i]);
			op[x].clear();
		}
		puts(s==n?"YES":"NO");
	}
	return 0;
} 
