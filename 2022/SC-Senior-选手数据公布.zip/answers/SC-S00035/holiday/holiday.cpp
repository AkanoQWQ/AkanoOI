#include<bits/stdc++.h>
using namespace std;
#define ull unsigned long long
const int N=2555;
int n,m,k,e[N][N];
ull sq[N],d[N][3],ans=0;
vector<int>v[N];
int q[N],t,id[N][3];
void bfs(int x){
	t=1;q[0]=x;
	for(int i=0;i<t;i++){
		if(e[x][q[i]]>k)break;
		int sz=v[q[i]].size();
		for(int jj=0,j;jj<sz;jj++){
			j=v[q[i]][jj];
			if(j!=x&&!e[x][j]){
				e[x][j]=e[x][q[i]]+1;
				q[t++]=j;
			}
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin); 
	freopen("holiday.out","w",stdout); 
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++)cin>>sq[i];
	for(int i=0;i<m;i++){
		int x,y;
		cin>>x>>y;
		v[x].push_back(y);
		v[y].push_back(x);
	}
	for(int i=1;i<=n;i++)bfs(i);
	for(int i=2;i<=n;i++){
		for(int j=2;j<=n;j++){
			if(!e[j][i]||!e[1][j])continue;
			ull p=sq[i]+sq[j];
			if(p>d[i][2])
				if(p>d[i][1]){
					d[i][2]=d[i][1];
					id[i][2]=id[i][1];
					if(p>d[i][0]){
						d[i][1]=d[i][0];
						id[i][1]=id[i][0];
						d[i][0]=p;
						id[i][0]=j;
					}
					else{
						d[i][1]=p;
						id[i][1]=j;
					}
				}
				else{
					d[i][2]=p;
					id[i][2]=j;
				}
		}
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<i;j++)
			if(e[i][j])
				for(int ii=0;ii<3;ii++)
					for(int jj=0;jj<3;jj++)
						if(d[i][ii]+d[j][jj]>ans)
							if(id[i][ii]&&id[j][jj]&&id[i][ii]!=j&&id[i][ii]!=id[j][jj]&&i!=id[j][jj])
								ans=d[i][ii]+d[j][jj];
	cout<<ans;
	return 0;
} 
