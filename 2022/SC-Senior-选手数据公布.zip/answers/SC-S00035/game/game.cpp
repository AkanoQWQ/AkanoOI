#include<bits/stdc++.h>
using namespace std;
const int N=100005,M=20,inf=0x3f3f3f3f;
int n,m,q,a[N],b[N],l,r,ll,rr,lg2[N],mx[3][N][M],mi[3][N][M],sa0[N];
long long ans;
int qmx(int id,int x,int y){
	int k=lg2[y-x+1];
	return max(mx[id][x][k],mx[id][y-(1<<k)+1][k]);
}
int qmi(int id,int x,int y){
	int k=lg2[y-x+1];
	return min(mi[id][x][k],mi[id][y-(1<<k)+1][k]);
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	for(int i=2;i<N;i++)lg2[i]=lg2[i>>1]+1;
	for(int i=0;i<3;i++)
		for(int j=0;j<N;j++)
			for(int k=0;k<M;k++)
				mx[i][j][k]=-inf,mi[i][j][k]=inf;
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		mx[0][i][0]=a[i];
		mi[0][i][0]=a[i];
		if(a[i]>0)mi[2][i][0]=a[i];
		if(a[i]<0)mx[2][i][0]=a[i];
		sa0[i]=sa0[i-1];
		if(a[i]==0)sa0[i]++;
	}
	for(int i=1;i<=m;i++){
		scanf("%d",&b[i]);
		mx[1][i][0]=b[i];
		mi[1][i][0]=b[i];
	}
	for(int k=0;k<3;k++)
		for(int j=1;j<M;j++)
			for(int i=1;i+(1<<j)-1<=n;i++)
				mx[k][i][j]=max(mx[k][i][j-1],mx[k][i+(1<<j-1)][j-1]);
	for(int k=0;k<3;k++)
		for(int j=1;j<M;j++)
			for(int i=1;i+(1<<j)-1<=n;i++)
				mi[k][i][j]=min(mi[k][i][j-1],mi[k][i+(1<<j-1)][j-1]);
	while(q--){
		ans=-inf;
		scanf("%d%d%d%d",&l,&r,&ll,&rr);
		int amx=qmx(0,l,r),ami=qmi(0,l,r),bmx=qmx(1,ll,rr),bmi=qmi(1,ll,rr);
//		cout<<amx<<' '<<ami<<' '<<bmx<<' '<<bmi<<'\n';
		if(ami<0&&amx>0&&bmx>0&&bmi<0)
			ans=max(1ll*qmx(2,l,r)*bmx,1ll*qmi(2,l,r)*bmi);
		else ans=max(min(1ll*amx*bmx,1ll*amx*bmi),min(1ll*ami*bmx,1ll*ami*bmi));
		if(sa0[r]>sa0[l-1])ans=max(ans,0ll);
		cout<<ans<<'\n';
	}
	return 0;
} 
