#include<bits/stdc++.h>
using namespace std;
const int N=1e3+5;
bool g[N][N];//1->2
bool t[N][N];
bool gb[N],vis[N];
int n,m;
int out[N];
void dfs(int x){
	if(vis[x]||gb[x]){
		for(int i=1;i<=n;i++){
			if(vis[i])gb[i]=1,vis[i]=0;
		}
		return;
	}
	vis[x]=1;
	for(int i=1;i<=n;i++){
		if(t[x][i])dfs(i);
	}
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>m;
	for(int i=1,u,v;i<=m;i++){
		cin>>u>>v;
		g[u][v]=t[u][v]=1;
		out[u]++;
	}
	int q;
	cin>>q;
	while(q--){
		int r;cin>>r;
		if(r==1){
			int u,v;cin>>u>>v;
			t[u][v]=0;
			out[u]--;
		}else if(r==2){
			int u;cin>>u;
			for(int i=1;i<=n;i++){
				if(t[i][u])out[i]--;
				t[i][u]=0;
			}
		}else if(r==3){
			int u,v;
			cin>>u>>v;
			t[u][v]=1;
			out[u]++;
		}else if(r==4){
			int u;
			cin>>u;
			for(int i=1;i<=n;i++){
				if(g[i][u]&&(t[i][u]==0)){
					t[i][u]=1;
					out[i]++;
				}
			}
		}
		memset(gb,0,sizeof(gb)); 
		for(int i=1;i<=n;i++){
			if(!gb[i]){
				dfs(i);
				memset(vis,0,sizeof(vis));
			}
		}
		int fg=1;
		for(int i=1;i<=n;i++)if(!gb[i]){
				fg=0;
				break;
		}
		if(fg==0){
			cout<<"NO"<<endl;
			continue;
		}//can we travel like it,hakurei reimu? 
		
		for(int i=1;i<=n;i++){
//			cout<<i<<" "<<out[i]<<endl; 
			if(out[i]!=1){
				fg=0;
//				break;
			}
		}
		if(fg==0){
			cout<<"NO"<<endl;
			continue;
		}
		cout<<"YES"<<endl;
	}
	return 0;
}
// oh this is infinite galaxy
// call us people
// which is the same length as the galaxy
// can we be more confident
