#include<bits/stdc++.h>
using namespace std;
const int N=2500;
int val[N];
int g[N][N],c[N];
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	ios::sync_with_stdio(false);
	int n,m,k;
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++){
		cin>>val[i];
		c[i]=val[i];
	}
	for(int i=1;i<=m;i++){
		int x,y;
		cin>>x>>y;
		g[x][y]=g[y][x]=1;
	}
	if(k==0){
		int ans=0;
		for(int a=2;a<=n;a++){
			for(int b=2;b<=n;b++){
				for(int c=2;c<=n;c++){
					for(int d=2;d<=n;d++){ 
						if(a==b||a==c||a==d||b==c||b==d||c==d)continue;
						if((g[1][a]==0)||(g[a][b]==0)||(g[b][c]==0)||(g[c][d]==0)||(g[d][1]==0))continue;
						ans=max(ans,val[a]+val[b]+val[c]+val[d]);
					}
				}
			}
		}
		cout<<ans<<endl;
		return 0;
	}
	else{
		sort(c+1,c+n+1);
		cout<<c[n]+c[n-1]+c[n-2]+c[n-3]<<endl;
	}
	return 0;
}
//about relief
//beilef?i just don't believe it ehehe
//jumpover to get newlife
// breakout

//why ... floyd ... why i each time
// input edges diffErently in order
// answers is different////?

// BELIEVE 2022 BELIEVE THE PEOPLE BELIVER be     liver

//wow i know why it is different.
// I INPUT ONE MORE NUMBER.
 
