#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=2e3+5;
ll v[N];
vector<int>g[N];
void dfs(int x,int to,int fa,ll d){
	if(to==x)cout<<d<<endl;
	for(int i=0;i<g[x].size();i++){
		if(g[x][i]==fa)continue;
		else dfs(g[x][i],to,x,d+v[g[x][i]]);
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	ios::sync_with_stdio(false);
	int n,Q,k;
	cin>>n>>Q>>k;
	for(int i=1;i<=n;i++)cin>>v[i];
	
//	memset(f,0x3f,sizeof(f));
	for(int i=1;i<n;i++){
		int u,v;
		cin>>u>>v;
		g[u].push_back(v);
		g[v].push_back(u);
	}
	while(Q--){
		int ai,bi;
		cin>>ai>>bi;
		dfs(ai,bi,-1,v[ai]);
	}
	return 0;
}
//kaibai

