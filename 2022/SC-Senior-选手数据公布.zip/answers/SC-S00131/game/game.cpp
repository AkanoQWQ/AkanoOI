#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e5+5;
const ll INF=1e9+5;
ll a[N],b[N];
int n,m,q,kn,km;
ll	fa[N],fb[N];
ll askmax(int l,int r){
	ll ans=-INF;
	if(r-l+1<kn||n<=10){
		for(int i=l;i<=r;i++)ans=max(ans,a[i]); 
		return ans;
	}
	if(l%kn!=1)while(l%kn!=1)ans=max(ans,a[l]),l++;
	if(r%kn!=0)while(r%kn!=0)ans=max(ans,a[r]),r--;
	for(int i=l/kn+1;i<=r/kn;i++)ans=max(ans,fa[i]);
	return ans;
}
ll askmin(int l,int r){
	ll ans=INF;
	if(r-l+1<km||m<=10){
		for(int i=l;i<=r;i++)ans=min(ans,b[i]); 
		return ans;
	}
	if(l%km!=1)while(l%km!=1)ans=min(ans,b[l]),l++;
	if(r%km!=0)while(r%km!=0)ans=min(ans,b[r]),r--;
	for(int i=l/km+1;i<=r/km;i++)ans=min(ans,fb[i]);
	return ans;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>m>>q;
	kn=sqrt(n),km=sqrt(m);
	int cn=n/kn,cm=m/km;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=cn;i++){
		fa[i]=-INF;
		for(int j=(i-1)*kn+1;j<=i*kn;j++){
			fa[i]=max(fa[i],a[j]);		
		}
	}
	fa[cn+1]=-INF;
	if(n%kn)for(int j=cn*kn+1;j<=n;j++)fa[cn+1]=max(fa[cn+1],a[j]);
	
	for(int i=1;i<=m;i++)cin>>b[i];
	for(int i=1;i<=cm;i++){
		fb[i]=INF;
		for(int j=(i-1)*km+1;j<=i*km;j++){
			fb[i]=min(fb[i],b[j]);		
		}
	}
	fb[cm+1]=INF;
	if(m%km)for(int j=cm*km+1;j<=m;j++)fb[cm+1]=min(fb[cm+1],b[j]);
	while(q--){
		int la,ra,lb,rb;
		cin>>la>>ra>>lb>>rb;
		long long maxn=askmax(la,ra);
		long long minn=askmin(lb,rb);
		cout<<minn*maxn<<endl;	
	}
	return 0;
}
//me never do something bad
//please give me some points thx god
//i will repeat beating wooden fish
//to honor u
