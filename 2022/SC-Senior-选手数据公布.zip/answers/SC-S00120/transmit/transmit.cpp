#include <bits/stdc++.h>

#define maxn 200005
#define ll long long

const ll inf = (1ll << 60);

using namespace std;

int n, q, k;
ll a[maxn];
ll ans[maxn];
vector<int> vec[maxn];

struct qry{
	int x, y, id;
};
#define vecqry vector<qry>

int vis[maxn];
int sz[maxn];
int MX, id;

void findzx(int u, int fa, int rts) {
//	cout<<"Finding:"<<u<<" "<<fa<<" "<<rts<<" "<<sz[u]<<endl;
	int mxsiz = 0;
	for (int v : vec[u]) {
		if (vis[v] || v == fa) continue;
		findzx(v, u, rts);
		mxsiz = max(mxsiz, sz[v]);
	}
	mxsiz = max(mxsiz, rts - sz[u]);
//	cout<<mxsiz<<endl;
	if (mxsiz < MX) MX = mxsiz, id = u;
}

int fat[maxn][4];
ll f[maxn];
ll g[maxn];
ll h[maxn];

int mark[maxn];

void dfs(int u, int fa, int cnt) {
//	cout<<"Dfsing:"<<u<<" "<<fa<<" "<<cnt<<endl;
	fat[u][0] = fa;
	mark[u] = cnt;
	sz[u] = 1;
	for (int i = 1; i < k; i++) fat[u][i] = fat[fa][i - 1];
	f[u] = g[u] = h[u] = inf;
	for (int i = 0; i < k; i++) {
		f[u] = min(f[u], f[fat[u][i]]);
		g[u] = min(g[u], g[fat[u][i]]);
		h[u] = min(h[u], h[fat[u][i]]);
	}
	f[u] += a[u], g[u] += a[u], h[u] += a[u];
//	cout<<"Dfs:"<<u<<" "<<f[u]<<" "<<h[u]<<" "<<g[u]<<endl;
//	cout<<f[1]<<" "<<h[1]<<" "<<g[1]<<" "<<f[11]<<" "<<h[11]<<" "<<g[11]<<endl;
	for (int v : vec[u]) {
		if (vis[v] || v == fa) continue;
		dfs(v, u, cnt); sz[u] += sz[v];
	}
}

void solve(int u, vecqry &q) {
//	cout<<"Solving:"<<u<<endl;
	vis[u] = 1;
	int cnt = 0;
	f[u] = g[u] = h[u] = a[u];
	g[u] = h[u] = inf;
	fat[u][0] = n + 1;
	for (int v : vec[u]) {
		if (vis[v]) continue;
		++cnt;
		dfs(v, u, cnt);
	}
	MX = n + 1; mark[u] = n + 1;
	vector<vecqry> tmp(cnt + 1);
//	cout<<mark[2]<<" "<<mark[10]<<endl;
//	cout<<f[5]<<" "<<h[5]<<" "<<g[5]<<endl;
//	cout<<f[10]<<" "<<h[10]<<" "<<g[10]<<endl;
//	cout<<"OK\n";
	for (auto p : q) {
//		cout<<p.x<<" "<<p.y<<" "<<mark[p.x]<<" "<<mark[p.y]<<endl;
		if (mark[p.x] == mark[p.y]) tmp[mark[p.x]].push_back(p);
		else {
			ans[p.id] = min(ans[p.id], f[p.x] + f[p.y] - a[u]);
			ans[p.id] = min(ans[p.id], f[p.x] + g[p.y]);
			ans[p.id] = min(ans[p.id], g[p.x] + f[p.y]);
			ans[p.id] = min(ans[p.id], g[p.x] + g[p.y]);
//			ans[p.id] = min(ans[p.id], )
//			cout<<p.id<<" "<<p.x<<" "<<p.y<<endl;
//			ans[p.id] = min(ans[p.id], f[p.x] + f[p.y] - a[u]);
//			ans[p.id] = min(ans[p.id], f[p.x] + h[p.y]);
//			ans[p.id] = min(ans[p.id], f[p.x] + g[p.y]);
//			ans[p.id] = min(ans[p.id], h[p.x] + f[p.y]);
//			ans[p.id] = min(ans[p.id], h[p.x] + h[p.y]);
//			ans[p.id] = min(ans[p.id], g[p.x] + f[p.y]);
		}
	}
	cnt = 0;
	for (int v : vec[u]) {
		if (vis[v]) continue;
		++cnt;
		MX = n + 1;
		findzx(v, u, sz[v]);
//		cout<<"Find:"<<MX<<" "<<id<<endl;
		solve(id, tmp[cnt]);
		vecqry().swap(tmp[cnt]);
	}
}

int main() {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	scanf("%d%d%d", &n, &q, &k);
	f[n + 1] = f[n + 2] = g[n + 2] = h[n + 1] = inf;
	for (int i = 1; i <= n; i++) scanf("%lld", &a[i]);
	for (int i = 1; i < n; i++) {
		int x, y;
		scanf("%d%d", &x, &y);
		vec[x].push_back(y);
		vec[y].push_back(x);
	}
	vecqry qwq(q);
	for (int i = 0; i < q; i++) scanf("%d%d", &qwq[i].x, &qwq[i].y), qwq[i].id = i, ans[i] = inf;
	solve(1, qwq);
	for (int i = 0; i < q; i++) printf("%lld\n", ans[i]);
	return 0;
}
