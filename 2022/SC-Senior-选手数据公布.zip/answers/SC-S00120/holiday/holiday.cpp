#include <bits/stdc++.h>

#define maxn 2505
#define maxm 10005
#define ll long long

using namespace std;

int n, m, k;
ll a[maxn];
vector<int> vec[maxn];

int w[maxn][maxn];
queue<int> q;

void bfs(int s) {
	w[s][s] = 1; q.push(s);
	while (!q.empty()) {
		int now = q.front(); q.pop();
		if (w[s][now] == k) continue;
		for (int v : vec[now]) {
			if (!w[s][v]) {
				w[s][v] = w[s][now] + 1;
				q.push(v);
			}
		}
	}
}

struct data{
	struct pr{
		ll x;
		ll id; 
		bool operator < (pr a) {return x > a.x;}
		ll &operator [](const int a) {return a ? id : x;}
	}x[4];
	pr &operator [](const int a) {return x[a];}
	void update(pr p) {
		x[3] = p;
		sort(x + 1, x + 4);
	}
}f[maxn];

int main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k); k += 2;
	for (int i = 2; i <= n; i++) scanf("%lld", &a[i]);
	while (m--) {
		int x, y;
		scanf("%d%d", &x, &y);
		vec[x].push_back(y);
		vec[y].push_back(x);
	}
	for (int i = 1; i <= n; i++) bfs(i);
//	for (int i = 1; i <= n; i++) {
//		for (int j = 1; j <= n; j++) {
//			printf("%d ", w[i][j]);
//		}
//		puts("");
//	}
	for (int i = 2; i <= n; i++) {
		for (int j = 2; j <= n; j++) {
			if (i == j) continue;
			if (w[i][j] && w[j][1]) f[i].update({a[i] + a[j], j});
		}
	}
	ll ans = 0;
	for (int i = 2; i <= n; i++) {
		for (int j = 2; j <= n; j++) {
			if (i == j || !w[i][j]) continue;
			for (int p = 0; p < 3; p++) {
				if (!f[i][p][1] || f[i][p][1] == j) continue;
				for (int q = 0; q < 3; q++) {
					if (!f[j][q][1] || f[j][q][1] == f[i][p][1] || f[j][q][1] == i) continue;
//					cout<<f[i][p][1]<<" "<<i<<" "<<j<<" "<<f[j][q][1]<<endl;
					ans = max(ans, f[i][p][0] + f[j][q][0]);
				}
			}
		}
	}
	printf("%lld\n", ans);
	return 0;
} 

/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1
*/
