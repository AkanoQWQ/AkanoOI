#include <bits/stdc++.h>

#define maxn 100005
#define ll long long
const int inf = 1e9 + 1;

using namespace std;

int n, m, q;

int lg[maxn];

int f[4][20][maxn];
int g[2][20][maxn];

int qrymn(int f[][maxn], int l, int r) {
	int k = lg[r - l + 1];
	return min(f[k][l], f[k][r - (1 << k) + 1]);
}

int qrymx(int f[][maxn], int l, int r) {
	int k = lg[r - l + 1];
	return max(f[k][l], f[k][r - (1 << k) + 1]);
}

int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &q);
	for (int i = 1; i <= n; i++) scanf("%d", &f[0][0][i]), f[1][0][i] = f[0][0][i];
	for (int i = 1; i <= n; i++) {
		if (f[0][0][i] >= 0) {
			f[2][0][i] = f[0][0][i];
			f[3][0][i] = -inf;
		}
		else {
			f[2][0][i] = inf;
			f[3][0][i] = f[0][0][i];
		}
	}
	for (int i = 1; i <= m; i++) scanf("%d", &g[0][0][i]), g[1][0][i] = g[0][0][i];
	for (int i = 2; i <= max(n, m); i++) lg[i] = lg[i >> 1] + 1;
	for (int i = 1; i < 20; i++) {
		for (int j = 1; j <= max(n, m); j++) {
			if (j + (1 << (i - 1)) <= n) {
				f[0][i][j] = min(f[0][i - 1][j], f[0][i - 1][j + (1 << (i - 1))]);
				f[1][i][j] = max(f[1][i - 1][j], f[1][i - 1][j + (1 << (i - 1))]);
				f[2][i][j] = min(f[2][i - 1][j], f[2][i - 1][j + (1 << (i - 1))]);
				f[3][i][j] = max(f[3][i - 1][j], f[3][i - 1][j + (1 << (i - 1))]);
			}
			if (j + (1 << (i - 1)) <= m) {
				g[0][i][j] = min(g[0][i - 1][j], g[0][i - 1][j + (1 << (i - 1))]);
				g[1][i][j] = max(g[1][i - 1][j], g[1][i - 1][j + (1 << (i - 1))]);
			}
		}
	}
	while (q--) {
		int a, b, c, d;
		scanf("%d%d%d%d", &a, &b, &c, &d);
		ll mn1, mx1, sd1, sx1, mn2, mx2;
		mn1 = qrymn(f[0], a, b);
		mx1 = qrymx(f[1], a, b);
		sd1 = qrymn(f[2], a, b);
		sx1 = qrymx(f[3], a, b);
		mn2 = qrymn(g[0], c, d);
		mx2 = qrymx(g[1], c, d);
		ll ans = max(min(mn1 * mn2, mn1 * mx2), min(mx1 * mn2, mx1 * mx2));
		if (sd1 != inf) ans = max(ans, min(sd1 * mn2, sd1 * mx2));
		if (sx1 != -inf) ans = max(ans, min(sx1 * mn2, sx1 * mx2));
		printf("%lld\n", ans);
	}
	return 0;
}
