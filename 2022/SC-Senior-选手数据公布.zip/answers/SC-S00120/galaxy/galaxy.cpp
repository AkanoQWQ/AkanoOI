#include <bits/stdc++.h>

#define maxn 500005
#define maxm 500005

using namespace std;

int n, m, q;

int fr[maxm];
int to[maxm];

bool dst[maxm];
vector<int> g[maxn];

int pos[maxn];
int deg[maxn];
int cnt;

vector<int> hv[maxn];
vector<int> nh[maxn];
map<pair<int, int>, int> mp;

void ER(int i) {
//	cout<<"Er:"<<fr[i]<<" "<<to[i]<<" "<<i<<" "<<pos[i]<<" "<<hv[to[i]][pos[i]]<<endl;
	cnt -= (deg[fr[i]] == 1);
	cnt += ((--deg[fr[i]]) == 1);
	auto &x = hv[to[i]], &y = nh[to[i]];
	swap(x[pos[i]], x[x.size() - 1]);
	pos[x[pos[i]]] = pos[i];
	x.pop_back();
	y.push_back(i);
	pos[i] = y.size() - 1;
}

void IN(int i) {
	cnt -= (deg[fr[i]] == 1);
	cnt += ((++deg[fr[i]]) == 1);
	auto &x = hv[to[i]], &y = nh[to[i]];
	swap(y[pos[i]], y[y.size() - 1]);
	pos[y[pos[i]]] = pos[i];
	y.pop_back();
	x.push_back(i);
	pos[i] = x.size() - 1;
}

int main() {
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= m; i++) {
		scanf("%d%d", &fr[i], &to[i]);
		mp[{fr[i], to[i]}] = i;
		++deg[fr[i]];
		hv[to[i]].push_back(i);
		pos[i] = hv[to[i]].size() - 1;
//		g[to[i]].push_back(i);
	}
	for (int i = 1; i <= n; i++) cnt += (deg[i] == 1);
	scanf("%d", &q);
	while (q--) {
		int t, u, v;
		scanf("%d", &t);
		if (t == 1) {
			scanf("%d%d", &u, &v);
			ER(mp[{u, v}]);
		}
		else if (t == 2){
			scanf("%d", &u);
			for (auto p : hv[u]) {
				int &o = deg[fr[p]];
				cnt -= (o == 1), cnt += ((--o) == 1);
				nh[u].push_back(p);
			}
			hv[u].clear();
		}
		else if (t == 3) {
			scanf("%d%d", &u, &v);
			IN(mp[{u, v}]);
		}
		else if (t == 4){
			scanf("%d", &u);
			for (auto p : nh[u]) {
				int &o = deg[fr[p]];
				cnt -= (o == 1), cnt += ((++o) == 1);
				hv[u].push_back(p);
			}
			nh[u].clear();
		}
		puts(cnt == n ? "YES" : "NO");
	}
	return 0;
}
