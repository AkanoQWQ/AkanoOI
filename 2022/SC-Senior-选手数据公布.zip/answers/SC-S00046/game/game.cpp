#include <cstdio>
#include <iostream>
using namespace std;
const int N=100003;
const long long NIN=-4557430888798830400,PIN=4557430888798830399;
struct Node{
	int left,right;
	long long pmax,pmin,nmax,nmin;
};
struct segment_tree{
	int len_node;
	Node node[N*4];
	void push_up(Node &u,Node l,Node r)
	{
		u.pmax=max(l.pmax,r.pmax);
		u.pmin=min(l.pmin,r.pmin);
		u.nmax=max(l.nmax,r.nmax);
		u.nmin=min(l.nmin,r.nmin);
	}
	void push_up(int u)
	{
		push_up(node[u],node[u*2],node[u*2+1]);
	}
	void build(int u,int l,int r)
	{
		node[u]={l,r,0,0,0,0};
		if(l<r)
		{
			int mid=(l+r)/2;
			build(u*2,l,mid);
			build(u*2+1,mid+1,r);
		}
	}
	void modify(int u,int k,int x)
	{
		if(node[u].left==k&&node[u].right==k)
		{
			node[u].pmax=node[u].nmax=NIN,node[u].pmin=node[u].nmin=PIN;
			if(x>=0)
				node[u].pmax=node[u].pmin=x;
			if(x<=0)
				node[u].nmax=node[u].nmin=x;
		}
		else
		{
			int mid=(node[u].left+node[u].right)/2;
			if(k<=mid)
				modify(u*2,k,x);
			if(k>mid)
				modify(u*2+1,k,x);
			push_up(u);
		}
	}
	Node query(int u,int l,int r)
	{
		if(node[u].left>=l&&node[u].right<=r)
			return node[u];
		int mid=(node[u].left+node[u].right)/2;
		Node ans={0,0,NIN,PIN,NIN,PIN};
		if(l<=mid)
			ans=query(u*2,l,r);
		if(r>mid)
			push_up(ans,ans,query(u*2+1,l,r));
		return ans;
	}
};
int n,m;
segment_tree a,b;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int i,j,t,l1,r1,l2,r2;
	long long x,sa1,sa2,sa3,sa4,sb1,sb2,sb3,sb4,ans;
	Node sa,sb;
	scanf("%d%d%d",&n,&m,&t);
	a.build(1,1,n);
	b.build(1,1,m);
	for(i=1;i<=n;i++)
	{
		scanf("%lld",&x);
		a.modify(1,i,x);
	}
	for(i=1;i<=m;i++)
	{
		scanf("%lld",&x);
		b.modify(1,i,x);
	}
	for(i=1;i<=t;i++)
	{
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		sa=a.query(1,l1,r1),sb=b.query(1,l2,r2);
		sa1=sa.pmax,sa2=sa.pmin,sa3=sa.nmax,sa4=sa.nmin;
		sb1=sb.pmax,sb2=sb.pmin,sb3=sb.nmax,sb4=sb.nmin;
		ans=NIN;
		if(sa1>NIN/2)
		{
			if(sb4>PIN/2)
				ans=max(ans,sa1*sb2);
			else
				ans=max(ans,sa2*sb4);
		}
		if(sa4<PIN/2)
		{
			if(sb1>NIN/2)
				ans=max(ans,sa3*sb1);
			else
				ans=max(ans,sa4*sb3);
		}
		printf("%lld\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
