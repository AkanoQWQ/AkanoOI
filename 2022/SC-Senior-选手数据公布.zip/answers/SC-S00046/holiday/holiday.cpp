#include <bitset>
#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;
const int N=2503;
const long long NIN=-4557430888798830400;
bitset<N> edge[N],ant[N],s1[N];
int n,m,g[N][3];
long long a[N],f[N][3];
void mul(bitset<N> s[N],bitset<N> x[N],bitset<N> y[N])
{
	int i,j,k;
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
			if((x[i]&y[j]).any())
				s1[i][j]=1;
	for(i=1;i<=n;i++)
		s[i]|=s1[i];
}
void make_pow(int p)
{
	int i,j;
	for(i=1;i<=n;i++)
		ant[i][i]=1;
	while(p>0)
	{
		if(p%2==1)
			mul(ant,ant,edge);
		mul(edge,edge,edge);
		p/=2;
	}
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
			edge[i][j]=ant[i][j];
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int i,j,p,x,y;
	long long ans=0;
	scanf("%d%d%d",&n,&m,&p);
	for(i=2;i<=n;i++)
		scanf("%lld",&a[i]);
	for(i=1;i<=m;i++)
	{
		scanf("%d%d",&x,&y);
		edge[x][y]=edge[y][x]=1;
	}
	if(p>0)
		make_pow(p+1);
	memset(f,NIN,sizeof f);
//	for(i=1;i<=n;i++)
//	{
//		for(j=1;j<=n;j++)
//			printf("%d ",(int)edge[i][j]);
//		printf("\n");
//	}
	for(i=2;i<=n;i++)
		for(j=2;j<=n;j++)
			if(i!=j)
				if(edge[1][j]&&edge[j][i])
				{
					if(a[j]>=f[i][0])
					{
						f[i][2]=f[i][1],g[i][2]=g[i][1];
						f[i][1]=f[i][0],g[i][1]=g[i][0];
						f[i][0]=a[j],g[i][0]=j;
					}
					else if(a[j]>=f[i][1])
					{
						f[i][2]=f[i][1],g[i][2]=g[i][1];
						f[i][1]=a[j],g[i][1]=j;
					}
					else if(a[j]>f[i][2])
						f[i][2]=a[j],g[i][2]=j;
				}
//	for(i=1;i<=n;i++)
//		printf("%lld,%d %lld,%d %lld,%d\n",f[i][0],g[i][0],f[i][1],g[i][1],f[i][2],g[i][2]);
	for(i=2;i<=n;i++)
		for(j=2;j<=n;j++)
			if(i!=j)
				if(edge[i][j])
				{
					if(g[i][0]==j&&g[j][0]==i)
					{
						if(g[i][1]==g[j][1])
							ans=max(ans,max(f[i][1]+a[i]+a[j]+f[j][2],f[i][2]+a[i]+a[j]+f[j][1]));
						else
							ans=max(ans,f[i][1]+a[i]+a[j]+f[j][1]);
					}
					else if(g[i][0]==j)
					{
						if(g[i][1]==g[j][0])
							ans=max(ans,max(f[i][1]+a[i]+a[j]+f[j][1],f[i][2]+a[i]+a[j]+f[j][0]));
						else
							ans=max(ans,f[i][1]+a[i]+a[j]+f[j][0]);
					}
					else if(g[j][0]==i)
					{
						if(g[i][0]==g[j][1])
							ans=max(ans,max(f[i][1]+a[i]+a[j]+f[j][1],f[i][0]+a[i]+a[j]+f[j][2]));
						else
							ans=max(ans,f[i][0]+a[i]+a[j]+f[j][1]);
					}
					else if(g[i][0]==g[j][0])
						ans=max(ans,max(f[i][0]+a[i]+a[j]+f[j][1],f[i][1]+a[i]+a[j]+f[j][0]));
					else
						ans=max(ans,f[i][0]+a[i]+a[j]+f[j][0]);
				}
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
