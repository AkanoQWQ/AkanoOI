#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;
const int N=200003,log_N=20;
const long long PIN=4557430888798830399;
int n,q,m,depth[N],ance[N][log_N];
int len_list=0,e[N*2],ne[N*2],h[N];
int len_s,s[N],len_t,t[N];
long long a[N],f[N];
void add_once(int a,int b)
{
	e[len_list]=b;
	ne[len_list]=h[a];
	h[a]=len_list;
	len_list++;
}
void add_twice(int a,int b)
{
	add_once(a,b),add_once(b,a);
}
void dfs(int u,int father,int dep)
{
	int i;
	depth[u]=dep;
	ance[u][0]=father;
	for(i=1;i<log_N;i++)
		ance[u][i]=ance[ance[u][i-1]][i-1];
	for(i=h[u];i>=0;i=ne[i])
		if(e[i]!=father)
			dfs(e[i],u,dep+1);
}
int query(int x,int y)
{
	int i;
	if(depth[x]<depth[y])
		swap(x,y);
	if(depth[x]>depth[y])
		for(i=log_N-1;i>=0;i--)
			if(depth[x]-(1<<i)>=depth[y])
				x=ance[x][i];
	if(x==y)
		return x;
	for(i=log_N-1;i>=0;i--)
		if(ance[x][i]!=ance[y][i])
			x=ance[x][i],y=ance[y][i];
	return ance[x][0];
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int i,j,k,x,y,fa;
	long long ans,s1;
	scanf("%d%d%d",&n,&q,&m);
	for(i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	memset(h,-1,sizeof h);
	for(i=1;i<n;i++)
	{
		scanf("%d%d",&x,&y);
		add_twice(x,y);
	}
	dfs(1,0,1);
	for(i=1;i<=q;i++)
	{
		scanf("%d%d",&x,&y);
		len_s=len_t=0;
		fa=query(x,y);
		for(j=x;j!=fa;j=ance[j][0])
		{
			f[j]=PIN;
			if(len_s<m)
				f[j]=a[j]+((len_s==0)?0:a[s[1]]);
			for(k=1;k<=len_s&&k<=m;k++)
				f[j]=min(f[j],f[s[len_s-k+1]]+a[j]);
			s[++len_s]=j;
		}
		f[j]=PIN;
		if(len_s<m)
			f[j]=a[j]+((len_s==0)?0:a[s[1]]);
		for(k=1;k<=len_s&&k<=m;k++)
			f[j]=min(f[j],f[s[len_s-k+1]]+a[j]);
		s[++len_s]=j;
		s1=f[j];
		for(j=y;j!=fa;j=ance[j][0])
		{
			f[j]=PIN;
			if(len_t<m)
				f[j]=a[j]+((len_t==0)?0:a[t[1]]);
			for(k=1;k<=len_t&&k<=m;k++)
				f[j]=min(f[j],f[t[len_t-k+1]]+a[j]);
			t[++len_t]=j;
		}
		f[j]=PIN;
		if(len_t<m)
			f[j]=a[j]+((len_t==0)?0:a[t[1]]);
		for(k=1;k<=len_t&&k<=m;k++)
			f[j]=min(f[j],f[t[len_t-k+1]]+a[j]);
		t[++len_t]=j;
		ans=PIN;
		for(j=0;j<len_s&&j<=m;j++)
			for(k=0;k<len_t&&k+j<=m;k++)
				ans=min(ans,((j==0)?s1:f[s[len_s-j]])+f[t[len_t-k]]);
		printf("%lld\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
