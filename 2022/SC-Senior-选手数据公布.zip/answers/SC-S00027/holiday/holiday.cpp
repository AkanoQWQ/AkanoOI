#include<iostream>
#include<cstdio>
#include<vector>
#include<algorithm>
#include<queue>
#define ll unsigned long long
using namespace std;
int n, m, k;
const int maxn = 3e3 + 1;
vector<int>g[maxn];
int val[maxn];
struct node {
	int u,step,sum;
};
queue<node>q;
vector<int>g2[maxn];
int vis[maxn][5];
int bfs() {
	int ans = 0;
	q.push({1, 0, 0});
	while(!q.empty()) {
		int u = q.front().u, step = q.front().step, sum= q.front().sum;
		q.pop();
//		cout << 1;
		if(step == 5 && u == 1) {
			ans = max(ans, sum);
			continue;
		}
		if(step != 0 && u == 1) {
			continue;
		}
		if(step == 5) {
			continue;
		}
		for(int i = 0; i < g[u].size(); i++) {
			int v = g[u][i];
			vis[1][4] = 0;
			if(vis[v][step] == 1)continue;
			vis[v][step] = 1;
			q.push({v, step + 1, sum + val[v]});
		}
	}
	return ans;
}
int bfs2() {
	int ans = 0;
	q.push({1, 0, 0});
	while(!q.empty()) {
		int u = q.front().u, step = q.front().step, sum= q.front().sum;
		q.pop();
//		cout << 1;
		if(step == 5 && u == 1) {
			ans = max(ans, sum);
			continue;
		}
		if(step != 0 && u == 1) {
			continue;
		}
		if(step == 5) {
			continue;
		}
		for(int i = 0; i < g2[u].size(); i++) {
			int v = g2[u][i];
			vis[1][4] = 0;
			if(vis[v][step] == 1)continue;
			vis[v][step] = 1;
			q.push({v, step + 1, sum + val[v]});
		}
	}
	return ans;
}
int viss[maxn];
void  BFS(int x) {
	q.push({x, 0, 0});
	viss[x] = 1;
	while(!q.empty()) {
		int u = q.front().u, step = q.front().step;
		q.pop();
		if(step == k + 1) {
			return ;
		}
		for(int i = 0; i < g[u].size(); i++) {
			int v = g[u][i];
			if(viss[v] == 1)continue;
			viss[v] = 1;
			q.push({v, step + 1, 0});
		}
	}
	return ;
}

int main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin >> n >> m >> k;
	for(int i = 2; i <= n; i++) {
		cin >> val[i];
	}
	for(int i = 1; i <= m; i++) {
		int u, v;
		cin >> u >> v;
		g[u].push_back(v);
		g[v].push_back(u);
	}
	if(k == 0) {
		cout << bfs();
		return 0;
	}
//	sort(val+1,val+1+n);
//	cout<< val[n-1]+val[n-2]+val[n-3]+val[n];
	for(int i = 1; i <= n; i++){
		memset(vis, 0, sizeof(vis));
		BFS(i);
		for(int j = 1; j <= n; j++) {
			if(viss[i]&&i != j) {
				g2[i].push_back(j);
				g2[j].push_back(i);
			}
		}
	}
	cout << bfs2();
	return 0;
}
