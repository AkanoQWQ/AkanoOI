#include<iostream>
#include<cstdio>
#include<cmath>
#define ll long long
using namespace std;
int n, m, q;
const int maxn = 1e5 + 1;
#define mid (l + r >> 1)
#define lson rt << 1, l, mid
#define rson rt << 1 | 1, mid + 1, r 
struct nodee {
	ll  vish, visz, maxx, minn, hmin0, zmin0;
}; 
struct node {
	nodee tree[maxn * 8];
	void inin() {
		for(int i = 0; i < maxn * 8; i++) {
			tree[i].hmin0 = -1e18;
			tree[i].zmin0 = 1e18;
			tree[i].maxx = tree[i].minn = tree[i].vish = tree[i].visz = 0;
			tree[i].minn = 1e18;
			tree[i].maxx = -1e18;
		}
	}
	nodee mem(nodee a, nodee b){
		nodee c;
		c.hmin0 = max(a.hmin0, b.hmin0);
		c.zmin0 = min(a.zmin0, b.zmin0);
		c.maxx = max(a.maxx, b.maxx);
		c.minn = min(a.minn, b.minn);
		c.vish = a.vish + b.vish;
		c.visz = a.visz + b.visz;
		return c;
	}
	void update(int rt, int l, int r, int p, ll val) {
		if(l == r) {
			tree[rt].minn = val;
			tree[rt].maxx = val;
			if(val < 0) {
				tree[rt].hmin0 = val;
				tree[rt].zmin0 = 1e18;
				tree[rt].vish = 1;
				tree[rt].visz = 0;
			} else {
				tree[rt].zmin0 = val;
				tree[rt].hmin0 = -1e18;
				tree[rt].vish = 0;
				tree[rt].visz = 1;
			}
			if(val == 0) {
				tree[rt].hmin0 = 0;
				tree[rt].zmin0 = 0;
			}
			return ;
		}
		if(p <= mid) {
			update(lson, p, val);
		} else {
			update(rson, p, val);
		}
		tree[rt]  = mem(tree[rt << 1], tree[rt << 1 | 1]);
		return ;
	}
	nodee query(int rt, int l, int r, int L, int R) {
		if(L <= l && r <= R) {
			return tree[rt];
		} 
		nodee ans;
		ans.hmin0 = ans.maxx = ans.minn = ans.vish = ans.visz = ans.zmin0 = 0; 
		ans.zmin0 = 1e18;
		ans.hmin0= -1e18;
		ans.maxx = -1e18;
		ans.minn = 1e18;
		if(mid >= L) {
			ans = mem(ans, query(lson, L, R));
		} 
		if(mid < R) {
			ans = mem(ans, query(rson, L, R));
		}
		return ans;
	}
};
node T1, T2;
ll slove(nodee s1, nodee s2) {
	ll ans;
	if(s2.visz && s2.vish) {
		ans = -1e18;
		if(s1.hmin0 != -1e18) {
			ans = max(s1.hmin0 * s2.maxx, ans);
		}
		if(s1.zmin0 != 1e18) {
			ans = max(s1.zmin0 * s2.minn, ans);
		}
	} else if(s2.vish == 0) {
		ans = (s1.maxx * s2.minn);
	} else {
		ans = (s1.minn * s2.maxx);
	}
	return ans;
}
int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	T1.inin();
	T2.inin();
	cin >> n >> m >> q;
	for(int i = 1; i <= n; i++) {
		ll a;
		cin >> a;
		T1.update(1, 1, n, i, a);
	}
	for(int i = 1; i <= m; i++) {
	    ll b;
		cin >> b;
		T2.update(1, 1, m, i, b);	
	} 
	for(int i = 1; i <= q; i++) {
		int l1, l2, r1, r2;
		cin >> l1 >> r1 >> l2 >> r2;
		nodee s1 = T1.query(1 , 1, n, l1, r1), s2 = T2.query(1, 1, m, l2, r2);
//		cout << s1.hmin0 << ' ' << s1.zmin0 << ' ' << s1.maxx<< ' ' << s1.minn << ' ' << s2.hmin0 << ' ' << s2.zmin0 << ' '<< s2.minn << '\n';
		cout << slove(s1, s2) << '\n';
	}
	return 0;
}
