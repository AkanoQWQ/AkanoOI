#include<iostream>
#include<cstdio>
#include<vector>
#include<algorithm>
using namespace std;
int n ,m, q;
const int maxn = 5e5 + 1;
int cnt[maxn], s[maxn];
int main() {
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n >> m;
	for(int i =  1; i <= m; i++) {
		int u, v;
		cin >> u >> v;
		cnt[u]++;
		s[u]++;
	}
	cin>>q;
	int a[99];
	for(int i = 1; i <=q; i++) {
		int t, u, v;
		cin >> t ;
		if(t == 1) {
			cin>>u>>v;
			cnt[u]--;

		}
		if(t == 2) {
			cin>>u;
			cnt[u]--;
			if(cnt[u] < 0)
			cnt[u]=0;
		}
		if(t==3) {
			cin>>u>>v;
			cnt[u]++;	
		}
		if(t == 4) {
			cin>>u;
			cnt[u]++;
			if(cnt[u]>s[u])
			cnt[u] = s[u];
		}
		int flag = 1;
		for(int i = 1; i <= n;i++) {
//			cout<<cnt[/i]<<'\n';
			if(cnt[i]!=1){
				flag=0;
				break;
			}
		}
		if(flag == 1) {
			cout << "YES"<<'\n';
		
		}else 
		cout << "NO" << '\n';
	}
	return 0;
}
