#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N = 3e2;
int n, m, k;
int a[N + 5];
int f[N + 5][N + 5];
bool vvis[N + 5];
bool vis[N + 5][5];
int dis[N + 5][5];
queue < pair < int, int > > qq, q;
vector < vector < int > > g(N + 5);
void SPFA(int s)
{
	for(int u = 1; u <= n; u ++) for(int j = 0; j <= 4; j ++) vis[u][j] = false, dis[u][j] = 0;
	while(! q.empty()) q.pop();
	vis[s][0] = true, dis[s][0] = 0, q.push(make_pair(s, 0));
	while(! q.empty()){
		int u = q.front().first, kk = q.front().second; q.pop();
		vis[u][kk] = false;
		for(int v : g[u]){
			if(v == s) break;
			if(dis[u][kk] + a[v] > dis[v][kk + 1]){
				dis[v][kk + 1] = dis[u][kk] + a[v];
				if(vis[v][kk + 1] == false && kk + 1 != 4) vis[v][kk + 1] = true, q.push(make_pair(v, kk + 1));
			}
		}
	}
}
signed main()
{
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	scanf("%lld%lld%lld", & n, & m, & k); k ++;
	for(int i = 2; i <= n; i ++) scanf("%lld", & a[i]);
	for(int i = 1; i <= m; i ++){
		int u, v; scanf("%lld%lld", & u, & v);
		f[u][v] = f[v][u] = true;
	}
	for(int s = 1; s <= n; s ++){
		for(int v = 1; v <= n; v ++) vvis[v] = false;
		while(! qq.empty()) qq.pop();
		vvis[s] = true, qq.push(make_pair(s, 0));
		while(! qq.empty()){
			int u = qq.front().first, kk = qq.front().second; qq.pop();
			for(int v = 1; v <= n; v ++){
				if(f[u][v] == 0 || vvis[v] == true || kk == k) continue;
				vvis[v] = true, qq.push(make_pair(v, kk + 1));
				g[s].push_back(v);
			}
		}
	}
	SPFA(1);
	int ans = 0;
	for(int v : g[1]) ans = max(ans, dis[v][4]);
	printf("%lld\n", ans);
	return 0;
}
