#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N = 1e5;
int n, m, q;
int a[N + 5], b[N + 5], c[N + 5], d[N + 5];
int lg[N + 5];
int tmp[2][4];
struct ST{
	int mx[N + 5][20];
	int mn[N + 5][20];
	void Init(int n, int a[])
	{
		for(int i = 1; i <= n; i ++){
			if(a[i] != 1e18 + 1) mx[i][0] = a[i];
			else mx[i][0] = - 1e18 - 1;
			if(a[i] != 1e18 + 1) mn[i][0] = a[i];
			else mn[i][0] = 1e18 + 1;
		}
		for(int j = 1; (1 << j) <= n; j ++){
			for(int i = 1; i + (1 << j) - 1 <= n; i ++){
				if(mx[i][j - 1] > mx[i + (1 << (j - 1))][j - 1]) mx[i][j] = mx[i][j - 1];
				else mx[i][j] = mx[i + (1 << (j - 1))][j - 1];
				if(mn[i][j - 1] < mn[i + (1 << (j - 1))][j - 1]) mn[i][j] = mn[i][j - 1];
				else mn[i][j] = mn[i + (1 << (j - 1))][j - 1];
			}
		}
	}
	int Qmax(int l, int r)
	{
		int k = lg[r - l + 1];
		if(mx[l][k] > mx[r - (1 << k) + 1][k]) return mx[l][k];
		else return mx[r - (1 << k) + 1][k];
	}
	int Qmin(int l, int r)
	{
		int k = lg[r - l + 1];
		if(mn[l][k] < mn[r - (1 << k) + 1][k]) return mn[l][k];
		else return mn[r - (1 << k) + 1][k];
	}
};
ST qa, qb, qc, qd;
signed main()
{
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	scanf("%lld%lld%lld", & n, & m, & q);
	for(int i = 1; i <= n; i ++) scanf("%lld", & a[i]), b[i] = 1e18 + 1;
	for(int i = 1; i <= n; i ++) if(a[i] < 0) swap(a[i], b[i]);
	for(int i = 1; i <= m; i ++) scanf("%lld", & c[i]), d[i] = 1e18 + 1;
	for(int i = 1; i <= m; i ++) if(c[i] < 0) swap(c[i], d[i]);
	lg[1] = 0; for(int i = 2; i <= max(n, m); i ++) lg[i] = lg[i >> 1] + 1;
	qa.Init(n, a), qb.Init(n, b), qc.Init(m, c), qd.Init(m, d);
	while(q --){
		int l_1, r_1, l_2, r_2; scanf("%lld%lld%lld%lld", & l_1, & r_1, & l_2, & r_2);
		tmp[0][0] = qa.Qmax(l_1, r_1), tmp[0][1] = qa.Qmin(l_1, r_1), tmp[0][2] = qb.Qmax(l_1, r_1), tmp[0][3] = qb.Qmin(l_1, r_1);
		tmp[1][0] = qc.Qmax(l_2, r_2), tmp[1][1] = qc.Qmin(l_2, r_2), tmp[1][2] = qd.Qmax(l_2, r_2), tmp[1][3] = qd.Qmin(l_2, r_2);
		int maxn = - 1e18 - 1;
		for(int j = 0; j < 4; j ++){
			int minn = 1e18 + 1;
			for(int k = 0; k < 4; k ++){
				if(tmp[0][j] == 1e18 + 1 || tmp[0][j] == - 1e18 - 1 || tmp[1][k] == 1e18 + 1 || tmp[1][k] == - 1e18 - 1) continue;
				minn = min(minn, tmp[0][j] * tmp[1][k]);
			}
			maxn = max(maxn, minn);
		}
		printf("%lld\n", maxn);
	}
	return 0;
}
