#include <bits/stdc++.h>
using namespace std;
const int N = 5e5, M = 5e5;
int n, m, q, cnt;
int oud[N + 5];
map < pair < int, int >, bool > E, e;
vector < vector < int > > g(N + 5);
int main()
{
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	scanf("%d%d", & n, & m);
	for(int i = 1; i <= m; i ++){
		int u, v; scanf("%d%d", & u, & v);
		oud[u] ++;
		E[make_pair(u, v)] = e[make_pair(u, v)] = true;
	}
	for(int u = 1; u <= n; u ++) if(oud[u] == 1) cnt ++;
	scanf("%d", & q);
	while(q --){
		int t, u, v; scanf("%d", & t);
		if(t == 1){
			scanf("%d%d", & u, & v);
			if(oud[u] == 1) cnt --;
			oud[u] --;
			if(oud[u] == 1) cnt ++;
			e[make_pair(u, v)] = false;
		}
		if(t == 2){
			scanf("%d", & u);
			for(v = 1; v <= n; v ++){
				if(E[make_pair(v, u)] == false || e[make_pair(v, u)] == false) continue;
				if(oud[v] == 1) cnt --;
				oud[v] --;
				if(oud[v] == 1) cnt ++;
				e[make_pair(v, u)] = false;
			}
		}
		if(t == 3){
			scanf("%d%d", & u, & v);
			if(oud[u] == 1) cnt --;
			oud[u] ++;
			if(oud[u] == 1) cnt ++;
			e[make_pair(u, v)] = true;
		}
		if(t == 4){
			scanf("%d", & u);
			for(v = 1; v <= n; v ++){
				if(E[make_pair(v, u)] == false || e[make_pair(v, u)] == true) continue;
				if(oud[v] == 1) cnt --;
				oud[v] ++;
				if(oud[v] == 1) cnt ++;
				e[make_pair(v, u)] = true;
			}
		}
		puts(cnt == n ? "YES" : "NO");
	}
	return 0;
}
