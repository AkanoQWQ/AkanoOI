#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N = 2e3;
int n, Q, k;
int a[N + 5];
int g[N + 5][N + 5], f[N + 5][N + 5];
bool vis[N + 5];
queue < pair < int, int > > q;
signed main()
{
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	scanf("%lld%lld%lld", & n, & Q, & k);
	for(int u = 1; u <= n; u ++) scanf("%lld", & a[u]);
	for(int i = 1; i <= n - 1; i ++){
		int u, v; scanf("%lld%lld", & u, & v);
		g[u][v] = g[v][u] = 1;
	}
	for(int u = 1; u <= n; u ++) for(int v = 1; v <= n; v ++) f[u][v] = 1e17;
	for(int u = 1; u <= n; u ++) f[u][u] = 0;
	for(int s = 1; s <= n; s ++){
		for(int v = 1; v <= n; v ++) vis[v] = false;
		while(! q.empty()) q.pop();
		vis[s] = true, q.push(make_pair(s, 0));
		while(! q.empty()){
			int u = q.front().first, kk = q.front().second; q.pop();
			for(int v = 1; v <= n; v ++){
				if(g[u][v] == 0 || vis[v] == true || kk == k) continue;
				vis[v] = true, q.push(make_pair(v, kk + 1));
				f[s][v] = a[v];
			}
		}
	}
	for(int w = 1; w <= n; w ++){
		for(int u = 1; u <= n; u ++){
			for(int v = 1; v <= n; v ++){
				f[u][v] = min(f[u][v], f[u][w] + f[w][v]);
			}
		}
	}
	while(Q --){
		int u, v; scanf("%lld%lld", & u, & v);
		printf("%lld\n", a[u] + f[u][v]);
	}
	return 0;
}
