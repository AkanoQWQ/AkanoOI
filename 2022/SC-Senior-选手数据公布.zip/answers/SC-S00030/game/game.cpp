#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<ctime>
using namespace std;
const int N=1e5+100;
int n,m,q;
long long a[N],b[N];
int l1,r1,l2,r2;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;++i) scanf("%lld",&a[i]);
	for(int i=1;i<=m;++i) scanf("%lld",&b[i]);
	while(q--)
	{
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		long long bmx=-1e9-1,bmi=1e9+1,mx=-1e18-1,ling=0;
		for(int i=l2;i<=r2;++i)
		{
			bmx=max(bmx,b[i]),bmi=min(bmi,b[i]);
		}
		for(int i=l1;i<=r1;++i)
		{
			if(a[i]>0) mx=max(mx,a[i]*bmi);
			if(a[i]==0) mx=max(mx,ling);
			if(a[i]<0) mx=max(mx,a[i]*bmx);
		}
		cout<<mx<<"\n";
	}
	return 0;
}
/*6 4 1
3 -1 -2 1 2 0
1 2 -1 -3
1 5 1 4*/

