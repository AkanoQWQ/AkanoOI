#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<ctime>
using namespace std;
const int N=10100;
long long n,m,k,s[N],X,Y;
int t[550][550];
int zc[550][550];
long long ans=-1;
bool h[N],th[N];
int cz(int a,int b)
{
	if(zc[a][b]!=-1||zc[b][a]!=-1) return zc[a][b];
	if(t[a][b]) return 0;
	int minn=1e9;
	for(int i=1;i<=n;++i)
	{
	   if(th[i])
	   {
	   	if(!h[i])
	   {
	   	h[i]=true;
		minn=min(minn,cz(a,i)+cz(i,b)+1);
		h[i]=false;
	   }
	   }
	}
	zc[a][b]=zc[b][a]=min(zc[a][b],minn);
	return minn;
}
long long sum;
bool flag;
void bl(int dep,int cs)
{
	if(flag) return ;
	if(dep==1&&cs==5) 
	{
		flag=true;
		ans=max(ans,sum);
		return ;
	}
	if(dep==1&&cs!=5) return ;
	if(cs==5&&dep!=1) return ;
	for(int i=1;i<=n;++i)
	{
		if(i==1&&cs<4) continue;
		if(i!=dep)
		{
			if(!h[i]&&zc[dep][i]<=k&&zc[dep][i]!=-1)
			{
				h[i]=true;
				sum+=s[i];
				bl(i,cs+1);
				sum-=s[i];
				h[i]=false;
			}
		}
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	for(int i=2;i<=n;++i) scanf("%lld",&s[i]);
	memset(zc,-1,sizeof zc);
	for(int i=1;i<=m;++i)
	{
		scanf("%lld%lld",&X,&Y);
		t[X][Y]=t[Y][X]=1;
		zc[X][Y]=zc[Y][X]=0;
		th[X]=th[Y]=true;
	}
	for(int i=1;i<=n;++i)
	{
		for(int j=i+1;j<=n;++j)
		{
			if(th[i]&&th[j])
			{
				zc[i][j]=zc[j][i]=cz(i,j);
			}
		}
	}
		for(int j=2;j<=n;++j)
		{
			if(zc[1][j]<=k&&zc[1][j]!=-1)
			{
				flag=false;
				sum=s[j];
				h[j]=true;
				bl(j,1);
				h[j]=false;
			}
		}
	cout<<ans;
	return 0;
}
