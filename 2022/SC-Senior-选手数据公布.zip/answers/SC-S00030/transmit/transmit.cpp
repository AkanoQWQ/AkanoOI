#include<iostream>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<cstring>

using namespace std;
const int N=2e5+100;
int n,Q,k;
long long s[N],A,B;
long long h[N],e[N],ne[N],idx,S,T;
void add(long long a,long long b)
{
	e[++idx]=b,ne[idx]=h[a],h[a]=idx;
}
bool v[N];
long long mil=1e9;
long long cs(long long a,long long b)
{
    long long minn=1e9;
    for(int i=h[a];i;i=ne[i])
    {
    	if(!v[e[i]])
    	{
    		v[e[i]]=true;
    		long long j=s[e[i]]+cs(b,e[i]);
			minn=min(minn,j);
			//cout<<minn<<endl;
			v[e[i]]=false;
		}
	}
	for(int i=h[b];i;i=ne[i])
	{
		if(!v[e[i]])
		{
			v[e[i]]=true;
			minn=min(minn,s[e[i]]+cs(a,e[i]));
			v[e[i]]=false;
		}
	}
	return minn;
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&Q,&k);
	for(int i=1;i<=n;++i) scanf("%lld",&s[i]);
	for(int i=1;i<=n-1;++i)
	{
		scanf("%lld%lld",&A,&B);
		add(A,B);
		add(B,A);
	}
	while(Q--)
	{
		scanf("%lld%lld",&S,&T);
		printf("%lld\n",s[S]+s[T]);
	}
	return 0;
}
