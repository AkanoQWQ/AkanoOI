#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<ctime>
using namespace std;
const int N=5e5+100;
int n,m,q,u,v;
int h[N],e[N],ne[N],idx,t;
bool b[N];
int js[N],f;
void add(int a,int b)
{
	e[++idx]=b,ne[idx]=h[a],h[a]=idx;
}
void bl(int dep)
{
	if(f==1||f==2) return ; 
	int cs=0;
	for(int i=h[dep];i;i=ne[i])
	{
		if(!b[i]) 
		{
			++cs;
		}
		if(cs>1)
		{
			f=1;
			return ;
		}
	}
	if(cs==0)
	{
		f=1;
		return ;
	}
	for(int i=h[dep];i;i=ne[i])
	{
		if(!b[i])
		{
			js[e[i]]++;
		if(js[e[i]]>1)
		{
			f=2;
			return ;
		}
		bl(e[i]);
		break;
		}
	}
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;++i)
	{
		scanf("%d%d",&u,&v);
		add(u,v);
	}
	scanf("%d",&q);
	while(q--)
	{
		scanf("%d",&t);
		if(t==1) 
		{
			scanf("%d%d",&u,&v);
			for(int i=h[u];i;i=ne[i])
			{
				if(e[i]==v)
				{
					b[i]=true;
				//	cout<<i<<" ";
					break;
				}
			}
		}
		else if(t==2)
		{
			scanf("%d",&u);
			for(int i=1;i<=n;++i)
			{
				for(int j=h[i];j;j=ne[j])
				{
					if(e[j]==u) 
					{
						b[j]=true;
						break;
					}
				}
			}
		}
		else if(t==3)
		{
			scanf("%d%d",&u,&v);
			for(int i=h[u];i;i=ne[i])
			{
				if(e[i]==v)
				{
					b[i]=false;
					break;
				}
			}
		}
		else 
		{
			scanf("%d",&u);
			for(int i=1;i<=n;++i)
			{
				for(int j=h[i];j;j=ne[j])
				{
					if(e[j]==u) 
					{
						b[j]=false;
						break;
					}
				}
			}
		}
		f=0;
		for(int i=1;i<=n;++i)
		{
			memset(js,0,sizeof js);
		    js[i]++;
		    if(f==1) break;
		    if(f==2&&i==n) break;
		    f=0;
		    bl(i);
		}
		if(f==2) 
		{
			cout<<"YES\n";
		}
		else if(f==1) cout<<"NO\n";
		else cout<<"NO\n";
	}
	return 0;
}
/*6 4 1
3 -1 -2 1 2 0
1 2 -1 -3
1 5 1 4*/
/*5 7
1 2
2 3
3 2
3 4
4 5
5 4 
5 1*/

