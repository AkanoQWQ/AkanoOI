#include<bits/stdc++.h>
using namespace std;
#define max(a,b) a>b?a:b
#define min(a,b) a<b?a:b
#define ll long long
ll n,m,q,l1,l2,r1,r2,ans,k,maxx,minn;
ll a[200000],b[200000];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
	}
	for(int i=1;i<=m;i++)
	{
		scanf("%lld",&b[i]);
	}
	for(int i=1;i<=q;i++)
	{
		k=2000000000000000000;
		minn=2000000000000000000;
		maxx=-2000000000000000000;
		ans=-2000000000000000000;
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		for(int j=l2;j<=r2;j++)
		{
			maxx=max(b[j],maxx);
			minn=min(b[j],minn);
		}
		for(int j=l1;j<=r1;j++)
		{
			k=min(a[j]*minn,a[j]*maxx);
			ans=max(ans,k);
			//printf("%lld %lld\n",k,ans);
		}
		printf("%lld\n",ans);
	}
	return 0;
}
