#include<bits/stdc++.h>
using namespace std;
struct p
{
	int fr,to,next;
}e[1010000];
int cnt,n,m,k,a[2000000],Next[2000000],ans,vis[2000000];
void add(int fr,int to)
{
	cnt++;
	e[cnt].fr=fr;
	e[cnt].to=to;
	e[cnt].next=Next[fr];
	Next[fr]=cnt;
}
void dfs(int u,int j,int y)
{
	if(j==0 && u==1)
	{
		ans=max(ans,y);
		return;
	}
	for(int i=Next[u];i;i=e[i].next)
	{
		if((e[i].to!=1 || j==1) && !vis[e[i].to])
		{
			vis[e[i].to]=1;
			dfs(e[i].to,j-1,y+a[u]);
			vis[e[i].to]=0;
		}
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n-1;i++)
	{
		scanf("%d",&a[i+1]);
	}
	for(int i=1;i<=m;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
	}
	dfs(1,5,0);
	printf("%d",ans);
	return 0;
}
