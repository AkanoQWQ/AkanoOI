#include<cstdio>
using namespace std;
const int maxn=1e4+5,maxc=3e3+5;
int n,m,k,Point[maxn];
struct Edge{
	int To,Next;
}; 
Edge Graph[2*maxn];
int Head[maxn],Len;
void Read_connected_graph(int st,int en){
	Graph[++Len].To=en;
	Graph[Len].Next=Head[st];
	Head[st]=Len;
}
void Read(){
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++){
		scanf("%d",&Point[i]);
	}
	int st,en;
	for(int i=1;i<=m;i++){
		scanf("%d%d",&st,&en);
		Read_connected_graph(st,en);
		Read_connected_graph(en,st);
	}
}
bool Arr1[maxn][maxn];
int Arr2[maxn][maxn],Num[maxn];
void Look_for(int an,int st,int num){
	if(st!=an){
	    Arr2[an][++Num[an]]=st;
	    Arr1[an][st]=Arr1[st][an]=1;
	}
	if(num==0){
		return;
	}
	int i,y;
	for(i=Head[st];i;i=Graph[i].Next){
		y=Graph[i].To;
		Look_for(an,y,num-1);
	}
}
int Answer;
int Mid[maxn][maxn][2],Num_mid,Num_fa[maxn];
int Max(int a,int b){
	return a>b?a:b;
}
bool Mid_vis[maxn];
int Mid_num,Mid_poi[maxn];
void Solve(){
	int i,j,z,g;
	for(i=1;i<=n;i++){
		Look_for(i,i,k+1);
	}
	int x1,x2;
	for(i=1;i<=Num[1];i++){
		x1=Arr2[1][i];
		for(j=1;j<=Num[x1];j++){
			x2=Arr2[x1][j];
			if(x2!=1){
				if(Mid_vis[x2]!=1){
					Mid_poi[++Mid_num]=x2;
					Mid_vis[x2]=1;
					Mid[x2][++Num_fa[x2]][0]=x1;
				    Mid[x2][Num_fa[x2]][1]=Point[x1]+Point[x2];
				}
				else{
				    Mid[x2][++Num_fa[x2]][0]=x1;
				    Mid[x2][Num_fa[x2]][1]=Point[x1]+Point[x2];
//				    printf("%d ",Num_fa[x2]);
				}
			}
		}
	}
	for(i=1;i<=Mid_num;i++){
		x1=Mid_poi[i];
		for(j=1;j<=Mid_num;j++){
			x2=Mid_poi[j];
			if(x1!=x2&&Arr1[x1][x2]==1){
				for(z=1;z<=Num_fa[x1];z++){
//					printf("%d ",x1);
                    if(Mid[x1][z][0]!=x2){
		                for(g=1;g<=Num_fa[x2];g++){
		                    if(Mid[x1][z][0]!=Mid[x2][g][0]&&Mid[x2][g][0]!=x1){
		                	    Answer=Max(Answer,Mid[x1][z][1]+Mid[x2][g][1]);
						    }
		                }
					}
		        }
			}
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	Read();
	Solve();
	printf("%d",Answer);
	return 0;
}
