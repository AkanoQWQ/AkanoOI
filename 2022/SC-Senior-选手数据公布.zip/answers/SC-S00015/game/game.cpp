#include<cstdio>
#include<algorithm>
using namespace std;
typedef long long lld;
const int maxn=1e5+5,inf=0x3f3f3f3f;
int n,m,q;
int Num_a[maxn],Num_b[maxn];
struct GAME{
	int l1,r1,l2,r2;
	lld ans1,ans2;
};
GAME Game[maxn];
void Read(){
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++){
		scanf("%d",&Num_a[i]);
	}
	for(int i=1;i<=m;i++){
		scanf("%d",&Num_b[i]);
	}
	for(int i=1;i<=q;i++){
		scanf("%d%d%d%d",&Game[i].l1,&Game[i].r1,&Game[i].l2,&Game[i].r2);
	}
}
int Max_a(int st,int en){
	int Max=0;
	for(int i=st;i<=en;i++){
		Max=max(Max,Num_a[i]);
	}
	return Max;	
}
int Min_a(int st,int en){
	int Min=inf;
	for(int i=st;i<=en;i++){
		Min=min(Min,Num_a[i]);
	}
	return Min;
}
int Max_b(int st,int en){
	int Max=0;
	for(int i=st;i<=en;i++){
		Max=max(Max,Num_b[i]);
	}
	return Max;	
}
int Min_b(int st,int en){
	int Min=inf;
	for(int i=st;i<=en;i++){
		Min=min(Min,Num_b[i]);
	}
	return Min;
}
int Min_a_abs(int st,int en){
	int Min=inf;
	for(int i=st;i<=en;i++){
		Min=min(Min,abs(Num_a[i]));
	}
	return Min;
}
int Min_b_abs(int st,int en){
	int Min=inf;
	for(int i=st;i<=en;i++){
		Min=min(Min,abs(Num_b[i]));
	}
	return Min;
}
int check_a(int st,int en){
	int he_f=0,he=0,sta=en-st+1;
	for(int i=st;i<=en;i++){
		if(Num_a[i]<0){
			he_f++;
		}
		else if(Num_a[i]>=0){
			he++;
		}
	}
	if(he_f==sta){
		return 0;
	}
	else if(he==sta){
		return 1;
	}
	else{
		return 2;
	}
}
int check_b(int st,int en){
	int he_f=0,he=0,sta=en-st+1;
	for(int i=st;i<=en;i++){
		if(Num_a[i]<0){
			he_f++;
		}
		else if(Num_b[i]>=0){
			he++;
		}
	}
	if(he_f==sta){
		return 0;
	}
	else if(he==sta){
		return 1;
	}
	else{
		return 2;
	}
}
void Solve(){
	int l1,l2,r1,r2;
	for(int i=1;i<=q;i++){
		l1=Game[i].l1,l2=Game[i].l2,r1=Game[i].r1,r2=Game[i].r2;
		if(Game[i].l1==Game[i].r1){
			printf("%lld\n",Num_a[Game[i].l1]*Min_b(Game[i].l2,Game[i].r2));
			continue;
		}
		else if(Game[i].l2==Game[i].r2){
			printf("%lld\n",Num_b[Game[i].l2]*Max_a(Game[i].l1,Game[i].r1));
			continue;
		}
		int an1=check_a(Game[i].l1,Game[i].r1),an2=check_b(Game[i].l2,Game[i].r2);
		if(an1==0&&an2==0){
			printf("%lld\n",Min_a(l1,r1)*Max_b(l2,r2));
		}
		else if((an1==1&&an2==0)||(an1==0&&an2==1)){
			printf("%lld",Min_a(l1,r1)*Min_b(l2,r2));
		}
		else if(an1==1&&an2==1){
			printf("%lld",Max_a(l1,r1)*Min_b(l2,r2));
		}
		else if((an1==2&&an2!=2)){
			printf("%lld",Min_a(l1,r1)*Max(l2,r2));
		}
	}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	Read();
	Solve();
	return 0;
}
