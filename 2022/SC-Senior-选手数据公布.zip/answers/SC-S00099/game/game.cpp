#include <cstdio>
#include <iostream>

long long n, m, q, x[1005], y[1005];
long long l1[1005], r1[1005], l2[1005], r2[1005];
long long mi[1005][1005], ma[1005][1005];

int main(){
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	std::cin >> n >> m >> q;
	for(long long i = 1; i <= n; ++i) std::cin >> x[i];
	for(long long i = 1; i <= m; ++i) std::cin >> y[i], mi[i][i] = ma[i][i] = y[i];
	for(long long i = 1; i <= q; ++i) std::cin >> l1[i] >> r1[i] >> l2[i] >> r2[i];
	for(long long i = 1; i <= m; ++i){
		for(long long j = i + 1; j <= m; ++j){
			mi[i][j] = std::min(mi[i][j - 1], y[j]);
			ma[i][j] = std::max(ma[i][j - 1], y[j]);
		}
	}
	for(long long i = 1; i <= q; ++i){
		long long ans = -0x3f3f3f3f3f3f3f3f;
		long long mii = mi[l2[i]][r2[i]], maa = ma[l2[i]][r2[i]];
		for(long long j = l1[i]; j <= r1[i]; ++j)
			if(x[j] >= 0) ans = std::max(ans, x[j] * mii);
			else ans = std::max(ans, x[j] * maa);
		std::cout << ans << '\n';
	}
	return 0;
} 
