#include <cstdio>
#include <iostream>

long long n, m, k, v[2505], e[2505][2505], now, book[2505], ans;
void dfs(long long dep, long long x){
	book[x] = 1;
	now += v[x];
	if(dep == 4){
		if(e[x][1] <= k + 1) ans = std::max(ans, now);
		book[x] = 0;
		now -= v[x];
		return;
	}
	for(long long i = 1; i <= n; ++i)
		if(!book[i] && e[x][i] <= k + 1)
			dfs(dep + 1, i);
	book[x] = 0;
	now -= v[x];
	return;
}

int main(){
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout); 
	std::cin >> n >> m >> k;
	for(long long i = 2; i <= n; ++i) std::cin >> v[i];
	for(long long i = 1; i <= n; ++i)
		for(long long j = 1; j <= n; ++j)
			if(i != j) e[i][j] = 0x3f3f3f3f3f3f3f3f;
	for(long long i = 1; i <= m; ++i){
		long long a, b; std::cin >> a >> b;
		e[a][b] = e[b][a] = 1;
	}
	for(long long p = 1; p <= n; ++p)
		for(long long i = 1; i <= n; ++i)
			for(long long j = 1; j <= n; ++j)
				e[i][j] = std::min(e[i][j], e[i][p] + e[p][j]);
	dfs(0, 1);
	std::cout << ans;
	return 0;
} 
