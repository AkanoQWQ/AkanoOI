#include <cstdio>
#include <iostream>
#include <vector>
using namespace std;

vector<long long> e[200005];
long long n, q, k, book[200005], v[200005], d[200005];
long long f[200005][18], s[200005][18];
void dfs(long long x){
	book[x] = 1;
	for(long long i = 0; i < e[x].size(); ++i)
		if(!book[e[x][i]]){
			f[e[x][i]][0] = x;
			s[e[x][i]][0] = v[x];
			d[e[x][i]] = d[x] + 1;
			dfs(e[x][i]);
		}
	book[x] = 0;
}
long long lca(long long x, long long y){
	long long tot = v[x] + v[y];
	if(d[x] < d[y]) swap(x, y);
	for(long long i = 17; i >= 0; --i){
		if(d[f[x][i]] < d[y]) continue;
		tot += s[x][i], x = f[x][i];
	}
	if(x == y) return tot - v[x];
	for(long long i = 17; i >= 0; --i){
		if(f[x][i] == f[y][i]) continue;
		tot += s[x][i], x = f[x][i];
		tot += s[y][i], y = f[y][i];
	}
	tot += s[x][0];
	return tot;
}

int main(){
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	cin >> n >> q >> k;
	for(long long i = 1; i <= n; ++i) cin >> v[i];
	for(long long i = 1; i < n; ++i){
		long long a, b;
		scanf("%lld%lld", &a, &b);
		e[a].push_back(b);
		e[b].push_back(a);
	}
	d[1] = 1;
	dfs(1);
	for(long long i = 1; i <= 17; ++i)
		for(long long j = 1; j <= n; ++j){
			f[j][i] = f[f[j][i - 1]][i - 1];
			s[j][i] = s[j][i - 1] + s[f[j][i - 1]][i - 1];
	}
	for(long long i = 1; i <= q; ++i){
		long long p, q; cin >> p >> q;
		printf("%lld\n", lca(p, q));
	}
	return 0;
} 
