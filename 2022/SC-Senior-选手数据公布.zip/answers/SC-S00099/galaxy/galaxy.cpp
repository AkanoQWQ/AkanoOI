#include <cstdio>
#include <iostream>
using namespace std;

long long n, m, e[1005][1005], q;

int main(){
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	cin >> n >> m;
	for(long long i = 1; i <= m; ++i){
		long long a, b; cin >> a >> b;
		e[a][b] = 1, ++e[a][0], ++e[b][n + 1];
	}
	cin >> q;
	for(long long i = 1; i <= q; ++i){
		long long t, a, b; cin >> t;
		if(t == 1) cin >> a >> b, e[a][b] = 2, --e[a][0], --e[b][n + 1];
		if(t == 2){
			cin >> a;
			for(long long i = 1; i <= n; ++i)
				if(e[i][a] == 1) e[i][a] = 2, --e[i][0], --e[a][n + 1];
		}
		if(t == 3) cin >> a >> b, e[a][b] = 1, ++e[a][0], ++e[b][n + 1];
		if(t == 4){
			cin >> a;
			for(long long i = 1; i <= n; ++i)
				if(e[i][a] == 2) e[i][a] = 1, ++e[i][0], ++e[a][n + 1];
		}
		long long flag = 0;
		for(long long j = 1; j <= n; ++j){
			if(e[j][0] != 1){
				flag = 1;
				break;
			}
		}
		if(flag == 0) cout << "YES\n";
		else cout << "NO\n";
	}
	return 0;
} 
