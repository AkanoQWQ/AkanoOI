#include<bits/stdc++.h>
#define int long long
const int N = 2e5 + 5;
inline int read(){
	int s = 0, f = 0; char ch = getchar();
	while(!isdigit(ch)){if(ch == '-') f = 1; ch = getchar();}
	while(isdigit(ch)) s = s * 10 + ch - 48, ch = getchar();
	return f ? ~s + 1 : s;
}
inline int min(int x, int y){return x < y ? x : y;}
inline int max(int x, int y){return x > y ? x : y;}
int n, m, q;
int a[N];
struct SMT{
	struct node{
		int l, r, mx, mn, _mx, _mn;
		node(){mx = _mx = -INT_MAX, mn = _mn = INT_MAX; return;}
	}tr[N << 2];
	void pushup(int p){
		tr[p].mx = max(tr[p << 1].mx, tr[p << 1 | 1].mx);
		tr[p]._mx = max(tr[p << 1]._mx, tr[p << 1 | 1]._mx);
		tr[p].mn = min(tr[p << 1].mn, tr[p << 1 | 1].mn);
		tr[p]._mn = min(tr[p << 1]._mn, tr[p << 1 | 1]._mn);
		return;
	}
	void build(int l, int r, int p){
		tr[p].l = l, tr[p].r = r;
		if(l == r){
			if(a[l] > 0)
				tr[p].mx = tr[p].mn = a[l],
				tr[p]._mn = INT_MAX, tr[p]._mx = -INT_MAX;
			else if(a[l] < 0)
				tr[p]._mx = tr[p]._mn = -a[l],
				tr[p].mn = INT_MAX, tr[p].mx = -INT_MAX;
			else tr[p].mx = tr[p].mn = tr[p]._mx = tr[p]._mn = 0;
			return;
		}
		int mid = l + r >> 1;
		build(l, mid, p << 1);
		build(mid + 1, r, p << 1 | 1);
		pushup(p);
		return; 
	}
	int querymx(int l, int r, int p){
		if(l <= tr[p].l && tr[p].r <= r) return tr[p].mx;
		int mid = tr[p].l + tr[p].r >> 1, res = -INT_MAX;
		if(l <= mid) res = max(res, querymx(l, r, p << 1));
		if(r > mid) res = max(res, querymx(l, r, p << 1 | 1));
		return res;
	}
	int query_mx(int l, int r, int p){
		if(l <= tr[p].l && tr[p].r <= r) return tr[p]._mx;
		int mid = tr[p].l + tr[p].r >> 1, res = -INT_MAX;
		if(l <= mid) res = max(res, query_mx(l, r, p << 1));
		if(r > mid) res = max(res, query_mx(l, r, p << 1 | 1));
		return res;
	}
	int querymn(int l, int r, int p){
		if(l <= tr[p].l && tr[p].r <= r) return tr[p].mn;
		int mid = tr[p].l + tr[p].r >> 1, res = INT_MAX;
		if(l <= mid) res = min(res, querymn(l, r, p << 1));
		if(r > mid) res = min(res, querymn(l, r, p << 1 | 1));
		return res;
	}
	int query_mn(int l, int r, int p){
		if(l <= tr[p].l && tr[p].r <= r) return tr[p]._mn;
		int mid = tr[p].l + tr[p].r >> 1, res = INT_MAX;
		if(l <= mid) res = min(res, query_mn(l, r, p << 1));
		if(r > mid) res = min(res, query_mn(l, r, p << 1 | 1));
		return res;
	}
}S;
main(){
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	n = read(), m = read(), q = read();
	for(int i = 1; i <= n + m; ++ i) a[i] = read();
	S.build(1, n + m, 1);
	while(q --){
		int l1 = read(), r1 = read(), l2 = read() + n, r2 = read() + n;
		bool x1 = S.querymx(l1, r1, 1) != -INT_MAX, y1 = S.query_mx(l1, r1, 1) != -INT_MAX;
		bool x2 = S.querymx(l2, r2, 1) != -INT_MAX, y2 = S.query_mx(l2, r2, 1) != -INT_MAX;
//		printf("%d %d %d %d\n", S.querymx(l2, r2, 1), S.query_mx(l2, r2, 1), l2, r2);
		if(!y2){ //only +
//			puts("only +");
			if(x1) printf("%lld\n", S.querymx(l1, r1, 1) * S.querymn(l2, r2, 1));
			else printf("%lld\n", -S.query_mn(l1, r1, 1) * S.querymx(l2, r2, 1));
		}
		else if(!x2){ //only -
//			puts("only -");
			if(y1) printf("%lld\n", S.query_mx(l1, r1, 1) * S.query_mn(l2, r2, 1));
			else printf("%lld\n", -S.querymn(l1, r1, 1) * S.query_mx(l2, r2, 1));
		}
		else{ //+ and -
//			puts("+ and -");
			if(!y1) printf("%lld\n", -S.querymn(l1, r1, 1) * S.query_mx(l2, r2, 1));
			else if(!x1) printf("%lld\n", -S.query_mn(l1, r1, 1) * S.querymx(l2, r2, 1));
			else printf("%lld\n", max(-S.querymn(l1, r1, 1) * S.query_mx(l2, r2, 1), -S.query_mn(l1, r1, 1) * S.querymx(l2, r2, 1)));
		}
	}
	return 0;
}
