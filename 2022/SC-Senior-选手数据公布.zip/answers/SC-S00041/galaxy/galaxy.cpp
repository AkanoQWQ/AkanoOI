#include<bits/stdc++.h>
inline int read(){
	int s = 0, f = 0; char ch = getchar();
	while(!isdigit(ch)){if(ch == '-') f = 1; ch = getchar();}
	while(isdigit(ch)) s = s * 10 + ch - 48, ch = getchar();
	return f ? ~s + 1 : s;
}
inline int min(int x, int y){return x < y ? x : y;}
inline int max(int x, int y){return x > y ? x : y;}
int n, m, q, tot;
int f[1005][1005], g[1005][1005], t[1005], in[1005];
bool check(){
//	puts("---");
//	for(int i = 1; i <= n; ++ i) printf("%d ", t[i]);
//	printf("\n%d\n", tot);
//	puts("---");
	if(tot != n) return false;
	for(int i = 1; i <= n; ++ i){
		int cnt = 0;
		for(int j = 1; j <= n; ++ j) cnt += g[i][j];
		if(cnt != 1) return false;
	}
//	for(int i = 1; i <= n; ++ i)
//		for(int j = 1; j <= n; ++ j) in[j] += g[i][j];
//	for(int i = 1; i <= n; ++ i){
//		int pos = i, last = 0;
//		while(!vis[pos] && !in[pos]){
//			last = pos, vis[pos] = i;
//			for(int j = 1; j <= n; ++ j)
//				if(g[pos][j]){
//					pos = j;
//					break;
//				}
//		}
//	}
//	std::queue<int> q;
//	memset(in, 0, sizeof in);
//	for(int i = 1; i <= n; ++ i) ++ in[t[i]];
//	if(in[0]) return false;
//	for(int i = 1; i <= n; ++ i)
//		if(!in[i]) q.push(i);
//	int cnt = 0;
//	while(!q.empty()){
//		int u = q.front(); q.pop();
//		++ cnt;
//		-- in[t[u]];
//		if(in[t[u]] == 0) q.push(t[u]);
//	}
//	return cnt != n;
}
int main(){
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	n = read(), tot = m = read();
	for(int i = 1; i <= m; ++ i){
		int u = read(), v = read();
		f[u][v] = g[u][v] = 1, t[u] = v;
	}
	q = read();
	while(q --){
		int opt = read();
		if(opt == 1){
			int u = read(), v = read();
			g[u][v] = 0, -- tot;
		}
		else if(opt == 2){
			int u = read();
			for(int i = 1; i <= n; ++ i) g[i][u] = 0, tot -= g[i][u];
		}
		else if(opt == 3){
			int u = read(), v = read(); 
			g[u][v] = 1, ++ tot;
		}
		else{
			int u = read();
			for(int i = 1; i <= n; ++ i) tot += f[i][u] - g[i][u], g[i][u] = f[i][u];
		}
		if(check()) puts("YES");
		else puts("NO");
	}
	return 0;
}
//�ݻ٣��ݻ�һ����/�ݻ�u�������
//�޸����޸�һ����/�޸�u�������
//ʵ�ַ�����u�뻷��ͨ 
//�������󣺳���Ϊ1
//���������е����Ϊ1���뻷��ͨ 
/*
3 6
2 3
2 1
1 2
1 3
3 1
3 2
11
1 3 2
1 2 3
1 1 3
1 1 2
3 1 3
3 3 2
2 3
1 3 1
3 1 3
4 2
1 3 2
*/
