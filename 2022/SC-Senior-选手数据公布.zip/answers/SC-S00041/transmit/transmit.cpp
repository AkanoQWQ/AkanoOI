#include<bits/stdc++.h>
#define PII std::pair<int, int>
const int N = 1e5 + 5;
inline int read(){
	int s = 0, f = 0; char ch = getchar();
	while(!isdigit(ch)){if(ch == '-') f = 1; ch = getchar();}
	while(isdigit(ch)) s = s * 10 + ch - 48, ch = getchar();
	return f ? ~s + 1 : s;
}
inline int min(int x, int y){return x < y ? x : y;}
inline int max(int x, int y){return x > y ? x : y;}
int n, q, k;
int wgt[N], dpt[N], dist[N];
int head[N], ne[N << 1], to[N << 1], idx;
int f[N][20];
//std::vector<PII> v;
inline void add(int u, int v){
	to[++ idx] = v, ne[idx] = head[u], head[u] = idx;
	return;
}
void dfs(int u, int fa){
	dist[u] = dist[fa] + wgt[u], dpt[u] = dpt[fa] + 1, f[u][0] = fa;
	for(int i = 1; i <= n; ++ i)
		f[u][i] = f[f[u][i - 1]][i - 1];
	for(int i = head[u]; i; i = ne[i]){
		int v = to[i];
		if(v == fa) continue;
		dfs(v, u);
	}
	return;
}
inline int lca(int u, int v){
	if(dpt[u] < dpt[v]) std::swap(u, v);
	for(int i = 18; i >= 0; -- i)
		if(dpt[f[u][i]] >= dpt[v]) u = f[u][i];
	if(u == v) return u;
	for(int i = 18; i >= 0; -- i)
		if(f[u][i] != f[v][i]) u = f[u][i], v = f[v][i];
	return f[u][0];
}
int main(){
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	n = read(), q = read(), k = read();
	for(int i = 1; i <= n; ++ i) wgt[i] = read();
	for(int i = 1; i < n; ++ i){
		int u = read(), v = read();
		add(u, v); add(v, u);
	}
	dfs(1, 0);
	while(q --){
		int u = read(), v = read();
		if(k == 1){
			int l = lca(u, v);
			printf("%d\n", dist[u] + dist[v] - dist[l] - dist[f[l][0]]);
		}
	}
	return 0;
}
