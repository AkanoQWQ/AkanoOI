#include<bits/stdc++.h>
#define int long long
const int N = 2.5e3 + 5, M = 2e4 + 5; 
inline int read(){
	int s = 0, f = 0; char ch = getchar();
	while(!isdigit(ch)){if(ch == '-') f = 1; ch = getchar();}
	while(isdigit(ch)) s = s * 10 + ch - 48, ch = getchar();
	return f ? ~s + 1 : s;
}
inline int min(int x, int y){return x < y ? x : y;}
inline int max(int x, int y){return x > y ? x : y;}
int n, m, k, ans;
int a[N];
int f[N][N];
//int dp[N][5][105];
//int head[N], to[N], ne[N], wgt[N], idx;
bool vis[N];
//inline void add(int u, int v, int w){
//	to[++ idx] = v, wgt[i] = w, ne[idx] = head[u], head[u] = idx;
//	return;
//}
//void spfa(){
//	std::queue<int> q;
//	q.push(1);
//	memset(dp, -0x3f, sizeof dp);
//	dp[1][0][0] = 0;
//	while(!q.empty()){
//		int u = q.front(); q.pop();
//		vis[u] = false;
//		for(int i = head[u]; i; i = ne[i]){
//			int v = to[i], w = wgt[i];
//			bool flag = false;
//			for(int j = 0; j <= 4; ++ j){
//				int mx = -INT_MAX;
//				for(int t = w; t <= k; ++ t){
//					if(dp[v][j][t] < dp[u][j][t - w]) dp[v][j][t] = dp[u][j][t - w], flag = true;
//					if(j) mx = max(mx, dp[u][j - 1][t - w]);
//				}
//				mx = max(mx, dp[u][j - 1][0]);
//				if(j && dp[v][j][0] < mx + a[v]) dp[v][j][0] = mx + a[v], flag = true;
//			}
//			if(flag && !vis[v]){
//				q.push(v);
//				vis[v] = true;
//			}
//		}
//	}
//	return;
//}
void dfs(int u, int cnt, int sum){
	if(cnt == 5){
		if(f[u][1] > k) return;
		ans = max(ans, sum);
		return;
	}
	vis[u] = true;
	int res = 0;
	for(int v = 1; v <= n; ++ v){
		if(vis[v] || f[u][v] > k) continue;
		dfs(v, cnt + 1, sum + a[v]);
		vis[v] = false;
	}
	return;
}
main(){
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	n = read(), m = read(), k = read() + 1;
	for(int i = 2; i <= n; ++ i) a[i] = read();
	memset(f, 0x3f, sizeof f);
	for(int i = 1; i <= m; ++ i){
		int u = read(), v = read();
//		add(u, v); add(v, u);
		f[u][v] = f[v][u] = 1;
	}
	for(int i = 1; i <= n; ++ i) f[i][i] = 0;
//	spfa();
//	int ans = 0;
//	for(int i = 1; i <= k; ++ i) ans = max(ans, dp[1][4][k]);
//	printf("%d\n", ans);
	for(int k = 1; k <= n; ++ k)
		for(int i = 1; i <= n; ++ i)
			for(int j = 1; j <= n; ++ j)
				f[i][j] = min(f[i][j], f[i][k] + f[k][j]);
	dfs(1, 1, 0);
	printf("%lld\n", ans);
	return 0;
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1
*/
