#include<bits/stdc++.h>
using namespace std;
long long a[100005];
long long b[100005];
bool cmp(int x,int y){
	return x>y;
}
bool iff(long long x,long long y,long long z,long long w){
	int flag1=0,flag2=0,flag4=0,flag5=0;
	for(long long i=x;i<=y;i++){
		if(a[i]>0)flag1++;
		if(a[i]<0)flag2++;
	}
	for(long long i=z;i<=w;i++){ 
		if(b[i]>0)flag4++;
		if(b[i]<0)flag5++;
	}
	if((flag1!=0&&flag5!=0)&&(flag2!=0&&flag4!=0))return true;
	else return false;
}
long long ans;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	long long n,m,q;
	cin>>n>>m>>q;
	for(long long i=1;i<=n;i++){
		cin>>a[i];
	}
	for(long long i=1;i<=m;i++){
		cin>>b[i];
	}
	for(long long i=1;i<=q;i++){
		int l,r,ll,rr;
		cin>>l>>r>>ll>>rr;
		if(iff(l,r,ll,rr)==true){
			ans=-99999999999999999;
	 		for(int k=l;k<=r;k++){
		 		long long ans1=999999999999999999;
				for(long long j=ll;j<=rr;j++){
					if(a[k]>=0&&b[j]<=0&&ans1>a[k]*b[j]){
						ans1=a[k]*b[j];
					}
					else if(a[k]<=0&&b[j]>=0&&ans1>a[k]*b[j]){
						ans1=a[k]*b[j];
					}
				}
				if(ans1>ans)ans=ans1;
			}
		}
		else{
			long long tan1=0,tan2=0,tan3=0,tan4=0;
			for(long long i=l;i<=r;i++){
				if(a[i]>0)tan1++;
				if(a[i]<0)tan2++;
			}
			for(long long i=ll;i<=rr;i++){
				if(b[i]>0)tan3++;
				if(b[i]<0)tan4++;
			}
			if((tan2==0&&tan3!=0)||(tan4==0&&tan1!=0)){
				sort(a+l,a+r,cmp);
				sort(b+ll,b+rr);
				ans=a[l]*b[ll];
			}
			if((tan1==0&&tan4!=0)||(tan2!=0&&tan3==0)){
				sort(a+l,a+r);
				sort(b+ll,b+rr,cmp);
				ans=a[l]*b[ll];
			}
		}
		cout<<ans<<endl;
	}
	return 0;
}
