#include <iostream>
#include <stdio.h>
#include <vector>
using namespace std;
vector <long long> max_map[10010];
vector <long long> min_map[10010];
long long n,m,q,i,a[20000],b[20000],x1,y1,x2,y2,ans,_max;
void init()
{
	max_map[1].push_back(0);
	min_map[1].push_back(0);
	for(i=1;i<=m;i++)
	{
		max_map[1].push_back(b[i]);
		min_map[1].push_back(b[i]);
	}
	for(long long i=2;i<=m;i++)
	{
		max_map[i].push_back(0);
		min_map[i].push_back(0);
		for(long long j=1;j<=m-i+1;j++)
		{
			max_map[i].push_back(max(max_map[i-1][j],max_map[i-1][j+1]));
			min_map[i].push_back(min(min_map[i-1][j],min_map[i-1][j+1]));
		}
	}
	return ;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	for(i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	for(i=1;i<=m;i++)
		scanf("%lld",&b[i]);
	init();
	while(q--)
	{
		scanf("%lld%lld%lld%lld",&x1,&y1,&x2,&y2);
		_max = -4611686018427387904;
		for(i=x1;i<=y1;i++)
		{
			if(a[i]>0)
			{
				ans = a[i]*min_map[y2-x2+1][x2];
			}
			else if(a[i]<0)
			{
				ans = a[i]*max_map[y2-x2+1][x2];
			}
			else
				ans = 0;
			if(_max<ans)
			{
				_max = ans;
			}
		}
		printf("%lld\n",_max);
	}
	
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
