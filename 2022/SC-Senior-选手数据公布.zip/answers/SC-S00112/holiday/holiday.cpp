#include <iostream>
#include <stdio.h>
#include <algorithm>
using namespace std;
int n,m,k,i,w[5000],x,y;
bool _swap(int a,int b)
{
	return a>b;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(i=2;i<=n;i++)
		scanf("%d",&w[i]);
	for(i=1;i<=m;i++)
		scanf("%d%d",&x,&y);
	sort(w+1,w+n+1,_swap);
	printf("%d",w[1]+w[2]+w[3]+w[4]);
	
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
