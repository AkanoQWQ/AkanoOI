#include<bits/stdc++.h>
using namespace std;

int n,m,k;
int v[3000];

struct matrix{
	bool val[3000][3000];
	inline void cs(){
		memset(val,0,sizeof(val));
		for(int i=1;i<=n;i++){
			val[i][i]=1;
		}
		return;
	}
	inline void cl(){
		memset(val,0,sizeof(val));
		return;
	}
}ori,ret1,ret2;

bool cmp(int a,int b){
	return v[a]>v[b];
}
int id[3000];
bool vis[3000];

bool dfs(int pre,int cnt,int ans){
	if(cnt==4){
		if(!ori.val[pre][1]) return 0;
		else{
			printf("%d\n",ans);
			return 1;
		}
	}
	for(int i=2;i<=n;i++){
		if(vis[id[i]]) continue;
		if(!ori.val[pre][id[i]]) continue;
		vis[id[i]]=1;
		if(dfs(id[i],cnt+1,ans+v[id[i]])) return 1;
		vis[id[i]]=0;
	}
	return 0;
} 

int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	ori.cl();
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++){
		scanf("%d",&v[i]);
		id[i]=i;
		ori.val[i][i]=1;
	}
	ori.val[1][1]=1;
	int x,y;
	for(int i=1;i<=m;i++){
		scanf("%d%d",&x,&y);
		ori.val[x][y]=1;
		ori.val[y][x]=1;
	}
	int ks=k+1;
	ret1.cs();
	while(ks){
		if(ks&1){
			ret2.cl();
			for(int i=1;i<=n;i++){
				for(int j=1;j<=n;j++){
					for(int kk=1;kk<=n;kk++){
						ret2.val[i][j]|=ret1.val[i][kk]&ori.val[kk][j];
					}
				}
			}
			ret1=ret2;
		}
		ret2.cl();
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				for(int kk=1;kk<=n;kk++){
					ret2.val[i][j]|=ori.val[i][kk]&ori.val[kk][j];
				}
			}
		}
		ori=ret2;
		ks>>=1;
	}
	ori=ret1;
	sort(id+2,id+1+n,cmp);
	dfs(1,0,0);
	return 0;
}
