#include<bits/stdc++.h>
using namespace std;

int n,m,q;

struct sgt{
	int val[200000];
	
	struct node{
		int l,r,mx1,mn1,mx2,mn2;
		bool f1,f2,f3;
	}tr[1000000];
	
	void pup(int x){
		tr[x].f3=tr[x*2].f3|tr[x].f3;
		if(tr[x*2].f1||tr[x*2+1].f1){
			tr[x].f1=1;
			tr[x].mn1=min(tr[x*2].mn1,tr[x*2+1].mn1);
			tr[x].mx1=max(tr[x*2].mx1,tr[x*2+1].mx1);
		}
		if(tr[x*2].f2||tr[x*2+1].f2){
			tr[x].f2=1;
			tr[x].mn2=min(tr[x*2].mn2,tr[x*2+1].mn2);
			tr[x].mx2=max(tr[x*2].mx2,tr[x*2+1].mx2);
		}
	}
	
	void build(int i,int l,int r){
		tr[i].l=l,tr[i].r=r;
		tr[i].mn1=tr[i].mn2=0x7f7f3f3f;
		tr[i].mx1=tr[i].mx2=-0x7f7f3f3f;
		if(l==r){
			if(val[l]==0) tr[i].f3=1;
			else if(val[l]>0) tr[i].f1=1,tr[i].mx1=tr[i].mn1=val[l];
			if(val[l]>0) tr[i].f2=1,tr[i].mx2=tr[i].mn2=val[l];
			return;
		}
		int mid=(l+r)>>1;
		build(i*2,l,mid);
		build(i*2+1,mid+1,r);
		pup(i);
	}
	
	bool ask_f1(int x,int l,int r){
		if(l<=tr[x].l&&r>=tr[x].r){
			return tr[x].f1;
		}
		int mid=(tr[x].l+tr[x].r)/2;
		bool ret=0;
		if(l<=mid) ret|=ask_f1(x*2,l,r);
		if(r>mid) ret|=ask_f1(x*2+1,l,r);
		return ret;
	}
	
	bool ask_f2(int x,int l,int r){
		if(l<=tr[x].l&&r>=tr[x].r){
			return tr[x].f2;
		}
		int mid=(tr[x].l+tr[x].r)/2;
		bool ret=0;
		if(l<=mid) ret|=ask_f2(x*2,l,r);
		if(r>mid) ret|=ask_f2(x*2+1,l,r);
		return ret;
	}
	
	bool ask_f3(int x,int l,int r){
		if(l<=tr[x].l&&r>=tr[x].r){
			return tr[x].f3;
		}
		int mid=(tr[x].l+tr[x].r)/2;
		bool ret=0;
		if(l<=mid) ret|=ask_f3(x*2,l,r);
		if(r>mid) ret|=ask_f3(x*2+1,l,r);
		return ret;
	}
	
	int ask_mx1(int x,int l,int r){
		if(l<=tr[x].l&&r>=tr[x].r){
			return tr[x].mx1;
		}
		int mid=(tr[x].l+tr[x].r)/2;
		int ret=-0x7f7f3f3f;
		if(l<=mid) ret=max(ret,ask_mx1(x*2,l,r));
		if(r>mid) ret=max(ret,ask_mx1(x*2+1,l,r));
		return ret;
	}
	
	int ask_mx2(int x,int l,int r){
		if(l<=tr[x].l&&r>=tr[x].r){
			return tr[x].mx2;
		}
		int mid=(tr[x].l+tr[x].r)/2;
		int ret=-0x7f7f3f3f;
		if(l<=mid) ret=max(ret,ask_mx2(x*2,l,r));
		if(r>mid) ret=max(ret,ask_mx2(x*2+1,l,r));
		return ret;
	}
	
	int ask_mn1(int x,int l,int r){
		if(l<=tr[x].l&&r>=tr[x].r){
			return tr[x].mn1;
		}
		int mid=(tr[x].l+tr[x].r)/2;
		int ret=0x7f7f3f3f;
		if(l<=mid) ret=min(ret,ask_mn1(x*2,l,r));
		if(r>mid) ret=min(ret,ask_mn1(x*2+1,l,r));
		return ret;
	}
	
	
	int ask_mn2(int x,int l,int r){
		if(l<=tr[x].l&&r>=tr[x].r){
			return tr[x].mn2;
		}
		int mid=(tr[x].l+tr[x].r)/2;
		int ret=0x7f7f3f3f;
		if(l<=mid) ret=min(ret,ask_mn2(x*2,l,r));
		if(r>mid) ret=min(ret,ask_mn2(x*2+1,l,r));
		return ret;
	}
}root1,root2;

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++){
		scanf("%d",&root1.val[i]);
	}
	for(int i=1;i<=m;i++){
		scanf("%d",&root2.val[i]);
	}
	root1.build(1,1,n);
	root2.build(1,1,m);
	int l1,l2,r1,r2;
	bool f11,f12,f13,f21,f22,f23;
	while(q--){
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		f11=root1.ask_f1(1,l1,r1);
		f12=root1.ask_f2(1,l1,r1);
		f13=root1.ask_f3(1,l1,r1);
		f21=root2.ask_f1(1,l2,r2);
		f22=root2.ask_f2(1,l2,r2);
		f23=root2.ask_f3(1,l2,r2);
		if(f21&&f22){
			if(f13)
				puts("0");
			else if(f11&&f12)
				printf("%lld\n",min(1ll*root1.ask_mn1(1,l1,r1)*root2.ask_mn2(1,l2,r2),1ll*root1.ask_mx2(1,l1,r1)*root2.ask_mx1(1,l2,r2)));
			else if(f11)
				printf("%lld\n",1ll*root1.ask_mn1(1,l1,r1)*root2.ask_mn2(1,l2,r2));
			else 
				printf("%lld\n",1ll*root1.ask_mx2(1,l1,r1)*root2.ask_mx1(1,l2,r2));
		}
//		else if(f12&&f11){
//			if(f23)
//				puts("0");
//			else if(f21)
//				printf("%lld\n",1ll*root1.ask_mx1(1,l1,r1)*root2.ask_mn1(1,l2,r2));
//			else
//				printf("%lld\n",1ll*root1.ask_mn2(1,l1,r1)*root2.ask_mx2(1,l2,r2));
//		}
		else if(f21){
			if(f11){
				if(f23) puts("0");
				else
					printf("%lld\n",1ll*root1.ask_mx1(1,l1,r1)*root2.ask_mn1(1,l2,r2));
				}  
					
			else{
				if(f13) puts("0");
				else
					printf("%lld\n",1ll*root1.ask_mx2(1,l1,r1)*root2.ask_mx1(1,l2,r2));
			}
		}
		else if(f22){
			if(f11){
				if(f13) puts("0");
				else  
					printf("%lld\n",1ll*root1.ask_mn1(1,l1,r1)*root2.ask_mn2(1,l2,r2));
			}
			else{
				if(f23) puts("0");
				else
					printf("%lld\n",1ll*root1.ask_mn2(1,l1,r1)*root2.ask_mx2(1,l2,r2));
			}
		}
		else if(f23) puts("0");
	}
}
