#include<bits/stdc++.h>
using namespace std;

int rd[3000],cd[3000];
int avi[3000][3000];
bool vis[3000];
int n,m,q,u,v;

bool dfs(int x){
	vis[x]=1;
	for(int i=1;i<=n;i++){
		if(avi[x][i]==1){
			if(vis[i]){
				vis[x]=0;
				return 1;
			}
			if(dfs(i)){
				vis[x]=0;
				return 1;
			}
		}
	}
	vis[x]=0;
	return 0;
}

bool check(){
	for(int i=1;i<=n;i++){
		if(!dfs(i)) return 0;
	}
	return 1;
}

int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&u,&v);
		avi[u][v]=1;
		rd[v]++,cd[u]++;
	}
	scanf("%d",&q);
	int opt;
	while(q--){
		scanf("%d",&opt);
		if(opt==1){
			scanf("%d%d",&u,&v);
			rd[v]--,cd[u]--;
			avi[u][v]=-1;
		}
		else if(opt==2){
			scanf("%d",&u);
			for(int i=1;i<=n;i++){
				if(avi[i][u]==1){
					avi[i][u]=-1;
					rd[u]--,cd[i]--;
				}
			}
		}
		else if(opt==3){
			scanf("%d%d",&u,&v);
			rd[v]++,cd[u]++;
			avi[u][v]=1;
		}
		else if(opt==4){
			scanf("%d",&u);
			for(int i=1;i<=n;i++){
				if(avi[i][u]==-1){
					avi[i][u]=1;
					rd[u]++,cd[i]++;
				}
			}
		}
		bool f=1;
		for(int i=1;i<=n;i++){
			if(cd[i]!=1){
				f=0;break;
			}
		}
		if(f&&check()) puts("YES");
		else puts("NO");
	}
}
