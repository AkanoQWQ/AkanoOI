#include<bits/stdc++.h>
using namespace std;

int n,m,k;
long long v[3000];

long long dis[3000][3000];

struct E{
	int u,v,nx;
	long long w;
}e[1000000];

int tt,hd[3000];
void ade(int u,int v,long long w){
	e[++tt].u=u,e[tt].v=v,e[tt].w=w,e[tt].nx=hd[u],hd[u]=tt;
}

struct nd{
	int dis,pos;
}now;

bool operator <(nd a,nd b){
	return a.dis>b.dis;
}
priority_queue<nd>q;
bool vis[3000];

void dij(int rt){
	memset(vis,0,sizeof(vis));
	dis[rt][rt]=0;
	now.dis=0,now.pos=rt;
	q.push(now);
	while(!q.empty()){
		now=q.top();
		q.pop();
		int u=now.pos;
		if(vis[u]) continue;
		vis[u]=1;
		for(int i=hd[u];i;i=e[i].nx){
			int v=e[i].v;
			if(dis[rt][v]>dis[rt][u]+e[i].w){
				dis[rt][v]=dis[rt][u]+e[i].w;
				now.dis=dis[rt][v],now.pos=v;
				q.push(now);
			}
		}
	}
}

struct matrix{
	bool val[3000][3000];
	inline void cs(){
		memset(val,0,sizeof(val));
		for(int i=1;i<=n;i++){
			val[i][i]=1;
		}
		return;
	}
	inline void cl(){
		memset(val,0,sizeof(val));
		return;
	}
}ori,ret1,ret2;

int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	ori.cl();
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++){
		scanf("%lld",&v[i]);
		ori.val[i][i]=1;
	}
	int x,y;
	for(int i=1;i<n;i++){
		scanf("%d%d",&x,&y);
		ori.val[x][y]=1;
		ori.val[y][x]=1;
	}
	int ks=k;
	ret1.cs();
	while(ks){
		if(ks&1){
			ret2.cl();
			for(int i=1;i<=n;i++){
				for(int j=1;j<=n;j++){
					for(int kk=1;kk<=n;kk++){
						ret2.val[i][j]|=(ret1.val[i][kk]&ori.val[kk][j]);
					}
				}
			}
			ret1=ret2;
		}
		ret2.cl();
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				for(int kk=1;kk<=n;kk++){
					ret2.val[i][j]|=(ori.val[i][kk]&ori.val[kk][j]);
				}
			}
		}
		ori=ret2;
		ks/=2;
	}
	ori=ret1;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(i!=j&&ori.val[i][j]){
				ade(i,j,v[j]);
			}
		}
	}
	memset(dis,0x3f,sizeof(dis));
	for(int i=1;i<=n;i++) dij(i);
	while(m--){
		scanf("%d%d",&x,&y);
		printf("%lld\n",dis[x][y]+v[x]);
	}
	return 0;
}
