#include<bits/stdc++.h>
using namespace std;
#define ll long long
inline ll read()
{
	ll x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')f=-1;
		ch=getchar();
	 } 
	while(ch>='0'&&ch<='9')
	{
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
}

const int N=1e5+5;
const ll inf=0x3f3f3f3f3f3f3f3f;
int n,m,q;
ll a[N],b[N];
struct ww{
	ll mx,mi;
}tr[N*8],rt[N*8];

void updat(int p)
{
	tr[p].mi=min(tr[p<<1|1].mi,tr[p<<1].mi);
	tr[p].mx=max(tr[p<<1|1].mx,tr[p<<1].mx);
}

void build(int p,int l,int r)
{
	if(l==r)
	{
		tr[p].mx=tr[p].mi=a[l];
		return ;
	}
	int mid=(l+r)>>1;
	build(p<<1,l,mid);
	build(p<<1|1,mid+1,r);
	updat(p);
}

ll ask1mx(int p,int l,int r,int x,int y)
{
	if(l>y||r<x)return -inf;
	if(x<=l&&r<=y)return tr[p].mx;
	int mid=(l+r)>>1;
	ll res=-inf;
	if(x<=mid)res=max(res,ask1mx(p<<1,l,mid,x,y));
	if(y>mid)res=max(res,ask1mx(p<<1|1,mid+1,r,x,y));
	return res;
}

ll ask2mx(int p,int l,int r,int x,int y)
{
	if(l>y||r<x)return -inf;
	if(x<=l&&r<=y)return rt[p].mx;
	int mid=(l+r)>>1;
	ll res=-inf;
	if(x<=mid)res=max(res,ask2mx(p<<1,l,mid,x,y));
	if(y>mid)res=max(res,ask2mx(p<<1|1,mid+1,r,x,y));
	return res;
}

void updat1(int p)
{
	rt[p].mi=min(rt[p<<1|1].mi,rt[p<<1].mi);
	rt[p].mx=max(rt[p<<1|1].mx,rt[p<<1].mx);
}

void build1(int p,int l,int r)
{
	if(l==r)
	{
		rt[p].mx=rt[p].mi=b[l];
		return ;
	}
	int mid=(l+r)>>1;
	build1(p<<1,l,mid);
	build1(p<<1|1,mid+1,r);
	updat1(p);
}

ll ask2mi(int p,int l,int r,int x,int y)
{
	if(l>y||r<x)return inf;
	if(x<=l&&r<=y)return rt[p].mi;
	int mid=(l+r)>>1;
	ll res=inf;
	if(x<=mid)res=min(res,ask2mi(p<<1,l,mid,x,y));
	if(y>mid)res=min(res,ask2mi(p<<1|1,mid+1,r,x,y));
	return res;
}

ll ask1mi(int p,int l,int r,int x,int y)
{
	if(l>y||r<x)return inf;
	if(x<=l&&r<=y)return tr[p].mi;
	int mid=(l+r)>>1;
	ll res=inf;
	if(x<=mid)res=min(res,ask1mi(p<<1,l,mid,x,y));
	if(y>mid)res=min(res,ask1mi(p<<1|1,mid+1,r,x,y));
	return res;
}

ll ask1(int p,int l,int r,int x,int y)
{
	if(l>y||r<x)return inf;
	int mid=(l+r)>>1;
	if(x<=l&&r<=y)
	{
		if(tr[p].mi>=0)return tr[p].mi;
		if(tr[p].mx<0)return inf;
		return min(ask1(p<<1,l,mid,x,y),ask1(p<<1|1,mid+1,r,x,y));
	}
	ll res=inf;
	if(x<=mid)res=min(res,ask1(p<<1,l,mid,x,y));
	if(y>mid)res=min(res,ask1(p<<1|1,mid+1,r,x,y));
	return res;
}

ll ask2(int p,int l,int r,int x,int y)
{
	if(l>y||r<x)return -inf;
	int mid=(l+r)>>1;
	if(x<=l&&r<=y)
	{
		if(tr[p].mx<0)return tr[p].mx;
		if(tr[p].mi>=0)return -inf;
		return max(ask2(p<<1,l,mid,x,y),ask2(p<<1|1,mid+1,r,x,y));
	}
	ll res=-inf;
	if(x<=mid)res=max(res,ask2(p<<1,l,mid,x,y));
	if(y>mid)res=max(res,ask2(p<<1|1,mid+1,r,x,y));
	return res;
}

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),m=read(),q=read();
	int opt=0;
	for(int i=1;i<=n;i++)
	{
		a[i]=read();
		if(a[i]<=0)opt=1;
	}
	for(int i=1;i<=m;i++)
	{
		b[i]=read();
		if(b[i]<=0)opt=1;
	}
	build(1,1,n);
	build1(1,1,m);
	int l,l_,r,r_;
	if(opt==0)
	{
		for(int i=1;i<=q;i++)
		{
			l=read(),r=read(),l_=read(),r_=read();
			ll tmp1=ask1mx(1,1,n,l,r);
			ll tmp2=ask2mi(1,1,m,l_,r_);
			printf("%lld\n",1ll*tmp1*tmp2);
		}
	}
	else
	{
		for(int i=1;i<=q;i++)
		{
			l=read(),r=read(),l_=read(),r_=read();
			ll tmp1=ask1mi(1,1,n,l,r);
			ll tmp2=ask1mx(1,1,n,l,r);
			ll tmp3=ask2mi(1,1,m,l_,r_);
			ll tmp4=ask2mx(1,1,m,l_,r_);
			if(tmp1>0)
			{
				if(tmp3>0)printf("%lld\n",1ll*tmp3*tmp2);
				else printf("%lld\n",1ll*tmp1*tmp3);
				continue;
			}
			if(tmp2<0)
			{
				if(tmp4<0)printf("%lld\n",1ll*tmp4*tmp1);
				else printf("%lld\n",1ll*tmp2*tmp4);
				continue;
			}
			if(tmp3>0)
			{
				printf("%lld\n",1ll*tmp3*tmp2);
				continue;
			}
			if(tmp4<0)
			{
				printf("%lld\n",1ll*tmp4*tmp1);
				continue;
			}
			ll tmp5=ask1(1,1,n,l,r);//>=0
			if(tmp5==0)
			{
				printf("%d\n",0);
				continue;
			}
			ll tmp6=ask2(1,1,n,l,r);//<0
//			cout<<tmp5<<" "<<tmp6<<endl;
			ll tmp=max(1ll*tmp5*tmp3,tmp6*tmp4);
			printf("%lld\n",tmp);
		}
	}
	return 0;
}
/*
6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3
*/
