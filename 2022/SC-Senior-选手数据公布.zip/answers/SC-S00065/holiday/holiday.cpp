#include<bits/stdc++.h>
using namespace std;
#define ll long long
inline ll read()
{
	ll x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')f=-1;
		ch=getchar();
	 } 
	while(ch>='0'&&ch<='9')
	{
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
}

const int N=2505;
const int M=1e4+5;
int n,m,k,tot,vis[N],tot1;
int h[N],ver[M*2],nex[M*2];
int h1[N],ver1[M*2],nex1[M*2];
ll a[N],ans;

void add(int x,int y)
{
	ver[++tot]=y,nex[tot]=h[x],h[x]=tot;
}

void add1(int x,int y)
{
	ver1[++tot1]=y,nex1[tot1]=h1[x],h1[x]=tot1;
}

void bfs(int c)
{
	queue<int>q;
	for(int i=1;i<=n;i++)vis[i]=0;
	q.push(c);
	while(q.size())
	{
		int x=q.front();
		q.pop();
		if(x!=c)
		{
			add1(c,x);
//			cout<<c<<"->"<<x<<" "<<vis[x]<<endl;
		}
//		if(vis[x]>k)continue;
		for(int i=h[x];i;i=nex[i])
		{
			int v=ver[i];
			if(vis[v])continue;
			if(vis[x]<=k)
			{
				vis[v]=vis[x]+1;
				q.push(v);
			}
		}
	}
}

void dfs(int x,int fa,int cnt,ll val)
{
//	cout<<x<<" "<<fa<<endl;
	if(cnt>5)return ;
	if(x==1&&fa!=0&&cnt==5)
	{
//		cout<<val<<endl; 
		ans=max(ans,val);
	}
	if(x==1&&fa!=0)return ;
	for(int i=h1[x];i;i=nex1[i])
	{
		int v=ver1[i];
//		cout<<v<<endl;
		if(v==fa||vis[v])continue;
		vis[v]=1;
//		cout<<v<<" "<<cnt+1<<endl;
		dfs(v,x,cnt+1,val+a[v]);
		vis[v]=0;
	}
}

int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read(),m=read(),k=read();
	for(int i=2;i<=n;i++)a[i]=read();
	int x,y;
	for(int i=1;i<=m;i++)
	{
		x=read(),y=read();
		add(x,y);add(y,x);
	}
//	bfs(1);
	for(int i=1;i<=n;i++)bfs(i);
	memset(vis,0,sizeof vis);
	dfs(1,0,0,0);
	cout<<ans<<endl;
	return 0;
 }
