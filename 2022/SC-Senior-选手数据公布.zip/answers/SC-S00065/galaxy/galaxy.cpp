#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
}

const int N=5e5+5;
const int M=5e5+5;
int tot,n,m,q,vis[M],cnt;
int h[N],ver[M],nex[M],d[N];

void add(int x,int y)
{
	ver[++tot]=y,nex[tot]=h[x],h[x]=tot;
}

int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read(),m=read();
	int opt,x,y;
	for(int i=1;i<=m;i++)
	{
		x=read(),y=read();
		add(y,x);
		d[x]++;
	}
	for(int i=1;i<=n;i++)if(d[i]!=1)cnt++;
	q=read();
	for(int i=1;i<=q;i++)
	{
		opt=read(),x=read();
		if(opt==1)
		{
			y=read();
			if(d[x]==1)cnt++;d[x]--;
			if(d[x]==1)cnt--;
			for(int i=h[y];i;i=nex[i])
			{
				int v=ver[i];
				if(v==x)
				{
					vis[i]=1;break;
				}
			}
		}
		else if(opt==2)
		{
			for(int i=h[x];i;i=nex[i])
			{
				int v=ver[i];
				if(!vis[i])
				{
					vis[i]=1;
					if(d[v]==1)cnt++;
					d[v]--;
					if(d[v]==1)cnt--;
				}
			}
		}
		else if(opt==3)
		{
			y=read();
			if(d[x]==1)cnt++;d[x]++;
			if(d[x]==1)cnt--;
			for(int i=h[y];i;i=nex[i])
			{
				int v=ver[i];
				if(v==x)
				{
					vis[i]=0;break;
				}
			}
		}
		else
		{
			for(int i=h[x];i;i=nex[i])
			{
				int v=ver[i];
				if(vis[i])
				{
					vis[i]=0;
					if(d[v]==1)cnt++;
					d[v]++;
					if(d[v]==1)cnt--;
				}
			}
		}
		if(cnt==0)printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
