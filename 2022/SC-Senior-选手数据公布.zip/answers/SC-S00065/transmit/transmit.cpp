#include<bits/stdc++.h>
using namespace std;
#define ll long long
inline ll read()
{
	ll x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
}

const int N=2e5+5;
int h[N],ver[N*2],nex[N*2];
int f[N][22],tot,n,m,k,d[N];
ll a[N],b[N],dp[N];

void add(int x,int y)
{
	ver[++tot]=y,nex[tot]=h[x],h[x]=tot;
}

void dfs(int x,int fa)
{
	d[x]=d[fa]+1;
	f[x][0]=fa;
	for(int i=1;i<=20;i++)
	{
		f[x][i]=f[f[x][i-1]][i-1];
	}
	for(int i=h[x];i;i=nex[i])
	{
		int v=ver[i];
		if(v==fa)continue;
		dfs(v,x);
	}
}

int lca(int x,int y)
{
	if(d[x]<d[y])swap(x,y);
	for(int i=20;i>=0;i--)
	{
		if(d[f[x][i]]>=d[y])x=f[x][i];
	}
	if(x==y)return x;
	for(int i=20;i>=0;i--)
	{
		if(f[x][i]!=f[y][i])x=f[x][i],y=f[y][i];
	}
	x=f[x][0];
	return x;
}

void init(int x,int mid,int y)
{
	memset(dp,0x3f,sizeof dp);
	int cnt=0;
	while(x!=mid)
	{
		b[++cnt]=a[x];
		x=f[x][0];
	}
	b[++cnt]=a[x];
	int len=cnt+d[y]-d[mid];
	cnt=len;
	while(y!=mid)
	{
		b[len]=a[y];len--;
		y=f[y][0];
	}
	dp[1]=b[1];
	for(int i=1;i<cnt;i++)
	{
		for(int j=1;j<=k;j++)
		{
			if(i+j>cnt)break;
			dp[i+j]=min(dp[i+j],dp[i]+b[i+j]);
		}
	}
	printf("%lld\n",dp[cnt]);
	return ;
}

int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=read(),m=read(),k=read();
	int x,y;
	for(int i=1;i<=n;i++)a[i]=read();
	for(int i=1;i<n;i++)
	{
		x=read(),y=read();
		add(x,y);add(y,x);
	}
	dfs(1,0);
	for(int i=1;i<=m;i++)
	{
		x=read(),y=read();
		int tmp=lca(x,y);
//		cout<<x<<" "<<y<<" "<<tmp<<endl;
		init(x,tmp,y);
	}
	return 0;
}
/*
10 10 3
835701672 912572995 368308854 156367225 251245604 788978650 385396264 960190423 51944511 479806606
2 1
3 2
4 2
5 3
6 3
7 2
8 7
9 1
10 9
1 7
1 5
2 1
1 9
10 5
3 10
2 9
10 2
1 4
4 7
*/
