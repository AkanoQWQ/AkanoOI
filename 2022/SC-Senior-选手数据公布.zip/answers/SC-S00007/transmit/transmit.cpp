#include <bits/stdc++.h>
using namespace std;
#define int long long
#define inf 0x3f3f3f3f3f3f3f3fll
int Q, n, k, cs[200005], x, y, ed, Ans;
int fa[200005][25], dep[200005];
int f[200005][4], g[200005][4];
int firs[200005], nex[400005], to[400005], tot;
void Add (int u, int v){
	++ tot;
	nex[tot] = firs[u];
	firs[u] = tot;
	to[tot] = v;
}
int LCA (int u, int v){
	if (dep[u] < dep[v])
		swap (u, v);
	for (int i = 20;i >= 0;-- i)
		if (dep[fa[u][i]] >= dep[v])
			u = fa[u][i];
	if (u == v)
		return v;
	for (int i = 20;i >= 0;-- i)
		if (fa[u][i] != fa[v][i]){
			u = fa[u][i];
			v = fa[v][i];
		}
	return fa[u][0];
}
void init (int u, int father){
	dep[u] = dep[father] + 1;
	fa[u][0] = father;
	for (int i = 1;i <= 20;++ i)
		fa[u][i] = fa[fa[u][i - 1]][i - 1];
	for (int e = firs[u];e;e = nex[e]){
		int v = to[e];
		if (v == father)
			continue;
		init (v, u);
	}
}
void solve_f (int u){
	if (u == ed)
		return ;
	int v = fa[u][0];
	f[v][0] = f[u][0] + cs[v];
	for (int i = 1;i <= k;++ i){
		f[v][0] = min (f[v][0], f[u][i] + cs[v]);
		f[v][i] = f[u][i - 1];
	}
	solve_f (v);
}
void solve_g (int u){
	if (u == ed)
		return ;
	int v = fa[u][0];
	g[v][0] = g[u][0] + cs[v];
	for (int i = 1;i <= k;++ i){
		g[v][0] = min (g[v][0], g[u][i] + cs[v]);
		g[v][i] = g[u][i - 1];
	}
	solve_g (v);
}
signed main (){
	freopen ("transmit.in", "r", stdin);
	freopen ("transmit.out", "w", stdout);
	scanf ("%lld%lld%lld", &n, &Q, &k);
	for (int i = 1;i <= n;++ i)
		scanf ("%lld", &cs[i]);
	for (int i = 1;i < n;++ i){
		scanf ("%lld%lld", &x, &y);
		Add (x, y);
		Add (y, x);
	}
	init (1, 0);
	while (Q --){
		scanf ("%lld%lld", &x, &y);
		ed = LCA (x, y);
		f[x][0] = cs[x];
		f[x][1] = inf;
		f[x][2] = inf;
		f[x][3] = inf;
		solve_f (x);
		g[y][0] = cs[y];
		g[y][1] = inf;
		g[y][2] = inf;
		g[y][3] = inf;
		solve_g (y);
		Ans = inf;
		for (int i = 0;i <= k;++ i)
			for (int j = 0;i + j <= k;++ j)
				Ans = min (Ans, f[ed][i] + g[ed][j]);
		printf ("%lld\n", Ans);
	}
	return 0;
}
