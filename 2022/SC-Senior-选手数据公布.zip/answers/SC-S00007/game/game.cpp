#include <bits/stdc++.h>
using namespace std;
#define int long long
#define inf 0x3f3f3f3f3f3f3f3fll
int n, m, Q, l1, r1, l2, r2, Res;
int a[100005], b[100005], log_[100005], cf_a[100005], cf_b[100005];
int za[25][100005], zi[25][100005], fa[25][100005], fi[25][100005];
int b_max[25][100005], b_min[25][100005];
int Q_za (int l, int r){
	int p = log_[r - l + 1];
	return max (za[p][l], za[p][r - (1 << p) + 1]);
}
int Q_zi (int l, int r){
	int p = log_[r - l + 1];
	return min (zi[p][l], zi[p][r - (1 << p) + 1]);
}
int Q_fa (int l, int r){
	int p = log_[r - l + 1];
	return max (fa[p][l], fa[p][r - (1 << p) + 1]);
}
int Q_fi (int l, int r){
	int p = log_[r - l + 1];
	return min (fi[p][l], fi[p][r - (1 << p) + 1]);
}
int Q_ba (int l, int r){
	int p = log_[r - l + 1];
	return max (b_max[p][l], b_max[p][r - (1 << p) + 1]);
}
int Q_bi (int l, int r){
	int p = log_[r - l + 1];
	return min (b_min[p][l], b_min[p][r - (1 << p) + 1]);
}
signed main (){
	freopen ("game.in", "r", stdin);
	freopen ("game.out", "w", stdout);
	scanf ("%lld%lld%lld", &n, &m, &Q);
	for (int i = 1;i <= n;++ i){
		scanf ("%lld", &a[i]);
		if (a[i] > 0){
			za[0][i] = a[i];
			zi[0][i] = a[i];
			fa[0][i] = - inf;
			fi[0][i] = inf;
		}
		else if (a[i] < 0){
			za[0][i] = - inf;
			zi[0][i] = inf;
			fa[0][i] = a[i];
			fi[0][i] = a[i];
		}
		else
			++ cf_a[i];
		cf_a[i] = cf_a[i - 1] + cf_a[i];
	}
	for (int i = 1;i <= m;++ i){
		scanf ("%lld", &b[i]);
		b_max[0][i] = b[i];
		b_min[0][i] = b[i];
		if (b[i] == 0)
			cf_b[i] = 1;
		cf_b[i] = cf_b[i - 1] + cf_b[i];
	}
	for (int i = 1;i <= 20;++ i)
		for (int j = 1;j <= n;++ j){
			za[i][j] = za[i - 1][j];
			zi[i][j] = zi[i - 1][j];
			fa[i][j] = fa[i - 1][j];
			fi[i][j] = fi[i - 1][j];
			int u = j + (1 << (i - 1));
			if (u <= n){
				za[i][j] = max (za[i][j], za[i - 1][u]);
				zi[i][j] = min (zi[i][j], zi[i - 1][u]);
				fa[i][j] = max (fa[i][j], fa[i - 1][u]);
				fi[i][j] = min (fi[i][j], fi[i - 1][u]);
			}
		}
	for (int i = 1;i <= 20;++ i)
		for (int j = 1;j <= m;++ j){
			b_max[i][j] = b_max[i - 1][j];
			b_min[i][j] = b_min[i - 1][j];
			int u = j + (1 << (i - 1));
			if (u <= n){
				b_max[i][j] = max (b_max[i][j], b_max[i - 1][u]);
				b_min[i][j] = min (b_min[i][j], b_min[i - 1][u]);
			}
		}
	log_[0] = - 1;
	for (int i = 1;i <= max (n, m);++ i)
		log_[i] = log_[i >> 1] + 1;
	while (Q --){
		scanf ("%lld%lld%lld%lld", &l1, &r1, &l2, &r2);
		Res = - inf;
		if (Q_za (l1, r1) != - inf)
			Res = max (Res, Q_za (l1, r1) * Q_bi (l2, r2));
		if (Q_zi (l1, r1) != inf)
			Res = max (Res, Q_zi (l1, r1) * Q_bi (l2, r2));
		if (Q_fa (l1, r1) != - inf)
			Res = max (Res, Q_fa (l1, r1) * Q_ba (l2, r2));
		if (Q_fi (l1, r1) != inf)
			Res = max (Res, Q_fi (l1, r1) * Q_ba (l2, r2));
		if (Res < 0 && cf_a[l1 - 1] != cf_a[r1])
			Res = 0;
		if (Res > 0 && cf_b[l2 - 1] != cf_b[r2])
			Res = 0;
		printf ("%lld\n", Res);
	}
	return 0;
}
