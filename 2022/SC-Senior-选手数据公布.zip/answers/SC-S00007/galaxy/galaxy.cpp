#include <bits/stdc++.h>
using namespace std;
int n, m, Q, x, y, opt, cd[500005], cnt;
int lin[500005];
int firs[500005], nex[500005], to[500005], tot;
map < pair < int, int >, bool > mp;
void Add (int u, int v){
	++ tot;
	nex[tot] = firs[u];
	firs[u] = tot;
	to[tot] = v;
}
int main (){
	freopen ("galaxy.in", "r", stdin);
	freopen ("galaxy.out", "w", stdout);
	scanf ("%d%d", &n, &m);
	for (int i = 1;i <= m;++ i){
		scanf ("%d%d", &x, &y);
		Add (y, x);
		if (cd[x] == 1)
			-- cnt;
		++ cd[x];
		if (cd[x] == 1)
			++ cnt;
	}
	scanf ("%d", &Q);
	while (Q --){
		scanf ("%d%d", &opt, &x);
		if (opt == 1){
			scanf ("%d", &y);
			mp[make_pair (x, y)] = true;
			if (cd[x] == 1)
				-- cnt;
			-- cd[x];
			if (cd[x] == 1)
				++ cnt;
		}
		if (opt == 2)
			for (int e = firs[x];e;e = nex[e])
				if (! mp[make_pair (to[e], x)]){
					mp[make_pair (to[e], x)] = true;
					if (cd[to[e]] == 1)
						-- cnt;
					-- cd[to[e]];
					if (cd[to[e]] == 1)
						++ cnt;
				}
		if (opt == 3){
			scanf ("%d", &y);
			mp.erase (make_pair (x, y));
			if (cd[x] == 1)
				-- cnt;
			++ cd[x];
			if (cd[x] == 1)
				++ cnt;
		}
		if (opt == 4)
			for (int e = firs[x];e;e = nex[e])
				if (mp[make_pair (to[e], x)]){
					mp.erase (make_pair (to[e], x));
					if (cd[to[e]] == 1)
						-- cnt;
					++ cd[to[e]];
					if (cd[to[e]] == 1)
						++ cnt;
				}
		if (cnt == n)
			printf ("YES\n");
		else
			printf ("NO\n");
	}
	return 0;
}
