#include <bits/stdc++.h>
using namespace std;
#define int long long
#define inf 0x3f3f3f3f3f3f3f3fll
int n, m, p, cs[2505], x, y, ip, Ans;
int dis[2505][2505];
int firs[2505], nex[20005], to[20005], tot;
queue < int > Q;
void Add (int u, int v){
	++ tot;
	nex[tot] = firs[u];
	firs[u] = tot;
	to[tot] = v;
}
void Bfs (){
	dis[ip][ip] = 0;
	Q.push (ip);
	while (! Q.empty ()){
		int u = Q.front (), v;
		Q.pop ();
		for (int e = firs[u];e;e = nex[e]){
			v = to[e];
			if (dis[ip][v] > dis[ip][u] + 1){
				dis[ip][v] = dis[ip][u] + 1;
				Q.push (v);
			}
		}
	}
}
signed main (){
	freopen ("holiday.in", "r", stdin);
	freopen ("holiday.out", "w", stdout);
	scanf ("%lld%lld%lld", &n, &m, &p);
	++ p;
	for (int i = 2;i <= n;++ i)
		scanf ("%lld", &cs[i]);
	for (int i = 1;i <= m;++ i){
		scanf ("%lld%lld", &x, &y);
		Add (x, y);
		Add (y, x);
	}
	for (ip = 1;ip <= n;++ ip){
		for (int i = 1;i <= n;++ i)
			dis[ip][i] = inf;
		Bfs ();
	}
	for (int i = 2;i <= n;++ i)
		if (dis[1][i] <= p)
			for (int j = 2;j <= n;++ j)
				if (dis[i][j] <= p && i != j)
					for (int k = 2;k <= n;++ k)
						if (dis[j][k] <= p && i != k && j != k)
							for (int h = 2;h <= n;++ h)
								if (dis[k][h] <= p && dis[h][1] <= p && i != h && j != h && k != h)
									Ans = max (Ans, cs[i] + cs[j] + cs[k] + cs[h]);
	printf ("%lld\n", Ans);
	return 0;
}
