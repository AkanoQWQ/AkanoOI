#include<bits/stdc++.h>
using namespace std;

#define int long long
#define ri register int 

inline int rd()
{
	int a=0,f=1;
	char c=getchar();
	for(;c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) a=(a<<1)+(a<<3)+c-'0';
	return a*f;
}

inline void wr(int x)
{
	if(x<0)putchar('-'),x=-x;
	if(x>9) wr(x/10);
	putchar(x%10+'0');
}

signed main()
{
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	
	return 0;
	
}
