#include<bits/stdc++.h>
using namespace std;

#define int long long
#define ri register int 

inline int rd()
{
	int a=0,f=1;
	char c=getchar();
	for(;c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) a=(a<<1)+(a<<3)+c-'0';
	return a*f;
}

inline void wr(int x)
{
	if(x<0)putchar('-'),x=-x;
	if(x>9) wr(x/10);
	putchar(x%10+'0');
}

int n,m,lim,inf,ans=-1;
int dis[2550][2550];
int v[2550];
bool lt[2550];
int plan[2550][2550];

//struct node{
//	int bh,v;
//};
//bool operator <(const node a,const node b){return a.v<b.v;}
//priority_queue<node>edge[2550];
vector<int>edge[2550];
/*
inline void addedge(int i,int j)
{
	node x;
	x.bh=i,x.v=v[i]; edge[j].push(x);
	x.bh=j,x.v=v[j]; edge[i].push(x);
}*/

inline void Floyd()
{
	for(ri k=1;k<=n;k++)
		for(ri i=1;i<=n;i++)
		{
			if(i==k) continue;
			for(ri j=1;j<=n;j++)
			{
				if(j==k||j==i) continue;
				
				if(dis[i][k]!=inf&&dis[j][k]!=inf)
					if(dis[i][j]>dis[i][k]+dis[j][k])
						dis[i][j]=dis[j][i]=dis[i][k]+dis[j][k];			
			}
		}
	
	for(ri i=1;i<=n;i++)
		for(ri j=i+1;j<=n;j++)
		{
			if(dis[i][j]<=lim)
			{
				edge[i].push_back(j);
				edge[j].push_back(i);
				if(i==1)
				{
					lt[j]=1;
				}
				else
				{
					if(lt[i])
					{
						plan[i][j]=v[i]+v[j];
					}
					if(lt[j])
					{
						plan[j][i]=v[i]+v[j];
					}
				}
			}
		}
			
	
}

inline void solve()
{
	for(ri i=0;i<edge[1].size();i++)
	{
		ri v1=edge[1][i];
		for(ri j=i+1;j<edge[1].size();j++)
		{
			ri v4=edge[1][j];
			for(ri ii=0;ii<edge[v1].size();ii++)
			{
				ri v2=edge[v1][ii];
				if(v2==v4) continue;
				for(ri jj=0;jj<edge[v4].size();jj++)
				{
					ri v3=edge[v4][jj];
					if(v3==v2||v3==v1) continue;
					if(dis[v2][v3]>lim) continue;
					
					if(ans<plan[v1][v2]+plan[v4][v3])
						ans=plan[v1][v2]+plan[v4][v3];
					
				}
			}
		}
			
	}
		
}

signed main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);

	memset(dis,127,sizeof(dis));	
	inf=dis[0][0];
	n=rd(),m=rd(),lim=rd();
	lim++;
	
	for(ri i=2;i<=n;i++) v[i]=rd();
	
	for(ri i=1;i<=m;i++)
	{
		ri u=rd(),v=rd();
		dis[u][v]=dis[v][u]=1;
	}
	
	Floyd();
	
	solve();
	
	wr(ans);
	
	return 0;
	
}

/*

8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1

7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4

*/
