#include<bits/stdc++.h>
using namespace std;

#define int long long
#define ri register int
 
const int inf=1e18+1;

inline int rd()
{
	int a=0,f=1;
	char c=getchar();
	for(;c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) a=(a<<1)+(a<<3)+c-'0';
	return a*f;
}

inline void wr(int x)
{
	if(x<0)putchar('-'),x=-x;
	if(x>9) wr(x/10);
	putchar(x%10+'0');
}

inline void MAX(int &a,int b){if(a<b)a=b;}
inline void MIN(int &a,int b){if(a>b)a=b;}

int n,m,q;
int a[100050],b[100050];
//int C[1005][10005];

signed main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	
	n=rd(),m=rd(),q=rd();
	
	for(ri i=1;i<=n;i++)
		a[i]=rd();
	for(ri i=1;i<=m;i++)
		b[i]=rd();
	
	while(q--)
	{
		ri maxn=-inf,minn=inf;
		
		ri l1=rd(),r1=rd(),l2=rd(),r2=rd();
		
		for(ri i=l1;i<=r1;i++)
		{
			minn=inf;
			for(ri j=l2;j<=r2;j++)
			{
				ri C=a[i]*b[j];
				MIN(minn,C);
			}
			MAX(maxn,minn);
		}
		wr(maxn),puts("");
	}
	
	return 0;
	
}

/*

3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2

6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3


*/
