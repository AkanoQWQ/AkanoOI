#include<bits/stdc++.h>
using namespace std;
int n,m,k;
int ans;
int s[2505];
int head[2505],vis[2505],cnt;
struct node{
	int from,to,next;
}edges[10005];
void add(int a,int b){
	cnt++;
	edges[cnt].from=a;
	edges[cnt].to=b;
	edges[cnt].next=head[a];
	head[a]=cnt;
}
void dfs1(int now,int depth,int sum){
	sum+=s[now];
	if(depth==5){
		for(int e=head[now];e;e=edges[e].next){
			int to=edges[e].to;
			if(to==1){
				ans=max(ans,sum);
				break;
			}
		}
		return;
	}
	for(int e=head[now];e;e=edges[e].next){
			int to=edges[e].to;
			if(vis[to]==0){
				vis[to]=1;
				dfs1(to,depth+1,sum);
				vis[to]=0;
			}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++){
		cin>>s[i];
	}
	for(int i=1;i<=m;i++){
		int x,y;
		cin>>x>>y;
		add(x,y);
		add(y,x);
	}
	if(k==0){
		dfs1(1,1,0);
	}
	cout<<ans;
	return 0;
}

