#include<bits/stdc++.h>
using namespace std;
int n,m,q;
long long int a[100001],b[100001];
void solve1(int l1,int r1,int l2,int r2){
	long long int ans=1e18+114514;
	if(l1==r1){
		long long int x=a[l1]; 
		for(int i=l2;i<=r2;i++){
			long long int y=x*b[i];
			ans=min(ans,y);
		}
	}else{
		ans=0;
		long long int x=b[l2]; 
		for(int i=l1;i<=r1;i++){
			long long int y=x*a[i];
			ans=max(ans,y);
		}
	}
	cout<<ans<<endl;
}
void solve2(int l1,int r1,int l2,int r2){
	long long int maxa=0,minb=1e18+114514;
	for(int i=l1;i<=r1;i++){
		maxa=max(maxa,a[i]);
	}
	for(int i=l2;i<=r2;i++){
		minb=min(minb,b[i]);
	}
	long long int ans=0;
	ans=maxa*minb;
	cout<<ans<<endl;
}
void solve3(int l1,int r1,int l2,int r2){
	long long int ans=-1e18-114514;
	for(int i=l1;i<=r1;i++){
		long long int num;
		if(a[i]>0){
			num=1e18+114514;
			for(int i=l2;i<=r2;i++){
				num=min(num,b[i]);
			}
		}else{
			num=-1e18-114514;
			for(int i=l2;i<=r2;i++){
				num=max(num,b[i]);
			}
		}
		long long int sum=a[i]*num;
		ans=max(ans,sum);
	}
	cout<<ans<<endl;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	bool T=1;
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		if(a[i]<=0){
			T=0;
		}
	}
	for(int j=1;j<=m;j++){
		cin>>b[j];
		if(b[j]<=0){
			T=0;
		}
	}
	for(int i=1;i<=q;i++){
		int l1,r1,l2,r2;
		cin>>l1>>r1>>l2>>r2;
		if(l1==r1||l2==r2){
			solve1(l1,r1,l2,r2);
		}else{
			if(T)
			solve2(l1,r1,l2,r2);
			else
			solve3(l1,r1,l2,r2);
		}
	}

	return 0;
}
