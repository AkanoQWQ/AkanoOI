#include<bits/stdc++.h>
using namespace std;
int n,m,q;
int vis[100005];
int f[1005][10005],du[1005];
bool x=0,y=0;
void dfs1(int now){
	int cnt=0;
	for(int i=1;i<=n;i++){
		if(f[now][i]==1){
			cnt++;
		}	
	}
	if(cnt!=1){
		x=1;
		return;
	}
	for(int i=1;i<=n;i++){
		if(f[now][i]==1&&vis[i]==0){
			vis[i]=1;
			dfs1(i);
		}
	}
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int u,v;
		cin>>u>>v;
		f[u][v]=1;
		du[v]++;
	}
	cin>>q;
	for(int Q=1;Q<=q;Q++){
		int t;
		x=0,y=0;
		memset(vis,0,sizeof(vis));
		cin>>t;
		if(t==1){
			int u,v;
			cin>>u>>v;
			f[u][v]=-1;	
			du[v]--;		
		}else if(t==2){
			int u;
			cin>>u;
			for(int i=1;i<=n;i++){
				if(f[i][u]==1){
					f[i][u]=-1;
					du[u]--;
				}
			}
		}else if(t==3){
			int u,v;
			cin>>u>>v;
			f[u][v]=1;
			du[v]++;
		}else{
			int u;
			cin>>u;
			for(int i=1;i<=n;i++){
				if(f[i][u]==-1){
					f[i][u]=1;
					du[u]++;
				}
			}
		}
		queue<int> qq;
		for(int i=1;i<=n;i++){
			if(vis[i]==0){
				dfs1(i);
			}
		}
		int cn=0;
		for(int i=1;i<=n;i++){
			if(du[i]==0){
				qq.push(i);
				cn++;
			}
		}
		while(!qq.empty()){
			int u=qq.front();qq.pop();
			for(int v=1;v<=n;v++){
				if(f[u][v]==1){
					du[v]--;
					if(du[v]==0){
						qq.push(v);
						cn++;
					}
				}
			}
		}
		if(cn>=n){
			y=1;
		}
		if(y==0&&x==0){
			cout<<"YES"<<endl;
		}else{
			cout<<"NO"<<endl;
		}
	}


	return 0;
}

