#include<bits/stdc++.h>
using namespace std;
int n,q,k;
long long int v[200005];
int head[200005],vis[200005],cnt;
struct node{
	int from,to,next;
}edges[200005];
void add(int a,int b){
	cnt++;
	edges[cnt].from=a;
	edges[cnt].to=b;
	edges[cnt].next=head[a];
	head[a]=cnt;
}
void solve1(int now,int fa,int f,long long int sum){
	sum+=v[now];
	if(now==f){
		cout<<sum<<endl;
		return;
	}
	for(int e=head[now];e;e=edges[e].next){
		int to=edges[e].to;
		if(to!=fa){
			solve1(to,now,f,sum);
		}
	}
}
long long int r[200005],num;
long long int dp[200005];
void solve2(int now,int fa,int f,long long int rt[],int tot){
	rt[++tot]=now;
	if(now==f){
		for(int i=1;i<=tot;i++){
			r[i]=rt[i];
		}
		num=tot;
		return;
	}
	for(int e=head[now];e;e=edges[e].next){
		int to=edges[e].to;
		if(to!=fa){
			solve2(to,now,f,rt,tot);
		}
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++){
		cin>>v[i];
	}
	for(int i=1;i<n;i++){
		int x,y;
		cin>>x>>y;
		add(x,y);
		add(y,x);
	}
	for(int Q=1;Q<=q;Q++){
		int s,e;
		cin>>s>>e;
		if(k==1){
			solve1(s,0,e,0);
		}else if(k==2){
			memset(r,0,sizeof(r));
			num=0;
			solve2(s,0,e,r,num);
			r[1]=s;
			r[num]=e;
			dp[1]=v[r[1]];
			dp[2]=dp[1]+v[r[2]];
			for(int i=3;i<=num;i++){
				dp[i]=min(dp[i-2]+v[r[i]],dp[i-1]+v[r[i]]);
			}
			cout<<dp[num]<<endl;
		}else{
			memset(r,0,sizeof(r));
			num=0;
			solve2(s,0,e,r,num);
			r[1]=s;
			r[num]=e;
			dp[1]=v[r[1]];
			dp[2]=dp[1]+v[r[2]];
			dp[3]=min(dp[1]+v[r[3]],dp[2]+v[r[3]]);
			for(int i=4;i<=num;i++){
				dp[i]=min(dp[i-1]+v[r[i]],min(dp[i-2]+v[r[i]],dp[i-3]+v[r[i]]));
			}
//			for(int i=1;i<=num;i++){
//				cout<<r[i]<<" ";
//			}

			cout<<dp[num]<<endl;
		}
	}


	return 0;
}

