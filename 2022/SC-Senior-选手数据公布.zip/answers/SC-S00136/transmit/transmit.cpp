#include <bits/stdc++.h>
using namespace std;
int n,Q,k,jl[2510][2510],hd[2510],nxt[2010],go[2010],tot,jz[2510],zdl[2010][2010];
bool book[2510];
queue<int> q; 
void add(int x,int y)
{
	nxt[++tot]=hd[x];go[tot]=y;hd[x]=tot;
	return;
}
void bfs(int cur)
{
	book[cur]=1;
	jl[cur][cur]=0;
	zdl[cur][cur]=0;
	q.push(cur);
	while(!q.empty())
	{
		int u=q.front();
		q.pop();
		for(int i=hd[u];i;i=nxt[i])
		{
			int v=go[i];
			if(book[v])continue;
			jl[cur][v]=jl[cur][u]+1;
			zdl[cur][v]=jz[cur]+jz[v];
			book[v]=1;
			if(jl[cur][v]<k)q.push(v);
		}
	}
	return ;
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	memset(jl,0x3f,sizeof(jl));
	memset(zdl,0x7f,sizeof(zdl));
	scanf("%d%d%d",&n,&Q,&k);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&jz[i]);
	}
	for(int i=1;i<=n-1;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,y);add(y,x);
		zdl[x][y]=zdl[y][x]=jz[x]+jz[y];
	}
	for(int i=1;i<=n;i++)
	{
		bfs(i);
		memset(book,0,sizeof(book));
	}
	for(int p=1;p<=n;p++)
	{
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				if(i==j||i==p||j==p)continue;
				if(jl[i][p]<=k&&jl[p][j]<=k)
				{
					zdl[i][j]=min(zdl[i][j],zdl[i][p]+zdl[p][j]-jz[p]);
					jl[i][j]=jl[j][i]=k;
				}
			}
		}
	}
	while(Q--)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		printf("%d\n",zdl[x][y]);
	}
	return 0;
}
