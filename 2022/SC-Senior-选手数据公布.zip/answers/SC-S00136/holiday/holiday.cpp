#include <bits/stdc++.h>
using namespace std;
int n,m,k,jl[2510][2510],hd[2510],nxt[20010],go[20010],tot,jz[2510];
long long ans;
bool book[2510];
queue<int> q; 
void add(int x,int y)
{
	nxt[++tot]=hd[x];go[tot]=y;hd[x]=tot;
	return;
}
void bfs(int cur)
{
	book[cur]=1;
	jl[cur][cur]=-1;
	q.push(cur);
	while(!q.empty())
	{
		int u=q.front();
		q.pop();
		for(int i=hd[u];i;i=nxt[i])
		{
			int v=go[i];
			if(book[v])continue;
			jl[cur][v]=jl[cur][u]+1;
			book[v]=1;
			if(jl[cur][v]<k)q.push(v);
		}
	}
	return ;
}
void dfs(int las,int cs,long long hz)
{
	if(cs==5)
	{
		ans=max(ans,hz);
		return ;
	}
	for(int i=2;i<=n;i++)
	{
		if(jl[las][i]>k||book[i])continue;
		if(cs==4&&jl[1][i]>k)continue;
		book[i]=1;
		dfs(i,cs+1,hz+jz[i]);
		book[i]=0;
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	memset(jl,0x3f,sizeof(jl));
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++)scanf("%lld",&jz[i]);
	for(int i=1;i<=m;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,y);add(y,x);
	}
	for(int i=1;i<=n;i++)
	{
		bfs(i);
		memset(book,0,sizeof(book));
	}
	dfs(1,1,0);
	printf("%lld\n",ans);
	return 0;
}
