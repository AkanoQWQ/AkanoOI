#include <bits/stdc++.h>
using namespace std;
int n,m,q,lg[100010];
long long a[100010],b[100010],st[1000010][12];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++)scanf("%lld",&b[i]); 
	lg[0]=-1;
	for(int i=1;i<=m;i++)lg[i]=lg[i>>1]+1;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			st[(i-1)*m+j][0]=a[i]*b[j];
		}
	}
	for(int k=1;k<10;k++)
	{
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				if(j+(1<<k)-1<=m)
				{
					st[(i-1)*m+j][k]=min(st[(i-1)*m+j][k-1],st[(i-1)*m+j+(1<<(k-1))][k-1]);
				}
			} 
		}	 
	}
	while(q--)
	{
		int l1,r1,l2,r2;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		long long ans=-1e18;
		int k=lg[r2-l2+1];
		for(int i=l1;i<=r1;i++)
		{
			long long jg=min(st[(i-1)*m+l2][k],st[(i-1)*m+r2-(1<<k)+1][k]);
			if(jg>ans)ans=jg;
		}
		printf("%lld\n",ans);
	}
	return 0;
 } 
