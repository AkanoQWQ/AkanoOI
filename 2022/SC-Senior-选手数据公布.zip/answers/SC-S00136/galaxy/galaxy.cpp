#include <bits/stdc++.h>
using namespace std;
int n,m,q,x,y;
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)scanf("%d%d",&x,&y);
	scanf("%d",&q);
	while(q--)
	{
		srand(time(NULL));
		int ans=rand();
		if(ans%2==0)printf("YES\n");
		else printf("NO\n"); 
	}	
	return 0;
}
