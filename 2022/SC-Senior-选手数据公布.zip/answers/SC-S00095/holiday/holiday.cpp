#include<bits/stdc++.h>
#define maxn 2510
#define maxm 10010
using namespace std;
template<typename T>void read(T &x){
	x=0;
	T neg=0;
	int c=getchar();
	while(!isdigit(c)) neg|=!(c^'-'),c=getchar();
	while(isdigit(c)) x=(x<<1)+(x<<3)+(c^48),c=getchar();
	if(neg) x=(~x)+1;
}
int n,m,k,xx;
long long s[maxn],maxx;
bool b[maxn];
struct edge{
	int v,nt;
}e[maxm<<1];
int to,hd[maxm];
void addedge(int u,int v){
	e[++to].v=v;
	e[to].nt=hd[u];
	hd[u]=to;
	return ;
}
void dfs(int x,long long ans){
	if(xx==5){
		if(x==1) maxx=max(ans,maxx);
		return ;
	}
	for(int i=hd[x];i;i=e[i].nt){
		int v=e[i].v;
		if(!b[v]){
			b[v]=1;
			xx++,ans+=s[v];
			dfs(v,ans);
			ans-=s[v],xx--;
			b[v]=0;
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	read(n),read(m),read(k);
	for(int i=2;i<=n;i++){
		read(s[i]);
	}
	for(int i=1;i<=m;i++){
		int x,y;
		read(x),read(y);
		addedge(x,y),addedge(y,x);
	}
	dfs(1,0);
	printf("%lld\n",maxx);
	return 0;
}
