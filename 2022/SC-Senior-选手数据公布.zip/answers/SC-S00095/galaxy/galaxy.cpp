#include<bits/stdc++.h>
#define maxm 500010
#define maxn 10010
using namespace std;
template<typename T>void read(T &x){
	x=0;
	T neg=0;
	int c=getchar();
	while(!isdigit(c)) neg|=!(c^'-'),c=getchar();
	while(isdigit(c)) x=(x<<1)+(x<<3)+(c^48),c=getchar();
	if(neg) x=(~x)+1;
}
int n,m,q,ct;
struct edge{
	int v,w,nt;
}e[maxm<<1];
int to,hd[maxm];
void addedge(int u,int v){
	e[++to].v=v;
	e[to].w=1;
	e[to].nt=hd[u];
	hd[u]=to;
	return ;
}
bool b[maxn][maxn],na;
//void ch(int x,int now){
//	if(now==x&&ct){
//		na=1;
//		return ;
//	}
//	for(int i=hd[x];i;i=e[i].nt){
//		if(e[i].w==1) ct++,ch(x,e[i].v);
//	}
//	return ;
//}
bool check(){
//	bool bb=0;
//	bool bbb=0;
	for(int i=1;i<=n;i++){
		int x=0;
		for(int j=hd[i];j;j=e[j].nt)
			if(e[j].w==1) x++;
		if(x!=1) return 0;
	}
//	for(int i=1;i<n;i++){
//		for(int j=i+1;j<=n;j++){
//			if(b[i][j]==1&&b[j][i]==1) bb=1;
//		}
//		ct=0,na=0,ch(i,i);
//		if(na) bbb=1;
//	}
//	if((!bb)&&(!bbb)) return 0;
	return 1;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	read(n),read(m);
	for(int i=1;i<=m;i++){
		int u,v;
		read(u),read(v);
		addedge(u,v);
		b[u][v]=1;
	}
	read(q);
	int t;
	while(q--){
		read(t);
		int u,v;
		if(t==1){
			read(u),read(v);
			b[u][v]=0;
			for(int i=hd[u];i;i=e[i].nt)
				if(v==e[i].v) e[i].w=-1;
		}
		else if(t==2){
			read(u);
			for(int i=1;i<=n;i++)
				b[i][u]=0;
			for(int i=1;i<=m;i++)
				if(e[i].v==u) e[i].w=-1;
		}
		else if(t==3){
			read(u),read(v);
			b[u][v]=1;
			for(int i=hd[u];i;i=e[i].nt)
				if(v==e[i].v) e[i].w=1;
		}
		else{
			read(u);
			for(int i=1;i<=n;i++)
				b[i][u]=1;
			for(int i=1;i<=m;i++)
				if(e[i].v==u) e[i].w=1;
		}
		if(check()) printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
