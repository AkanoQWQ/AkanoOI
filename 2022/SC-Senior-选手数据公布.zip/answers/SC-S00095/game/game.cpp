#include<bits/stdc++.h>
#define maxn 100010
#define inf 0x3f3f3f3f
using namespace std;
template<typename T>void read(T &x){
	x=0;
	T neg=0;
	int c=getchar();
	while(!isdigit(c)) neg|=!(c^'-'),c=getchar();
	while(isdigit(c)) x=(x<<1)+(x<<3)+(c^48),c=getchar();
	if(neg) x=(~x)+1;
}
int n,m,q;
int l1,l2,r1,r2;
int a[maxn],b[maxn];
bool aa,bb;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	read(n),read(m),read(q);
	for(int i=1;i<=n;i++){
		read(a[i]);
		if(a[i]) aa=1;
	}
	for(int i=1;i<=m;i++){
		read(b[i]);
		if(b[i]) bb=1;
	}
	while(q--){
		read(l1),read(r1),read(l2),read(r2);
		if(l1==r1){
			if(a[l1]==0){
				printf("0\n");
				continue;
			}
			else if(a[l1]>0){
				int minn=inf;
				for(int i=l2;i<=r2;i++)
					minn=min(b[i],minn);
				printf("%lld\n",1ll*a[l1]*minn);
				continue;
			}
			else{
				int maxx=b[l2];
				for(int i=l2+1;i<=r2;i++)
					maxx=max(maxx,b[i]);
				printf("%lld\n",1ll*a[l1]*maxx);
				continue;
			}
		}
		else if(l2==r2){
			if(b[l1]==0){
				printf("0\n");
				continue;
			}
			else if(b[l1]<0){
				int minn=inf;
				for(int i=l1;i<=r1;i++)
					minn=min(a[i],minn);
				printf("%lld\n",1ll*b[l1]*minn);
				continue;
			}
			else{
				int maxx=a[l1];
				for(int i=l1+1;i<=r1;i++)
					maxx=max(maxx,a[i]);
				printf("%lld\n",1ll*b[l1]*maxx);
				continue;
			}
		}
		if(aa&&bb){
			int maxx=a[l1],minn=inf;
			for(int i=l1+1;i<=r1;i++){
				maxx=max(a[i],maxx);
			}
			for(int i=l2;i<=r2;i++){
				minn=min(minn,b[i]);
			}
			printf("%lld\n",1ll*maxx*minn);
			continue;
		}
	}
	
	return 0;
}
