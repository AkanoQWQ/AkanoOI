#include <bits/stdc++.h>
using namespace std;
const int maxl=20;
const int maxn=100010;
int n,m,q,i,j,d,a,t,lx,ly,rx,ry;
int v[maxn],lb[maxn];
int s[4][maxl][maxn],b[2][maxl][maxn];
long long nw,cx,ans;
int QueA(int id,int l,int r){
	int le=lb[r-l+1];
	if(id&1) return max(s[id][le][l],s[id][le][r-(1<<le)+1]);
	return min(s[id][le][l],s[id][le][r-(1<<le)+1]);
}
int QueB(bool id,int l,int r){
	int le=lb[r-l+1];
	if(id) return max(b[id][le][l],b[id][le][r-(1<<le)+1]);
	return min(b[id][le][l],b[id][le][r-(1<<le)+1]);
}
bool QueZ(int l,int r){return (*lower_bound(v+1,v+t+1,l))<=r;}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	memset(s[0],0x3f,sizeof(s[0]));
	memset(s[3],0xc0,sizeof(s[3]));
	for(i=2;i<maxn;++i) lb[i]=lb[i>>1]+1;
	scanf("%d%d%d",&n,&m,&q);
	for(i=1;i<=n;++i){
		scanf("%d",&a);
		if(a>0) s[0][0][i]=s[1][0][i]=a;
		else if(a<0) s[2][0][i]=s[3][0][i]=a;
		else v[++t]=i;
	}
	v[t+1]=n+1;
	for(i=1;i<=m;++i){
		scanf("%d",b[0][0]+i);
		b[1][0][i]=b[0][0][i];
	}
	for(j=1;j<maxl;++j){
		d=m-(1<<j)+1;
		for(i=1;i<=d;++i){
			b[0][j][i]=min(b[0][j-1][i],b[0][j-1][i+(1<<(j-1))]);
			b[1][j][i]=max(b[1][j-1][i],b[1][j-1][i+(1<<(j-1))]); 
		}
		d=n-(1<<j)+1;
		for(i=1;i<=d;++i){
			s[0][j][i]=min(s[0][j-1][i],s[0][j-1][i+(1<<(j-1))]);
			s[1][j][i]=max(s[1][j-1][i],s[1][j-1][i+(1<<(j-1))]); 
			s[2][j][i]=min(s[2][j-1][i],s[2][j-1][i+(1<<(j-1))]);
			s[3][j][i]=max(s[3][j-1][i],s[3][j-1][i+(1<<(j-1))]); 
		}
	}
	for(i=1;i<=q;++i){
		scanf("%d%d%d%d",&lx,&ly,&rx,&ry);
		if(QueZ(lx,ly)) ans=0;
		else ans=-LLONG_MAX;
		cx=QueB(0,rx,ry);
		nw=QueA(cx>=0,lx,ly); 
		if(nw!=0x3f3f3f3f&&nw>0) ans=max(ans,nw*cx);
		cx=QueB(1,rx,ry);
		nw=QueA(2+(cx>0),lx,ly);
		if(nw!=0xc0c0c0c0&&nw<0) ans=max(ans,nw*cx);
		printf("%lld\n",ans);
	}
	return 0;
}

