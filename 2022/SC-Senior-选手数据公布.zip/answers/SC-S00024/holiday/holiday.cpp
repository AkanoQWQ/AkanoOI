#include <bits/stdc++.h>
using namespace std;
const int maxl=15;
const int maxn=2510;
const int maxm=10010;
#define ll long long
int n,m,k,i,j,u,v,t,l,r,b;
int h[maxn],d[maxn],q[maxn],lb[maxn];
bool g[maxn][maxn];
ll ans,nw,s[maxn],st[maxl][maxn][maxn];
struct edge{int to,nxt;}E[maxm<<1];
ll Que(int xt,int ys,int yt){
	if(ys>yt) return 0; int le=lb[yt-ys+1];
	return max(st[le][xt][ys],st[le][xt][yt-(1<<le)+1]);
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	for(i=2;i<maxn;++i) lb[i]=lb[i>>1]+1;
	scanf("%d%d%d",&n,&m,&k); k+=2;
	for(i=2;i<=n;++i) scanf("%lld",s+i);
	while(m--){
		scanf("%d%d",&u,&v);
		E[++t]={v,h[u]}; h[u]=t;
		E[++t]={u,h[v]}; h[v]=t;
	}
	for(i=1;i<=n;++i){
		for(j=1;j<=n;++j) d[j]=0;
		l=r=1; q[1]=i; d[i]=1;
		while(l<=r){
			u=q[l++];
			if(d[u]==k) continue;
			for(j=h[u];j;j=E[j].nxt){
				v=E[j].to;
				if(d[v]) continue;
				d[v]=d[u]+1; g[i][v]=1;
				q[++r]=v;
			}
		}
		g[i][i]=0;
	}
	for(i=2;i<=n;++i){
		if(g[i][1]){
			for(j=2;j<=n;++j){
				if(g[j][i]) st[0][j][i]=s[i]+s[j];
			}
		}
	}
	for(k=1;k<maxl;++k){
		b=n-(1<<k)+1;
		if(!b) continue;
		for(i=1;i<=n;++i){
			for(j=1;j<=b;++j){
				st[k][i][j]=max(st[k-1][i][j],st[k-1][i][j+(1<<(k-1))]);
			}
		}
	}
	for(i=2;i<=n;++i){
		if(!g[1][i]) continue;
		for(j=2;j<=n;++j){
			if(!g[i][j]) continue;
			u=i; v=j; if(u>v) swap(u,v);
			nw=0;
			for(k=2;k<=n;++k){
				if(!g[j][k]) continue; if(k==i) continue;
				nw=max(nw,max(max(Que(k,1,u-1),Que(k,u+1,v-1)),Que(k,v+1,n)));
			}
			ans=max(ans,s[i]+s[j]+nw);
		}
	}
	printf("%lld",ans);
	return 0;
}

