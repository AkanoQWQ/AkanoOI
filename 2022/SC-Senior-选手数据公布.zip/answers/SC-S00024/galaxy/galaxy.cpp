#include <bits/stdc++.h>
using namespace std;
const int maxn=500010;
int n,m,i,j,k,o,u,v,t,cd;
int deg[maxn]; bool g[maxn];
map<pair<int,int>,int> M;
void Chg(int &x,int y){
	if(x==1) --cd;
	if(y==1) ++cd;
	x=y;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(i=1;i<=m;++i){
		scanf("%d%d",&u,&v);
		M[make_pair(u,v)]=i; 
		Chg(deg[u],deg[u]+1);
	}
	scanf("%d",&m);
	for(k=1;k<=m;++k){
		scanf("%d%d",&o,&u);
		if(o&1){
			scanf("%d",&v);
			g[M[make_pair(u,v)]]=(o==1);
			if(o==1) Chg(deg[u],deg[u]-1);
			else Chg(deg[u],deg[u]+1); 
		}
		else{
			for(i=1;i<=n;++i){
				auto p=make_pair(i,u);
				if(M.find(p)!=M.end()){
					t=M[p];
					if(o==2){if(!g[t]) Chg(deg[i],deg[i]-1),g[t]=1;}
					else if(g[t]) Chg(deg[i],deg[i]+1),g[t]=0;
				} 
			}
		}
		if(cd!=n) printf("NO\n");
		else printf("YES\n");
	}
	return 0;
}

