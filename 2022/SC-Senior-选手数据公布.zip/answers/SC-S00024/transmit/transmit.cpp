#include <bits/stdc++.h>
using namespace std;
const int maxl=20;
const int maxn=200010;
int n,q,k,i,j,u,v,b,t,tt,tf,tp,to,top;
int h[maxn],p[maxn],va[maxn],hf[maxn],stk[maxn];
int dep[maxn],fa[maxl][maxn];
long long a,dp[maxn],ds[maxn];
bool vis[maxn],in[maxn];
struct edge{int to,nxt;}E[maxn<<1],F[4000010];
void dfs(int p,int f){
	dep[p]=dep[f]+1;
	ds[p]=ds[f]+va[p];
	int lp,to;
	for(lp=h[p];lp;lp=E[lp].nxt){
		to=E[lp].to;
		if(to==f) continue;
		fa[0][to]=p; 
		dfs(to,p);
	}
}
int lca(int x,int y){
	if(dep[x]<dep[y]) swap(x,y);
	for(j=maxl-1;~j;--j) if(dep[fa[j][x]]>=dep[y]) x=fa[j][x];
	if(x==y) return x;
	for(j=maxl-1;~j;--j) if(fa[j][x]!=fa[j][y]) x=fa[j][x],y=fa[j][y];
	return fa[0][x];
}
priority_queue<pair<long long,int> > pq;
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k); 
	for(i=1;i<=n;++i) scanf("%d",va+i);
	for(i=1;i<n;++i){
		scanf("%d%d",&u,&v);
		E[++t]={v,h[u]}; h[u]=t;
		E[++t]={u,h[v]}; h[v]=t;
	}
	dfs(1,0);
	for(j=1;j<maxl;++j)
		for(i=1;i<=n;++i)
			fa[j][i]=fa[j-1][fa[j-1][i]];
	if(k!=1){
		for(i=1;i<=n;++i){
			for(u=i+1;u<=n;++u){
				if(dep[i]+dep[u]-(dep[lca(i,u)]<<1)>k) continue;
				F[++tf]={u,hf[i]}; hf[i]=tf; 
				F[++tf]={i,hf[u]}; hf[u]=tf;
			}
		}
	}
	memset(dp,0x3f,sizeof(dp));
	while(q--){
		scanf("%d%d",&u,&v); t=lca(u,v);
		if(k==1) printf("%lld\n",ds[u]+ds[v]-(ds[fa[0][t]]<<1)-va[t]);
		else{
			dp[u]=va[u]; 
			stk[++top]=u; in[u]=1;
			pq.push(make_pair(-dp[u],u));
			while(!pq.empty()){
				u=pq.top().second; 
				pq.pop();
				if(vis[u]) continue;
				vis[u]=1;
				if(u==v){
					printf("%lld\n",dp[v]);
					while(!pq.empty()) pq.pop();
					break;
				}
				for(i=hf[u];i;i=F[i].nxt){
					to=F[i].to;
					if(dp[to]>dp[u]+va[to]){
						dp[to]=dp[u]+va[to];
						pq.push(make_pair(-dp[to],to));
						if(!in[to]) stk[++top]=to,in[to]=1;
					}
				}
			}
			while(top){
				vis[stk[top]]=in[stk[top]]=0;
				dp[stk[top--]]=0x3f3f3f3f3f3f3f3f;
			}
		}
	}
	return 0;
}

