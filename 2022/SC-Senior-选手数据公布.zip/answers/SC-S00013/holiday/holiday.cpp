#include<bits/stdc++.h>
#define int long long
using namespace std;

void read(int &a)
{
    char c=getchar();
    int f=1;
    a=0;
    while(c>'9'||c<'0')
    {
        if(c=='-') f=-1;
        c=getchar();
    }
    while(c<='9'&&c>='0')
    {
        a=a*10+c-'0';
        c=getchar();
    }
    a=a*f;
}

int n,m,k,b[2501],ans,a[2501],dp[5][2501];
vector<int> Map1[2501],Map2[2501],dpa[5][2501];

void dfs1(int s,int u,int step)
{
    if(step>k) return;
    for(auto i:Map1[u])
    {
        if(b[i]==0)
        {
            b[i]=1;
            Map2[s].push_back(i);
            Map2[i].push_back(s);
            dfs1(s,i,step+1);
        }
    }
}

signed main()
{
    freopen("holiday.in","r",stdin);
    freopen("holiday.out","w",stdout);
    read(n);
    read(m);
    read(k);
    for(int i=2;i<=n;i++)read(a[i]);
    for(int i=1;i<=m;i++)
    {
        int u,v;
        read(u);
        read(v);
        Map1[u].push_back(v);
        Map1[v].push_back(u);
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++) b[j]=0;
        dfs1(i,i,0);
    }
    for(int i=2;i<=n;i++) dp[0][i]=-1;
    for(int i=1;i<=4;i++)
    {
        dp[i][1]=-1;
        for(int j=2;j<=n;j++)
        {
            dp[i][j]=-1;
            for(auto l:Map2[j])
            {
                int opo=0;
                //printf("%d %d %d %d %d %d %d\n",i,j,l,dp[i][j],dp[i-1][l],a[j],dp[i-1][l]+a[j]>dp[i][j]);
                for(auto o:dpa[i-1][l]) if(j==o) opo=1;
                if(opo==1) continue;
                if(dp[i-1][l]!=-1&&dp[i-1][l]+a[j]>dp[i][j])
                {
                    dpa[i][j].clear();
                    dpa[i][j]=dpa[i-1][l];
                    dpa[i][j].push_back(j);
                    dp[i][j]=dp[i-1][l]+a[j];
                }
                if(dp[i-1][l]!=-1&&dp[i-1][l]+a[j]==dp[i][j])
                {
                    for(int o=0;o<i-1;o++)
                    {
                        //printf("%d %d %d %d\n",i,j,l,o);
                        if(dpa[i][j][o]!=dpa[i-1][l][o]) dpa[i][j][o]=0;
                    }
                }
                //printf("1\n");
            }
        }
    }
    int ans=0;
    for(int i:Map2[1]) ans=max(ans,dp[4][i]);
    printf("%d\n",ans);
    for(int i:Map2[1])
    {
        if(ans==dp[4][i])
        {
            for(auto o:dpa[4][i]) printf("%d ",o);
            putchar('\n');
        }
    }
    for(int i:Map2[1])
    {
        if(ans==dp[4][i])
        {
            for(auto o:dpa[4][i]) printf("%d ",a[o]);
            putchar('\n');
        }
    }
    return 0;
}