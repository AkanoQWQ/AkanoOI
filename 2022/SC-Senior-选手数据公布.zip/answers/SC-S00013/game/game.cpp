#include<bits/stdc++.h>
using namespace std;
#define int long long

int n,m,q,a1[1001],a2[1001],a[1001][1001];

signed main()
{
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    cin>>n>>m;
    cin>>q;
    for(int i=1;i<=n;i++) cin>>a1[i];
    for(int i=1;i<=m;i++) cin>>a2[i];
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)
            a[i][j]=a1[i]*a2[j];
    for(int i=1;i<=q;i++)
    {
        int l1,l2,r1,r2,ans=INT_MIN;
        cin>>l1>>r1>>l2>>r2;
        for(int j=l1;j<=r1;j++)
        {
            int cnt=INT_MAX;
            for(int k=l2;k<=r2;k++)
            {
                cnt=min(cnt,a[j][k]);
            }
            ans=max(ans,cnt);
        }
        cout<<ans<<"\n";
    }
}