#include<bits/stdc++.h>
using namespace std;

void read(int &a)
{
    char c=getchar();
    int f=1;
    a=0;
    while(c>'9'||c<'0')
    {
        if(c=='-') f=-1;
        c=getchar();
    }
    while(c<='9'&&c>='0')
    {
        a=a*10+c-'0';
        c=getchar();
    }
    a=a*f;
}

struct point
{
    point* last,*next;
    int i;
};

struct list
{
    int n,v;
    list()
    {
        n=0;
        v=0;
    }
    point *begin,*end;
    void insert(int i)
    {
        point* a=new point();
        if(n++==0) 
        {
            begin=a;
            end=a;
            return;
        }
        a->last=end;
        end->next=a;
        end=a;
    }
}a[200001];

int dfn[400001],dfnn,p;
vector<int> Map[200001];
int f[200001],n,m,k,b[200001],ans[200001];

void dfs(int u)
{
    for(auto i:Map[u])
    {
        if(i==f[u]) continue;
        f[i]=u;
        dfn[++dfnn]=i;
        a[i].insert(dfnn);
        dfs(i);
        dfn[++dfnn]=u;
        a[u].insert(dfnn);
    }
}

int main()
{
	freopen("transmit.in","r",stdin);
    freopen("transmit.out","w",stdout);
    read(n);
    read(m);
    read(k);
    p=sqrt(n);
    for(int i=1;i<=n;i++)
    {
        read(b[i]);
    }
    for(int i=1;i<n;i++)
    {
        int u,v;
        read(u);
        read(v);
        Map[u].push_back(v);
    }
    f[1]=0;
    dfn[++dfnn]=1;
    a[dfnn].insert(1);
    dfs(1);
    point o[400001];
    for(int i=1;i<=m;i++)
    {
        int u,v;
        read(u);
        read(v);
        int l=a[u].end->i;
        int r=a[v].end->i;
        if(l>r) swap(l,r);
        int cnt=0;
        for(int j=l;j<=r;j++)
        {
            cnt+=b[j];
            if(o[dfn[j]].next->i<=r) j=o[dfn[j]].next->i,o[dfn[j]]=*o[dfn[j]].next;;
        }
        ans[i]=cnt;
    }
    for(int i=1;i<=m;i++) printf("%d\n",ans[i]);
}
