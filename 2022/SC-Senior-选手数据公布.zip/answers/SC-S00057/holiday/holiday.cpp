#include<bits/stdc++.h>
#define N 10005
using namespace std;
int n,m,k,tot,ans,to[N*2],nxt[N*2],first[N],c[N];
bool mp[N],con1[N];
void add(int x,int y){
	nxt[++tot]=first[x];
	first[x]=tot;
	to[tot]=y;
	return;
}
void dfs(int x,int len,int score){
	mp[x]=true;
	if(len>0)for(int e=first[x];e;e=nxt[e]){
		int u=to[e];
		if(mp[u])continue;
		dfs(u,len-1,score+c[x]);
	}else if(con1[x]){
		ans=max(ans,score+c[x]);
	}
	mp[x]=false;
	return;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int a,b;
	memset(mp,false,sizeof(mp));
	memset(con1,false,sizeof(con1));
	scanf("%d %d %d",&n,&m,&k);
	for(int i=2;i<=n;i++)scanf("%d",&c[i]);
	for(int i=0;i<m;i++){
		scanf("%d %d",&a,&b); 
		add(a,b);
		add(b,a);
		if(a==1||b==1)con1[a]=con1[b]=1;
	}
	dfs(1,4,0);
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
