#include<bits/stdc++.h>
#define N 100005
#define Bad -0x7f7f7f7f7f7f7f7f
using namespace std;
struct dian{
	long long p,n;
};
long long l1,r1,l2,r2,n,m,q,ans0,ans1,ans2,ans3,ans4,pos1=-Bad,pos2=0,bmax,bmin;
dian a[N],b[N];
bool comp(dian x,dian y){
	return x.n<y.n;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld %lld %lld",&n,&m,&q);
	int x;
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i].n);
		a[i].p=i;
	}
	a[0].n=0;a[0].p=2147483647;
	for(int i=1;i<=m;i++){
		scanf("%lld",&b[i].n);
		b[i].p=i;
	}
	sort(a,a+n+1,comp);
	sort(b+1,b+m+1,comp);
	for(long long i=0;i<=n;i++)
		if(a[i].n==0){
			pos1=min(pos1,i);
			pos2=max(pos2,i);
		}
	while(q-->0){
		scanf("%lld %lld %lld %lld",&l1,&r1,&l2,&r2);
		int pos;
		for(int i=pos1;i<=pos2;i++){
			if(a[i].p>=l1&&a[i].p<=r1){
				ans0=0;
				goto Ed;
			}
		}
		ans0=-0x7f7f7f7f7f7f7f7f;
		Ed:; 
		pos=m;
		while(pos>=1&&(b[pos].p>r2||b[pos].p<l2))pos--;
		bmax=b[pos].n;
		pos=1;
		while(pos<=m&&(b[pos].p>r2||b[pos].p<l2))pos++;
		bmin=b[pos].n;
		pos=pos1;
		while(pos>=0&&(a[pos].p>r1||a[pos].p<l1))pos--;
		if((a[pos].p>r1||a[pos].p<l1))ans1=Bad;
		else ans1=a[pos].n*bmax;
		pos=pos2;
		while(pos<=n&&(a[pos].p>r1||a[pos].p<l1))pos++;
		if((a[pos].p>r1||a[pos].p<l1))ans2=Bad;
		else ans2=a[pos].n*bmin;
		pos=n;
		while(a[pos].n>0&&pos>=0&&(a[pos].p>r1||a[pos].p<l1))pos--;
		if((a[pos].p>r1||a[pos].p<l1))ans3=Bad;
		else ans3=a[pos].n*bmin;
		pos=0;
		while(a[pos].n<0&&pos<=n&&(a[pos].p>r1||a[pos].p<l1))pos++;
		if((a[pos].p>r1||a[pos].p<l1))ans4=Bad;
		else ans4=a[pos].n*bmax;
		printf("%lld\n",max(ans0,max(max(ans3,ans4),max(ans1,ans2))));
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
