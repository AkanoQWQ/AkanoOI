#include<bits/stdc++.h>
#define N 200005
using namespace std;
int dis[N][23],f[N][24],dep[N],len[N]; 
int n,q,k,v[N];
int tot,to[N*2],nxt[N*2],first[N];
void add(int x,int y){
	nxt[++tot]=first[x];
	first[x]=tot;
	to[tot]=y;
}
void preset(int x,int fa){
	f[x][0]=fa;
	dep[x]=dep[fa]+1;
	len[x]=len[fa]+v[x];
	for(int i=1;i<23;i++){
		f[x][i]=f[f[x][i-1]][i-1];
	}
	for(int e=first[x];e;e=nxt[e]){
		int u=to[e];
		if(u!=fa)preset(u,x);
	}
	return;
}
int lca(int x,int y){
	if(dep[x]<dep[y])swap(x,y);
	for(int i=21;i>=0;i--){
		if(dep[f[x][i]]>=dep[y])x=f[x][i];
	}
	for(int i=21;i>=0;i--){
		if(f[x][i]!=f[y][i]){
			x=f[x][i];
			y=f[y][i];
		}
	}
	return f[y][0];
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int a,b;
	scanf("%d %d %d",&n,&q,&k);
	for(int i=1;i<=n;i++){
		scanf("%d",&v[i]);
	}
	for(int i=1;i<n;i++){
		scanf("%d %d",&a,&b);
		add(a,b);
		add(b,a);
	}
	preset(1,0);
	for(int i=1;i<=q;i++){
		scanf("%d %d",&a,&b);
		int t=lca(a,b);
		printf("%d\n",len[a]+len[b]-len[t]*2+v[t]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
