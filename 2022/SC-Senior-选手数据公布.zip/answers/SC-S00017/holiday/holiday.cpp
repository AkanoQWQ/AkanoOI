#include<cstdio>
#include<queue>
#include<iostream>
using namespace std;
const int o=2510,O=1e5;
int n,m,K,dis[o][o],h[o],cnt;long long s[o],fi[o],se[o],th[o],fi1,se1,fi2,se2,ans;queue<int> q;
struct Edge{int v,p;}e[O];
inline void ad(int U,int V){e[++cnt].v=V;e[cnt].p=h[U];h[U]=cnt;}
inline void f(long long&Fi,long long&Se,int x,int y){
	if(fi[x]==s[y]) Fi=se[x],Se=th[x];
	else if(se[x]==s[y]) Fi=fi[x],Se=th[x];
	else Fi=fi[x],Se=se[x];
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&K);
	for(int i=2;i<=n;++i) scanf("%lld",&s[i]);
	for(int u,v;m--;ad(u,v),ad(v,u)) scanf("%d%d",&u,&v);
	for(int i=1;i<=n;++i){
		for(q.push(i),dis[i][i]=1;!q.empty();q.pop()) if(dis[i][q.front()]<K+2)
			for(int j=h[q.front()];j;j=e[j].p) if(!dis[i][e[j].v]) dis[i][e[j].v]=dis[i][q.front()]+1,q.push(e[j].v);
		for(int j=2;j<=n;++j) if(i-j&&dis[i][j]&&dis[1][j]){
			if(s[j]>fi[i]) th[i]=se[i],se[i]=fi[i],fi[i]=s[j];
			else if(s[j]>se[i]) th[i]=se[i],se[i]=s[j];
			else th[i]=max(th[i],s[j]);
		}
	}
	for(int i=2;i<n;++i) for(int j=i+1;j<=n;++j) if(dis[i][j]){
		f(fi1,se1,i,j*!!dis[1][j]);f(fi2,se2,j,i*!!dis[1][i]);
		if(!fi1||!fi2) continue;
		if(fi1^fi2) ans=max(ans,fi1+fi2+s[i]+s[j]);
		else if(se1||se2) ans=max(ans,fi1+max(se1,se2)+s[i]+s[j]);
	}
	printf("%lld",ans);
	return 0;
}
