#include<cstdio>
#include<iostream>
using namespace std;
const int o=4e5+10,E=1e9+10;const long long inf=1e18+10;
int n,m,q,a[o],b[o],mn1[o],mx1[o],mn2[o],mx2[o],mn[o],mx[o],Mn1,Mn2,Mx1,Mx2,mnb,mxb;long long ans;
void build1(int id,int l,int r){
	if(l==r){
		if(a[l]>=0) mn1[id]=mx1[id]=a[l],mn2[id]=E,mx2[id]=-E;
		else mn2[id]=mx2[id]=a[l],mn1[id]=E,mx1[id]=-E;
		return;
	}
	int md=l+r>>1;
	build1(id<<1,l,md);build1((id<<1)|1,md+1,r);
	mn1[id]=min(mn1[id<<1],mn1[(id<<1)|1]);mn2[id]=min(mn2[id<<1],mn2[(id<<1)|1]);
	mx1[id]=max(mx1[id<<1],mx1[(id<<1)|1]);mx2[id]=max(mx2[id<<1],mx2[(id<<1)|1]);
}
void build2(int id,int l,int r){
	if(l==r){mn[id]=mx[id]=b[l];return;}
	int md=l+r>>1;
	build2(id<<1,l,md);build2((id<<1)|1,md+1,r);
	mn[id]=min(mn[id<<1],mn[(id<<1)|1]);mx[id]=max(mx[id<<1],mx[(id<<1)|1]);
}
void query1(int id,int ql,int qr,int l=1,int r=n){
	if(ql<=l&&r<=qr){Mn1=min(Mn1,mn1[id]);Mn2=min(Mn2,mn2[id]);Mx1=max(Mx1,mx1[id]);Mx2=max(Mx2,mx2[id]);return;}
	int md=l+r>>1;
	if(ql<=md) query1(id<<1,ql,qr,l,md);
	if(md<qr) query1((id<<1)|1,ql,qr,md+1,r);
}
void query2(int id,int ql,int qr,int l=1,int r=m){
	if(ql<=l&&r<=qr){mnb=min(mnb,mn[id]);mxb=max(mxb,mx[id]);return;}
	int md=l+r>>1;
	if(ql<=md) query2(id<<1,ql,qr,l,md);
	if(md<qr) query2((id<<1)|1,ql,qr,md+1,r);
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;++i) scanf("%d",&a[i]);
	for(int i=1;i<=m;++i) scanf("%d",&b[i]);
	build1(1,1,n);build2(1,1,m);
	for(int l1,r1,l2,r2;q--;printf("%lld\n",ans)){
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		Mn1=Mn2=mnb=E;Mx1=Mx2=mxb=-E;
		query1(1,l1,r1);query2(1,l2,r2);ans=-inf;
		if(Mx1>=0){
			if(mnb<0) ans=max(ans,Mn1*1ll*mnb);
			else ans=max(ans,Mx1*1ll*mnb);
		}
		if(Mn2<0){
			if(mxb>=0) ans=max(ans,Mx2*1ll*mxb);
			else ans=max(ans,Mn2*1ll*mxb);
		}
	}
	return 0;
}
