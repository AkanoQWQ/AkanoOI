#include<cstdio>
#include<vector>
#include<set>
using namespace std;
const int o=5e5+10;const unsigned B=700;
int n,m,q,d[o],ill;vector<int> e[o];set<int> S[o],T[o];
inline void ad(int x,int val){ill-=(d[x]!=1);ill+=((d[x]+=val)!=1);}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int u,v;m--;e[v].push_back(u)) scanf("%d%d",&u,&v),++d[u],S[v].insert(u);
	for(int i=1;i<=n;++i) ill+=(d[i]!=1);
	scanf("%d",&q);
	for(int t,u,v;q--;printf(ill?"NO\n":"YES\n")){
		scanf("%d%d",&t,&u);
		if(t==1) scanf("%d",&v),S[v].erase(u),T[v].insert(u),ad(u,-1);
		else if(t==2) for(int t;!S[u].empty();S[u].erase(S[u].begin())) ad(t=*S[u].begin(),-1),T[u].insert(t);
		else if(t==3) scanf("%d",&v),T[v].erase(u),S[v].insert(u),ad(u,1);
		else for(int t;!T[u].empty();T[u].erase(T[u].begin())) ad(t=*T[u].begin(),1),S[u].insert(t);
	}
	return 0;
}
