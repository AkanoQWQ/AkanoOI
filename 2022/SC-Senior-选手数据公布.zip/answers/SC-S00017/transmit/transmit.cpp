#include<cstdio>
#include<iostream>
#include<queue>
#include<bitset>
#include<utility>
using namespace std;
const int o=2e5+10,O=2010;
int n,q,K,h[o],cnt,v[o],d[o],anc[o][20],dis[O][O],tp1,tp2;long long ans[O][O];bitset<O> b[O],rem;
queue<int> Q;priority_queue<pair<long long,int> > pq;
struct Edge{int v,p;}e[o*2];
inline void ad(int U,int V){e[++cnt].v=V;e[cnt].p=h[U];h[U]=cnt;}
struct dp{
	long long a[2][2];int st,ed;
	inline dp operator+(const dp&b)const{
		dp res;
		res.st=st;res.ed=b.ed;
		for(int i=0;i<K;++i) for(int j=0;j<K;++j){
			res.a[i][j]=a[i][K-1]+b.a[0][j]-v[ed];
			for(int k=0;k<K;++k) for(int $=0;$<K;++$) res.a[i][j]=min(res.a[i][j],a[i][k]+b.a[$][j]);
		}
		return res;
	}
	inline dp rev()const{
		dp res;
		res.st=ed;res.ed=st;
		if(K>1) for(int i=0;i<2;++i) for(int j=0;j<2;++j) res.a[!j][!i]=a[i][j];
		else res.a[0][0]=a[0][0];
		return res;
	}
}f[o][20],st1[o],st2[o],Ans;
void dfs(int nw){
	d[nw]=d[anc[nw][0]]+1;f[nw][0].st=nw;f[nw][0].ed=anc[nw][0];
	f[nw][0].a[0][0]=v[nw];f[nw][0].a[1][1]=v[anc[nw][0]];f[nw][0].a[0][1]=f[nw][0].a[1][0]=v[nw]+v[anc[nw][0]];
	for(int i=h[nw];i;i=e[i].p) if(e[i].v-anc[nw][0]) anc[e[i].v][0]=nw,dfs(e[i].v);
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&K);
	for(int i=1;i<=n;++i) scanf("%d",&v[i]);
	for(int i=1,u,v;i<n;++i) scanf("%d%d",&u,&v),ad(u,v),ad(v,u);
	if(n<=2000){
		for(int i=1;i<=n;++i){
			for(Q.push(i),dis[i][i]=1;!Q.empty();Q.pop())
				for(int j=h[Q.front()];j;j=e[j].p) if(!dis[i][e[j].v]) dis[i][e[j].v]=dis[i][Q.front()]+1,Q.push(e[j].v);
			for(int j=1;j<=n;++j) if(dis[i][j]<=K+1) b[i].set(j);
		}
		for(int i=1;i<=n;++i){
			for(int j=1;j<=n;++j) rem.set(j);
			rem.reset(i);pq.push(make_pair(-(ans[i][i]=v[i]),i));
			for(int t;!pq.empty();){
				t=pq.top().second;pq.pop();
				for(int j;(j=(b[t]&rem)._Find_first())<O;rem.reset(j))
					pq.push(make_pair(-(ans[i][j]=ans[i][t]+v[j]),j));
			}
		}
		for(int x,y;q--;printf("%lld\n",ans[x][y])) scanf("%d%d",&x,&y);
		return 0;
	}
	dfs(1);
	for(int i=1;i<20;++i) for(int j=1;j<=n;++j) anc[j][i]=anc[anc[j][i-1]][i-1],f[j][i]=f[j][i-1]+f[anc[j][i-1]][i-1];
	for(int x,y;q--;printf("%lld\n",Ans.a[0][1])){
		scanf("%d%d",&x,&y);tp1=tp2=0;
		if(d[x]<d[y]) swap(x,y);
		for(int i=20;i--;) if(d[anc[x][i]]>=d[y]) st1[++tp1]=f[x][i],x=anc[x][i];
		for(int i=20;i--;) if(anc[x][i]^anc[y][i]) st1[++tp1]=f[x][i],st2[++tp2]=f[y][i],x=anc[x][i],y=anc[y][i];
		if(x^y) st1[++tp1]=f[x][0],st2[++tp2]=f[y][0];
		Ans=st1[1];
		for(int i=2;i<=tp1;++i) Ans=Ans+st1[i];
		for(int i=tp2;i;--i) Ans=Ans+(st2[i].rev());
	}
	return 0;
}
