#include<bits/stdc++.h>
using namespace std;
int head[500010],dz,st[500010],cnt;
struct edge{
	int to,nxt,stat;
} eg[500010];
void addedge(int f,int t){
	dz++;
	eg[dz].to=t;
	eg[dz].nxt=head[f];
	head[f]=dz;
	return;
}
int ly[500010],n,m,q;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		addedge(y,x);
		st[x]++;
	}
	scanf("%d",&q);
	for(int i=1;i<=n;i++){
		if(st[i]==0){
			for(int j=1;j<=q;j++){
				printf("NO\n");
			} 
			return 0;
		}
		if(st[i]==1)	cnt++;
	}
	for(int j=1;j<=q;j++){
		int t,x,y;
		scanf("%d",&t);
		if(t==2){
			scanf("%d",&x);
			int s=head[x];
			while(s!=0){
				if(eg[s].stat==0){
					if(st[eg[s].to]==1)	cnt--;
					eg[s].stat=1;
					st[eg[s].to]--;
					if(st[eg[s].to]==1)	cnt++;
				}
				s=eg[s].nxt;
			}
		}
		if(t==4){
			scanf("%d",&x);
			int s=head[x];
			while(s!=0){
				if(eg[s].stat==1){
					if(st[eg[s].to]==1)	cnt--;
					eg[s].stat=0;
					st[eg[s].to]++;
					if(st[eg[s].to]==1)	cnt++;
				}
				s=eg[s].nxt;
			}
		}
		if(t==1){
			scanf("%d%d",&x,&y);
			int s=head[y];
			while(s!=0){
				if(eg[s].to==x){
					if(st[x]==1)	cnt--;
					eg[s].stat=1;
					if(st[x]-1==1)	cnt++;
					break;
				}
				s=eg[s].nxt;
			}
			st[x]--;
		}
		if(t==3){
			scanf("%d%d",&x,&y);
			int s=head[y];
			while(s!=0){
				if(eg[s].to==x){
					if(st[x]==1)	cnt--;
					eg[s].stat=0;
					if(st[x]+1==1)	cnt++;
					break;
				}
				s=eg[s].nxt;
			}
			st[x]++;
		}
/*		for(int i=1;i<=n;i++){
			printf("%d ",st[i]);
		}
		printf("\n");*/
		if(cnt==n)	printf("YES\n");
		else	printf("NO\n");
	}
}
