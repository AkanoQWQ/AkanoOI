#include<bits/stdc++.h>
using namespace std;//O((n+m)q)-->O(logn*n)
int a[100010],b[100010],n,m,q;
int amax[100010][20],amin[100010][20],bmax[100010][20],bmin[100010][20];
int logg[100010];
void getlog(){
	logg[0]=-1;
	for(int i=1;i<=100010;i++){
		logg[i]=logg[i>>1]+1;
	}
	return;
}
int l1,r1,l2,r2;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)	scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)	scanf("%d",&b[i]);
	for(int k=1;k<=q;k++){
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		int mina=2147482635,minb=2147482635,maxa=2147482635,maxb=2147482635,x,y;
		long long tmp1,tmp2,max1=a[l1],max2=b[l2],min1=a[l1],min2=b[l2],f1,f2;
		for(int i=l1+1;i<=r1;i++){
			if(abs(a[i]-0)<abs(maxa-0)&&a[i]>=0)	maxa=a[i];
			if(abs(a[i]-0)<abs(mina-0)&&a[i]<0)	mina=a[i];
//			printf("a:great:%d %d,%d\n",maxa,mina,a[i]);
		}
		tmp1=tmp2=214748264;
		for(int i=l2;i<=r2;i++){
			tmp1=min(tmp1,(long long)mina*b[i]);
			tmp2=min(tmp2,(long long)maxa*b[i]);
		}
		if(tmp1>tmp2)	x=mina;
		else	x=maxa;
		for(int i=l2+1;i<=r2;i++){
			if(abs(b[i]-0)<abs(maxb-0)&&b[i]>=0)	maxb=b[i];
			if(abs(b[i]-0)<abs(minb-0)&&b[i]<0)	minb=b[i];
	//		printf("b:great:%d %d,%d\n",maxb,minb,b[i]);
		}
		tmp1=tmp2=-214748264;
		for(int i=l1;i<=r1;i++){
			tmp1=max(tmp1,(long long)minb*a[i]);
			tmp2=max(tmp2,(long long)maxb*a[i]);
		}
		if(tmp1<tmp2)	y=minb;
		else	y=maxb;
	//	printf("%d %d\n",x,y);
		printf("%lld\n",(long long)x*y);
	}
}
