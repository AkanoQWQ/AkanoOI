#include<bits/stdc++.h>
using namespace std;
int head[2510],mhead[2510],n,dz,dz2;
struct edge{
	int to,nxt;
} eg[20010],mg[20010];
long long val[2510];int m,k;
int vis[2510][2510],route[2510];long long maxn;
void addedge(int f,int t){
	dz++;
	eg[dz].to=t;
	eg[dz].nxt=head[f];
	head[f]=dz;
	return;
}
void addedgepro(int f,int t){
	dz2++;
	mg[dz2].to=t;
	mg[dz2].nxt=mhead[f];
	mhead[f]=dz2;
	return;
}
void dfs(int f,int t,int step){
	if(step==k)	return;
	int s=head[t];
	while(s!=0){
		if(vis[f][eg[s].to]==0&&f!=eg[s].to){
			addedgepro(f,eg[s].to);
			addedgepro(eg[s].to,f);
			vis[f][eg[s].to]=1;
			vis[eg[s].to][f]=1;
			dfs(f,eg[s].to,step+1);
		}
		s=eg[s].nxt;
	}
	return;
}
void dfsp(int pt,int step,long long ans){
	if(step==5&&pt!=1)	return;
	if(step==5){
		maxn=max(maxn,ans);
	}
	int s=mhead[pt];
	while(s!=0){
		if(route[mg[s].to]==0||(mg[s].to==1&&step==4)){
			route[mg[s].to]=1;
			dfsp(mg[s].to,step+1,ans+val[pt]);
			route[mg[s].to]=0;
		}
		s=mg[s].nxt;
	}
	
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++){
		scanf("%lld",&val[i]);
	}
	for(int i=1;i<=m;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		addedge(x,y);addedge(y,x);
	}
	for(int i=1;i<=n;i++){
		dfs(i,i,-1);
	}
	route[1]=1;
	dfsp(1,0,0);
	printf("%lld",maxn);
}
