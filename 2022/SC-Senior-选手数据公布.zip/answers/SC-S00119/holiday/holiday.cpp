#include <cstdio>
#include <cstring>
#include <algorithm>

typedef long long lld;
typedef __int128_t lll;

int buff[1011], pbuff;
void write(lll x){
	if(x < 0) putchar('-'), x = -x;
	if(x == 0) putchar('0');
	while(x){
		buff[++pbuff] = x % 10;
		x /= 10;
	}
	while(pbuff > 0){
		putchar(buff[pbuff] + '0');
		pbuff--;
	}
	return;
}

const int N = 21, M = 10011, inf = 0x3f3f3f3f;
int n, m, k;
int a[N];
//struct Edge{
//	int v, nex;
//}edge[M];
//int head[N], pedge;
//void add
int dis[N][N];

void floyd(){
	for(int t = 1; t <= n; t++)
		for(int i = 1; i <= n; i++)
			for(int j = 1; j <= n; j++)
				if(dis[i][j] > dis[i][t] + dis[t][j])
					dis[i][j] = dis[i][t] + dis[t][j];
}

lll f[N][7][N][N][N][N];
bool vis[N][7][N][N][N][N];
lll dp(int u, int t, int a1, int a2, int a3, int a4){
	lll& fr = f[u][t][a1][a2][a3][a4];
	if(vis[u][t][a1][a2][a3][a4]) return fr;
	vis[u][t][a1][a2][a3][a4] = true;
	if(t == 4){
		if(dis[1][u] > k + 1) fr = -inf;
		else fr = 0;
		return fr;
	}
	fr = -inf;
	for(int v = 2; v <= n; v++){
		if(u == v) continue;
		if(v == a1 || v == a2 || v == a3 || v == a4) continue;
		if(dis[u][v] <= k + 1){
			lll tmp = 0;
			if(t + 1 == 1) tmp = dp(v, t + 1, v, 0, 0, 0);//, printf("[%d] ", v), write(tmp), putchar(10);
			else if(t + 1 == 2) tmp = dp(v, t + 1, a1, v, 0, 0);//, printf("[%d] ", v),write(tmp), putchar(10);
			else if(t + 1 == 3) tmp = dp(v, t + 1, a1, a2, v, 0);//, printf("[%d] ", v),write(tmp), putchar(10);
			else if(t + 1 == 4) tmp = dp(v, t + 1, a1, a2, a3, v);//, printf("[%d] ", v),write(tmp), putchar(10);
			if(tmp == -inf) continue;
//			printf("(%d, %d, %d, %d, %d, %d) --> [%d]<+%d>", u, t, a1, a2, a3, a4, v, a[v]);
//			write(tmp); putchar(10);
			fr = std::max(fr, tmp + a[v]);
		}
	}
	return fr;
}

int main(){
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	std::memset(dis, 0x3f, sizeof dis);
	scanf("%d%d%d", &n, &m, &k);
	for(int i = 2; i <= n; i++)
		scanf("%d", a + i);
	for(int i = 1; i <= m; i++){
		int x, y; scanf("%d%d", &x, &y);
		dis[x][y] = dis[y][x] = 1;
	}
	for(int i = 1; i <= n; i++) dis[i][i] = 0;
	floyd();
//	for(int i = 1; i <= n; i++)
//		for(int j = 1; j <= n; j++)
//			printf("%d%c", dis[i][j], " \n"[j == n]);
//	write(-11); putchar(10);
	write(dp(1, 0, 0, 0, 0, 0)); putchar(10);
//	write(dp(7, 1, 7, 0, 0, 0)); putchar(10);
//	write(dp(4, 2, 7, 4, 0, 0)); putchar(10);
//	write(dp(3, 3, 7, 4, 3, 0)); putchar(10);
	
//	for(int i = 1; i <= n; i++)
//		for(int t = 0; t <= 4; t++)
//			printf("f(%d, %d) = ", i, t), write(dp(i, t, 0)), putchar(10);
	fclose(stdin), fclose(stdout);
	return 0;
}
