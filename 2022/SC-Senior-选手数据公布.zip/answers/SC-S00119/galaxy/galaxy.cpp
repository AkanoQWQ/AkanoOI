#include <cstdio>
#include <cstring>
#include <algorithm>

const int N = 1011;
int n, m, q;
int e[N][N]; // 1: ��ʹ��  0: ������ -1: �Ѵݻ� 

//bool can[N], vis[N];
//int cnt[N];
//bool flag;
//void dfs(int u, int dep){
//	if(dep > n){
//		flag = true;
//		return;
//	}
//	if(flag) return;
//	for(int v = 1; v <= n; v++){
//		if(e[u][v] != 1) continue;
//		dfs(v, dep + 1);
//	}
//	return;
//}
bool check(){
	for(int i = 1; i <= n; i++){
		int cnt = 0;
		for(int j = 1; j <= n; j++)
			if(e[i][j] == 1){
				cnt++;
				if(cnt > 1) return false;
			}
		if(cnt == 0) return false;
	}
//	for(int i = 1; i <= n; i++){
//		flag = false;
//		dfs(i, 1);
//		if(!flag) return false;
//	}
	return true;
}

int main(){
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= m; i++){
		int u, v; scanf("%d%d", &u, &v);
		e[u][v] = e[v][u] = 1;
	}
	scanf("%d", &q);
	for(int i = 1; i <= q; i++){
		int t; scanf("%d", &t);
		if(t == 1){
			int u, v; scanf("%d%d", &u, &v);
			e[u][v] = -1;
		}else if(t == 2){
			int u; scanf("%d", &u);
			for(int v = 1; v <= n; v++){
				if(e[v][u] == 1) e[v][u] = -1;
			}
		}else if(t == 3){
			int u, v; scanf("%d%d", &u, &v);
			e[u][v] = 1;
		}else if(t == 4){
			int u; scanf("%d", &u);
			for(int v = 1; v <= n; v++){
				if(e[v][u] == -1) e[v][u] = 1;
			}
		}
		printf(check() ? "YES\n" : "NO\n");
	}
	fclose(stdin), fclose(stdout);
	return 0;
}
