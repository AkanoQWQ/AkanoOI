#include <cstdio>
#include <cstring>
#include <algorithm>

typedef long long lld;

const int N = 100011;
int n, m, q;
lld a[N], b[N];
lld st_a[N][25];
lld st_b[N][25];
lld st_a_min[N][25];
lld st_b_max[N][25];
int lg[N];

lld Amax(int l, int r){
	int k = lg[r - l + 1];
	return std::max(st_a[l][k], st_a[r - (1 << k) + 1][k]);
}
lld Amin(int l, int r){
	int k = lg[r - l + 1];
	return std::min(st_a_min[l][k], st_a_min[r - (1 << k) + 1][k]);
}
lld Bmin(int l, int r){
	int k = lg[r - l + 1];
	return std::min(st_b[l][k], st_b[r - (1 << k) + 1][k]);
}
lld Bmax(int l, int r){
	int k = lg[r - l + 1];
	return std::max(st_b_max[l][k], st_b_max[r - (1 << k) + 1][k]);
}

int main(){
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &q);
	for(int i = 1; i <= n; i++) scanf("%lld", a + i);
	for(int i = 1; i <= m; i++) scanf("%lld", b + i);
	for(int i = 1; i <= n; i++) st_a[i][0] = a[i];
	for(int i = 1; i <= m; i++) st_b[i][0] = b[i];
	for(int j = 1; j <= 20; j++)
		for(int i = 1; i + (1 << j) - 1 <= n; i++)
			st_a[i][j] = std::max(st_a[i][j - 1], st_a[i + (1 << (j - 1))][j - 1]);
	for(int j = 1; j <= 20; j++)
		for(int i = 1; i + (1 << j) - 1 <= n; i++)
			st_a_min[i][j] = std::min(st_a_min[i][j - 1], st_a_min[i + (1 << (j - 1))][j - 1]);
	for(int j = 1; j <= 20; j++)
		for(int i = 1; i + (1 << j) - 1 <= m; i++)
			st_b[i][j] = std::min(st_b[i][j - 1], st_b[i + (1 << (j - 1))][j - 1]);
	for(int j = 1; j <= 20; j++)
		for(int i = 1; i + (1 << j) - 1 <= m; i++)
			st_b_max[i][j] = std::max(st_b_max[i][j - 1], st_b_max[i + (1 << (j - 1))][j - 1]);
//	for(int i = 1; i <= n; i++)
//		for(int j = 0; j <= 20; j++)
//			printf("%lld%c", st_b[i][j], " \n"[j == 20]);
	lg[0] = lg[1] = 0;
	for(int i = 2; i <= 100000; i++)
		lg[i] = lg[i >> 1] + 1;
	for(int i = 1; i <= q; i++){
		int l1, r1, l2, r2; scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
		if(l1 == r1 || l2 == r2){
			if(l1 == r1){
				lld x = a[l1], y;
				if(x > 0) y = Bmin(l2, r2);
				else y = Bmax(l2, r2);
				printf("%lld\n", x * y);
			}else if(l2 == r2){
				lld x, y = b[l2];
				if(y > 0) x = Amax(l1, r1);
				else x = Amin(l1, r1);
				printf("%lld\n", x * y);
			}
		}else{
			lld x = Amax(l1, r1), y = Bmin(l2, r2);
	//		printf("x = %lld y = %lld\n", x, y);
			printf("%lld\n", x * y);
		}
	}
	fclose(stdin), fclose(stdout);
	return 0;
}
