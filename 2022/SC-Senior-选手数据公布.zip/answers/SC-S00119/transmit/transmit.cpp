#include <cstdio>
#include <cstring>
#include <algorithm>

typedef long long lld;

const int N = 200011;
int n, Q, k;
lld val[N];
struct Edge{
	int v, nex;
}edge[N * 2];
int head[N], pedge;
void add(int u, int v){
	edge[++pedge] = (Edge){v, head[u]};
	head[u] = pedge;
}

int fa[N], dep[N];
void dfs(int u, int fath){
	fa[u] = fath;
	dep[u] = dep[fath] + 1;
	for(int i = head[u]; i; i = edge[i].nex){
		if(edge[i].v == fath) continue;
		dfs(edge[i].v, u);
	}
}

int lca(int u, int v, int& len){
	len = 0;
	while(u != v){
		if(dep[u] < dep[v]) v = fa[v], len++;
		else u = fa[u], len++;
	}
	return u;
}

int link[N], len;
lld f[N];
int que[N], l, r;
lld dp(){
	std::memset(f, 0, sizeof f);
	std::memset(que, 0, sizeof que);
	l = 1, r = 0;
//	f[0] = 0;
	f[1] = val[link[1]];
	que[++r] = 1;
	for(int i = 2; i <= len; i++){
		f[i] = 0x3f3f3f3f3f3f3f3f;
		for(; l <= r && que[l] < std::max(1, i - k); l++);
		f[i] = f[que[l]] + val[link[i]];
//		for(int j = std::max(1, i - k); j < i; j++){
//			f[i] = std::min(f[i], f[j] + val[link[i]]);
//		}
		for(; r >= l && f[que[r]] > f[i]; r--);
		que[++r] = i;
	}
//	printf("f: "); for(int i = 1; i <= len; i++) printf("%lld%c", f[i], " \n"[i == len]);
	return f[len];
}

int main(){
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	scanf("%d%d%d", &n, &Q, &k);
	for(int i = 1; i <= n; i++)
		scanf("%lld", val + i);
	for(int i = 1; i < n; i++){
		int u, v; scanf("%d%d", &u, &v);
		add(u, v), add(v, u);
	}
	dfs(1, 1);
	for(int i = 1; i <= Q; i++){
		int u, v; scanf("%d%d", &u, &v);
		int L = lca(u, v, len);
		
		std::memset(link, 0, sizeof link);
		int x = u, p = 1;
		len++;
		for(; x != L; x = fa[x], p++) link[p] = x; link[p] = L; for(x = v, p = len; x != L; x = fa[x], p--) link[p] = x;
//		for(int j = 1; j <= len; j++) printf("%d%c", link[j], " \n"[j == len]);
		
		printf("%lld\n", dp());
	}
	fclose(stdin), fclose(stdout);
	return 0;
}
