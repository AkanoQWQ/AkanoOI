#include<bits/stdc++.h>
using namespace std;
long long read(){
	long long x=0,f=1;
	char c=getchar();
	while(c>'9'||c<'0'){
		if(c=='-') f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		x=x*10+c-'0';
		c=getchar();
	}
	return x*f;
}
void write(long long x){
	if(x<0) putchar('-'),x=-x;
	if(x>9) write(x/10);
	putchar(x%10+'0');
	return ;
}
long long n,m,k,score[2505],ans=-1;
vector<int> e[2505];
bool vis[2505];
void dfs1(int st,int dep,long long sumvalue){
	vis[st]=1;
	if(dep==4){
		bool flag1=0;
		for(unsigned int i=0;i<e[st].size();i++){
			if(e[st][i]==1){
				flag1=1;
				break;
			}
		}
		if(flag1==1){
			ans=max(ans,sumvalue);
		}
		return ;
	}
	for(unsigned int i=0;i<e[st].size();i++){
		if(vis[e[st][i]]==0){
			dfs1(e[st][i],dep+1,sumvalue+score[e[st][i]]);	
		}
	}
	return ;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read();
	m=read();
	k=read();
	for(int i=2;i<=n;i++){
		score[i]=read();
	}
	long long ca,cb;
	for(int i=1;i<=m;i++){
		ca=read();
		cb=read();
		e[ca].push_back(cb);
		e[cb].push_back(ca);
	}
	if(k==0){
		dfs1(1,0,0);
		write(ans);
	}
	return 0;
}
