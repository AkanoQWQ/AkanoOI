#include<bits/stdc++.h>
using namespace std;
int read(){
	int x=0,f=1;
	char c=getchar();
	while(c>'9'||c<'0'){
		if(c=='-') f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		x=x*10+c-'0';
		c=getchar();
	}
	return x*f;
}
void write(long long x){
	if(x<0) putchar('-'),x=-x;
	if(x>9) write(x/10);
	putchar(x%10+'0');
	return ;
}
int m,n,q,a[100005],b[100005];
struct segtree1{
	int lc,rc,mmax;
}node1[500005];
void pushup1(int st){
	node1[st].mmax=max(node1[st*2].mmax,node1[st*2+1].mmax);
	return ;
}
void build1(int l,int r,int st){
	node1[st].lc=l;
	node1[st].rc=r;
	if(l==r){
		node1[st].mmax=a[l];
		return ;
	}
	int mid=(l+r)/2;
	build1(l,mid,st*2);
	build1(mid+1,r,st*2+1);
	pushup1(st);
	return ;
}
int getmax(int l,int r,int st){
	if(node1[st].lc>r||node1[st].rc<l) return -1000000009;
	if(node1[st].lc>=l&&node1[st].rc<=r){
		return node1[st].mmax;
	}
	return max(getmax(l,r,st*2),getmax(l,r,st*2+1));
}
struct segtree2{
	int lc,rc,mmin;
}node2[500005];
void pushup2(int st){
	node2[st].mmin=min(node2[st*2].mmin,node2[st*2+1].mmin);
	return ;
}
void build2(int l,int r,int st){
	node2[st].lc=l;
	node2[st].rc=r;
	if(l==r){
		node2[st].mmin=b[l];
		return ;
	}
	int mid=(l+r)/2;
	build2(l,mid,st*2);
	build2(mid+1,r,st*2+1);
	pushup2(st);
	return ;
}
int getmin(int l,int r,int st){
	if(node2[st].lc>r||node2[st].rc<l) return 1000000009;
	if(node2[st].lc>=l&&node2[st].rc<=r){
		return node2[st].mmin;
	}
	return min(getmin(l,r,st*2),getmin(l,r,st*2+1));
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();
	m=read();
	q=read();
	for(int i=1;i<=n;i++){
		a[i]=read();
	}
	for(int i=1;i<=m;i++){
		b[i]=read();
	}
	int l1,r1,l2,r2;
	long long ans,minone;
	if(n<=200&&m<=200&&q<=200){
		while(q--){
			l1=read();
			r1=read();
			l2=read();
			r2=read();
			ans=-1000000000000000009;
			for(int i=l1;i<=r1;i++){
				minone=1000000000000000009;
				for(int j=l2;j<=r2;j++){
					minone=min(minone,(long long)a[i]*b[j]);
				}
				ans=max(ans,minone);
			}
			write(ans);
			putchar('\n');
		}
	}
	else{
		build1(1,n,1);
		build2(1,n,1);
		while(q--){
			l1=read();
			r1=read();
			l2=read();
			r2=read();
			ans=(long long)getmax(l1,r1,1)*getmin(l2,r2,1);
			write(ans);
			putchar('\n');
		}
	}
	return 0;
}
