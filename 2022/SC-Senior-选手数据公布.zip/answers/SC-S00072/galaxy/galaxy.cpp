#include<bits/stdc++.h>
using namespace std;
int read(){
	int x=0,f=1;
	char c=getchar();
	while(c>'9'||c<'0'){
		if(c=='-') f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		x=x*10+c-'0';
		c=getchar();
	}
	return x*f;
}
void write(int x){
	if(x<0) putchar('-'),x=-x;
	if(x>9) write(x/10);
	putchar(x%10+'0');
	return ;
}
struct edge{
	int from;
	bool des;
};
vector<edge> e[500005];
int n,m,q,t,u,v,out[500005];
bool findd=0,vis[500005];
void dfs(int st){
	if(findd==1) return ;
	vis[st]=1;
	for(unsigned int i=0;i<e[st].size();i++){
		if(vis[e[st][i].from]==0){
			dfs(e[st][i].from);
		}
		if(vis[e[st][i].from]==1){
			findd=1;
			return ;
		}
	}
	vis[st]=0;
	return ;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read();
	m=read();
	int ca,cb;
	for(int i=1;i<=m;i++){
		ca=read();
		cb=read();
		edge tt;
		tt.from=ca;
		tt.des=0;
		out[ca]++;
		e[cb].push_back(tt);//���෴�ı� 
	}
	q=read();
	while(q--){
		t=read();
		if(t==1){
			u=read();
			v=read();
			out[u]--;
			for(unsigned int i=0;i<e[v].size();i++){
				if(e[v][i].from==u){
					e[v][i].des=1;
					break;
				}
			}
		}
		else if(t==2){
			u=read();
			for(unsigned int i=0;i<e[u].size();i++){
				if(e[u][i].des==0){
					e[u][i].des=1;
					out[e[u][i].from]--;
				}
			}
		}
		else if(t==3){
			u=read();
			v=read();
			out[u]++;
			for(unsigned int i=0;i<e[v].size();i++){
				if(e[v][i].from==u){
					e[v][i].des=0;
					break;
				}
			}
		}
		else if(t==4){
			u=read();
			for(unsigned int i=0;i<e[u].size();i++){
				if(e[u][i].des==1){
					e[u][i].des=0;
					out[e[u][i].from]++;
				}
			}
		}
//		for(int i=1;i<=n;i++){
//			cout<<"out["<<i<<"] = "<<out[i]<<endl;
//			cout<<"from : ";
//			for(int j=0;j<e[i].size();j++){
//				if(e[i][j].des==0){
//					cout<<e[i][j].from<<" ";
//				}
//			}
//			cout<<endl;
//		}
//		cout<<endl;
		bool flag1=0;
		for(int i=1;i<=n;i++){
			if(out[i]!=1){
				flag1=1;
				puts("NO");
				break;
			}
		}
		if(flag1==0){
			for(int i=1;i<=n;i++) vis[i]=0;
			bool pd=0;
			for(int i=1;i<=n;i++){
				bool flag2=0;
				for(unsigned int j=0;j<e[i].size();j++){
					if(e[i][j].des==0){
						flag2=1;
						break;
					}
				}
				if(flag2==0) continue;
				findd=0;
				if(vis[i]==0){
					dfs(i);
					if(findd==0){
						pd=1;
						break;
					}
				}
			}
			if(pd==1){
				puts("NO");
			}
			else{
				puts("YES");
			}
		}
	}
	return 0;
}
