#include<bits/stdc++.h>
using namespace std;

const long long N=200005;
long long n,q,k;
long long v[N];
struct Edge{
	long long to,nxt;
}edge[N<<1];
long long cnt=1,h[N];
long long ans;
bool vis[N];

void add(int u,int v)
{
	edge[cnt].to=v;
	edge[cnt].nxt=h[u];
	h[u]=cnt++;
}

void dfs(int now,int turn,long long sum,int ed)
{
	vis[now]=1;
	if(sum>ans)	return ;
	if(turn>k)	return ;
	if(now==ed)
	{
		if(sum+v[ed]<ans)	ans=sum+v[ed];
		vis[ed]=0;
		return ;
	}
	for(int j=h[now];j;j=edge[j].nxt)
	{
		if(vis[edge[j].to]==0)
		{
			dfs(edge[j].to,0,sum+v[edge[j].to],ed);
			dfs(edge[j].to,turn+1,sum,ed);			
		}
	}
	vis[now]=0;
}

int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%lld%lld%lld",&n,&q,&k);
	for(int i=1;i<=n;i++)
		scanf("%lld",&v[i]);
	for(int i=1;i<n;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
		add(v,u);
	}
	for(int i=1;i<=q;i++)
	{
		memset(vis,0,sizeof vis);
		ans=0x3f3f3f3f3f3f3f3f;
		int st,ed;
		scanf("%d%d",&st,&ed);
		dfs(st,0,v[st],ed);
		printf("%lld\n",ans);
	}
	return 0;
} 
