#include<bits/stdc++.h>
using namespace std;

const long long M=10005;
const long long N=3000;
long long n,m,k;
long long a[N];
bool vis[N];
struct Edge{
	long long nxt,to;
}edge[M<<1];
long long cnt=1;
long long h[N];
int ans=0;
long long dis[N];

void add(int u,int v)
{
	edge[cnt].to=v;
	edge[cnt].nxt=h[u];
	h[u]=cnt++;
}

void dfs(int now,int turn,int sum,int num)
{
	if(turn>k)	return ;
	if(num==4)
	{
		if(now==1)
			if(sum>ans)	ans=sum;
		return ;
	}
	for(int j=h[now];j;j=edge[j].nxt)
	{
		if(vis[edge[j].to]==0)
		{
			vis[edge[j].to]=1;
			dfs(edge[j].to,0,sum+a[now],num+1);
			vis[edge[j].to]=0;
			dfs(edge[j].to,turn+1,sum,num);
			
		}
	}
}

int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	for(int i=2;i<=n;i++)
		scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
		add(v,u);
	}
	dfs(1,0,0,0);
	printf("%d",ans);
	return 0;
} 
