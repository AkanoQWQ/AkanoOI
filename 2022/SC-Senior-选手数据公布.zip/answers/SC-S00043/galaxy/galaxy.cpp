#include<bits/stdc++.h>
using namespace std;

const long long N=500005;
long long n,m,q;
struct Edge{
	long long to,nxt;
	long long w=0;
}edge[N<<1];
long long cnt=1,h[N];
bool flg1,flg2;
bool vis[N];

void add(int u,int v,int w)
{
	edge[cnt].to=v;
	edge[cnt].w=w;
	edge[cnt].nxt=h[u];
	h[u]=cnt++;
}

bool f()
{
	int num=0;
	for(int i=1;i<=n;i++)
	{
		int cnt=0;
		for(int j=h[i];j;j=edge[j].nxt)
		{
			if(vis[edge[j].to]==1)	continue;
			if(edge[j].w==1) 
			{
				cnt++;
				num++;
			}
			vis[edge[j].to]=1;
			if(cnt>1&&num!=n)
			{
				flg1=0; 
			}
			if(vis[edge[j].to]==1&&vis[i]==1)
			{
				flg2=1;
			}
		}
	}
	if(flg1==0||flg2==0)	return 0;
	return 1;
}

void f1(int u)
{
	for(int i=1;i<=n;i++)
	{
		if(i==u)	continue;
		for(int j=h[u];j;j=edge[j].nxt)
		{
			if(edge[j].to==u)
				edge[j].w=0;
		}
	}
}

void f2(int u)
{
	for(int i=1;i<=n;i++)
	{
		if(i==u)	continue;
		for(int j=h[u];j;j=edge[j].nxt)
		{
			if(edge[j].to==u)
				edge[j].w=1;
		}
	}
}

int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(int i=1;i<=m;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v,1);
		add(v,u,1);
	}
	scanf("%lld",&q);
	for(int i=1;i<=q;i++)
	{
		flg1=flg2=1;
		int t;
		scanf("%d",&t);
		if(t==1)
		{
			int u,v;
			scanf("%d%d",&u,&v);
			for(int j=h[u];j;j=edge[j].nxt)
			{
				if(edge[j].to==v)
				{
					edge[j].w=0;
					break;
				}
			}
		}
		if(t==2)
		{
			int u;
			scanf("%d",&u);
			f1(u);
		}
		if(t==3)
		{
			int u,v;
			scanf("%d%d",&u,&v);
			for(int j=h[u];j;j=edge[j].nxt)
			{
				if(edge[j].to==v)
				{
					edge[j].w=1;
					break;
				}
			}
		}
		if(t==4)
		{
			int u;
			scanf("%d",&u);
			f2(u);
		}
		
		if(f())	puts("YES");
		else	puts("NO"); 
	}
	return 0;
} 
