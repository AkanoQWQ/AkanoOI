#include<bits/stdc++.h>
using namespace std;

const long long N=10005;
long long n,m,q;
long long a[N],b[N];
long long c[N][N];
long long l1,l2,r1,r2;
long long ans;

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	for(int i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++)
		scanf("%lld",&b[i]);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			c[i][j]=a[i]*b[j];
	for(int i=1;i<=q;i++)
	{
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		ans=-0x3f3f3f3f3f3f3f3f;
		for(int i=l1;i<=r1;i++)
		{
			long long minn=0x3f3f3f3f3f3f3f3f;
			for(int j=l2;j<=r2;j++)
				minn=min(minn,c[i][j]);
			ans=max(ans,minn);
		}
		printf("%lld\n",ans);
	}
	return 0;
} 
