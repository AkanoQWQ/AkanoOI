#include <bits/stdc++.h>
using namespace std;
#define LL long long

const int N = 1e5 + 10;
int n, m, q;
int a[N], b[N];

struct tree{
	int l, r, zx, zd, fx, fd, sf;
	
	tree() {l = r = zx = zd = fx = fd = sf = 0;}
	
	tree operator + (const tree &oth) const
	{
		tree ans;
		ans.l = l, ans.r = oth.r;
		
		ans.fx = min(fx, oth.fx);
	
		if(fd != 0 && oth.fd == 0)	ans.fd = fd; 
		else if(fd == 0 && oth.fd != 0) ans.fd = oth.fd; 
		else ans.fd = max(fd, oth.fd);
		
		if(zx != 0 && oth.zx == 0)	ans.zx = zx; 
		else if(zx == 0 && oth.zx != 0) ans.zx = oth.zx; 
		else ans.zx = min(zx, oth.zx);
		
		ans.zd = max(zd, oth.zd);
		
		ans.sf |= (sf | oth.sf);
		return ans;
	}
}t1[N << 2], t2[N << 2];

void pushup(int p, tree *t)
{
	t[p] = t[p << 1] + t[p << 1 | 1];
}

void build(int p, int l, int r, tree *t, int *a)
{
	t[p].l = l, t[p].r = r;
	if(l == r) 
	{
		if(a[l] < 0) t[p].fx = t[p].fd = a[l];
		if(a[l] > 0) t[p].zx = t[p].zd = a[l];
		if(a[l] == 0) t[p].sf = 1;
		return ;
	}
	int mid = l + r >> 1;
	build(p << 1, l, mid, t, a);
	build(p << 1 | 1, mid + 1, r, t, a);
	pushup(p, t);
}

tree query(int p, int L, int R, tree *t)
{
	int l = t[p].l, r = t[p].r;
	if(L <= l && r <= R) return t[p];
	int mid = l + r >> 1;
	tree res;
	if(L <= mid) res = res + query(p << 1, L, R, t);
	if(mid < R) res = res + query(p << 1 | 1, L, R, t);
	return res;
}

int main()
{
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &q);
	
	for(int i = 1; i <= n; i ++) scanf("%d", &a[i]);
	for(int i = 1; i <= m; i ++) scanf("%d", &b[i]);
	
	build(1, 1, n, t1, a);
	build(1, 1, m, t2, b);
	
	for(int i = 1; i <= q; i ++)
	{
		int l1, l2, r1, r2;
		scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
		tree ans1 = query(1, l1, r1, t1), ans2 = query(1, l2, r2, t2);
//		printf("%d %d %d %d %d %d %d %d\n", ans1.fx, ans1.fd, ans1.zx, ans1.zd, ans2.fx, ans2.fd, ans2.zx, ans2.zd);
		LL ans = LLONG_MIN;
		if(ans1.zd > 0)
		{
			if(ans2.fx < 0) ans = max(ans, (LL)ans1.zx * ans2.fx);
			else if(ans2.zd > 0) ans = max(ans, (LL)ans1.zd * ans2.zx);
			
			if(ans2.sf) ans = min(ans, 0ll);
		}
		if(ans1.fx < 0)
		{
			if(ans2.zd > 0) ans = max(ans, (LL)ans1.fd * ans2.zd);
			else if(ans2.fx < 0) ans = max(ans, (LL)ans1.fx * ans2.fd);
			
			if(ans2.sf) ans = min(ans, 0ll);
		}
		if(ans1.sf) ans = max(ans, 0ll);
		
		printf("%lld\n", ans);
	}
	return 0;
}
