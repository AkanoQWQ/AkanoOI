#include <bits/stdc++.h>
using namespace std;
#define LL long long

const int N = 2510, M = 2e4 + 10;
int n, m, k;
LL w[N];
int h[N], ne[N], e[N], idx;
int q[N], hh, tt, dis[N];
LL f[N], g[N], ans;
int sg1[N], sg2[N];

vector<int> vec[N];

void add(int a, int b)
{
	e[idx] = b, ne[idx] = h[a], h[a] = idx ++;
}

void bfs(int s)
{
	q[hh = tt = 1] = s;
	memset(dis, -1, sizeof dis);
	while(hh <= tt)
	{
		int u = q[hh ++];
		for(int i = h[u]; ~i; i = ne[i])
		{
			int j = e[i];
			if(dis[j] != -1 || j == s) continue;
			dis[j] = dis[u] + 1;
			if(dis[j] <= k) vec[s].push_back(j), q[++ tt] = j;
		}
	}
}

int main()
{
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	memset(h, -1, sizeof h);
	scanf("%d%d%d", &n, &m, &k);
	for(int i = 2; i <= n; i ++)
		scanf("%lld", &w[i]);
	
	for(int i = 1; i <= m; i ++)
	{
		int a, b;
		scanf("%d%d", &a, &b);
		add(a, b), add(b, a);
	}
	
	for(int i = 1; i <= n; i ++)
		bfs(i);
	
	int len = vec[1].size();
	for(int t = 0; t < len; t ++)
	{
		int i = vec[1][t];
		int lenn = vec[i].size();
		for(int x = 0; x < lenn; x ++)
		{
			int j = vec[i][x];
			if(i == j || j == 1) continue;
			if(w[i] + w[j] > f[j]) g[j] = f[j], sg2[j] = sg1[j], f[j] = w[i] + w[j], sg1[j] = i;
			else if(w[i] + w[j] > g[j]) g[j] = w[i] + w[j], sg2[j] = i;	
		}
	}
	
//	for(int i = 1; i <= n; i ++)
//		printf("%lld %d %lld %d\n", f[i], sg1[i], g[i], sg2[i]);
	
	for(int i = 2; i <= n; i ++)
	{
		int lenn = vec[i].size();
		for(int x = 0; x < lenn; x ++)
		{
			int j = vec[i][x];
			if(i == j) continue;
			int a = sg1[i], b = sg2[i], c = sg1[j], d = sg2[j];
//			printf("%d\n%d %lld %d %lld\n%d\n%d %lld %d %lld\n", i, a, f[i], b, g[i], j, c, f[j], d, g[j]);
			if(!f[i] || !f[j]) continue;
			if(c != i && a != j && c != a) ans = max(ans, f[i] + f[j]);
			else
			{
				if(!b && !d) continue;
				if(!b)
				{
					if(a != j && a != d && d != i) ans = max(ans, f[i] + g[j]);
				}
				else if(!d)
				{
					if(b != j && b != c && c != i) ans = max(ans, g[i] + f[j]);
				}
				else
				{
					if(d != i && d != a && a != j) ans = max(ans, f[i] + g[j]);
					if(c != i && c != b && b != j) ans = max(ans, g[i] + f[j]);
					if(d != i && d != b && b != j) ans = max(ans, g[i] + g[j]);
				}
			}
//			printf("%lld\n\n", ans);
		}
	}
		
	
	printf("%lld", ans);
	return 0;
}
