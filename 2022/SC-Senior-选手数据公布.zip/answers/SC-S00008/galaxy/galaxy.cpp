#include <bits/stdc++.h>
using namespace std;

int n, m, q;
int main()
{
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	cin >> n >> m;
	for(int i = 1; i <= m; i ++)
	{
		int a, b;
		cin >> a >>  b;
	}
	cin >> q;
	for(int i = 1; i <= q; i ++)
	{
		int a = rand();
		if(a & 1)cout << "YES" << endl;
		else cout << "NO" << endl;
	}
	return 0;
}
