#include<cstdio>
#include<bits/stdc++.h>
using namespace std;
int n,m,u,v,min_a=2,max_a=-1;
int p,q;
int hole[1000001][3];
int a[1000001];
int main(){
	freopen("galaxy.in",r,stdin);
	freopen("galaxy.out",w,stdout);
	cin>>n>>m;
	p=1;
	for(int i=1;i<=m;i++){
		cin>>u>>v;
		hole[p][0]=u;
		hole[p][1]=v;
		hole[p][2]=1;
		p++;
	}
	cin>>q;
	for(int i=1;i<=q;i++){
		int type=0;
		min_a=2;
		max_a=-1;
		cin>>type;
		if(type==1){
			cin>>u>>v;
			for(int j=1;j<=p;j++){
				if(hole[j][0]==u && hole[j][1]==v){
					hole[j][2]=0;
					break;
				}
			}
		}
		if(type==2){
			cin>>v;
			for(int j=1;j<=p;j++){
				if(hole[j][1]==v){
					hole[j][2]=0;
				}
			}
		}
		if(type==3){
			cin>>u>>v;
			for(int j=1;j<=p;j++){
				if(hole[j][0]==u && hole[j][1]==v){
					hole[j][2]=1;
					break;
				}
			}
		}
		if(type==4){
			cin>>v;
			for(int j=1;j<=p;j++){
				if(hole[j][1]==v){
					hole[j][2]=1;
				}
			}
		}
		for(int i=1;i<=p;i++){
			if(hole[i][2]==1){
				a[hole[i][0]]++;
			}
		}
		for(int i=1;i<=n;i++){
			min_a=min(min_a,a[i]);
			max_a=max(max_a,a[i]);
		}
		if(min_a==1 && max_a==1){
			cout<<"YES";
		}
		else{
			cout<<"NO";
		}
		for(int i=1;i<=n;i++){
			a[i]=0;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
