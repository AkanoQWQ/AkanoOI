#include<cstdio>
#include<bits/stdc++.h>
using namespace std;
int n,m,q;
int A[100001],B[100001];
int C[10001][10001];
int l1,r1,l2,r2;
int main(){
	freopen("game.in",r,stdin);
	freopen("game.out",w,stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++){
		cin>>A[i];
	}
	for(int i=1;i<=m;i++){
		cin>>B[i];
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			C[i][j]=A[i]*B[j];
		}
	}
	for(int i=1;i<=q;i++){
		cin>>l1>>r1>>l2>>r2;
		int ans=1e9,f_ans=-1e9;
		for(int i=l1;i<=r1;i++){
			ans=1e9;
			for(int j=l2;j<=r2;j++){
				ans=min(ans,C[i][j]);
			}
			f_ans=max(f_ans,ans);
		}
		cout<<f_ans;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
