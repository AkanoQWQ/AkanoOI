#include<bits/stdc++.h>
using namespace std;

#define rep(i,a,b) for(int i=(a),i##end=(b);i<=i##end;++i)
#define per(i,a,b) for(int i=(a),i##end=(b);i>=i##end;--i)

typedef long long ll;
typedef vector<int>vi;

template<class T>void chkmin(T&x,T y){if(y<x)x=y;}
template<class T>void chkmax(T&x,T y){if(x<y)x=y;}

#define nc getchar
#define pc putchar
int read(){
  int x=0;
  char c=nc();
  while(c<48)c=nc();
  while(c>47)x=x*10+(c^48),c=nc();
  return x;
}

const int maxn=5e5+10;
int n,m,q;

struct edge{
  int u,v;
}iG[maxn];
struct Querys{
  int op,u,v;
}Q[maxn];

bool hav[maxn];
int deg[maxn];
set<int>in[maxn];
vector<int>vec[maxn];

void solve(){
  n=read(),m=read();
  rep(i,1,m){
    int u=read(),v=read();
    iG[i]={u,v};
  }
  q=read();
  rep(i,1,q){
    Q[i].op=read(),Q[i].u=read();
    if(Q[i].op==1||Q[i].op==3)Q[i].v=read();
  }
  int cnt1=0;
  typedef pair<int,int>pii;
  map<pii,int>mp;
  rep(i,1,m){
    int u=iG[i].u,v=iG[i].v;
    in[v].insert(i);
    vec[v].push_back(i);
    mp[{u,v}]=i;
    hav[i]=1;
    deg[u]++;
  }
  rep(i,1,n)cnt1+=deg[i]==1;
  rep(_,1,q){
    auto e=Q[_];
    if(e.op==1){
      int id=mp[{e.u,e.v}];
      hav[id]=0;
      cnt1-=deg[e.u]--==1;
      cnt1+=deg[e.u]==1;
      in[e.v].erase(id);
    }else if(e.op==3){
      int id=mp[{e.u,e.v}];
      hav[id]=1;
      cnt1-=deg[e.u]++==1;
      cnt1+=deg[e.u]==1;
      in[e.v].insert(id);
    }else if(e.op==2){
      for(int id:in[e.u]){
        int v=iG[id].u;
        hav[id]=0;
        cnt1-=deg[v]--==1;
        cnt1+=deg[v]==1;
      }
      in[e.u].clear();
    }else{
      for(int id:vec[e.u]){
        if(!hav[id]){
          hav[id]=1;
          cnt1-=deg[iG[id].u]++==1;
          cnt1+=deg[iG[id].u]==1;
          in[e.u].insert(id);
        }
      }
    }
    puts(cnt1==n?"YES":"NO");
  }
}

int main(){
  freopen("galaxy.in","r",stdin);
  freopen("galaxy.out","w",stdout);
  solve();
  return 0;
}

