#include<bits/stdc++.h>
using namespace std;

#define rep(i,a,b) for(int i=(a),i##end=(b);i<=i##end;++i)
#define per(i,a,b) for(int i=(a),i##end=(b);i>=i##end;--i)

typedef long long ll;
typedef vector<int>vi;
typedef pair<int,int>pii;

template<class T>void chkmin(T&x,T y){if(y<x)x=y;}
template<class T>void chkmax(T&x,T y){if(x<y)x=y;}

#define nc getchar
#define pc putchar
int read(){
  int x=0;
  char c=nc();
  while(c<48)c=nc();
  while(c>47)x=x*10+(c^48),c=nc();
  return x;
}
void write(ll x){
  if(!x){
    pc('0');return;
  }
  if(x<0){
    pc('-'),x=-x;
  }
  static char st[40];
  int top=0;
  while(x)st[++top]=x%10|48,x/=10;
  while(top)pc(st[top--]);
}

const int maxn=2e5+10;
const ll inf=1e18;
int n,q,k,A[maxn],B[maxn];

vi E[maxn];

struct mat{
  ll arr[3][3];
  ll*operator[](int pos){
    return arr[pos];
  }
  const ll*operator[](int pos)const{
    return arr[pos];
  }
}I,up[18][maxn],dw[18][maxn];
mat operator*(const mat&A,const mat&B){
  mat C;
  C[0][0]=min({inf,A[0][0]+B[0][0],A[0][1]+B[1][0],A[0][2]+B[2][0]});
  C[0][1]=min({inf,A[0][0]+B[0][1],A[0][1]+B[1][1],A[0][2]+B[2][1]});
  C[0][2]=min({inf,A[0][0]+B[0][2],A[0][1]+B[1][2],A[0][2]+B[2][2]});
  
  C[1][0]=min({inf,A[1][0]+B[0][0],A[1][1]+B[1][0],A[1][2]+B[2][0]});
  C[1][1]=min({inf,A[1][0]+B[0][1],A[1][1]+B[1][1],A[1][2]+B[2][1]});
  C[1][2]=min({inf,A[1][0]+B[0][2],A[1][1]+B[1][2],A[1][2]+B[2][2]});
  
  C[2][0]=min({inf,A[2][0]+B[0][0],A[2][1]+B[1][0],A[2][2]+B[2][0]});
  C[2][1]=min({inf,A[2][0]+B[0][1],A[2][1]+B[1][1],A[2][2]+B[2][1]});
  C[2][2]=min({inf,A[2][0]+B[0][2],A[2][1]+B[1][2],A[2][2]+B[2][2]});
  return C;
}

mat get(int u){
  mat C;
  rep(i,0,2)rep(j,0,2)C[i][j]=inf;
  if(k==1){
    C[0][0]=A[u];
  }
  if(k==2){
    C[0][0]=A[u];
    C[0][1]=A[u];
    C[1][0]=0;
  }
  if(k==3){
    C[0][0]=A[u];
    C[0][1]=A[u];
    C[1][0]=0;
    C[1][2]=0;
    C[2][0]=0;
    C[2][2]=B[u];
  }
  return C;
}

int dep[maxn],fa[18][maxn];

void dfs(int u,int f){
  dep[u]=dep[f]+1;
  fa[0][u]=f;
  up[0][u]=dw[0][u]=get(u);
  rep(i,1,17){
    fa[i][u]=fa[i-1][fa[i-1][u]];
    if(!fa[i][u])break;
    up[i][u]=up[i-1][u]*up[i-1][fa[i-1][u]];
    dw[i][u]=dw[i-1][fa[i-1][u]]*dw[i-1][u];
  }
  for(int v:E[u])if(v!=f){
    dfs(v,u);
  }
}
int qlca(int u,int v){
  if(dep[u]<dep[v])swap(u,v);
  per(i,17,0){
    if(dep[u]-(1<<i)>=dep[v]){
      u=fa[i][u];
    }
  }
  if(u==v)return u;
  per(i,17,0){
    if(fa[i][u]!=fa[i][v]){
      u=fa[i][u];
      v=fa[i][v];
    }
  }
  return fa[0][u];
}
void ask_up(int u,int anc,mat&res,bool flg=0){
//  while(u!=anc)res=res*up[0][u],u=fa[0][u];
  per(i,17,0){
    if(dep[u]-(1<<i)>=dep[anc]){
      res=res*up[i][u];
      u=fa[i][u];
    }
  }
  if(!flg)res=res*up[0][anc];
}
void ask_dw(int u,int anc,mat&res){
  if(u==anc)return;
  u=fa[0][u];
  if(u==anc)return;
  static vector<pii>st;
  st.clear();
//  while(u!=anc)st.push_back({u,0}),u=fa[0][u];
  per(i,17,0){
    if(dep[u]-(1<<i)>=dep[anc]){
      st.push_back({u,i});
      u=fa[i][u];
    }
  }
  per(_,st.size()-1,0){
    int u=st[_].first;
    int i=st[_].second;
    res=res*dw[i][u];
  }
}

void solve(){
  rep(i,0,2)rep(j,0,2)I[i][j]=i==j?0:inf;
  n=read(),q=read(),k=read();
  rep(i,1,n)A[i]=read();
  rep(i,2,n){
    int u=read(),v=read();
    E[u].push_back(v);
    E[v].push_back(u);
  }
  rep(i,1,n){
    B[i]=1e9;
    for(int j:E[i])chkmin(B[i],A[j]);
  }
  dfs(1,0);
  while(q--){
    int S=read(),T=read();
    int anc=qlca(S,T);
    mat dp;
    rep(i,0,2)rep(j,0,2)dp[i][j]=i==0&&j==0?0:inf;
    ask_up(S,anc,dp,T==anc);
    ask_dw(T,anc,dp);
    write(min({dp[0][0],dp[0][1],dp[0][2]})+A[T]),pc(10);
  }
}

int main(){
  freopen("transmit.in","r",stdin);
  freopen("transmit.out","w",stdout);
  solve();
  return 0;
}
