#include<bits/stdc++.h>
using namespace std;

#define rep(i,a,b) for(int i=(a),i##end=(b);i<=i##end;++i)
#define per(i,a,b) for(int i=(a),i##end=(b);i>=i##end;--i)

typedef long long ll;

const int maxn=1e5+10;

template<class T>void chkmin(T&x,T y){if(y<x)x=y;}
template<class T>void chkmax(T&x,T y){if(x<y)x=y;}

#define nc getchar
#define pc putchar
int read(){
  int x=0;
  char c=nc();
  while(c<48)c=nc();
  while(c>47)x=x*10+(c^48),c=nc();
  return x;
}
void write(ll x){
  if(!x){
    pc('0');return;
  }
  if(x<0){
    pc('-'),x=-x;
  }
  static char st[40];
  int top=0;
  while(x)st[++top]=x%10|48,x/=10;
  while(top)pc(st[top--]);
}
struct node{
  int nmn,nmx,pmn,pmx,hav0;
};
const int lim=1e9;
struct seq{
  int len;
  #define mid ((l+r)>>1)
  #define lson k<<1,l,mid
  #define rson k<<1|1,mid+1,r
  node tr[maxn<<2];
  node merge(node A,node B){
    return{min(A.nmn,B.nmn),max(A.nmx,B.nmx),min(A.pmn,B.pmn),max(A.pmx,B.pmx),A.hav0||B.hav0};
  }
  void build(int k,int l,int r){
    if(l==r){
      int x;
      scanf("%d",&x);
      if(x<0){
        tr[k].nmn=tr[k].nmx=x;
        tr[k].pmn=lim+1,tr[k].pmx=-lim-1;
      }
      if(x>0){
        tr[k].pmn=tr[k].pmx=x;
        tr[k].nmn=lim+1,tr[k].nmx=-lim-1;
      }
      tr[k].hav0=x==0;
    }else{
      build(lson);
      build(rson);
      tr[k]=merge(tr[k<<1],tr[k<<1|1]);
    }
  }
  node ask(int k,int l,int r,int ql,int qr){
    if(ql<=l&&r<=qr)return tr[k];
    if(qr<=mid)return ask(lson,ql,qr);
    if(ql>mid)return ask(rson,ql,qr);
    return merge(ask(lson,ql,qr),ask(rson,ql,qr));
  }
}a,b;

int q;

void solve(){
  scanf("%d%d%d",&a.len,&b.len,&q);
  a.build(1,1,a.len);
  b.build(1,1,b.len);
  while(q--){
    int la,ra,lb,rb;
    scanf("%d%d%d%d",&la,&ra,&lb,&rb);
    node x=a.ask(1,1,a.len,la,ra);
    node y=b.ask(1,1,b.len,lb,rb);
    vector<int> p,q;
    p.push_back(x.nmn),p.push_back(x.nmx),p.push_back(x.pmn),p.push_back(x.pmx);if(x.hav0)p.push_back(0);
    q.push_back(y.nmn),q.push_back(y.nmx);q.push_back(y.pmn),q.push_back(y.pmx);if(y.hav0)q.push_back(0);
    ll ans=-1.1e18;
    for(int x:p)if(abs(x)<=lim){
      ll res=1.1e18;
      for(int y:q)if(abs(y)<=lim){
        chkmin(res,1ll*x*y);
      }
      chkmax(ans,res);
    }
    write(ans);
    pc(10);
  }
}

int main(){
  freopen("game.in","r",stdin);
  freopen("game.out","w",stdout);
  solve();
  return 0;
}

