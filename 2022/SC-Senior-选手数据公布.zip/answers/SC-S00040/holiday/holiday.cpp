#include<bits/stdc++.h>
using namespace std;

#define rep(i,a,b) for(int i=(a),i##end=(b);i<=i##end;++i)
#define per(i,a,b) for(int i=(a),i##end=(b);i>=i##end;--i)

typedef long long ll;

bool chkmax(ll&x,ll y){
  return x<y?x=y,1:0;
}

int n,m,k;

ll A[2505];

vector<int>G[2505];

bool E[2505][2505];

struct node{
  ll val;int chk;
}go1[2505],go2[2505],go3[2505];

vector<node>vec[2505];

void solve(){
  cin>>n>>m>>k;
  rep(i,2,n)cin>>A[i];
  rep(i,1,m){
    int u,v;
    cin>>u>>v;
    G[u].push_back(v);
    G[v].push_back(u);
  }
  rep(S,1,n){
    static int dis[2505],Q[2505];
    memset(dis,-1,sizeof dis);
    int l=1,r=1;
    Q[1]=S,dis[S]=0;
    while(l<=r){
      int u=Q[l++];
      E[S][u]=1;
      if(dis[u]==k+1)continue;
      for(int v:G[u])if(dis[v]==-1)dis[v]=dis[u]+1,Q[++r]=v;
    }
  }
  rep(i,2,n)if(E[1][i])rep(j,2,n)if(i!=j&&E[i][j]){
    if(go1[j].val<A[i]+A[j]){
      go3[j]=go2[j],go2[j]=go1[j],go1[j]={A[i]+A[j],i};
    }else if(go2[j].val<A[i]+A[j]){
      go3[j]=go2[j],go2[j]={A[i]+A[j],i};
    }else if(go3[j].val<A[i]+A[j]){
      go3[j]={A[i]+A[j],i};
    }
  }
  rep(i,2,n){
    if(go1[i].chk){
      vec[i].push_back(go1[i]);
    }
    if(go2[i].chk){
      vec[i].push_back(go2[i]);
    }
    if(go3[i].chk){
      vec[i].push_back(go3[i]);
    }
  }
  ll ans=0;
  rep(i,2,n)if(go1[i].chk)rep(j,i+1,n)if(i!=j&&E[i][j]&&go1[j].chk){
    for(node p:vec[i])for(node q:vec[j]){
      if(p.chk!=q.chk&&p.chk!=j&&q.chk!=i){
        chkmax(ans,p.val+q.val);
      }
    }
  }
  cout<<ans<<endl;
}

int main(){
  freopen("holiday.in","r",stdin);
  freopen("holiday.out","w",stdout);
  solve();
  return 0;
}
