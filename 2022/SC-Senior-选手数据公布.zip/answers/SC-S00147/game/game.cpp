#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 100010, LN = 20, inf = 0x3f3f3f3f;
ll a[N], b[N], ais[N][LN], amx[N][LN], amn[N][LN], amnzh[N][LN], amxfu[N][LN], mxb[N][LN], mnb[N][LN];
int n, m, q, ln, lm;
int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &q);
	ln = (int)(log2(n)) + 1;
	lm = (int)(log2(m)) + 1;
	for (int i = 1; i <= n; i++) {
		scanf("%lld", &a[i]), ais[i][0] = (a[i] == 0);
		amx[i][0] = amn[i][0] = a[i];
		if (a[i] > 0) amnzh[i][0] = a[i], amxfu[i][0] = -inf;
		if (a[i] < 0) amnzh[i][0] =inf, amxfu[i][0] = a[i];
	}
	for (int i = 1; i <= m; i++)
		scanf("%lld", &b[i]), mxb[i][0] = mnb[i][0] = b[i];
	for (int j = 1; j <= lm; j++)
		for (int i = 1; i + (1 << j) - 1 <= m; i++)
			mxb[i][j] = max(mxb[i][j - 1], mxb[i + (1 << (j - 1))][j - 1]),
			mnb[i][j] = min(mnb[i][j - 1], mnb[i + (1 << (j - 1))][j - 1]);
	for (int j = 1; j <= ln; j++)
		for (int i = 1; i + (1 << j) - 1 <= n; i++)
			ais[i][j] = ais[i][j - 1] | ais[i + (1 << (j - 1))][j - 1],
			amn[i][j] = min(amn[i][j - 1], amn[i + (1 << (j - 1))][j - 1]),
			amx[i][j] = max(amx[i][j - 1], amx[i + (1 << (j - 1))][j - 1]),
			amnzh[i][j] = min(amnzh[i][j - 1], amnzh[i + (1 << (j - 1))][j - 1]),
			amxfu[i][j] = max(amxfu[i][j - 1], amxfu[i + (1 << (j - 1))][j - 1]);
	while (q--) {
		ll Bmn = inf, Bmx = -inf;
		int Al, Ar, Bl, Br;
		scanf("%d%d%d%d", &Al, &Ar, &Bl, &Br);
		int p = Bl;
		for (int j = lm; j >= 0; j--)
			if (p + (1 << j) - 1 <= Br) 
				Bmn = min(Bmn, mnb[p][j]), 
				Bmx = max(Bmx, mxb[p][j]), 
				p += (1 << j);
		if (Bmn < 0 && Bmx > 0) {
			int ais0 = -1;
			p = Al;
			for (int j = ln; j >= 0; j--)
				if (p + (1 << j) - 1 <= Ar) {
					if (ais0 == -1) ais0 = ais[p][j];
					else ais0 |= ais[p][j];
					p += (1 << j);
				}
			if (ais0 == 1) printf("0\n");
			else {
				ll Amnzh = inf, Amxfu = -inf;
				p = Al;
				for (int j = ln; j >= 0; j--)
					if (p + (1 << j) - 1 <= Ar)
						Amnzh = min(Amnzh, amnzh[p][j]),
						Amxfu = max(Amxfu, amxfu[p][j]),
						p += (1 << j);
				printf("%lld\n", max(Amnzh * Bmn, Amxfu * Bmx));
			}
		} else if (Bmn >= 0) {
			ll Amx = -inf;
			p = Al;
			for (int j = ln; j >= 0; j--)
				if (p + (1 << j) - 1 <= Ar)
					Amx = max(Amx, amx[p][j]), p += (1 << j);
			if (Amx > 0) printf("%lld\n", Amx * Bmn);
			else if (Amx == 0) printf("0\n");
			else printf("%lld\n", Amx * Bmx);
		} else { // Bmx <= 0
			ll Amn = inf;
			p = Al;
			for (int j = ln; j >= 0; j--)
				if (p + (1 << j) - 1 <= Ar)
					Amn = min(Amn, amn[p][j]), p += (1 << j);
			if (Amn > 0) printf("%lld\n", Amn * Bmn);
			else if (Amn == 0) printf("0\n");
			else printf("%lld\n", Amn * Bmx);
		}
	}
	return 0;
}
