#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 2510, M = 10010, K = 110;
struct edge {
	int t, n;
	edge(int _t = 0, int _n = 0) {
		t = _t, n = _n;
	}
} e[M << 1];
int n, m, k, tot, h[N], c[N], dis[N][N];
pair<ll, int> b[N];
ll ans, a[N];
inline void add(int u, int v) {
	e[++tot] = edge(v, h[u]), h[u] = tot;
	e[++tot] = edge(u, h[v]), h[v] = tot;
	dis[u][v] = dis[v][u] = 1;
}
int main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	memset(dis, 0x3f, sizeof dis);
	scanf("%d%d%d", &n, &m, &k);
	for (int i = 2; i <= n; i++)
		scanf("%lld", &a[i]);
	for (int i = 1, u, v; i <= m; i++) 
		scanf("%d%d", &u, &v), add(u, v);
	k++;
	if (n <= 300) { // 70 pts
		for (int l = 1; l <= n; l++)
			for (int i = 1; i <= n; i++)
				for (int j = 1; j <= n; j++)
					if (dis[i][j] > dis[i][l] + dis[l][j])
						dis[i][j] = dis[i][l] + dis[l][j];
		for (int i = 2; i <= n; i++)
			b[i] = make_pair(a[i], i);
		sort(b + 1, b + n + 1);
		for (int i = 2; i <= n; i++) 
			for (int j = 2; j <= n; j++)
				if (i != j && dis[i][j] <= k && dis[j][1] <= k)
					if (a[c[i]] < a[j]) c[i] = j;
		for (int i = 2; i <= n; i++)
			for (int j = 2; j <= n; j++)
				for (int l = 2; l <= n; l++) 
					if (i != j && j != l && l != i) 
						if (dis[1][i] <= k && dis[i][j] <= k
							&& dis[j][l] <= k && dis[l][1] <= k * 2) {
							ll res = a[i] + a[j] + a[l];
							if (c[l] != 0 && c[l] != j && c[l] != i)
								ans = max(ans, res + a[c[l]]);
						}
		printf("%lld\n", ans);
	}/* else if (k == 1) { // 85 pts
		;
	}*/ else {
		printf("AHHHHHH\n");
	}
	return 0;
}
