#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 200010, LN = 20;
struct tree {
	int t, n;
	tree(int _t = 0, int _n = 0) {
		t = _t, n = _n;
	}
} e[N << 1];
int n, q, k, ln, tot, h[N], fafa[N], dep[N], father[N][LN], path[N][LN];
ll a[N], dp[N], dpp[N];
inline void add(int u, int v) {
	e[++tot] = tree(v, h[u]), h[u] = tot;
	e[++tot] = tree(u, h[v]), h[v] = tot;
}
void build(int u, int fa) {
	father[u][0] = fa;
	dep[u] = dep[fa] + 1;
	path[u][0] = a[fa];
	for (int i = h[u], v; i; i = e[i].n) 
		if ((v = e[i].t) != fa) build(v, u);
}
inline ll LCA(int x, int y) {
	ll res = a[x] + a[y];
	for (int i = ln; i >= 0; i--)
		if (dep[father[x][i]] >= dep[y])
			x = father[x][i], res += path[x][i];
	if (x == y) return res - a[y];
	for (int i = ln; i >= 0; i--)
		if (father[x][i] != father[y][i])
			x = father[x][i], y = father[y][i],
			res += path[x][i] + path[y][i];
	return res + path[x][0];
}
void dfs(int u, int father) {
	fafa[u] = father;
	for (int i = h[u], v; i; i = e[i].n)
		if ((v = e[i].t) != father) dfs(v, u);
}
int main() {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	scanf("%d%d%d", &n, &q, &k);
	ln = (int)(log2(n)) + 1;
	for (int i = 1; i <= n; i++)
		scanf("%lld", &a[i]);
	for (int i = 1, u, v; i < n; i++) {
		scanf("%d%d", &u, &v);
		add(u, v);
	}
	build(1, 0);
	for (int j = 1; j <= ln; j++)
		for (int i = 1; i <= n; i++)
			father[i][j] = father[father[i][j - 1]][j - 1],
			path[i][j] = path[i][j - 1] + path[father[i][j - 1]][j - 1];
	while (q--) {
		int s, t; scanf("%d%d", &s, &t);
		if (k == 1) printf("%lld\n", LCA(s, t)); // 16 pts
		else if (n <= 2000) {
			memset(fafa, 0, sizeof fafa);
			memset(dpp, 0, sizeof dpp);
			memset(dp, 0, sizeof dp);
			dfs(s, 0);
			int nk = 0;
			dp[++nk] = t;
			while (1) {
				dp[++nk] = fafa[dp[nk - 1]];
				if (dp[nk] == s) break;
			}
			for (int i = 1; i <= nk; i++)
				dp[i] = a[dp[i]];
			dpp[1] = dp[1];
			dpp[2] = dp[2] + dp[1];
			if (k == 3) dpp[3] = dp[1] + dp[3];
			for (int i = k + 1; i <= nk; i++) {
				if (k == 2) dpp[i] = min(dpp[i - 1], dpp[i - 2]) + dp[i];
				else dpp[i] = min(min(dpp[i - 1], dpp[i - 2]), dpp[i - 3]) + dp[i];
			}
			printf("%lld\n", dpp[nk]);
		}
	}
	return 0;
}
