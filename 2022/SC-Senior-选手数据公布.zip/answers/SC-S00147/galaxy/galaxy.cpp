#include <bits/stdc++.h>
using namespace std;
#define pb push_back
const int N = 500010;
vector<int> a[N];
int n, m, q;
int main() {
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1, u, v; i <= m; i++) 
		scanf("%d%d", &u, &v), a[u].pb(v);
	scanf("%d", &q);
	while (q--) {
		int op; scanf("%d", &op);
		if (op == 1) {
			int u, v; scanf("%d%d", &u, &v);
			;
		} else if (op == 2) {
			int u; scanf("%d", &u);
			;
		} else if (op == 3) {
			int u, v; scanf("%d%d", &u, &v);
			;
		} else {
			int u; scanf("%d", &u);
			;
		}
		printf("NO\n");
	}
	return 0;
}
