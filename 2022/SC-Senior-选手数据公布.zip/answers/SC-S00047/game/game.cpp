#include<bits/stdc++.h>
#define ls(x) x<<1
#define rs(x) x<<1|1
#define int long long
using namespace std;
struct node
{
	int l,r;
	int z_max,z_min,f_max,f_min; 
}tree[1000001][2];
int b[1000001][2];
int n,m,q;
void update(int x,int typ)
{
	tree[x][typ].z_max=max(tree[ls(x)][typ].z_max,tree[rs(x)][typ].z_max);
	tree[x][typ].z_min=min(tree[ls(x)][typ].z_min,tree[rs(x)][typ].z_min);
	tree[x][typ].f_max=max(tree[ls(x)][typ].f_max,tree[rs(x)][typ].f_max);
	tree[x][typ].f_min=min(tree[ls(x)][typ].f_min,tree[rs(x)][typ].f_min);
}
void build(int x,int L,int R,int typ)
{
	tree[x][typ].l=L,tree[x][typ].r=R;
	tree[x][typ].z_max=tree[x][typ].f_max=-1145141919,tree[x][typ].z_min=tree[x][typ].f_min=1145141919;
	if(L==R)
	{
		if(b[L][typ]>0) tree[x][typ].z_max=tree[x][typ].z_min=b[L][typ];
		else if(b[L][typ]<0) tree[x][typ].f_max=tree[x][typ].f_min=b[L][typ];
		else tree[x][typ].z_max=tree[x][typ].z_min=tree[x][typ].f_max=tree[x][typ].f_min=0;
		return; 
	}
	int M=(L+R)>>1;
	build(ls(x),L,M,typ);
	build(rs(x),M+1,R,typ);
	update(x,typ);
}
int query_zmax(int x,int L,int R,int typ)
{
	if(L<=tree[x][typ].l&&tree[x][typ].r<=R)
		return tree[x][typ].z_max;
	int M=(tree[x][typ].l+tree[x][typ].r)>>1,ans=-1145141919;
	if(L<=M) ans=max(ans,query_zmax(ls(x),L,R,typ));
	if(M<R) ans=max(ans,query_zmax(rs(x),L,R,typ));
	return ans;
}
int query_fmax(int x,int L,int R,int typ)
{
	if(L<=tree[x][typ].l&&tree[x][typ].r<=R)
		return tree[x][typ].f_max;
	int M=(tree[x][typ].l+tree[x][typ].r)>>1,ans=-1145141919;
	if(L<=M) ans=max(ans,query_fmax(ls(x),L,R,typ));
	if(M<R) ans=max(ans,query_fmax(rs(x),L,R,typ));
	return ans;
}
int query_zmin(int x,int L,int R,int typ)
{
	if(L<=tree[x][typ].l&&tree[x][typ].r<=R)
		return tree[x][typ].z_min;
	int M=(tree[x][typ].l+tree[x][typ].r)>>1,ans=1145141919;
	if(L<=M) ans=min(ans,query_zmin(ls(x),L,R,typ));
	if(M<R) ans=min(ans,query_zmin(rs(x),L,R,typ));
	return ans;
}
int query_fmin(int x,int L,int R,int typ)
{
	if(L<=tree[x][typ].l&&tree[x][typ].r<=R)
		return tree[x][typ].f_min;
	int M=(tree[x][typ].l+tree[x][typ].r)>>1,ans=1145141919;
	if(L<=M) ans=min(ans,query_fmin(ls(x),L,R,typ));
	if(M<R) ans=min(ans,query_fmin(rs(x),L,R,typ));
	return ans;
}
signed main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++) cin>>b[i][0];
	for(int i=1;i<=m;i++) cin>>b[i][1];
	build(1,1,n,0);
	build(1,1,m,1);
	int l_1,r_1,l_2,r_2;
	for(int i=1;i<=q;i++)
	{
		cin>>l_1>>r_1>>l_2>>r_2;
		int zmax_1=query_zmax(1,l_1,r_1,0);
		int fmax_1=query_fmax(1,l_1,r_1,0);
		int zmin_1=query_zmin(1,l_1,r_1,0);
		int fmin_1=query_fmin(1,l_1,r_1,0);
		int zmax_2=query_zmax(1,l_2,r_2,1);
		int fmax_2=query_fmax(1,l_2,r_2,1);
		int zmin_2=query_zmin(1,l_2,r_2,1);
		int fmin_2=query_fmin(1,l_2,r_2,1);
		int ans=-(1ll<<61);
		if(zmax_1!=-1145141919)
		{
			int ans_=(1ll<<61);
			if(zmin_2!=1145141919) ans_=min(ans_,zmax_1*zmin_2);
			if(fmin_2!=1145141919) ans_=min(ans_,zmax_1*fmin_2); 
			ans=max(ans,ans_);
		} 
		if(fmax_1!=-1145141919)
		{
			int ans_=(1ll<<61);
			if(zmax_2!=-1145141919) ans_=min(ans_,fmax_1*zmax_2);
			if(fmax_2!=-1145141919) ans_=min(ans_,fmax_1*fmax_2); 
			ans=max(ans,ans_);
		}
		if(zmin_1!=1145141919)
		{
			int ans_=(1ll<<61);
			if(zmin_2!=1145141919) ans_=min(ans_,zmin_1*zmin_2);
			if(fmin_2!=1145141919) ans_=min(ans_,zmin_1*fmin_2);
			ans=max(ans,ans_);
		}
		if(fmin_1!=1145141919)
		{
			int ans_=(1ll<<61);
			if(zmax_2!=-1145141919) ans_=min(ans_,fmin_1*zmax_2);
			if(fmax_2!=-1145141919) ans_=min(ans_,fmin_1*fmax_2);
			ans=max(ans,ans_);
		}
		cout<<ans<<endl;
	}
	return 0;
}
/*
3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2

6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3
ϣ������ĺ����һ��ˮ��
��ը��лл
���Ա�������һ�Ҫ��������ô���� 
��������0.9��
������������ 
�������ϳ�ʲô��
���������Ӻ�Ү�������� 
*/
