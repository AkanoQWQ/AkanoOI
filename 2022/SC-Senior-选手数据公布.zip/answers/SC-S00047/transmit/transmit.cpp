#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,Q,k;
int fi[1000001],to[1000001],nx[1000001],tot;
int val[1000001];
int depth[1000001],fa[1000001][22];
vector<int>vec,vec1;
int f[1000001]; 
void link(int a,int b)
{
	nx[++tot]=fi[a];
	fi[a]=tot;
	to[tot]=b;
}
void dfs(int x,int fath)
{
	for(int i=fi[x];i;i=nx[i])
	{
		int v=to[i];
		if(v!=fath)
		{
			fa[v][0]=x;
			depth[v]=depth[x]+1;
			dfs(v,x);
		}
	}
}
int Lca(int x,int y)
{
	if(x==1||y==1) return 1;
	if(depth[x]<depth[y]) swap(x,y);
	for(int i=20;i>=0;i--)
		if(depth[fa[x][i]]>=depth[y])
			x=fa[x][i];
	if(x==y) return x;
	for(int i=20;i>=0;i--)
		if(fa[x][i]!=fa[y][i])
			x=fa[x][i],y=fa[y][i];
	return fa[x][0];
}
signed main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int x,y;
	cin>>n>>Q>>k;
	for(int i=1;i<=n;i++)
		cin>>val[i];
	for(int i=1;i<n;i++)
	{
		cin>>x>>y;
		link(x,y);
		link(y,x); 
	}
	dfs(1,0);
	for(int i=1;i<=20;i++)
	 	for(int x=1;x<=n;x++)
	 		fa[x][i]=fa[fa[x][i-1]][i-1];
	for(int i=1;i<=Q;i++)
	{
		int x,y,x_,y_,L,all=0;
		cin>>x>>y;
		L=Lca(x,y);
		x_=x,y_=y;
		while(x_!=L)
		{
			vec.push_back(val[x_]);
			all+=val[x_];
			x_=fa[x_][0];
		}
		while(y_!=fa[L][0])
		{
			vec1.push_back(val[y_]);
			all+=val[y_];
			y_=fa[y_][0];
		}
		for(int i=vec1.size()-1;i>=0;i--)
			vec.push_back(vec1[i]);
		if(k==1)
			cout<<all<<endl;
		else
		{
			f[0]=vec[0];
			for(int i=1;i<vec.size();i++)
			{
				f[i]=(1ll<<62);
				for(int j=max(i-k,0ll);j<i;j++)
					f[i]=min(f[i],f[j]+vec[i]);
			}
			cout<<f[vec.size()-1]<<endl;
		}
		memset(f,0,sizeof(f));
		vec.clear(),vec1.clear();
	}
	return 0;
}
/*
7 3 3
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7
4 7
5 6
1 2

10 10 3
835701672 912572995 368308854 156367225 251245604 788978650 385396264 960190423 51944511 479806606
2 1
3 2
4 2
5 3
6 3
7 2
8 7
9 1
10 9
1 7
1 5
2 1
1 9
10 5
3 10
2 9
10 2
1 4
4 7
��Ү�������ˡ� 
����ǰ�������ô������
���50��·���ˡ� 
������ˣ��һ���Ҫ˵��
����Զϲ��Fredrick 
*/
