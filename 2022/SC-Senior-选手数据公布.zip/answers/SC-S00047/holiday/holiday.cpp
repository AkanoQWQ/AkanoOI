#include<bits/stdc++.h>
#define Max 1000001
#define mp(a,b) make_pair(a,b)
using namespace std;
int fi[Max],to[Max],nx[Max],tot;
long long val[Max],dis[Max];
bool vis[Max],check[Max];
bool Check[2530][2530];
int n,m,k;
priority_queue<pair<long long,long long>,vector<pair<long long,long long> >,less<pair<long long,long long> > >heap[2530];
void link(int a,int b)
{
	nx[++tot]=fi[a];
	fi[a]=tot;
	to[tot]=b;
}
void bfs_1()
{
	memset(vis,0,sizeof(vis));
	queue<pair<int,int> >que;
	vis[1]=1;
	que.push(mp(-1,1));
	while(!que.empty())
	{
		int steps=que.front().first;
		int x=que.front().second;
		que.pop();
		for(int i=fi[x];i;i=nx[i])
		{
			int v=to[i];
			if(!vis[v]&&steps+1<=k)
				vis[v]=1,check[v]=1,que.push(mp(steps+1,v)); 
		}
	}
}
void bfs(int P)
{
	memset(vis,0,sizeof(vis));
	queue<pair<int,int> >que;
	vis[P]=1;
	que.push(mp(-1,P));
	while(!que.empty())
	{
		int steps=que.front().first;
		int x=que.front().second;
		que.pop();
		for(int i=fi[x];i;i=nx[i])
		{
			int v=to[i];
			if(!vis[v]&&steps+1<=k)
			{
				vis[v]=1,que.push(mp(steps+1,v));
				Check[P][v]=1;
				if(check[v])
					heap[P].push(mp(val[v],v));
			}
		}
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++)
		cin>>val[i];
	for(int i=1;i<=m;i++)
	{
		int x,y;
		cin>>x>>y;
		link(x,y);
		link(y,x);
	}
	bfs_1();
	for(int i=2;i<=n;i++)
		bfs(i);
	long long ans=0;
	stack<pair<int,int> >trash_i,trash_j;
	for(int i=2;i<=n;i++)
		for(int j=i+1;j<=n;j++)
		{
			if(!Check[i][j]) continue;
			if(!heap[i].size()||!heap[j].size()) continue;
			if(heap[i].top().second==j) trash_i.push(heap[i].top()),heap[i].pop();
			if(heap[j].top().second==i) trash_j.push(heap[j].top()),heap[j].pop();
			if(heap[i].size()&&heap[j].size())
			{
				if(heap[i].top().second==heap[j].top().second)
				{
					long long p=heap[i].top().first;
					trash_i.push(heap[i].top()),heap[i].pop();
					trash_j.push(heap[j].top()),heap[j].pop();
					if(heap[i].size()&&heap[i].top().second==j) trash_i.push(heap[i].top()),heap[i].pop();
					if(heap[j].size()&&heap[j].top().second==i) trash_j.push(heap[j].top()),heap[j].pop();
					long long maxx=-1;
					if(heap[i].size()) maxx=max(heap[i].top().first,maxx);
					if(heap[j].size()) maxx=max(heap[j].top().first,maxx);
					if(maxx!=-1)
					ans=max(ans,val[i]+val[j]+p+maxx);
				}
				else
					ans=max(ans,val[i]+val[j]+heap[i].top().first+heap[j].top().first);
			} 
			while(!trash_i.empty()) heap[i].push(trash_i.top()),trash_i.pop();
			while(!trash_j.empty()) heap[j].push(trash_j.top()),trash_j.pop();
		}
	cout<<ans<<endl;
	return 0;
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1

7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4
��������T1������ һ����Сʱ
��Ҫ�������� 
��Ҫ��ȥ�򹫿����򹫿����򹫿��� 
n��logӦ�ÿ��Թ���
��Ҫ����˵��Ϊʡ���õ�heap������
�����̵��������ǰ� 
*/
