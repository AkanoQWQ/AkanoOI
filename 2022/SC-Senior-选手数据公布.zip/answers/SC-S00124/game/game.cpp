#include<bits/stdc++.h>
#define ll long long
inline int read(){
	int sum=0,h=1;
	char ch=getchar();
	while(!isdigit(ch)){if(ch=='-') h=-1;ch=getchar();}
	while(isdigit(ch)) sum=sum*10+ch-'0',ch=getchar();
	return sum*h;
}
inline void write(ll x){
	if(x<0){
		putchar('-');
		x=-x;
	}
	if(x>9) write(x/10);
	putchar(x%10+'0');
	return;
}
const int N=1e5+5;
int n,m,q;
int a[N][2];
//const ll M=1e17;
//struct segment_tree{
//	int l,r;
//	int maxn,minn;
//	int zmin,fmax;
//	void init(){
//		zmin=M;
//		fmax=-M;
//		maxn=-M;
//		minn=M;
//		return;
//	}
//}tr[N*4][2];
ll max(ll x,ll y){
	return x>y?x:y;
}
ll min(ll x,ll y){
	return x<y?x:y;
}
//void pushup(int p,int k){
//	tr[p][k].maxn=max(tr[p<<1][k].maxn,tr[p<<1|1][k].maxn);
//	tr[p][k].minn=min(tr[p<<1][k].minn,tr[p<<1|1][k].minn);
//	if(tr[p<<1][k].maxn<=0) tr[p][k].fmax=max(tr[p][k].fmax,tr[p<<1][k].maxn);
//	if(tr[p<<1|1][k].maxn<=0) tr[p][k].fmax=max(tr[p][k].fmax,tr[p<<1|1][k].maxn);
//	if(tr[p<<1][k].minn<=0) tr[p][k].fmax=max(tr[p][k].fmax,tr[p<<1][k].minn);
//	if(tr[p<<1|1][k].minn<=0) tr[p][k].fmax=max(tr[p][k].fmax,tr[p<<1|1][k].minn);
//	if(tr[p<<1][k].minn>=0) tr[p][k].zmin=min(tr[p][k].zmin,tr[p<<1][k].minn);
//	if(tr[p<<1|1][k].minn>=0) tr[p][k].zmin=min(tr[p][k].zmin,tr[p<<1|1][k].minn);
//	if(tr[p<<1][k].maxn>=0) tr[p][k].zmin=min(tr[p][k].zmin,tr[p<<1][k].maxn);
//	if(tr[p<<1|1][k].maxn>=0) tr[p][k].zmin=min(tr[p][k].zmin,tr[p<<1|1][k].maxn);
//	return;
//}
//void build(int p,int l,int r,int k){
//	tr[p][k].l=l,tr[p][k].r=r;
//	tr[p][k].init();
//	if(l==r){
//		if(a[l][k]<=0) tr[p][k].fmax=a[l][k];
//		else tr[p][k].fmax=-M;
//		tr[p][k].maxn=a[l][k];
//		tr[p][k].minn=a[l][k];
//		if(a[l][k]>=0) tr[p][k].zmin=a[l][k];
//		else tr[p][k].zmin=M;
//		return;
//	}
//	int mid=l+r>>1;
//	build(p<<1,l,mid,k);
//	build(p<<1|1,mid+1,r,k);
//	pushup(p,k);
//	return;
//}
//int query_max(int p,int l,int r,int k){
//	if(l<=tr[p][k].l and tr[p][k].r<=r) return tr[p][k].maxn;
//	int mid=tr[p][k].l+tr[p][k].r>>1;
//	int res=-M;
//	if(l<=mid) res=max(res,query_max(p<<1,l,r,k));
//	if(r>mid) res=max(res,query_max(p<<1|1,l,r,k));
//	return res;
//}
//int query_zmin(int p,int l,int r,int k){
//	if(l<=tr[p][k].l and tr[p][k].r<=r) return tr[p][k].zmin;
//	int mid=tr[p][k].l+tr[p][k].r>>1;
//	int res=M;
//	if(l<=mid) res=min(res,query_zmin(p<<1,l,r,k));
//	if(r>mid) res=min(res,query_zmin(p<<1|1,l,r,k));
//	return res;
//}
//int query_fmax(int p,int l,int r,int k){
//	if(l<=tr[p][k].l and tr[p][k].r<=r) return tr[p][k].fmax;
//	int mid=tr[p][k].l+tr[p][k].r>>1;
//	int res=M;
//	if(l<=mid) res=max(res,query_fmax(p<<1,l,r,k));
//	if(r>mid) res=max(res,query_fmax(p<<1|1,l,r,k));
//	return res;
//}
//int query_min(int p,int l,int r,int k){
//	if(l<=tr[p][k].l and tr[p][k].r<=r) return tr[p][k].minn;
//	int mid=tr[p][k].l+tr[p][k].r>>1;
//	int res=M;
//	if(l<=mid) res=min(res,query_min(p<<1,l,r,k));
//	if(r>mid) res=min(res,query_min(p<<1|1,l,r,k));
//	return res;
//}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;++i) a[i][0]=read();
	for(int i=1;i<=m;++i) a[i][1]=read();
//	build(1,1,n,0);
//	build(1,1,m,1);
	for(int o=1;o<=q;++o){
		int l1,r1,l2,r2;
		l1=read(),r1=read(),l2=read(),r2=read();
//		int maxn1=query_max(1,l1,r1,0);
//		int maxn2=query_max(1,l2,r2,1);
//		int minn1=query_min(1,l1,r1,0);
//		int minn2=query_min(1,l2,r2,1);
//		int fmax1=query_fmax(1,l1,r1,0);
//		int fmax2=query_fmax(1,l2,r2,1);
//		int zmin1=query_zmin(1,l1,r1,0);
//		int zmin2=query_zmin(1,l2,r2,1);
//		if(minn2>0 and maxn1>0) write(maxn1*minn2),puts("");
//		else if(maxn2<0 and minn1<0) write(maxn2*minn1),puts("");
//		else if(maxn2>0 and minn2<0){
//			if(fmax1==0) puts("0");
//			else write(max(fmax1*maxn2,zmin1*minn2)),puts("");
//		}
		ll ans=-1e17;
		for(int i=l1;i<=r1;++i){
			ll minn=1e17;
			for(int j=l2;j<=r2;++j){
				minn=min(minn,a[i][0]*a[j][1]);
			}
			ans=max(ans,minn);
		}
		write(ans);
		puts("");
	}
	return 0;
}
