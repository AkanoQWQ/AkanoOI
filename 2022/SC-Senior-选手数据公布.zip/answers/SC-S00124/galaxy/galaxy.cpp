#include<bits/stdc++.h>
inline int read(){
	int sum=0,h=1;
	char ch=getchar();
	while(!isdigit(ch)){if(ch=='-') h=-1;ch=getchar();}
	while(isdigit(ch)) sum=sum*10+ch-'0',ch=getchar();
	return sum*h;
}
inline void write(int x){
	if(x<0){
		putchar('-');
		x=-x;
	}
	if(x>9) write(x/10);
	putchar(x%10+'0');
	return;
}
const int N=1e3+5;
int n,m,q;
int a[N];
int head[N*2],ne[2*N],ver[2*N],tot;
int mp[N][N];
std::vector<int> out[N];
bool vis[N];
void add(int x,int y){
	ver[++tot]=y;
	ne[tot]=head[x];
	head[x]=tot;
	return;
}
bool spfa(int u){
	std::queue<int> q;
	memset(vis,0,sizeof vis);
	vis[u]=1;
	q.push(u);
	int cnt=0;
	while(!q.empty()){
		int x=q.front();q.pop();
		vis[x]=0;
		++cnt;
		if(cnt>n) return 1;
		for(int i=head[x];i;i=ne[i]){
			int y=ver[i];
			if(mp[x][y]) continue;
			if(!vis[y]){
				q.push(y);
				vis[y]=1;
			}
		}
	}
	return 0;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=m;++i){
		int x,y;
		x=read(),y=read();
		add(x,y);
		out[y].push_back(x);
	}
	q=read();
	for(int o=1;o<=q;++o){
		int pos=read();
		if(pos==1){
			int u,v;
			u=read(),v=read();
			mp[u][v]=1;
		}
		if(pos==2){
			int u=read();
			for(int i=0;i<out[u].size();++i) mp[out[u][i]][u]=1;
		}
		if(pos==3){
			int u,v;
			u=read(),v=read();
			mp[u][v]=0;
		}
		if(pos==4){
			int u=read();
			for(int i=0;i<out[u].size();++i) mp[out[u][i]][u]=0;
		}
		bool flag=0;
		for(int i=1;i<=n;++i){
			int cnt=0;
			if(flag) break;
			for(int j=head[i];j;j=ne[j]){
				int y=ver[j];
				if(mp[i][y]==0) ++cnt;
				if(cnt==2){
					puts("NO");
					flag=1;
					break;
				}
			}
		}
		if(flag) continue;
		flag=0;
		for(int i=1;i<=n;++i){
			if(!spfa(i)){
				flag=1;
				puts("NO");
				break;
			}
		}
		if(flag) continue;
		puts("YES");
	}
	return 0;
}
