#include<bits/stdc++.h>
inline int read(){
	int sum=0,h=1;
	char ch=getchar();
	while(!isdigit(ch)){if(ch=='-') h=-1;ch=getchar();}
	while(isdigit(ch)) sum=sum*10+ch-'0',ch=getchar();
	return sum*h;
}
inline void write(int x){
	if(x<0){
		putchar('-');
		x=-x;
	}
	if(x>9) write(x/10);
	putchar(x%10+'0');
	return;
}
const int N=2502,M=1e4+5;
int n,m,k;
int _head[M*2],_ver[M*2],_ne[M*2],_tot;
int a[N];
bool vis[N];
int dist[N][N];
int head[N*N],ver[N*N],ne[N*N],edge[N*N],tot;
int ans;
void _add(int x,int y){
	_ver[++_tot]=y;
	_ne[_tot]=_head[x];
	_head[x]=_tot;
	return;
}
int min(int x,int y){
	return x<y?x:y;
}
int max(int x,int y){
	return x>y?x:y;
}
void add(int x,int y,int z){
	ver[++tot]=y;
	edge[tot]=z;
	ne[tot]=head[x];
	head[x]=tot;
	return;
}
void dfs(int p,int x,int dis){
	if(dis>k) return;
	dist[p][x]=min(dist[p][x],dis);
	for(int i=_head[x];i;i=_ne[i]){
		int y=_ver[i];
		if(vis[y]) continue;
		vis[y]=1;
		dfs(p,y,dis+1);
	}
	return;
}
void get_ans(int x,int res,int len){
	if(len==5){
		if(dist[x][1]>k or dist[x][1]==-1) return;
		else ans=max(ans,res);
		return;
	}
	for(int i=head[x];i;i=ne[i]){
		int y=ver[i];
		if(vis[y]) continue;
		vis[y]=1;
		get_ans(y,res+edge[i],len+1);
		vis[y]=0;
	}
	return;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read(),m=read(),k=read();
	for(int i=2;i<=n;++i) a[i]=read();
	for(int i=1;i<=m;++i){
		int x,y;
		x=read(),y=read();
		_add(x,y);
		_add(y,x);
	}
	memset(dist,0x3f,sizeof dist);
	for(int i=1;i<=n;++i){
		vis[i]=1;
		dfs(i,i,-1);
		memset(vis,0,sizeof vis);
	}
	for(int i=1;i<=n;++i){
		for(int j=1;j<=n;++j){
			if(dist[i][j]<=k and i!=j) add(i,j,a[j]);
		}
	}
	vis[1]=1;
	get_ans(1,0,1);
	write(ans);
	return 0;
} 
