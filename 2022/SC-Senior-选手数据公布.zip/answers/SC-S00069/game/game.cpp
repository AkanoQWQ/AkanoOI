#include <stdint.h>
#include <stdio.h>

/*
15:39
	�������ԣ�������֤����ȷ�ԣ�����ʱ��������1s֮��
	���ǣ�ֻ�ܹ�ǰ12��nС��1000�Ĳ��Ե㣬��ſ���ͨ��10����
	10000��û�����ݲ��ԣ����ö�֪ 
*/
typedef int64_t ll;
const ll IMAX = ~((ll)1 << 63);
const ll IMIN = ((ll)1 << 63);

inline ll max(ll a, ll b) {
	return a > b ? a : b;
}

inline ll min(ll a, ll b) {
	return a < b ? a : b;
}


const int SIZE = 10002;
int n, m, q;
ll A[SIZE], B[SIZE];
ll C[SIZE][SIZE];

ll rnd(int l1, int r1, int l2, int r2) {
	ll lineM, totalM = IMIN;
	
	for (int i = l1; i <= r1; i++) {
		lineM = IMAX;
		for (int j = l2; j <= r2; j++) {
			lineM = min(lineM, C[i][j]);
		}
		
		totalM = max(totalM, lineM);
	}
	
	return totalM;
}


ll bigrnd(int l1, int r1, int l2, int r2) {
	ll lineM, totalM = IMIN;
	
	for (int i = l1; i <= l1 + 10 && i <= r1; i++) {
		lineM = IMAX;
		for (int j = l2; j <= l2 + 10 && j <= r2; j++) {
			lineM = min(lineM, A[i] * B[j]);
		}
		
		totalM = max(totalM, lineM);
	}
	
	for (int i = max(r1 - 10, l1); i <= r1; i++) {
		lineM = IMAX;
		for (int j = max(r2 - 10, l2); j <= r2; j++) {
			lineM = min(lineM, A[i] * B[j]);
		}
		
		totalM = max(totalM, lineM);
	}
	
	for (int i = l1 / 10; i <= r1 / 10; i++) {
		lineM = IMAX;
		for (int j = l2 / 10; j <= r2 / 10; j++) {
			lineM = min(lineM, C[i][j]);
		}
		totalM = max(totalM, lineM);
	}
	
	return totalM;
}

void smallData() {
	// enum C
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= m; j++) {
			C[i][j] = A[i] * B[j];
		}
	}
	
	int l1, r1, l2, r2;
	for (int i = 0; i < q; i++) {
		scanf("%d %d %d %d", &l1, &r1, &l2, &r2);

		printf("%lld\n", rnd(l1, r1, l2, r2));
	}
}



void bigData() {
	for (int i = 1; i <= n; i += 10) {
		for (int j = 1; j <= n; j += 10) {
			ll lineM, totalM = IMIN;
			for (int ki = i; ki < i + 10 && ki <= n; ki++) {
				lineM = IMAX;
				for (int kj = i; kj < j + 10 && kj <= n; kj++) {
					lineM = min(lineM, A[ki] * B[kj]);
				}
				totalM = min(lineM, lineM);
			}
			C[(i - 1)/10][(j - 1)/10] = totalM;
		}
	}
	
	int l1, r1, l2, r2;
	for (int i = 0; i < q; i++) {
		scanf("%d %d %d %d", &l1, &r1, &l2, &r2);

		printf("%lld\n", bigrnd(l1, r1, l2, r2));
	}
} 

int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout); 
	
	scanf("%d%d%d", &n, &m, &q);
	ll * ptr = A;
	for (int i = 0; i < n; i++)
		scanf("%lld", ++ptr);
	ptr = B;
	for (int i = 0; i < m; i++)
		scanf("%lld", ++ptr);
	if (n <= 100000) {
		smallData();
	} else {
		bigData();
	}
	return 0;
}
