#include<bits/stdc++.h>
using namespace std;
queue<int> q;
int n,m,K,cnt,ans=-1e9,a[2505],d[2505],head[2505],maxx[2505][2505];
bool vis[2505][2505];
struct node{
	int to,next;
}e[100005];
void add(int u,int v){
	e[++cnt].to=v;
	e[cnt].next=head[u];
	head[u]=cnt;
}
void dfs(){
	for(int j=1;j<=n;j++){
		memset(d,0,sizeof(d));
		d[j]=1;
		q.push(j);
		while(!q.empty()){
			int u=q.front();
			q.pop();
			vis[j][u]=1;
			if(d[u]-1==K+1)  continue;
			for(int i=head[u];i;i=e[i].next){
				int v=e[i].to;
				if(!d[v])  d[v]=d[u]+1,q.push(v);
			}
		}
	}
	for(int i=2;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(i!=j&&vis[i][j]&&vis[j][1]){
				for(int k=0;k<3;k++)
					if(a[j]>a[maxx[i][k]]){
						for(int l=2;l>k;l--)  maxx[i][l]=maxx[i][l-1];
						maxx[i][k]=j;
						break;
					}
			}
		}
	}
	for(int i=2;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			if(vis[i][j]){
				for(int k=0;k<3;k++)  for(int l=0;l<3;l++)  if(maxx[i][k]&&maxx[j][l]){
					ans=max(ans,a[i]+a[maxx[i][k]]+a[maxx[j][l]]+a[j]);
				}
			}
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>K;
	for(int i=2;i<=n;i++)  cin>>a[i];
	for(int i=1;i<=m;i++){
		int x,y;
		cin>>x>>y;
		add(x,y);
		add(y,x);
	}
	dfs();
	cout<<ans;
	return 0;
}
