#include<bits/stdc++.h>
using namespace std;
int n,m,q,pd,a[100005],b[100005],qza[1005][1005],qzb[1005][1005],qzc[1005][1005],qzd[1005][1005];
void worka(){
	for(int i=1;i<=n;i++){
		int maxx=-0x7ffffff,minn=0x7ffffff;
		for(int j=i;j<=n;j++){
			maxx=max(maxx,max(a[i],a[j]));
			minn=min(minn,min(a[i],a[j]));
			qza[i][j]=maxx;
			qzc[i][j]=minn;
		}
	}
}
void workb(){
	for(int i=1;i<=m;i++){
		int maxx=-0x7ffffff,minn=0x7ffffff;
		for(int j=i;j<=m;j++){
			maxx=max(maxx,max(b[i],b[j]));
			minn=min(minn,min(b[i],b[j]));
			qzb[i][j]=minn;
			qzd[i][j]=maxx;
		}
	}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		if(a[i]<0)  pd=1;
	}
	for(int i=1;i<=m;i++)  cin>>b[i];
	worka();
	workb();
	if(pd==0){
		for(int k=1;k<=q;k++){
			int l1,l2,r1,r2;
			cin>>l1>>r1>>l2>>r2;
			if(l1==r1)  cout<<qzb[l2][r2]*a[l1]<<"\n";
			else  if(l2==r2)  cout<<qza[l1][r1]*b[l2]<<"\n";
			else  cout<<qza[l1][r1]*qzb[l2][r2]<<"\n";
		}
	}
	else{
		for(int k=1;k<=q;k++){
			int l1,l2,r1,r2;
			cin>>l1>>r1>>l2>>r2;
			if(l1==r1){
				if(a[l1]<0)  cout<<qzd[l2][r2]*a[l1]<<"\n";
				else  cout<<qzb[l2][r2]*a[l1]<<"\n";
			}
			else  if(l2==r2){
				if(b[l2]<0)  cout<<qzc[l1][r1]*b[l2]<<"\n";
				else  cout<<qza[l1][r1]*b[l2]<<"\n";
			}
			else{
				int x=0;
				for(int i=1;i<=n;i++)  if(a[i]==0){
					cout<<"0\n";
					x=1;
				}
				if(x==0){
					for(int j=1;j<=m;j++)  if(b[j]==0){
						cout<<"0\n";
						x=2;
					}
				}
				if(x==0){
					int minn=-0x7ffffff,y=1;
					for(int i=1;i<=n;i++){
						if(a[i]<0){
							if(minn<0-a[i])  y=i,minn=0-a[i];
						}
					}
					cout<<a[y]<<"\n";
				}
			}
		}
	}
	return 0;
}
