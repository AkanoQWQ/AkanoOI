#include<bits/stdc++.h>
#include<ctime>
using namespace std;
int n,m,q;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int u,v;
		cin>>u>>v;
	}
	cin>>q;
	srand(time(0));
	for(int i=1;i<=q;i++){
		int u,v,t,a;
		cin>>t;
		if(t==1)  cin>>u>>v;
		if(t==2)  cin>>u;
		if(t==3)  cin>>u>>v;
		if(t==4)  cin>>u;
		a=rand()%3+1;
		if(a==1||a==3)  cout<<"NO\n";
		else  cout<<"YES\n";
	}
}
