#include<bits/stdc++.h>
using namespace std;
const int maxn=1e4+10;
int n,m,q,e=-0x3f3f3f;
int a[1005],b[1005];
int c[1005][1005];
int vis[1005];
int l,r,ll,rr;
int main()
{
	freopen("game.in",r,"stdin");
	freopen("game.out",w,"stdout");
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=m;i++)
	{
		cin>>b[i];
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			c[i][j]=a[i]*b[j];
		}
	}
	int ans;
	int cnt;
	while(q--)
	{
		memset(vis,0X3f3f3f,sizeof(vis));
		
		cin>>l>>r>>ll>>rr;
		if(l==r)
		{
			for(int i=ll;i<=rr;i++)
			{
				ans=min(ans,c[l][i]);
			}
			cout<<ans<<endl;
		}
		if(ll==rr)
		{
			for(int i=l;i<=r;i++)
			{
				ans=max(ans,c[i][ll]);
			}
			cout<<ans<<endl;
		}
		else
		{
			for(int i=l;i<=r;i++)
			{
				for(int j=ll;j<=rr;j++)
				{
					vis[i]=min(vis[i],c[i][j]);
				}
			}
			for(int i=l;i<=r;i++)
			{
				e=max(vis[i]);
			}
			cout<<e;
			for(int i=l;i<=r;i++)
			{
				if(vis[i]==e)	cnt=i;
			}
				for(int j=ll;j<=rr;j++)
				{
					ans=min(ans,c[cnt][j]);
				}
				cout<<ans<<endl;
		}
		
		
	}
	return 0;
	
}
