#include<cstdio>
#include<iostream>
using namespace std;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m,u,v;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		cin>>u>>v;
	int q;
	cin>>q;
	while(q--){
		int t,u,v;
		cin>>t;
		if(t==1||t==3)
			cin>>u>>v;
		else if(t==2||t==4)
			cin>>u;
		cout<<"NO"<<'\n';
	}
	return 0;
}
