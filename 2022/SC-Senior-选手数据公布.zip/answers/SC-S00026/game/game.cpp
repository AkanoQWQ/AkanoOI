#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
#define int long long
int max(int x,int y){
	return x>=y?x:y;
}
int min(int x,int y){
	return x<=y?x:y;
}
const int N=1e5+7,LOG=18;
bool flag=1;
int n,m,q,a[N],b[N];
int l1,r1,l2,r2;
int log_2[N],st_a1[N][LOG+1],st_a2[N][LOG+1],st_b1[N][LOG+1],st_b2[N][LOG+1];
int query_a1(int l,int r){
	int log=log_2[r-l+1];
	return max(st_a1[l][log],st_a1[r-(1<<log)+1][log]);
}
int query_a2(int l,int r){
	int log=log_2[r-l+1];
	return min(st_a2[l][log],st_a2[r-(1<<log)+1][log]);
}
int query_b1(int l,int r){
	int log=log_2[r-l+1];
	return min(st_b1[l][log],st_b1[r-(1<<log)+1][log]);
}
int query_b2(int l,int r){
	int log=log_2[r-l+1];
	return max(st_b2[l][log],st_b2[r-(1<<log)+1][log]);
}
void solve(){
	scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
	if(flag){//��������1 
		printf("%lld\n",query_a1(l1,r1)*query_b1(l2,r2));
	}
	else{//��������2 
		if(l1==r1){
			if(a[l1]<0)
				printf("%lld\n",a[l1]*query_b2(l2,r2));
			else if(a[l1]>=0)
				printf("%lld\n",a[l1]*query_b1(l2,r2));
		}
		else if(l2==r2){
			if(b[l2]<0)
				printf("%lld\n",b[l2]*query_a2(l1,r1));
			else if(b[l2]>=0)
				printf("%lld\n",b[l2]*query_a1(l1,r1));
		}
	}
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	//��������65pts 
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
		st_a1[i][0]=st_a2[i][0]=a[i];
		flag&=(a[i]>0);
	}
	for(int i=1;i<=m;i++){
		scanf("%lld",&b[i]);
		st_b2[i][0]=st_b1[i][0]=b[i];
		flag&=(b[i]>0);
	}
	log_2[1]=0;
	for(int i=2;i<N;i++)
		log_2[i]=log_2[i>>1]+1;
	for(int j=1;j<=LOG;j++)
		for(int i=1;i+(1<<j)-1<=n;i++)
			st_a1[i][j]=max(st_a1[i][j-1],st_a1[i+(1<<j-1)][j-1]);
	for(int j=1;j<=LOG;j++)
		for(int i=1;i+(1<<j)-1<=n;i++)
			st_a2[i][j]=min(st_a2[i][j-1],st_a2[i+(1<<j-1)][j-1]);
	for(int j=1;j<=LOG;j++)
		for(int i=1;i+(1<<j)-1<=m;i++)
			st_b1[i][j]=min(st_b1[i][j-1],st_b1[i+(1<<j-1)][j-1]);
	for(int j=1;j<=LOG;j++)
		for(int i=1;i+(1<<j)-1<=m;i++)
			st_b2[i][j]=max(st_b2[i][j-1],st_b2[i+(1<<j-1)][j-1]);
	while(q--)
		solve();
	return 0;
}
