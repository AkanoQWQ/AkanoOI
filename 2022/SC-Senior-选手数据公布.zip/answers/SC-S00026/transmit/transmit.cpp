#include<cstdio>
#include<iostream>
using namespace std;
#define int long long
void swap(int &x,int &y){
	int t=x;
	x=y,y=t;
}
const int N=2e5+7,LOG=19;
int n,q,k,a[N];
struct graph{
	int head[N],edge_tot,to[N<<1],next[N<<1];
	void add_edge(int u,int v){
		edge_tot++;
		to[edge_tot]=v;
		next[edge_tot]=head[u];
		head[u]=edge_tot;
	}
}tree;
int fa[N],sum[N],depth[N];
void dfs(int u,int father){
	fa[u]=father;
	sum[u]+=sum[father];
	depth[u]=depth[father]+1;
	for(int i=tree.head[u],v;i;i=tree.next[i]){
		v=tree.to[i];
		if(v==father)
			continue;
		dfs(v,u);
	}
}
int get_lca(int x,int y){
	if(depth[x]<depth[y])
		swap(x,y);
	while(depth[x]>depth[y])
		x=fa[x];
	while(x!=y)
		x=fa[x],y=fa[y];
	return x;
}
signed main(){
	//k=1��n<=2000��8pts 
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
		sum[i]=a[i];		
	}
	for(int i=1,u,v;i<n;i++){
		cin>>u>>v;
		tree.add_edge(u,v);
		tree.add_edge(v,u);
	}
	dfs(1,0);
	for(int i=1,s,t,lca;i<=q;i++){
		scanf("%d%d",&s,&t);
		lca=get_lca(s,t);
		printf("%lld\n",sum[s]+sum[t]-2*sum[lca]+a[lca]);
	}
	return 0;
}
