#include<cstdio>
#include<iostream>
using namespace std;
#define int long long
#define err putchar('W');
const int N=2507,M=2e4+7;
int max(int x ,int y){
	return x>=y?x:y;
}
int n,m,k,a[N];
struct graph{
	int head[N],edge_tot,to[M],next[M];
	void add_edge(int u,int v){
		edge_tot++;
		to[edge_tot]=v;
		next[edge_tot]=head[u];
		head[u]=edge_tot;
	}
}G;
bool vis[N];
int dp[N][7],ans;
void dfs(int u,int _last,int dep){
//	cout<<u<<' ';
	if(u==1&&0<dep&&dep<=4)
		return;
	if(dep>4){
		if(u==1)
			ans=max(ans,dp[u][dep]);
		return;
	}
	for(int i=G.head[u],v;i;i=G.next[i]){
		v=G.to[i];
		if(v==_last||vis[v]||(v==1&&dep!=4))
			continue;
		vis[v]=1;
		dp[v][dep+1]=max(dp[v][dep+1],dp[u][dep]+a[v]);
//		printf("%d->%d %d %d\n",u,v,dep,vis[v]);
		dfs(v,u,dep+1);
		vis[v]=0;
	}
}
signed main(){
	//k=0��[0,10]pts 
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++)
		scanf("%lld",&a[i]);
	for(int i=1,u,v;i<=m;i++){
		scanf("%d%d",&u,&v);
		G.add_edge(u,v);
		G.add_edge(v,u);
	}
	dfs(1,0,0);
	printf("%lld",ans);
	return 0;
}
