#pragma GCC optimize(2)
#include <bits/stdc++.h>
#define ll long long
using namespace std;

const int maxn=5e5+5;
const int maxm=5e5+5;
const int maxn2=1005;

int n,m,q,cnt,head[maxn],mp[maxn2][maxn2];
struct Edge{
	int to,nxt;
	bool yon;
}edge[maxm];
bool pt[maxn];

inline void Add(int fo,int to){
	edge[++cnt]={to,head[fo],true};
	head[fo]=cnt;
}

bool vis[maxn];
inline bool dfs(int x){
	vis[x]=true;
	for(int i=head[x];i;i=edge[i].nxt){
		int &to=edge[i].to;
		if(!pt[edge[i].to]) continue;
		if(vis[to]) return true;
		if(dfs(to)) return true;
	}
	return false;
}

inline bool Check(){
	for(int i=1;i<=n;++i){
		if(!pt[i]) continue;
		int tot=0;
		for(int j=head[i];j;j=edge[j].nxt)
			if(edge[j].yon&&pt[edge[j].to]) ++tot;
		if(tot^1) return false;
	}
	
	memset(vis,0,sizeof(vis));
	for(int i=1;i<=n;++i)
		if(pt[i]){
			if(!dfs(1)) return false;
			else return true;
		}
	return false;	
}

inline void solve(){
	cin>>q;
	int opt,fo,to;
	while(q--){
		cin>>opt;
		if(opt==1){
			cin>>fo>>to;
			edge[mp[fo][to]].yon=false;
		} else if(opt==2){
			cin>>fo;
			pt[fo]=false;
		} else if(opt==3){
			cin>>fo>>to;
			edge[mp[fo][to]].yon=true;
		} else{
			cin>>fo;
			pt[fo]=true;
		}
		
		if(Check()) cout<<"YES\n";
		else cout<<"NO\n";
	}
	return ;
}

int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	
	cin>>n>>m;
	int fo,to;
	for(int i=1;i<=m;++i){
		cin>>fo>>to;
		Add(fo,to);
		mp[fo][to]=i;
	}
	for(int i=1;i<=n;++i)
		pt[i]=true;
	solve();
	return 0;
}

