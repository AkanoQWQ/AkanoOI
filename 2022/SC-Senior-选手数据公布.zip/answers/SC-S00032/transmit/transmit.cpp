#pragma GCC optimize(2)
#include <bits/stdc++.h>
#define ll long long
using namespace std;

const int maxn=2e5+5;
const int maxn2=2005;

int n,m,k,cnt,head[maxn];
bool yon[maxn2][maxn2];
struct Edge{
	int to,nxt;
}edge[maxn<<1];
inline void Add(int fo,int to){
	edge[++cnt]={to,head[fo]};
	head[fo]=cnt;
	return ;
}

inline void dfs1(int pos,int x,int d){
	yon[pos][x]=true;
	if(d==k) return ;
	for(int i=head[x];i;i=edge[i].nxt){
		int &to=edge[i].to;
		dfs1(pos,to,d+1);
	}
	return ;
}

ll v[maxn];
ll dis[maxn2][maxn2];
bool vis[maxn];
inline void spfa(int pos){
	queue<int> q;
	q.push(pos);
	dis[pos][pos]=v[pos];
	while(!q.empty()){
		int x=q.front(); q.pop();
		vis[x]=false;
		for(int i=1;i<=n;++i){
			int to=i;
			if(!yon[x][to]) continue;
			if(dis[pos][to]>dis[pos][x]+v[to]){
				dis[pos][to]=dis[pos][x]+v[to];
				if(!vis[to]) vis[to]=true,q.push(to);
			}
		}
	}
	return ;
}

inline void solve(){
	for(int i=1;i<=n;++i)
		dfs1(i,i,0);
	
	memset(dis,0x7f7f,sizeof(dis));
	for(int i=1;i<=n;++i)
		spfa(i);
	
	int fo,to;
	while(m--){
		cin>>fo>>to;
		cout<<dis[fo][to]<<'\n';
	}
	return ;
}

int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	
	cin>>n>>m>>k;
	for(int i=1;i<=n;++i)
		cin>>v[i];
	int fo,to;
	for(int i=1;i<n;++i){
		cin>>fo>>to;
		Add(fo,to);
		Add(to,fo);
	}
	solve();
	return 0;
}

