#pragma GCC optimize(2)
#include <bits/stdc++.h>
#define ll long long
#define mod 998244353
using namespace std;

const int maxn=2505;
const int maxm=10005;
const int N=7;

int n,m,k,cnt,head[maxn];

struct Edge{
	int to,nxt;
}edge[maxm<<1];

inline void Add(int fo,int to){
	edge[++cnt]={to,head[fo]};
	head[fo]=cnt;
	return ;
}

ll a[maxn],f[N][maxn];
int dis[maxn][maxn];
bool vis[maxn],yon[maxn][maxn];
inline void bfs(int pos){
	queue <int> q;
	q.push(pos);
	vis[pos]=true;
	while(!q.empty()){
		int x=q.front(); q.pop();
		for(int i=head[x];i;i=edge[i].nxt){
			int &to=edge[i].to;
			if(vis[to]) continue;
			vis[to]=true;
			dis[pos][to]=dis[pos][x]+1;
			q.push(to);
		}
	}
	memset(vis,0,sizeof(vis));
	return ;
}

inline ll Max(ll A,ll B)
{return A>B?A:B;}

ll ans;
inline void dfs(int tot,int pos1,int pos2,ll val){
	if(tot==2){
		if(yon[pos1][pos2]) ans=Max(ans,val);
		return ;
	}
	
	if(!tot){
		for(int i=2;i<n;++i){
			if(vis[i]||!yon[pos1][i]) continue;
			for(int j=i+1;j<=n;++j){
				if(vis[j]||!yon[pos2][j]) continue;
				vis[i]=vis[j]=true;
				dfs(tot+1,i,j,val+a[i]+a[j]);
				vis[i]=vis[j]=false;
			}
		}
	} else{
		for(int i=2;i<=n;++i){
			if(vis[i]||!yon[pos1][i]) continue;
			for(int j=2;j<=n;++j){
				if(vis[j]||!yon[pos2][j]) continue;
				vis[i]=vis[j]=true;
				dfs(tot+1,i,j,val+a[i]+a[j]);
				vis[i]=vis[j]=false;
			}
		}
	}
	return ;
}

inline void solve(){
	memset(dis,-1,sizeof(dis));
	for(int i=1;i<=n;++i)
		bfs(i);
	
	for(int i=1;i<n;++i)
		for(int j=i+1;j<=n;++j)
			if(dis[i][j]!=-1&&dis[i][j]<=k)
				yon[i][j]=yon[j][i]=true;
	
	dfs(0,1,1,0);
	cout<<ans<<'\n';
	return ;
}

int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	
	cin>>n>>m>>k;
	for(int i=2;i<=n;++i)
		cin>>a[i];
	
	int fo,to;
	for(int i=1;i<=m;++i){
		cin>>fo>>to;
		Add(fo,to);
		Add(to,fo);
	}
	
	solve();
	return 0;
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1

27
----------
7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4

7
*/
