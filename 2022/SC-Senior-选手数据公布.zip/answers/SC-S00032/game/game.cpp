#pragma GCC optimize(2)
#include <bits/stdc++.h>
#define ll long long
#define llinf 0x7f7f7f7f7f7f7f7f
using namespace std;

const int maxn=1e5+5;
const int MAXN=2005;

int n,m,q;
ll a[maxn],b[maxn];
ll mp[MAXN][MAXN];

#define ls node[col][x].lch
#define rs node[col][x].rch
int cnt;
struct Node{
	int l,r,lch,rch;
	ll mn;
}node[MAXN][MAXN<<1];//column

inline ll Max(ll A,ll B)
{return A>B?A:B;}
inline ll Min(ll A,ll B)
{return A<B?A:B;}

inline int build(int col,int l,int r){
	int x=++cnt;
	node[col][x].l=l,node[col][x].r=r;
	if(l==r){
		node[col][x].mn=mp[col][l];
		return x;
	} int mid=(l+r)>>1;
	ls=build(col,l,mid),rs=build(col,mid+1,r);
	node[col][x].mn=Min(node[col][ls].mn,node[col][rs].mn);
	return x;
}

inline ll query(int col,int x,int l,int r){
	if(node[col][x].l>=l&&node[col][x].r<=r)
		return node[col][x].mn;
	int mid=(node[col][x].l+node[col][x].r)>>1;
	ll res=llinf;
	if(l<=mid) res=Min(res,query(col,ls,l,r));
	if(r>mid) res=Min(res,query(col,rs,l,r));
	return res;
}

inline void solve1(){
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
			mp[i][j]=a[i]*b[j];
	
	for(int i=1;i<=n;++i)
		build(i,1,m),cnt=0;
	
	int l1,l2,r1,r2;
	while(q--){
		cin>>l1>>r1>>l2>>r2;
		ll ans=-llinf;
		for(int i=l1;i<=r1;++i)
			ans=Max(ans,query(i,1,l2,r2));
		cout<<ans<<'\n';
	}
	return ;
}

inline void solve(){
	return ;
}

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	
	cin>>n>>m>>q;
	for(int i=1;i<=n;++i)
		cin>>a[i];
	for(int i=1;i<=m;++i)
		cin>>b[i];
	if(n<2000&&m<2000)
		solve1();
	else solve();
	
	return 0;
}

