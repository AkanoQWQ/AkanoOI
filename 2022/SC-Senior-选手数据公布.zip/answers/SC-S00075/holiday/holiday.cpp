#include <cstdio>
#include <queue>
#define _min(a,b) ((a)<(b)?(a):(b))
#define _max(a,b) ((a)>(b)?(a):(b))

struct node{
	int u,w;
	bool operator < (const node a) const{
		return w<a.w;
	}
};
//e
struct edge{
	int to,nxt;
	edge(){
		nxt=-1;
		return;
	} 
}e[10010<<1];
int head[2510],short_path[2510][2510],tot,dis[2510][2510],dp[3][2510],maxp,n;
unsigned long long socer,ansend;
unsigned long long a[2510];
char em[2510][2510],book[2510];
//add
void addEdge(int u,int v){
	em[u][v]=1;
	e[tot].nxt=head[u];
	e[tot].to=v;
	head[u]=tot;
	++tot;
	return;
}

unsigned long long count(int step,int p){
	if(step==4){
		ansend=_max(ansend,socer);
		return 0;
	}
	unsigned long long ans=0-1;
	for(int i=2;i<=n;++i){
		if(!book[i]&&dis[i][p]<=maxp&&(step!=3||dis[1][i]<=maxp)){
			book[i]=1;
			socer+=a[i];
			ans=_max(count(step+1,i),ans);
			socer-=a[i];
			book[i]=0;
		}
	}
	return ans; 
}

int read(){
	long long x=0;char f=0,c=getchar();
	while(c<'0'||'9'<c) f|=(c=='-'),c=getchar();
	while('0'<=c&&c<='9') x=(x<<1)+(x<<3)+(c&15),c=getchar();
	return f?-x:x; 
}

std::priority_queue<node> Q; 

int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	
	register int i,j,k,u,v;
	//read
	n=read();
	int m=read();
	maxp=read()+1;
	for(i=1;i<=n;++i) head[i]=-1;
	for(i=2;i<=n;++i) a[i]=read();
	for(i=0;i<m;++i){
		u=read();
		v=read();
		addEdge(u,v);
		addEdge(v,u);
	}
	

	
	//floyd
	if(n<=300){
		for(i=1;i<=n;++i)
			for(j=1;j<=n;++j)
				if(i!=j)
					dis[i][j]=em[i][j]?1:0x3f3f3f3f;
				else
					dis[i][j]=0;
		for(k=1;k<=n;++k)
			for(i=1;i<=n;++i)
				for(j=1;j<=n;++j)
					dis[i][j]=_min(dis[i][j],dis[i][k]+dis[k][j]);
	}else{
		for(i=1;i<=n;++i) dis[1][i]=0x3f3f3f3f,book[i]=0;
		dis[1][1]=0;
		Q.push((node){1,0});
		while(!Q.empty()){
			u=Q.top().u;
			Q.pop();
			if(book[u]) continue;
			book[u]=1;
			for(i=head[u];~i;i=e[i].nxt)
				if(dis[1][e[i].to]<dis[1][u]+1){
					dis[1][e[i].to]=dis[1][u]+1;
					if(!book[e[i].to]) Q.push((node){e[i].to,dis[1][e[i].to]});
				}
		}
		for(k=2;k<=n;++k){
			if(dis[1][k]>maxp*6) continue; 
			for(i=1;i<=n;++i) dis[k][i]=0x3f3f3f3f,book[i]=0;
			dis[i][1]=0;
			Q.push((node){1,0});
			while(!Q.empty()){
				u=Q.top().u;
				Q.pop();
				if(book[u]) continue;
				book[u]=1;
				for(i=head[u];~i;i=e[i].nxt)
					if(dis[i][e[i].to]<dis[i][u]+1){
						dis[i][e[i].to]=dis[i][u]+1;
						if(!book[e[i].to]) Q.push((node){e[i].to,dis[i][e[i].to]});
					}
			}
		}
	}
	
//	for(i=1;i<=n;++i){
//		for(j=1;j<=n;++j)
//			printf("%d ",dis[i][j]);
//		putchar('\n');
//	}
	

	for(i=1;i<=n;++i) book[i]=0;
	count(0,1);

	printf("%lld",ansend);
	
	return 0;
}
