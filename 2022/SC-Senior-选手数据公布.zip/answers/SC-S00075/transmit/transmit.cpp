#include <cstdio>
#include <algorithm>
#include <queue>
#define _min(a,b) ((a)<(b)?(a):(b))
#define _max(a,b) ((a)>(b)?(a):(b))
//e
struct rmq{
	int f[200000][20];
	void build(int n,int *p){
		register int i,j;
		int k=std::__lg(n);
		for(i=1;i<=n;++i) f[i][0]=p[i];
		
		for(j=1;j<=k;++j)
			for(i=1;i<=n;++i)
				f[i][j]=f[f[i][j-1]][j-1];
		return;
	}
}st;

struct edge{
	int to,nxt;
	edge(){
		nxt=-1;
		return;
	} 
}tree[200010<<1];
int tot,head[200010],dep[200010],pa[200010],V[200010];
long long V_pre[200010];
//add
void addEdge(int u,int v){
	tree[tot].nxt=head[u];
	tree[tot].to=v;
	head[u]=tot;
	++tot;
	return;
}

int read(){
	long long x=0;char f=0,c=getchar();
	while(c<'0'||'9'<c) f|=(c=='-'),c=getchar();
	while('0'<=c&&c<='9') x=(x<<1)+(x<<3)+(c&15),c=getchar();
	return f?-x:x; 
}

void dfs(int u,int p){
	pa[u]=p;
	dep[u]=dep[p]+1;
	V_pre[u]=V_pre[p]+V[u];
	for(int i=head[u];~i;i=tree[i].nxt){
		if(tree[i].to!=p)
			dfs(tree[i].to,u);
	}
}

int getlca(int u,int v){
	if(dep[u]<dep[v]){
		u^=v;
		v=u^v;
		u=u^v;
	}
	int k=std::__lg(dep[u]-dep[v]);
	register int i;
	for(i=k;i>=0;--i){
		if(dep[st.f[u][i]]>=dep[v])
			u=st.f[u][i];
	}
	if(u==v) return u;
	k=std::__lg(dep[u]);
	for(i=k;i>=0;--i){
		if(st.f[u][i]!=st.f[v][i])
			u=st.f[u][i],v=st.f[v][i];
	}
	return st.f[u][0];
}
/*
7 100 3
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7
*/
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	
	register int i,u,v,lca;
	int n=read();
	int Q=read();
	int k=read();
	for(i=1;i<=n;++i) V[i]=read(),head[i]=-1;
	
	for(i=1;i<n;++i){
		u=read();
		v=read();
		addEdge(u,v);
		addEdge(v,u);
	}
	
	dfs(1,1);
	
	st.build(n,pa);
	
	pa[1]=0; 
	
	for(i=0;i<Q;++i){
		u=read();
		v=read();
		lca=getlca(u,v);
		printf("%lld\n",V_pre[u]+V_pre[v]-V_pre[pa[lca]]*2-V[lca]);
	}
	
	return 0;
}
