#include<iostream>
#include<cstdio>
#include<cmath>
#define ll long long
using namespace std;
const int N=1e5+10,INF=1e9;
template <class T>
inline void read(T &x)
{
	x=0;bool f=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	if(f)x=-x;
}
template <class T,class ...T1>
inline void read(T &x,T1 &...x1)
{
	read(x),read(x1...);
}
int n,m,q;
int a[N],b[N];
struct Node1
{
	int l,r;
	int minx,maxx;
};
struct Tree1
{
	Node1 tr[N<<2];
	void pushup(int x)
	{
		tr[x].minx=min(tr[x<<1].minx,tr[x<<1|1].minx);
		tr[x].maxx=max(tr[x<<1].maxx,tr[x<<1|1].maxx);
	}
	void build(int x,int l,int r,int p)
	{
		tr[x].l=l,tr[x].r=r;
		if(l==r)
		{
			tr[x].minx=tr[x].maxx=(!p)?a[l]:b[l];
			return ;
		}
		int mid=l+r>>1;
		build(x<<1,l,mid,p);
		build(x<<1|1,mid+1,r,p);
		pushup(x);
	}
	int qmin(int x,int l,int r)
	{
		if(tr[x].l>=l&&tr[x].r<=r)
			return tr[x].minx;
		int mid=tr[x].l+tr[x].r>>1;
		int res=INF;
		if(l<=mid)res=min(res,qmin(x<<1,l,r));
		if(r>mid)res=min(res,qmin(x<<1|1,l,r));
		return res;
	}
	int qmax(int x,int l,int r)
	{
		if(tr[x].l>=l&&tr[x].r<=r)
			return tr[x].maxx;
		int mid=tr[x].l+tr[x].r>>1;
		int res=-INF;
		if(l<=mid)res=max(res,qmax(x<<1,l,r));
		if(r>mid)res=max(res,qmax(x<<1|1,l,r));
		return res;
	}
}t1,t2;
struct Node2
{
	int l,r;
	int val;
};
struct Tree2
{
	Node2 tr[N<<2];
	void pushup(int x)
	{
		tr[x].val=min(tr[x<<1].val,tr[x<<1|1].val);
	}
	void build(int x,int l,int r,int p)
	{
		tr[x].l=l,tr[x].r=r;
		if(l==r)
		{
			if(!p)
			{
				if(a[l]>=0)tr[x].val=a[l];
				else tr[x].val=INF;
			}
			else
			{
				if(a[l]<=0)tr[x].val=-a[l];
				else tr[x].val=INF;
			}
			return ;
		}
		int mid=l+r>>1;
		build(x<<1,l,mid,p);
		build(x<<1|1,mid+1,r,p);
		pushup(x);
	}
	int qmin(int x,int l,int r)
	{
		if(tr[x].l>=l&&tr[x].r<=r)
			return tr[x].val;
		int mid=tr[x].l+tr[x].r>>1;
		int res=INF;
		if(l<=mid)res=min(res,qmin(x<<1,l,r));
		if(r>mid)res=min(res,qmin(x<<1|1,l,r));
		return res;
	}
}t3,t4;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	read(n,m,q);
	for(int i=1;i<=n;i++)
		read(a[i]);
	for(int i=1;i<=m;i++)
		read(b[i]);
	t1.build(1,1,n,0),t2.build(1,1,m,1);
	t3.build(1,1,n,0),t4.build(1,1,n,1);
	while(q--)
	{
		int l1,r1,l2,r2;
		ll ans;
		read(l1,r1,l2,r2);
		int min1=t1.qmin(1,l1,r1),max1=t1.qmax(1,l1,r1);
		int min2=t2.qmin(1,l2,r2),max2=t2.qmax(1,l2,r2);
		int ne1=t3.qmin(1,l1,r1),ne2=-t4.qmin(1,l1,r1);
		if(min1>=0)
		{
			if(min2>=0)ans=1ll*max1*min2;
			else ans=1ll*min1*min2;
		}
		else if(max1<=0)
		{
			if(max2<=0)ans=1ll*min1*max2;
			else ans=1ll*max1*max2;
		}
		else 
		{
			if(min2>=0)
				ans=1ll*max1*min2;
			else if(max2<=0)
				ans=1ll*min1*max2;
			else ans=max(1ll*ne1*min2,1ll*ne2*max2);
		}
		printf("%lld\n",ans);
	}
	return 0;
}
