#include<iostream>
#include<cstdio>
#include<cstring>
#define ll long long
using namespace std;
const int N=3e3+10,M=1e5+10;
template <class T>
inline void read(T &x)
{
	x=0;bool f=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	if(f)x=-x;
}
template <class T,class ...T1>
inline void read(T &x,T1 &...x1)
{
	read(x),read(x1...);
}
inline void write(__int128 x)
{
	if(x>=10)
	write(x/10);
	putchar(x%10+'0');
}
int n,m,t;
__int128 a[N];
int d[N][N];
int tot,head[N],ver[M],ne[M];
__int128 ans;
int vis[N];
inline void add(int u,int v)
{
	ver[++tot]=v;
	ne[tot]=head[u];
	head[u]=tot;
}
void dfs(int x,__int128 sum,int d)
{
	if(d>4)return ;
	for(int i=head[x];i;i=ne[i])
	{
		int y=ver[i];
		if(y==1)
		{
			if(d==4)ans=max(ans,sum);
			return ;
		}
		else
		{
			vis[y]=1;
			dfs(y,sum+a[y],d+1);
			vis[y]=0;
		}
	}
}
void sub()
{
	vis[1]=1;
	dfs(1,0,0);
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	memset(d,0x3f,sizeof(d));
	read(n,m,t);
	
	for(int i=2;i<=n;i++)
		read(a[i]),d[i][i]=0;
	for(int i=1;i<=m;i++)
	{
		int u,v;
		read(u,v);
		d[u][v]=d[v][u]=1;
		add(u,v),add(v,u);
	}
	if(t==0&&n>=100)
	{
		sub();
		write(ans);
		return 0;
	}
	t++;
	for(int k=1;k<=n;k++)
		for(int i=1;i<=n;i++)
			if(d[i][k]<=t)
			for(int j=1;j<=n;j++)
				d[i][j]=min(d[i][j],d[i][k]+d[k][j]);
	for(int i=2;i<=n;i++)
	{
		if(d[1][i]<=t)
		for(int j=i+1;j<=n;j++)
			if(d[1][j]<=t&&i!=j)
			for(int p=2;p<=n;p++)
				if(d[i][p]<=t&&i!=p&&j!=p)
				for(int q=2;q<=n;q++)
				{
					if(i!=q&&j!=q&&p!=q&&d[j][q]<=t&&d[p][q]<=t)
						ans=max(ans,a[i]+a[j]+a[p]+a[q]);
				}
	}
	write(ans);
	return 0;
}
