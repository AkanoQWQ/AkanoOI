#include<iostream>
#include<cstdio>
#include<cstring>
#include<vector>
#define ll long long
using namespace std;
const int N=3e3+10,M=5e5+10,INF=1e9;
template <class T>
inline void read(T &x)
{
	x=0;bool f=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	if(f)x=-x;
}
template <class T,class ...T1>
inline void read(T &x,T1 &...x1)
{
	read(x),read(x1...);
}
int n,m,q;
int d[N][N],cnt[N];
int tot,head[N],ver[M],ne[M];
int vis[N];
bool flag;
vector<int>e[N];
inline void add(int u,int v)
{
	ver[++tot]=v;
	ne[tot]=head[u];
	head[u]=tot;
}
bool check1()
{
	for(int i=1;i<=n;i++)
		if(cnt[i]!=1)
			return 0;
	return 1;
}
void dfs(int x)
{
	if(flag)return ;
	vis[x]=1;
	for(int i=head[x];i;i=ne[i])
	{
		int y=ver[i];
		if(!d[x][y])continue;
		if(vis[y])return flag=1,void();
		dfs(y);
	}
	vis[x]=0;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	read(n,m);
	for(int i=1;i<=m;i++)
	{
		int u,v;
		read(u,v);
		d[u][v]=1;
		cnt[u]++;
		add(u,v);
		e[v].push_back(u);
	}
	read(q);
	while(q--)
	{
		int op,u,v;
		read(op);
		if(op==1)
		{
			read(u,v);
			d[u][v]=0;
			cnt[u]--;
		}
		else if(op==2)
		{
			read(u);
			int si=e[u].size();
			for(int i=0;i<si;i++)
				if(d[e[u][i]][u])
					d[e[u][i]][u]=0,cnt[e[u][i]]--;
		}
		else if(op==3)
		{
			read(u,v);
			d[u][v]=1;
			cnt[u]++;
		}
		else 
		{
			read(u);
			int si=e[u].size();
			for(int i=0;i<si;i++)
				if(!d[e[u][i]][u])
					d[e[u][i]][u]=1,cnt[e[u][i]]++;
		}
		flag=0;
		if(check1())
		{
			memset(vis,0,sizeof(vis));
			dfs(1);
			if(flag)puts("YES");
			else puts("NO");
		}
		else puts("NO");
	}
	return 0;
}
