#include <bits/stdc++.h>
using namespace std;
const int INF = 2e4+1;
int Map[INF][INF];
int v[INF];
int n,q,k; 
int main ()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	return 0;
}
