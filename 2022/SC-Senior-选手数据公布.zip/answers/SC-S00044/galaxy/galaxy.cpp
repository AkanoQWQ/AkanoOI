#include <bits/stdc++.h>
using namespace std;
int n,m,q;
int main ()
{
	int u,v;
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for (int i = 1;i<=m;i++)
		cin>>u>>v;
	cin>>q;
	for (int o = 1;o<=q;o++)
	{
		int type;cin>>type;
		if (type == 1)
			cin>>u>>v;
		else if (type == 2)
			cin>>u;
		else if (type == 3)
			cin>>u>>v;
		else if (type == 4) 
			cin>>u;
		cout<<"NO"<<endl;
	}
	return 0;
}
