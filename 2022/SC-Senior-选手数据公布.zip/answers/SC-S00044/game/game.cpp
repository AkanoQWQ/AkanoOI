#include <bits/stdc++.h>
using namespace std;
const int INF = 1e5+1;
const int INT = 0x3f3f3f3f;
int a[INF],b[INF];
int Min[INF];
int n,m,q;
int main ()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for (int i = 1;i<=n;i++)
		cin>>a[i];
	for (int j = 1;j<=m;j++)
		cin>>b[j];
	for (int o = 1;o<=q;o++)
	{
		memset(Min,INT,sizeof(Min));
		int ans = -INT;
		int l1,r1,l2,r2;
		cin>>l1>>r1>>l2>>r2;
		for (int i = l1;i<=r1;i++)
			for(int j = l2;j<=r2;j++)	
				Min[i] = min(a[i]*b[j],Min[i]);
		int MIN = -INT;
		int Pos ;
		for(int i = l1;i<=r1;i++)
		{
			if (Min[i] >= MIN)
			{
				Pos = i;
				MIN = Min[i];
			}
		}
		ans = Min[Pos];
		cout<<ans<<'\n';
	}
	return 0;
}
