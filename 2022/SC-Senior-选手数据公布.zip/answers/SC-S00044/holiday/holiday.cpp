#include <bits/stdc++.h>
using namespace std;
const int INF = 2501;
const int INT = 0x3f3f3f3f;
bool Map[INF][INF];
int w[INF];
int n,m,k;
bool mark[INF];
int ans,temp1;
bool condition = true;
void dfs(int pos,int times,int travel,int now)
{
	if (times > k)
		return ;
	if (travel == 4)
	{
		if (Map[pos][1] != true)
		{
			condition = false;
			return;
		}
		else
		{
			temp1 = now;
			return ;
		}
	}

	for (int i = 1;i<=n;i++)
	{
		if (mark[i] == true && Map[pos][i] == true)
			dfs(i,times+1,travel,now);
		else if (Map[pos][i] == true)
		{
			dfs(i,times+1,travel,now);
			mark[i] = true;
			now = now + w[pos];
			dfs(i,times,travel+1,now+w[pos]);				
		}	
	}
}
void add(int u,int v)
{
	Map[u][v] = true;
	Map[v][u] = true;
}
int main ()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	w[1] = 0;
	for (int i = 2;i<=n;i++)
		cin>>w[i];
	for (int i = 1;i<=m;i++)
	{
		int u,v;cin>>u>>v;
		add(u,v);
	}
	for (int i = 1;i<=n;i++)
	{
		memset(mark,false,sizeof(mark));
		condition = true;
		if(Map[1][i] == true)
		{
			dfs(i,0,0,0);
			if (condition == false)
				continue;	
			ans = max(temp1,ans);	
		}
		else
			continue;
	}
	cout<<ans;
	return 0;
}
