#include <bits/stdc++.h>
using namespace std;
const int N = 2.5e3 + 12;
int n, m, lim;
long long s[N], ans;
int d[N][N];

int main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	cin >> n >> m >> lim;
	for (int i = 2; i <= n; i++)
		scanf("%lld", s + i);
	memset(d, 0x3f, sizeof d);
	for (int i = 1, a, b; i <= m; i++) {
		scanf("%d%d", &a, &b);
		d[b][a] = d[a][b] = 1;
	}
	for (int k = 1; k <= n; k++)
		for (int i = 1; i <= n; i++)
			for (int j = 1; j <= n; j++)
				d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
	for (int i = 1; i <= n; i++) 
		d[i][i] = 0x3f3f3f3f;
	
	for (int i = 2; i <= n; i++) if(d[1][i] <= lim + 1)
		for (int j = 2; j <= n; j++) if(d[i][j] <= lim + 1)
			for (int k = 2; k <= n; k++) if(i != k && d[j][k] <= lim + 1)
				for (int u = 2; u <= n; u++) if(i != u && j != u && d[k][u] <= lim + 1)
					if(d[u][1] <= lim + 1) {
						ans = max(ans, s[i] + s[j] + s[k] + s[u]);
					}
	printf("%lld", ans);
	
}
