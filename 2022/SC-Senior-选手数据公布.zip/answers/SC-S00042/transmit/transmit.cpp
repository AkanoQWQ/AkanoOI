#include <bits/stdc++.h>
using namespace std;
const int N = 2e4 + 12;
int n, v[N], Q, lim;
vector<int> son[N];
int d[N], f[N][23], fa[N], t, q[N], l, r;
long long g[N];
vector<int> vec, vec2;

void dfs(int x) {
	d[x] = d[fa[x]] + 1;
	for (int j = 0; j < son[x].size(); j++) {
		int y = son[x][j];
		if (y == fa[x]) continue;
		fa[y] = x;
		f[y][0] = x;
		for (int i = 1; i <= t; i++)
			f[y][i] = f[f[y][i - 1]][i - 1];
		dfs(y);		
	}
}

int lca(int x, int y) {
	if (d[x] > d[y]) swap(x, y);
	for (int i = t; i >= 0; i--)
		if (d[f[y][i]] >= d[x]) y = f[y][i];
	if (x == y) return x;
	for (int i = t; i >= 0; i--)
		if (f[y][i] != f[x][i]) y = f[y][i], x = f[x][i];
	return f[x][0];
}

long long work() {
	l = 1, r = 0; q[l] = 0, g[0] = 0;
	memset(g, 0, sizeof g);
	memset(q, 0, sizeof q);
	for (int i = 0; i < vec.size(); i++) {
		while (l <= r && i - q[l] > lim) l++;
		g[i] = g[q[l]] + v[vec[i]];
		while (l <= r && g[i] <= g[q[r]]) r--;
		q[++r] = i;
	}
//	cout << endl;
	return g[vec.size() - 1];
}

int main() {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	cin >> n >> Q >> lim;
	t = log2(n);
	for (int i = 1; i <= n; i++)
		scanf("%d", v + i);
	for (int i = 1, a, b; i < n; i++) {
		scanf("%d%d", &a, &b);
		son[a].push_back(b); son[b].push_back(a);
	}
	dfs(1);
	for (int i = 1, a, b; i <= Q; i++) {
		scanf("%d%d", &a, &b);
		int anc = lca(a, b);
//		cout << "anc " << anc << endl;
		vec.clear();vec2.clear(); 
		int x = a;
		while (x != anc) vec.push_back(x), x = fa[x];
		vec.push_back(anc);
		x = b;
		while (x != anc) vec2.push_back(x), x = fa[x];
		reverse(vec2.begin(), vec2.end());
		for (int j = 0; j < vec2.size(); j++)
			vec.push_back(vec2[j]);
		printf("%lld\n", work());
	}
}




















