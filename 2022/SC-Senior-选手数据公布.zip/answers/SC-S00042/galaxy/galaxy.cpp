#include <bits/stdc++.h>
using namespace std;
const int N = 1e4;
int main() {
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	int n, m;
	cin >> n >> m;
	for (int i = 1, a, b; i <= m; i++)
		scanf("%d%d", &a, &b);
	cin >> m;
	for (int i = 1, op, a, b; i <= m; i++) {
		puts(rand() & 1 ? "YES" : "NO");
	}
}
