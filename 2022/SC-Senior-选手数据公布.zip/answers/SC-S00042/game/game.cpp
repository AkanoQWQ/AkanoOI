#include <bits/stdc++.h>
using namespace std;
const int N = 1e5 + 12, inf = -1044266559;
int n, m, q;
int pw2[N];
struct ST_Form {
	int f[2][N][22], tot;
	ST_Form() {
		memset(f[0], 0x3f, sizeof f[0]);
		memset(f[1], -0x3f, sizeof f[1]);
	}
	void prework() {
		for (int j = 1; j <= pw2[tot] + 1; j++)
			for (int i = 1; i + (1 << j) <= tot + 1; i++) {
				f[1][i][j] = max(f[1][i][j - 1], f[1][i + (1 << j - 1)][j - 1]);
				f[0][i][j] = min(f[0][i][j - 1], f[0][i + (1 << j - 1)][j - 1]);
			}
	}
	int askmax(int l, int r) {
		int k = pw2[r - l + 1];
		return max(f[1][l][k], f[1][r - (1 << k) + 1][k]);
	}
	int askmin(int l, int r) {
		int k = pw2[r - l + 1];
		return min(f[0][l][k], f[0][r - (1 << k) + 1][k]);
	}
}b, a0, a1;

int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	cin >> n >> m >> q;
	for (int i = 2; i <= max(n, m); i++)
		pw2[i] = pw2[i >> 1] + 1;
	for (int i = 1, x; i <= n; i++) {
		scanf("%d", &x);
		if (x > 0) {
			a1.f[0][i][0] = a1.f[1][i][0] = x;
		} else if (x < 0) {
			a0.f[0][i][0] = a0.f[1][i][0] = x;
		} else a1.f[0][i][0] = a1.f[1][i][0] = a0.f[0][i][0] = a0.f[1][i][0] = 0;
	}
	for (int i = 1; i <= m; i++) 
		scanf("%d", &b.f[0][i][0]), b.f[1][i][0] = b.f[0][i][0];
	
	a0.tot = a1.tot = n;
	a0.prework();
	a1.prework();
	b.tot = m;
	b.prework();
//	long long val = -1e18;
//	for (int i = 43; i <= 102; i++)
//		val = max(1ll * a1.f[1][i][0], max(val, 1ll * a0.f[1][i][0]));
//	cout << val << endl;
	for (int i = 1, la, lb, ra, rb; i <= q; i++) {
		scanf("%d%d%d%d", &la, &ra, &lb, &rb);
		long long x = b.askmax(lb, rb);
		long long ans = -1e18;
		if (x > 0) ans = 1ll * x * a0.askmax(la, ra);
		else  {
			if (a0.askmin(la, ra) < 0) ans = max(ans, 1ll * a0.askmin(la, ra) * x);
			else ans = max(ans, 1ll * a1.askmin(la, ra) * b.askmin(lb, rb));
		}
		x = b.askmin(lb, rb);
		
		if (x < 0) ans = max(ans, 1ll * x * a1.askmin(la, ra));
		else {
			if (a1.askmax(la, ra) > 0) ans = max(ans, 1ll * a1.askmax(la, ra) * x);
			else ans = max(ans, 1ll * a0.askmin(la, ra) * b.askmax(lb, rb));
		}
		printf("%lld\n", ans);
	}
}

//-84292840


























