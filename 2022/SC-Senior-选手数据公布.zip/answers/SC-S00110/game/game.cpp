#include <iostream>
#include <cstdio>
using namespace std;
int n, m, q, l1, r1, l2, r2, x, y, u, v, z;
int a[2][100010], st[2][100010], s[2][400010][5];
long long ans;
//	minn, maxn, maxf, minz;

void add(int i, int x) {
	while(x <= z) {
		++st[i][x];
		x += x&(-x);
	}
}

int sum(int i, int x) {
	int ans = 0;
	while(x) {
		ans += st[i][x];
		x -= x&(-x);
	}
	return ans;
}

void build(int i, int l, int r, int p) {
	if(l == r) {
		s[i][p][1] = s[i][p][2] = a[i][l];
		if(a[i][l] < 0) s[i][p][3] = a[i][l];
		else s[i][p][3] = -1000000007;
		if(a[i][l] > 0) s[i][p][4] = a[i][l];
		else s[i][p][4] = 1000000007;
		return ;
	}
	int mid = (l+r)>>1;
	build(i, l, mid, p<<1);
	build(i, mid+1, r, p<<1|1);
	s[i][p][1] = min(s[i][p<<1][1], s[i][p<<1|1][1]);
	s[i][p][2] = max(s[i][p<<1][2], s[i][p<<1|1][2]);
	s[i][p][3] = max(s[i][p<<1][3], s[i][p<<1|1][3]);
	s[i][p][4] = min(s[i][p<<1][4], s[i][p<<1|1][4]);
}

int res(int i, int tar, int L, int R, int l, int r, int p) {
	if(L <= l && r <= R) {
		return s[i][p][tar];
	}
	int mid = (l+r)>>1, x;
	if(tar == 1 || tar == 4) {
		x = 1000000007;
		if(L <= mid) x = min(x, res(i, tar, L, R, l, mid, p<<1));
		if(mid < R) x = min(x, res(i, tar, L, R, mid+1, r, p<<1|1));
	} else if(tar == 2 || tar == 3) {
		x = -1000000007;
		if(L <= mid) x = max(x, res(i, tar, L, R, l, mid, p<<1));
		if(mid < R) x = max(x, res(i, tar, L, R, mid+1, r, p<<1|1));
	}
	return x;
}

int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &q);
	z = max(n, m);
	for(int i = 1; i <= n; ++i) scanf("%lld", &a[0][i]);
	for(int i = 1; i <= m; ++i) scanf("%lld", &a[1][i]);
	for(int i = 1; i <= n; ++i) if(a[0][i] == 0) add(0, i);
	for(int i = 1; i <= m; ++i) if(a[1][i] == 0) add(1, i);
	build(0, 1, n, 1);
	build(1, 1, m, 1);
	for(int i = 1; i <= q; ++i) {
		scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
		u = res(0, 1, l1, r1, 1, n, 1);
		v = res(0, 2, l1, r1, 1, n, 1);
		x = res(1, 1, l2, r2, 1, m, 1);
		y = res(1, 2, l2, r2, 1, m, 1);
		if(u >= 0) {
			if(x >= 0) {
				ans = 1ll*v*x;
			} else if(y <= 0) {
				ans = 1ll*u*x;
			} else {
				ans = 1ll*u*x;
			}
		} else if(v <= 0) {
			if(x >= 0) {
				ans = 1ll*v*y;
			} else if(y <= 0) {
				ans = 1ll*u*y;
			} else {
				ans = 1ll*v*y;
			}
		} else {
			if(x >= 0) {
				ans = 1ll*v*x;
			} else if(y <= 0) {
				ans = 1ll*u*y;
			} else {
				long long g, h;
				g = 1ll*res(0, 4, l1, r1, 1, n, 1)*x; h = 1ll*res(0, 3, l1, r1, 1, n, 1)*y;
				ans = (g > h ? g : h);
			}
		}
		if(sum(0, r1)-sum(0, l1-1) != 0) ans = (ans < 0 ? 0 : ans);
		if(sum(1, r2)-sum(1, l2-1) != 0) ans = (ans > 0 ? 0 : ans);
		printf("%lld\n", ans);
	}
	return 0;
}

