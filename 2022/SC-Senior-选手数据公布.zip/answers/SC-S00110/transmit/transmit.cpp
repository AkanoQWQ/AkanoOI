#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int n, q, k, val[2010], a[2010], cnt, u, v, hd[2010];
long long dis[2010];
struct node {
	int v, nxt;
}p[4010];

void add(int u, int v) {
	p[++cnt].nxt = hd[u];
	p[cnt].v = v;
	hd[u] = cnt;
}

void dfs(int x) {
	for(int i = hd[x]; i; i = p[i].nxt) {
		if(dis[p[i].v] != -1) continue;
		dis[p[i].v] = dis[x]+a[p[i].v];
		dfs(p[i].v);
	}
}

int main() {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	scanf("%d%d%d", &n, &q, &k);
	if(k != 1 || n > 2000) {
		printf("haaa--gneh\n");
		return 0;
	}
	for(int i = 1; i <= n; ++i) scanf("%d", &a[i]);
	for(int i = 2; i <= n; ++i) {
		scanf("%d%d", &u, &v);
		add(u, v);
		add(v, u);
	}
	for(int i = 1; i <= q; ++i) {
		scanf("%d%d", &u, &v);
		memset(dis, -1, sizeof dis);
		dis[u] = a[u];
		dfs(u);
		printf("%lld\n", dis[v]);
	}
	return 0;
}

