#include <iostream>
#include <cstdio>
#include <cstring>
#define maxn(x, y) (x > y ? x : y)
using namespace std;
int n, m, k, u, v, hd[2510], mv[2510][2510], cnt, vis[2510];
pair<int, int> st[2510];
long long a[2510], ans;
struct node {
	int v, nxt;
}p[20010];
struct stu {
	int x;
	long long val;
}q[2510][4];

void add(int u, int v) {
	p[++cnt].nxt = hd[u];
	p[cnt].v = v;
	hd[u] = cnt;
}

void dfs(int x) {
	cnt = 1;
	st[1] = make_pair(x, -1);
	vis[x] = 1;
	int l = 1;
	while(l <= cnt) {
		u = st[l].first, v = st[l].second;
		mv[x][u] = mv[u][x] = 1;
		if(v != k) {
			for(int i = hd[u]; i; i = p[i].nxt) {
				if(vis[p[i].v]) continue;
				vis[p[i].v] = 1;
				st[++cnt] = make_pair(p[i].v, v+1);
			}
		}
		++l;
	}
}

int main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	scanf("%d%d%d", &n, &m ,&k);
	for(int i = 2; i <= n; ++i) {
		scanf("%lld", &a[i]);
	}
	for(int i = 1; i <= m; ++i) {
		scanf("%d%d", &u, &v);
		add(u, v);
		add(v, u);
	}
	for(int i = 1; i <= n; ++i) {
		memset(vis, 0, sizeof vis);
		dfs(i);
	}
	for(int i = 2; i <= n; ++i) {
		q[i][1].val = q[i][2].val = q[i][3].val = 0;
		for(int j = 2; j <= n; ++j) {
			if(i == j || !mv[i][j] || !mv[1][j]) continue;
			if(a[j]+a[i] >= q[i][1].val) {
				q[i][3].val = q[i][2].val; q[i][2].val = q[i][1].val; q[i][1].val = a[i]+a[j];
				q[i][3].x = q[i][2].x; q[i][2].x = q[i][1].x; q[i][1].x = j;
			} else if(a[j]+a[i] >= q[i][2].val) {
				q[i][3].val = q[i][2].val; q[i][2].val = a[i]+a[j];
				q[i][3].x = q[i][2].x; q[i][2].x = j;
			} else if(a[j]+a[i] >= q[i][3].val) {
				q[i][3].val = a[i]+a[j];
				q[i][3].x = j;
			}
		}
	}
	for(int i = 2; i <= n; ++i) {
		for(int j = i+1; j <= n; ++j) {
			if(!mv[i][j]) continue;
			for(int k = 1; k <= 3; ++k) {
				if(q[i][k].val == 0) break;
				if(q[i][k].x == j) continue;
				if(q[j][1].x != i && q[j][1].x != q[i][k].x) {
					if(q[j][1].x == 0) continue;
					ans = maxn(ans, q[j][1].val+q[i][k].val);
				} else if(q[j][2].x != i && q[j][2].x != q[i][k].x) {
					if(q[j][2].x == 0) continue;
					ans = maxn(ans, q[j][2].val+q[i][k].val);
				} else if(q[j][3].x != i && q[j][3].x != q[i][k].x) {
					if(q[j][3].x == 0) continue;
					ans = maxn(ans, q[j][3].val+q[i][k].val);
				}
			}
		}
	}
	printf("%lld\n", ans);
	return 0;
}

