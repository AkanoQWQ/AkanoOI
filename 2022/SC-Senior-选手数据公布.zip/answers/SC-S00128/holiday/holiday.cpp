//�X�X�X�X�X�X�X�X�X
#include<bits/stdc++.h>
using namespace std;
const int N = 2500, INF = 0x3f3f3f3f;
int dis[N + 5][N + 5], mx[N + 5][3];;
long long s[N + 5];
queue<int> qu;
vector<int> e[N + 5];
void bfs(int p) {
	dis[p][p] = -1;
	qu.push(p);
	while(!qu.empty()) {
		int u = qu.front();
		qu.pop();
		for(auto v : e[u]) {
			if(dis[p][v] == INF) dis[p][v] = dis[p][u] + 1, qu.push(v);
		}
	}
}
int main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	int n, m, k;
	long long ans = 0;
	scanf("%d%d%d", &n, &m, &k);
	for(int i = 2; i <= n; i++) {
		scanf("%lld", &s[i]);
	}
	for(int i = 1, u, v; i <= m; i++) {
		scanf("%d%d", &u, &v);
		e[u].push_back(v);
		e[v].push_back(u);
	}
	memset(dis, 0x3f, sizeof dis);
	for(int i = 1; i <= n; i++) {
		bfs(i);
	}
	for(int i = 2; i <= n; i++) {
		if(dis[1][i] > k) continue; 
		for(int j = 2; j <= n; j++) {
			if(dis[i][j] > k || i == j) continue;
			if(s[i] > s[mx[j][0]]) {
				mx[j][2] = mx[j][1];
				mx[j][1] = mx[j][0];
				mx[j][0] = i;
			}
			else if(s[i] > s[mx[j][1]]) {
				mx[j][2] = mx[j][1];
				mx[j][1] = i;
			}
			else if(s[i] > s[mx[j][2]]) mx[j][2] = i;
		}
	}
	for(int i = 2; i <= n; i++) {
		for(int j = 2; j <= n; j++) {
			if(dis[i][j] > k || i == j) continue;
			for(int l = 0; l <= 2 && mx[i][l]; l++) {
				for(int r = 0; r <= 2 && mx[j][r]; r++) {
					if(mx[i][l] != mx[j][r] && i != mx[j][r] && mx[i][l] != j) {
						ans = max(ans, s[mx[i][l]] + s[i] + s[j] + s[mx[j][r]]);
						break;
					}
				}
			}
		}
	}
	printf("%lld", ans);
	return 0;
}
