//�X�X�X�X�X�X�X�X�X
#include<bits/stdc++.h>
using namespace std;
const int N = 5e5;
vector<int> e[N + 5];
struct Segment_Tree {
	struct tree {
		int ls, rs, lzy, cnt, sz;
	};
	vector<tree> t{1, (tree){-1, -1, 0, 0, 0}};
	void dn(int s, int e) {
		(t[s].lzy == 1) ? t[e].cnt = t[e].sz : t[e].cnt = 0;
		t[e].lzy = t[s].lzy;
	}
	void pshdn(int p) {
		if(t[p].lzy != 0) {
			if(t[p].ls >= 0) dn(p, t[p].ls);
			if(t[p].rs >= 0) dn(p, t[p].rs);
			t[p].lzy = 0;
		}
	}
	int wrk(int &p) {
		if(p >= 0) return p;
		p = (int)t.size();
		t.push_back((tree){-1, -1, 0, 0, 1});
		return p;
	}
	void updt(int p) {
		t[p].cnt = 0, t[p].sz = 0;
		if(t[p].ls >= 0) t[p].cnt += t[t[p].ls].cnt, t[p].sz += t[t[p].ls].sz; 
		if(t[p].rs >= 0) t[p].cnt += t[t[p].rs].cnt, t[p].sz += t[t[p].rs].sz;
	}
	void add(int l, int r, int x, int p = 1) {
		if(l == r) return ;
		int mid = l + r >> 1;
		if(x <= mid) add(l, mid, x, wrk(t[p].ls));
		else add(mid + 1, r, x, wrk(t[p].rs));
		updt(p);
	}
	void chg(int l, int r, int x, int c, int p) {
		if(l == r) {
			t[p].cnt = c;
			return ;
		}
		int mid = l + r >> 1;
		pshdn(p);
		if(x <= mid) chg(l, mid, x, c, t[p].ls);
		else chg(mid + 1, r, x, c, t[p].rs);
		updt(p);
	}
}T[N + 5];
int main() {
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	int n, m, q, cnt = 0;
	scanf("%d%d", &n, &m);
	for(int i = 1, u, v; i <= m; i++) {
		scanf("%d%d", &u, &v);
		e[u].push_back(v);
	}
	for(int i = 1; i <= n; i++) {
		for(auto v : e[i]) {
			T[i].add(1, n, v);
		}
		cnt += (T[i].t[0].cnt == 1);
	}
	scanf("%d", &q);
	while(q--) {
		int op, u, v, x;
		scanf("%d%d", &op, &u);
		x = T[u].t[0].cnt;
		switch(op) {
			case 1 : {
				scanf("%d", &v);
				T[u].chg(1, n, v, 0, 0);
				break;
			}
			case 2 : {
				T[u].t[0].cnt = 0;
				T[u].t[0].lzy = -1;
				break;
			}
			case 3 : {
				scanf("%d", &v);
				T[u].chg(1, n, v, 1, 0);
				break;
			}
			case 4 : {
				T[u].t[0].cnt = (int)e[u].size();
				T[u].t[0].lzy = 1;
				break;
			}
		}
		if(x == 1 && T[u].t[0].cnt != 1) cnt--;
		if(x != 1 && T[u].t[0].cnt == 1) cnt++;
		(cnt == n) ? printf("YES\n") : printf("NO\n");
	}
	return 0;
}
//����һ���������桰����β����ꡱ��Ϊ������״̬��
