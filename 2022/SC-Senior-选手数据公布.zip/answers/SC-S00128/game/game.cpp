//�X�X�X�X�X�X�X�X�X
#include<bits/stdc++.h>
using namespace std;
const int N = 1e5, INF = 0x3f3f3f3f;
int a[N + 5];
struct Segment_Tree {
	struct tree{
		int l, r, nn, nx, xn, xx, z; 
	}t[N * 4 + 5], f, g;
	void updt(int p) {
		f = t[p << 1], g = t[p << 1 | 1];
		t[p] = (tree){f.l, g.r, min(f.nn, g.nn), max(f.nx, g.nx), min(f.xn, g.xn), max(f.xx, g.xx), f.z + g.z};
	}
	void build(int l, int r, int p = 1) {
		if(l == r) {
			if(a[l] > 0) t[p] = (tree){l, r, 0, -INF, a[l], a[l], 0};
			else if(a[l] < 0) t[p] = (tree){l, r, a[l], a[l], INF, 0, 0};
			else t[p] = (tree){l, r, 0, -INF, INF, 0, 1};
			return ;
		}
		int mid = l + r >> 1;
		build(l, mid, p << 1);
		build(mid + 1, r, p << 1 | 1);
		updt(p);
	}
	tree ask(int l, int r, int p = 1) {
		if(l <= t[p].l && t[p].r <= r) return t[p];
		tree ls = {0, 0, 0, -INF, INF, 0, 0}, rs = {0, 0, 0, -INF, INF, 0, 0};
		if(l <= t[p << 1].r) ls = ask(l, r, p << 1);
		if(t[p << 1].r < r) rs = ask(l, r, p << 1 | 1);
		return (tree){0, 0, min(ls.nn, rs.nn), max(ls.nx, rs.nx), min(ls.xn, rs.xn), max(ls.xx, rs.xx), ls.z + rs.z};
	}
}Ta, Tb;
int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	int n, m, q;
	scanf("%d%d%d", &n, &m, &q);
	for(int i = 1; i <= n; i++) {
		scanf("%d", &a[i]);
	}
	Ta.build(1, n);
	for(int i = 1; i <= m; i++) {
		scanf("%d", &a[i]);
	}
	Tb.build(1, m);
	while(q--) {
		int la,ra, lb, rb;
		long long ans = -1ll * INF * INF;
		scanf("%d%d%d%d", &la, &ra, &lb, &rb);
		Ta.f = Ta.ask(la, ra), Tb.f = Tb.ask(lb, rb);
		if(Ta.f.nn) {
			if(Tb.f.xx) ans = max(ans, 1ll * Ta.f.nx * Tb.f.xx);
			else if(Tb.f.z) ans = max(ans, 0ll);
			else ans = max(ans, 1ll * Ta.f.nn * Tb.f.nx);
		}
		if(Ta.f.z) ans = max(ans, 0ll);
		if(Ta.f.xx) {
			if(Tb.f.nn) ans = max(ans, 1ll * Ta.f.xn * Tb.f.nn);
			else if(Tb.f.z) ans = max(ans, 0ll);
			else ans = max(ans, 1ll * Ta.f.xx * Tb.f.xn);
		}
		printf("%lld\n", ans);
	}
	return 0;
}
