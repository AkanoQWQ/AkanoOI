#include<iostream>
#include<cstdio>
using namespace std;
template <typename T>inline void read(T &x)
{
	x=0;char c=getchar(),f=0;
	for(;!isdigit(c);c=getchar()) if(c=='-') f=1;
	for(;isdigit(c);c=getchar()) x=x*10+(c^48);
	if(f) x=-x;
}
const int N=2503;
const int M=1e4+3;
struct Edge
{
	int v,nex;
}e[M<<1];
int n,m,k,head[N],ans,tot,sum,val[N],f[N];
bool vis[N];
inline void add(int u,int v)
{
	++tot;
	e[tot].v=v;
	e[tot].nex=head[u];
	head[u]=tot;
}
inline void dfs(int x,int dep)
{
	if(dep==4)
	{
		if(f[x]) ans=max(ans,sum);
		return ;
	}
	for(int i=head[x];i;i=e[i].nex)
	{
		int v=e[i].v;
		if(vis[v]) continue;
		vis[v]=1;
		sum+=val[v];
		dfs(v,dep+1);
		vis[v]=0;
		sum-=val[v];
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	read(n),read(m),read(k);
	for(int i=1;i<n;++i) read(val[i+1]);
	for(int i=1;i<=m;++i)
	{
		int x,y;
		read(x),read(y);
		if(x==1||y==1) f[x]=f[y]=1;
		add(x,y);
		add(y,x);
	}
	vis[1]=1;
	dfs(1,0);
	printf("%d",ans);
	return 0;
}
/*
7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4
*/
