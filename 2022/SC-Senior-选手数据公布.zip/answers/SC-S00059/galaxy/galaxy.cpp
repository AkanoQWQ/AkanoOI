#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
template <typename T>inline void read(T &x)
{
	x=0;char c=getchar(),f=0;
	for(;!isdigit(c);c=getchar()) if(c=='-') f=1;
	for(;isdigit(c);c=getchar()) x=x*10+(c^48);
	if(f) x=-x;
}
const int N=5e5+3;
struct Edge
{
	int v,nex;
}e[N],E[N<<1];
int n,m,q,tot=1,head[N],num[N],bk[N],out[N],vis[N],hd[N];
inline void add(int u,int v)
{
	++tot;
	e[tot].v=v;
	e[tot].nex=head[u];
	head[u]=tot;
}
inline void Add(int u,int v)
{
	++tot;
	E[tot].v=v;
	E[tot].nex=hd[u];
	hd[u]=tot;
}
inline void cut(int x)
{
	for(int i=hd[x];i;i=E[i].nex)
		bk[i^1]=1; 
}
inline void build(int x)
{
	for(int i=hd[x];i;i=E[i].nex)
		bk[i^1]=0;
}
inline bool dfs(int x)
{
	bool ans=0;
	for(int i=head[x];i;i=e[i].nex)
	{
		int v=e[i].v;
		if(vis[v])
		{
			ans=1;
			break;
		}
		if(bk[i]) continue;
		vis[v]=1;
		ans=dfs(v); 
    }
	return ans;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	read(n),read(m);
	for(int i=1;i<=m;++i)
	{
		int u,v;
		read(u),read(v);
		add(u,v);
		Add(v,u);
		++num[u];
	}
	read(q);
	for(int i=1;i<=q;++i)
	{
		int t,u,v;
		read(t);
		if(t==1)
		{
			read(u),read(v);
			--num[u];
			for(int j=head[u];j;j=e[j].nex)
			{
				if(e[j].v==v)
				{
					bk[j]=1;
					break;
				}
			}
		}
		if(t==2)
		{
			read(u);
			cut(u);
		}
		if(t==3)
		{
			read(u),read(v);
			++num[u];
			for(int j=head[u];j;j=e[j].nex)
			{
				if(e[j].v==v)
				{
					bk[j]=0;
					break;
				}
			}
		}
		if(t==4)
		{
			read(u);
			build(u);
		}
		bool f=1,ft=0;
		for(int j=1;j<=n;++j)
		{
			if(num[j]!=1)
			{
				f=0;
				break;
			}
			else
			{
				if(!ft) 
				{
					memset(vis,0,sizeof vis);
					vis[j]=1;
				    ft=dfs(j);
				}
			}
		}
		if(ft&&!f) printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
/*
3 6
2 3
2 1
1 2
1 3
3 1
3 2
11
1 3 2
1 2 3
1 1 3
1 1 2
3 1 3
3 3 2
2 3
1 3 1
3 1 3
4 2
1 3 2
*/
