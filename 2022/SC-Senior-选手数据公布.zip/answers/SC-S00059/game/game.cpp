#include<iostream>
#include<cstdio>
#include<cmath>
#define lc tr[num][tr[num][x].lch]
#define rc tr[num][tr[num][x].rch]
#define trx tr[num][x]
#define inf 0x3f3f3f3f
#define debug puts("!");
using namespace std;
const int N=1e5+3;
typedef long long ll;
template <typename T>inline void read(T &x)
{
	x=0;char c=getchar(),f=0;
	for(;!isdigit(c);c=getchar()) if(c=='-') f=1;
	for(;isdigit(c);c=getchar()) x=x*10+(c^48);
	if(f) x=-x;
}
struct tree
{
	int lch,rch,l,r;
	int maxn,minx;
}tr[2][N<<2];
int tot,a[N],b[N],n,m,q;
int build(int l,int r,int num)
{
	tot++;
	int x=tot;
	trx.l=l;
	trx.r=r;
	if(l==r)
	{
		if(num==0)	trx.maxn=trx.minx=a[l];
		else trx.maxn=trx.minx=b[l];
		return x;
	}
	int mid=(l+r)>>1;
	trx.lch=build(l,mid,num);
	trx.rch=build(mid+1,r,num);
	trx.maxn=max(lc.maxn,rc.maxn);
	trx.minx=min(lc.minx,rc.minx);
	return x;
}
int ask_max(int x,int num,int l,int r)
{
	if(l<=trx.l&&trx.r<=r) return trx.maxn;
	int mid=(trx.l+trx.r)>>1;
	int ans=-inf;
	if(l<=mid) ans=max(ans,ask_max(trx.lch,num,l,r));
	if(r>mid) ans=max(ans,ask_max(trx.rch,num,l,r));
	return ans; 
}
int ask_min(int x,int num,int l,int r)
{
	if(l<=trx.l&&trx.r<=r) return trx.minx;
	int mid=(trx.l+trx.r)>>1;
	int ans=inf;
	if(l<=mid) ans=min(ans,ask_min(trx.lch,num,l,r));
	if(r>mid) ans=min(ans,ask_min(trx.rch,num,l,r));
	return ans; 
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	read(n),read(m),read(q);
	for(int i=1;i<=n;++i) read(a[i]);
	build(1,n,0);
	tot=0;
	for(int i=1;i<=m;++i) read(b[i]);
	build(1,m,1);
	for(int i=1;i<=q;++i)
	{
		int l1,l2,r1,r2,ans1,ans2;
		read(l1),read(r1),read(l2),read(r2);
		if(l1==r1||l2==r2)
		{
			if(l1==r1)
			{
				ans1=a[l1];
				if(ans1<=0) ans2=ask_max(1,1,l2,r2);
				else ans2=ask_min(1,1,l2,r2);
			}
			else
			{
				ans2=b[l2];
				if(ans2<=0) ans1=ask_min(1,0,l1,r1);
				else ans1=ask_max(1,0,l1,r1);
			}
		}
		else
		{
			ans1=ask_max(1,0,l1,r1);
			ans2=ask_min(1,1,l2,r2);
		}
		printf("%lld\n",(ll)ans1*1ll*ans2);
	}
	return 0;
}
/*
3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2
*/
