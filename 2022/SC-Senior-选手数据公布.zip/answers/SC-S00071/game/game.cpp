#include<bits/stdc++.h>
using namespace std;
struct node
{
	long long l;
	long long r;
	long long Max;
	long long Min;
}tree[400100];
node t2[400010];
long long n,m,q;
long long a[100010],b[100010];
void build1(long long id,long long l,long long r)
{
	tree[id].l=l;
	tree[id].r=r;
	if(l==r)
	{
		tree[id].Max=a[l];
		return;
	}
	long long mid=(l+r)/2;
	build1(id*2,l,mid);
	build1(id*2+1,mid+1,r);
	tree[id].Max=max(tree[id*2].Max,tree[id*2+1].Max);
}
void build2(long long id,long long l,long long r)
{
	t2[id].l=l;
	t2[id].r=r;
	if(l==r)
	{
		t2[id].Min=b[l];
		return;
	}
	long long mid=(l+r)/2;
	build2(id*2,l,mid);
	build2(id*2+1,mid+1,r);
	t2[id].Min=min(t2[id*2].Min,t2[id*2+1].Min);
}
long long Query1(long long id,long long l,long long r)
{
	if(tree[id].l==l&&tree[id].r==r)
	{
		return tree[id].Max;
	}
	long long mid=(tree[id].l+tree[id].r)/2;
	if(mid>r)
		return Query1(id*2,l,r);
	else if(mid<l) return Query1(id*2+1,l,r);
	else return max(Query1(id*2,l,mid),Query1(id*2+1,mid+1,r));
}
long long Query2(long long id,long long l,long long r)
{
	if(t2[id].l==l&&t2[id].r==r)
	{
		return t2[id].Min;
	}
	long long mid=(t2[id].l+t2[id].r)/2;
	if(mid>r)
		return Query2(id*2,l,r);
	else if(mid<l) return Query2(id*2+1,l,r);
	else return min(Query2(id*2,l,mid),Query2(id*2+1,mid+1,r));
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	long long tmp=0;
	scanf("%lld%lld%lld",&n,&m,&q);
	for(long long i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
		if(a[i]<0)tmp=1;
	}
	for(long long i=1;i<=m;i++)
	{
		scanf("%lld",&b[i]);
		if(b[i]<0)tmp=1;
	}
	if(tmp==0)
	{
		build1(1,1,n);
		build2(1,1,m);
		while(q--)
		{
			long long l1,r1,l2,r2;
			scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
			long long t1=Query1(1,l1,r1);
			long long t2=Query2(1,l2,r2);
			printf("%lld\n",t1*t2);
		}		
	}
	else 
	{
		while(q--)
		{
			long long l1,r1,l2,r2;
			scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
			if(l1==r1)
			{
				long long t1=a[l1];
				long long Min=0x7f7f7f7f;
				for(long long i=l2;i<=r2;i++)
				{
					Min=min(Min,b[i]*t1);
				}
				printf("%lld\n",Min);
			}
			else if(l2==r2)
			{
				long long t2=b[l2];
				long long Max=0;
				for(long long i=l1;i<=r1;i++)
				{
					Max=max(Max,a[i]*t2);
				}
				printf("%lld\n",Max);
			}
			else 
			{
				long long Max=0;
				for(long long i=l1;i<=r1;i++)
				{
					for(long long j=l2;j<=r2;j++)
					{
						Max=max(Max,a[i]*b[j]);
					}
				}
				cout<<Max<<endl;
			}
		}
	}
	return 0;
}
/*
3 2 2
0 1 2
3 4
1 3 1 2
2 3 2 2

*/
