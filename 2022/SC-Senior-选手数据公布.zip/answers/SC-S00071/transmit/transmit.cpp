#include<bits/stdc++.h>
using namespace std;
long long n,Q,k;
long long Max;
struct node
{
	long long fa;
	long long v;
	long long top;
	long long step;
	long long son[5001];
}tree[5001];
void dfs(long long s,long long t,long long step,long long ans)
{
	if(s==0||t==0)return;
	if(step>=k)
	{
		return;
	}
	if(s==t)
	{
		Max=min(Max,ans);
		return;
	}
	if(tree[s].step>tree[t].step)
	{
		dfs(tree[s].fa,t,0,ans+tree[tree[s].fa].v);
		dfs(tree[s].fa,t,step+1,ans);
	}
	else if(tree[s].step<tree[t].step)
	{
		dfs(s,tree[t].fa,0,ans+tree[tree[t].fa].v);
		dfs(s,tree[t].fa,step+1,ans);
	}
	else if(s!=t)
	{
		dfs(s,tree[t].fa,0,ans+tree[tree[t].fa].v);
		dfs(s,tree[t].fa,step+1,ans);		
		s=tree[s].fa;
		dfs(s,t,step+1,ans);
		dfs(s,t,0,ans+tree[s].v);			
		t=tree[t].fa;
		dfs(s,t,0,ans+tree[t].v+tree[s].v);
		dfs(s,t,step+2,ans);		
	}
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%lld%lld%lld",&n,&Q,&k);
	for(long long i=1;i<=n;i++)
	{
		scanf("%lld",&tree[i].v);
	}
	for(long long i=1;i<n;i++)
	{
		long long a,b;
		scanf("%lld%lld",&a,&b);
		if(a>b)swap(a,b);
		tree[a].top++;
		tree[a].son[tree[a].top]=b;
		tree[b].fa=a;
		tree[b].step=tree[a].step+1;
	}
	while(Q--)
	{
		Max=2e17;
		long long s,t;
		scanf("%lld%lld",&s,&t);
		dfs(s,t,0,tree[s].v+tree[t].v);	
		printf("%lld\n",Max);	
	}

	return 0;
 } 
