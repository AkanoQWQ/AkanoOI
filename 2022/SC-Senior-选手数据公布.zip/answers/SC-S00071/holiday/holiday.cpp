#include<bits/stdc++.h>
using namespace std;
long long n,m,k;
long long a[10010];
struct node
{
	long long top;
	long long nxt[2510];
} mp[2501];
long long Max=0;
long long v[1000],top=0;
void dfs(long long id,long long step,long long ans,long long K,long long s)
{
	for(long long i=1;i<top;i++)
	{
		for(long long j=i+1;j<top;j++)
		if(v[i]==v[j])return;
	}
	if(step==5&&id==1)
	{
		Max=max(Max,ans);
	}
	if(step==5||K>k)return;
	for(long long i=1;i<=mp[id].top;i++)
	{
		long long tmp=mp[id].nxt[i];
		v[top++]=tmp;
		dfs(tmp,step+1,ans+a[tmp],K,id);
		top--;
		dfs(tmp,step,ans,K+1,id);
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	for(long long i=2;i<=n;i++)
	{
		scanf("%lld",&a[i]);
	}
	for(long long i=1;i<=m;i++)
	{
		long long tx,ty;
		scanf("%lld%lld",&tx,&ty);
		mp[tx].top++;
		mp[tx].nxt[mp[tx].top]=ty;
		mp[ty].top++;
		mp[ty].nxt[mp[ty].top]=tx;		
	}
	dfs(1,0,0,0,0);
	cout<<Max;
	return 0;
}
