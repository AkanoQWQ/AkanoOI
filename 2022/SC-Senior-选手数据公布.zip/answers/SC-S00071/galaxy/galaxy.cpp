#include<bits/stdc++.h>
using namespace std;
long long n,m,q;
long long a[500010],b[500010];
struct node
{
	long long top;
	long long nxt[2510];
} mp[2501];
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%lld%dll",&n,&m);
	for(long long i=1;i<=m;i++)
	{
		long long u,v;
		scanf("%lld%lld",&u,&v);
		mp[v].top++;
		mp[v].nxt[mp[v].top]=u;
		a[u]++;
		b[u]++;
	}
	scanf("%lld",&q);
	for(long long i=1;i<=q;i++)
	{
		long long t,u,v;
		scanf("%lld%lld",&t,&u);
		if(t==1)
		{
			scanf("%lld",&v);
			b[u]--;	
			for(long long j=1;j<=mp[v].top;j++)
			{
				if(mp[v].nxt[j]==u)
				mp[v].nxt[j]=n+m+u;
			}
		}
		else if(t==2)
		{
			for(long long j=1;j<=mp[u].top;j++)
			{
				b[mp[u].nxt[j]]--;
			}
		}
		else if(t==3)
		{
			scanf("%lld",&v);
			b[u]++;
			long long too=mp[v].top;
			mp[v].top++;
			mp[v].nxt[mp[v].top]=u;	
		}
		else if(t==4)
		{
			long long too=mp[u].top;
			for(long long j=1;j<=too;j++)
			{
				if(mp[u].nxt[j]>=n+m)
			mp[u].nxt[j]=mp[v].nxt[j]-n-m;		
				b[mp[u].nxt[j]]++;
			}			
		}
		long long tmp=0;
		for(long long j=1;j<=n;j++)
		{
			if(b[j]!=1)
			{
				tmp=1;
				break;	
			}
		}
		if(tmp==0)printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
