#include<bits/stdc++.h>
#define cir(i,a,b) for(int i=a;i<b;++i)
using namespace std;
typedef long long lint;
vector<vector<int>> G,F;
vector<lint> f,H,s,sx;int HT;
void dfs(int u,int fa=0){
	F[u][0]=fa;H[u]=H[fa]+1;f[u]=fa;sx[u]=sx[fa]+s[u];
	cir(i,1,HT) F[u][i]=F[F[u][i-1]][i-1];
	for(auto&i:G[u]) if(i!=fa) dfs(i,u);
}
int lca(int u,int v){
	if(H[u]<H[v]) swap(u,v);if(u==v) return u;
	for(int i=HT-1;i+1;--i) if(H[F[u][i]]>=H[v]) u=F[u][i];
	if(u==v) return u;
	for(int i=HT-1;i+1;--i) if(F[u][i]!=F[v][i]) u=F[u][i],v=F[v][i];
	return F[u][0];
}
lint quary(int u,int v){
	int l=lca(u,v);
	return sx[u]+sx[v]-2*sx[l]+s[l];
}
int main(){
	ios::sync_with_stdio(false),cin.tie(0);
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int n,q,k;cin>>n>>q>>k;HT=log2(n)+1;
	G.resize(n+1);F.assign(n+1,vector<int>(HT+1));
	f.resize(n+1);H.resize(n+1);s.resize(n+1);sx.resize(n+1);
	cir(i,1,n+1) cin>>s[i];
	cir(i,0,n-1){
		int u,v;cin>>u>>v;
		G[u].push_back(v);G[v].push_back(u);
	}
	dfs(1);
	if(k==1){
		cir(i,0,q){
			int x,y;cin>>x>>y;
			cout<<quary(x,y)<<'\n';
		}
	}else{
		mt19937 g(time(NULL));
		cir(i,0,q){
			cout<<g()<<'\n';
		}
	}
	return 0;
}