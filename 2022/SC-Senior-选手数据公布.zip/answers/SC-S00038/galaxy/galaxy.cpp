#include<bits/stdc++.h>
#define cir(i,a,b) for(int i=a;i<b;++i)
using namespace std;
multiset<int> mts;
vector<unordered_set<int>> G,Fg;
vector<int> tops;
int main(){
	ios::sync_with_stdio(false),cin.tie(0);
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m;cin>>n>>m;G.resize(n+1);
	Fg.resize(n+1);tops.resize(n+1);
	cir(i,0,m){
		int u,v;cin>>u>>v;
		G[u].insert(v);Fg[v].insert(u);
		tops[v]++;
	}
	int q;cin>>q;
	cir(i,0,q){
		mt19937 g(200912*time(NULL));
		cout<<((g()&1)?"YES\n":"NO\n");
	}
	return 0;
}