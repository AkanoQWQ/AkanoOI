#include<bits/stdc++.h>
#define cir(i,a,b) for(int i=a;i<b;++i)
using namespace std;
typedef long long lint;
const lint _inf=1e18+7;
template<typename T>
struct Node{
	T mx,mn,fz,zz;
	Node():mx(-_inf),mn(_inf),fz(-_inf),zz(_inf){}
	void mint(Node<T> nd){
		mx=max(mx,nd.mx);mn=min(mn,nd.mn);
		fz=max(fz,nd.fz);zz=min(zz,nd.zz);
	}
};
template<typename T>
struct sigment{
	vector<T> mn,mx,fz,zz,v;
	int _sz;
	void build(int u,int l,int r){
		if(l==r){
			mx[u]=mn[u]=v[l];
			if(!v[l]) fz[u]=zz[u]=v[l];
			else (v[l]>0?zz[u]:fz[u])=v[l],(v[l]<0?zz[u]:fz[u])=_inf*(v[l]<0?1:-1);
			return;
		}
		int ls=2*u,rs=2*u+1,mid=(l+r)/2;
		build(ls,l,mid);build(rs,mid+1,r);
		mx[u]=max(mx[ls],mx[rs]);mn[u]=min(mn[ls],mn[rs]);
		fz[u]=max(fz[ls],fz[rs]);zz[u]=min(zz[ls],zz[rs]);
	}
	sigment(vector<T>&_v){
		v=_v;_sz=_v.size();
		mn.resize(_sz*4+7);mx.resize(_sz*4+7);
		fz.resize(_sz*4+7);zz.resize(_sz*4+7);
		build(1,1,_sz-1);
	}
	Node<T> _quary(int u,int l,int r,int ql,int qr) const{
		Node<T> ret;
		if(ql<=l&&r<=qr){
			ret.mx=mx[u];ret.mn=mn[u];ret.fz=fz[u];ret.zz=zz[u];
			return ret;
		}
		int ls=2*u,rs=2*u+1,mid=(l+r)/2;
		if(mid>=ql) ret.mint(_quary(ls,l,mid,ql,qr));
		if(mid<qr) ret.mint(_quary(rs,mid+1,r,ql,qr));
		return ret;
	}
	Node<T> quary(int l,int r){return _quary(1,1,_sz-1,l,r);}
};
int main(){
	ios::sync_with_stdio(false),cin.tie(0);
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q;cin>>n>>m>>q;
	vector<lint> a(n+1),b(m+1);
	cir(i,1,n+1) cin>>a[i];
	cir(i,1,m+1) cin>>b[i];
	sigment<lint> siga(a),sigb(b);
	while(q--){
		int l1,r1,l2,r2;cin>>l1>>r1>>l2>>r2;
		auto qua=siga.quary(l1,r1),qub=sigb.quary(l2,r2);
		lint ans=max({min(qua.mx*qub.mn,qua.mx*qub.mx),min(qua.mn*qub.mx,qua.mn*qub.mn),
			(qua.fz!=-_inf?min(qua.fz*qub.mx,qua.fz*qub.mn):-_inf),(qua.zz!=_inf?min(qua.zz*qub.mn,qua.zz*qub.mx):-_inf)});
		cout<<ans<<'\n';
	}
	cout<<flush;
	return 0;
}