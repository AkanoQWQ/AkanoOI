#include<bits/stdc++.h>
#define cir(i,a,b) for(int i=a;i<b;++i)
using namespace std;
typedef long long lint;
vector<vector<int>> G,Dist;
vector<vector<lint>> D;
vector<lint> xf;
vector<bool> vis;
void bfs(int sn){
	queue<int> q;q.push(sn);vis[sn]=true;
	while(!q.empty()){
		auto f=q.front();q.pop();
		for(auto&i:G[f]){
			if(!vis[i]) Dist[sn][i]=Dist[sn][f]+1,q.push(i);
			vis[i]=true;
		}
	}
}
int main(){
	ios::sync_with_stdio(false),cin.tie(0);
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int n,m,k;cin>>n>>m>>k;++k;
	G.resize(n+1);xf.resize(n+1);
	Dist.assign(n+1,vector<int>(n+1));
	D.assign(n+1,vector<lint>(3));
	cir(i,2,n+1) cin>>xf[i];
	cir(i,0,m){
		int x,y;cin>>x>>y;
		G[x].push_back(y),G[y].push_back(x);
	}
	cir(i,1,n+1){
		vis.clear();vis.resize(n+1);
		bfs(i);
	}
	cir(i,2,n+1){
		D[i][Dist[1][i]<=k]=xf[i];
	}
	int xk=3;lint ans=0;
	while(xk--){
		for(int i=n;i>1;--i){
			cir(j,2,i) cir(kx,0,3){
				if(Dist[i][j]>k) continue;
				if(Dist[1][i]<=k&&kx)
					D[i][kx]=max(D[i][kx],D[j][kx-1]+xf[i]);
				D[i][kx]=max(D[i][kx],D[j][kx]+xf[i]);
			}
			ans=max(ans,D[i][2]);
		}
	}
	cout<<ans<<endl;
	return 0;
}