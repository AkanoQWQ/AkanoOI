#include<bits/stdc++.h>

using namespace std;

int ans[30], lena;
int n, m, k;
int loc[500];
long long g[3000];
int nacte[3000][10100],cnt[3000];

long long ar[3000];
long long sco[30];
int lens;
bool hav[3000];

bool check()
{
	if(lens<lena) return false;
	if(lens>lena) return true;
	
	int t=lens;
	while(t)
	{
		if(sco[t]==ans[t]) continue;
		if(sco[t]>ans[t]) return true;
		if(sco[t]<ans[t]) return false;
	}
	return false;   //  ==
}

void change()
{
	for(int i=1; i<=lens; i++)
		ans[i]=sco[i];
		
	lena=max(lena, lens);
}

void jia_s()
{
	int t=1;
	while(sco[t]>9)
	{
		sco[t+1]+=sco[t]/10;
		sco[t]%=10;
		t++;
	}
	lens=max(lens, t);
}

void dfs_to(int loca, int wd, int pol, int step)
{
	if(wd>k) return;
	if(pol>4) return;
	
	if(loca==1)
	{
		jia_s();
		if(check()) change();
		memset(sco, 0, sizeof(sco));
		return;
	}
	
	for(int i=loca; i<=loca+k && i<step; i++)
	{
		sco[pol+1]=g[i];
		dfs_to(i+1, wd+1, pol+1, step);
	}
}

void dfs(int loca, int step)
{
	if(step>k*5) return;
	
	if(loca==1)
	{
		dfs_to(1, 0, 0, step);
		return;
	}
	
	for(int i=1; i<=cnt[loca]; i++)
	{
		hav[nacte[loca][i]]=1;
		ar[step]=nacte[loca][i];
		dfs(nacte[loca][i], step+1);
		ar[step]=0;
		hav[nacte[loca][i]]=0;
	}
			
}


int main()
{
	freopen("holiday.in", "r", stdin);
	freopen("holiday,out", "w", stdout);
	
	scanf("%d%d%d", &n, &m, &k);
	k++;
	
	for(int i=2; i<=n; i++) scanf("%lld", &g[i]);
	
	int x, y;
	for(int i=1; i<=m; i++)
	{
		scanf("%d%d", &x, &y);
		nacte[x][++cnt[x]]=y;
		nacte[y][++cnt[y]]=x;
	}
	
	for(int i=1; i<=cnt[1]; i++)
	{
		ar[0]=nacte[1][i];
		dfs(nacte[1][i], 1);
		ar[0]=0;
	}
	
	
	for(int i=lena; i>=1; i--) printf("%d", ans[i]);
	
	return 0;
}
