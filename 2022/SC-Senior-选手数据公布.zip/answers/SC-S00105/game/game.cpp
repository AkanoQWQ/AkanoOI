#include<bits/stdc++.h>

using namespace std;

int n, m, q;
long long  a[1010], b[1010];

/*void cheng(long c, long long d)
{
	if(c>0 && d<0) printf("-");
	if(c<0 && d>0) printf("-");
	if(c<0) c=0-c;
	if(d<0) d=0-d;
	
	int ans[30];
	int on[30], tw[30], ont=0, twt=0;
	while(c)
	{
		on[++ont]=c%10;
		c/=10;
	}
	while(d)
	{
		tw[++twt]=d%10;
		d/=10;
	}
	
	for(int i=1; i<=ont; i++)
		for(int j=1; j<=twt; j++)
			ans[j+i-1]=on[i]*tw[j];
	
	int t=1;
	while(ans[t])
	{
		if(ans[t]>9)
		{
			ans[t+1]+=ans[t]/10;
			ans[t]%=10;
		}
		t++;
	}
	for(int i=t-1; i>=1; i--)
		printf("%d", ans[i]);
	printf("\n");
}*/

int main()
{
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	
	scanf("%d%d%d", &n, &m, &q);
	
	for(int i=1; i<=n; i++) scanf("%lld", &a[i]);
	
	for(int i=1; i<=m; i++) scanf("%lld", &b[i]);
	
	
	int l1, r1, l2, r2;
	while(q--)
	{
		scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
		
		long long Q1=0x3f3f3f3f, L2=-0x3f3f3f3f, L1=0x3f3f3f3f, Q2=-0x3f3f3f3f;  //1��С, 2��� 
		long long al=0x3f3f3f3f, ar=-0x3f3f3f3f, a3=1;
		
		for(int i=l2; i<=r2; i++) 
		{
			Q1=min(Q1, b[i]);
			Q2=max(Q2, b[i]);	
		}
		
		
		for(int i=l1; i<=r1; i++) 
		{
			L2=max(L2, a[i]);
			L1=min(L1, a[i]);
			if(a[i]>0) al=min(al, a[i]);
			if(a[i]<0) ar=max(ar, a[i]);
			if(a[i]==0) a3=0;				
		}
					
		if(Q1>0);	
		else
		{			
			if(L1>0) printf("%lld\n", Q1*L1);		
			else
			{			
				if(Q2<0) printf("%lld\n", Q1*L2);			
				else
				{				
					if(L2<0) printf("%lld\n", Q2*L2);					
					else
					{
						if(a3==0) printf("%d\n", 0);
						else printf("%lld\n", max(al*Q1, ar*Q2));
					}						
				}
			}
		}
	}
	return 0;
}
