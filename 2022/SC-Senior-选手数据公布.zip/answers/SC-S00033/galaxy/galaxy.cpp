#include<bits/stdc++.h>
#define N 500005
using namespace std;
int n,m,q;
int u,v;
int t,hc;
int first[N],nxt[N*2],to[N*2],z[N*2],et=1;
inline void add(int fr,int tto,int zf){
    nxt[++et]=first[fr];
    first[fr]=et;
    to[et]=tto;
    z[et]=zf;
}
int chu[N];
bool hao[N];
int main(){
    freopen("galaxy.in","r",stdin);
    freopen("galaxy.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int i=0;i<m;++i){
        scanf("%d%d",&u,&v);
        add(u,v,0);
        add(v,u,1);
        ++chu[u];
    }
    for(int i=1;i<=n;++i){
        if(chu[i]==1) ++hc;
    }
    scanf("%d",&q);
    while(q--){
        scanf("%d%d",&t,&u);
        if(t==1){
            scanf("%d",&v);
            --chu[u];
            if(chu[u]==1){
                ++hc;
            }
            else if(chu[u]==0) --hc;
            for(int i=first[u];i;i=nxt[i]){
                if(to[i]==v&&z[i]==0){
                    hao[i>>1]=1;
                }
            }
            if(hc!=n){
                printf("NO\n");
                continue;
            }
            /*if(!check()){
                printf("NO\n");
                continue;
            }*/
        }
        else if(t==2){
            for(int i=first[u];i;i=nxt[i]){
                if(z[i]==0||hao[i>>1]) continue;
                hao[i>>1]=1;
                --chu[to[i]];
                if(chu[to[i]]==1) ++hc;
                else if(chu[to[i]]==0) --hc;
            }
            if(hc!=n){
                printf("NO\n");
                continue;
            }
            /*if(!check()){
                printf("NO\n");
                continue;
            }*/
        }
        else if(t==3){
            scanf("%d",&v);
            ++chu[u];
            if(chu[u]==1){
                ++hc;
            }
            else if(chu[u]==2) --hc;
            for(int i=first[u];i;i=nxt[i]){
                if(to[i]==v&&z[i]==0){
                    hao[i>>1]=0;
                }
            }
            if(hc!=n){
                printf("NO\n");
                continue;
            }
            /*if(!check()){
                printf("NO\n");
                continue;
            }*/
        }
        else{
            for(int i=first[u];i;i=nxt[i]){
                if(z[i]==0||!hao[i>>1]) continue;
                hao[i>>1]=0;
                ++chu[to[i]];
                if(chu[to[i]]==1) ++hc;
                else if(chu[to[i]]==2) --hc;
            }
            if(hc!=n){
                printf("NO\n");
                continue;
            }
            /*if(!check()){
                printf("NO\n");
                continue;
            }*/
        }
        printf("YES\n");
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}
