#include<bits/stdc++.h>
#define N 2600
#define M 20010
#define ll long long
using namespace std;
int n,m,k;
int x,y;
ll a[N];
ll ans,tmp;
int first[N],nxt[M],to[M],et;
inline void add(int fr,int tto){
    nxt[++et]=first[fr];
    first[fr]=et;
    to[et]=tto;
}
int dis[N];
bool vis[N];
bool lian[N][N];
void dij(int s)
{
    memset(dis,0x3f,(n+1)*4);
    memset(vis,0,sizeof vis);
    priority_queue<pair<int,int>,vector<pair<int,int> >,greater<pair<int,int> > >q;
    dis[s]=0;
    pair<int,int>head;
    q.push({0,s});
    while(!q.empty()){
        head=q.top();
        q.pop();
        if(vis[head.second]) continue;
        vis[head.second]=1;
        if(head.first>k+1) break;
        for(int i=first[head.second];i;i=nxt[i]){
            if(dis[to[i]]>dis[head.second]+1){
                dis[to[i]]=dis[head.second]+1;
                q.push({dis[to[i]],to[i]});
            }
        }
    }
    for(int i=1;i<=n;++i){
        if(dis[i]<=k+1&&i!=s) lian[s][i]=1;
    }
}
inline bool cmp(int x,int y) {return a[x]<a[y];}
int lj[N][N],mal;
int main()
{
    freopen("holiday.in","r",stdin);
    freopen("holiday.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    for(int i=2;i<=n;++i){
        scanf("%lld",a+i);
    }
    for(int i=0;i<m;++i){
        scanf("%d%d",&x,&y);
        add(x,y);
        add(y,x);
    }
    for(int i=1;i<=n;++i){
        dij(i);
    }
    for(int i=1;i<=n;++i){
        for(int j=1;j<=n;++j){
            if(lian[i][j]){
                lj[i][++lj[i][0]]=j;
            }
            sort(lj[i]+1,lj[i]+1+lj[i][0],cmp);
        }
    }
    for(int i=1;i<lj[1][0];++i){
        for(int j=i+1;j<=lj[1][0];++j){
            tmp=0;
            mal=0;
            x=lj[1][i],y=lj[1][j];
            for(int kk=lj[x][0];kk>0;--kk){
                if(lj[x][kk]==y) continue;
                for(int jj=lj[y][0];jj>mal;--jj){
                    if(lj[y][jj]==x) continue;
                    if(lian[lj[x][kk]][lj[y][jj]]){
                        tmp=max(tmp,a[lj[x][kk]]+a[lj[y][jj]]);
                        mal=jj;
                        break;
                    }
                }
            }
            if(tmp==0) continue;
            ans=max(ans,tmp+a[x]+a[y]);
        }
    }
    printf("%lld",ans);
    fclose(stdin);
    fclose(stdout);
    return 0;
}
