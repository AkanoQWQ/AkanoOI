#include<bits/stdc++.h>
#define N 100005
#define ll long long
#define inf (1000000000000000000ll)
using namespace std;
int n,m,q;
ll zad[N][18],zbd[N][18],zax[N][18],zbx[N][18],zadd[N][18],zaxx[N][18];
bool yl[N][18];
int l1,r1,l2,r2;
int lo[N];
ll ad,ax,bd,bx,tmp;
inline void fd(ll& x,const ll& y)
{
    if(y>x&&y<0) x=y;
}
inline void zx(ll& x,const ll& y)
{
    if(y<x&&y>0) x=y;
}
int main()
{
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    scanf("%d%d%d",&n,&m,&q);
    for(int i=2;i<=n;++i){
        lo[i]=lo[i>>1]+1;
    }
    for(int i=1;i<=n;++i){
        scanf("%lld",zad[i]);
        zax[i][0]=zadd[i][0]=zaxx[i][0]=zad[i][0];
        yl[i][0]=(zad[i][0]==0);
    }
    for(int i=1;i<=m;++i){
        scanf("%lld",zbd[i]);
        zbx[i][0]=zbd[i][0];
    }
    for(int i=1;i<18;++i){
        for(int j=1;j+(1<<i)-1<=n;++j){
            zad[j][i]=-inf;
            zax[j][i]=inf;
            fd(zad[j][i],zad[j][i-1]);
            fd(zad[j][i],zad[j+(1<<(i-1))][i-1]);
            zx(zax[j][i],zax[j][i-1]);
            zx(zax[j][i],zax[j+(1<<(i-1))][i-1]);
            yl[j][i]=(yl[j][i-1]||yl[j+(1<<(i-1))][i-1]);
            zadd[j][i]=max(zadd[j][i-1],zadd[j+(1<<(i-1))][i-1]);
            zaxx[j][i]=min(zaxx[j][i-1],zaxx[j+(1<<(i-1))][i-1]);
        }
        for(int j=1;j+(1<<i)-1<=m;++j){
            zbd[j][i]=max(zbd[j][i-1],zbd[j+(1<<(i-1))][i-1]);
            zbx[j][i]=min(zbx[j][i-1],zbx[j+(1<<(i-1))][i-1]);
        }
    }
    while(q--){
        scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
        ad=tmp=-inf,ax=inf;
        fd(ad,zad[l1][lo[r1-l1+1]]);
        fd(ad,zad[r1-(1<<lo[r1-l1+1])+1][lo[r1-l1+1]]);
        zx(ax,zax[l1][lo[r1-l1+1]]);
        zx(ax,zax[r1-(1<<lo[r1-l1+1])+1][lo[r1-l1+1]]);
        bd=max(zbd[l2][lo[r2-l2+1]],zbd[r2-(1<<lo[r2-l2+1])+1][lo[r2-l2+1]]);
        bx=min(zbx[l2][lo[r2-l2+1]],zbx[r2-(1<<lo[r2-l2+1])+1][lo[r2-l2+1]]);
        if(ad<0&&ad!=-inf){
            tmp=max(tmp,ad*bd);
        }
        if(ax>0&&ax!=inf){
            tmp=max(tmp,ax*bx);
        }
        if(yl[l1][lo[r1-l1+1]]||yl[r1-(1<<lo[r1-l1+1])+1][lo[r1-l1+1]]){
            tmp=max(tmp,0ll);
        }
        ad=max(zadd[l1][lo[r1-l1+1]],zadd[r1-(1<<lo[r1-l1+1])+1][lo[r1-l1+1]]);
        ax=min(zaxx[l1][lo[r1-l1+1]],zaxx[r1-(1<<lo[r1-l1+1])+1][lo[r1-l1+1]]);
        tmp=max(tmp,max(min(ad*bd,ad*bx),min(ax*bd,ax*bx)));
        printf("%lld\n",tmp);
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}
