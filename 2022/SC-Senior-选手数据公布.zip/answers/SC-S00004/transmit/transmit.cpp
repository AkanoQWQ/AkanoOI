#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=2e5+10;
int v[N];vector<int>e[N];
int fa[N],dep[N];
int n,q,k;
void dfs(int u,int p){
	fa[u]=p;
	dep[u]=dep[p]+1;
	for(int i=0;i<e[u].size();i++)dfs(e[u][i],u);
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++){
		scanf("%d",&v[i]);
	}	
	for(int i=1;i<n;i++){
		int a,b;scanf("%d%d",&a,&b);
		e[a].push_back(b);
	}
	dfs(1,0);
	while(q--){
		int s,t;scanf("%d%d",&s,&t);
		if(dep[s]>dep[t])swap(s,t);
		ll cnt=0;
		while(dep[t]!=dep[s])cnt+=(ll)v[t],t=fa[t];
		while(s!=t)cnt+=(ll)v[s]+(ll)v[t],s=fa[s],t=fa[t];
		cnt+=v[s];
		printf("%lld\n",cnt);
	}
	return 0;
} 
/*
7 5 1
1 2 3 4 5 6 7
1 2
1 3
3 6
3 7
2 5
2 4
*/
