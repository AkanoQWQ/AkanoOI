#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=1e5+10;
int n,m,q,a_max[N][20],a_min[N][20],b_max[N][20],b_min[N][20];
int ask_a_max(int l,int r){
	int t=r-l+1,maxn=a_max[l][0];
	for(int i=19;i>=0;i--){
		if(t&(1<<i))maxn=max(maxn,a_max[l][i]),l+=(1<<i);
	}
	return maxn;
}
int ask_b_max(int l,int r){
	int t=r-l+1,maxn=b_max[l][0];
	for(int i=19;i>=0;i--){
		if(t&(1<<i))maxn=max(maxn,b_max[l][i]),l+=(1<<i);
	}
	return maxn;
}
int ask_a_min(int l,int r){
	int t=r-l+1,minn=a_min[l][0];
	for(int i=19;i>=0;i--){
		if(t&(1<<i))minn=min(minn,a_min[l][i]),l+=(1<<i);
	}
	return minn;
}
int ask_b_min(int l,int r){
	int t=r-l+1,minn=b_min[l][0];
	for(int i=19;i>=0;i--){
		if(t&(1<<i))minn=min(minn,b_min[l][i]),l+=(1<<i);
	}
	return minn;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	bool test1=1;
	for(int i=1;i<=n;i++){
		scanf("%d",&a_max[i][0]);a_min[i][0]=a_max[i][0];
		if(a_max[i][0]<=0)test1=0;
	}
	for(int i=1;i<=m;i++){
		scanf("%d",&b_max[i][0]);b_min[i][0]=b_max[i][0];
		if(b_max[i][0]<=0)test1=0;
	}
	for(int i=1;i<20;i++){
		for(int j=1;j<=n;j++){
			if(j+(1<<(i))>n)break;
			a_max[j][i]=max(a_max[j][i-1],a_max[j+(1<<(i-1))][i-1]);
			a_min[j][i]=min(a_min[j][i-1],a_min[j+(1<<(i-1))][i-1]);
		}
		for(int j=1;j<=m;j++){
			if(j+(1<<(i))>n)break;
			b_max[j][i]=max(b_max[j][i-1],b_max[j+(1<<(i-1))][i-1]);
			b_min[j][i]=min(b_min[j][i-1],b_min[j+(1<<(i-1))][i-1]);
		}
	}
//	for(int i=1;i<=n;i++){
//		for(int j=0;j<20;j++){
//			printf("%d ",a_max[i][j]);
//			
//		}
//		puts("");
//	}
	while(q--){
		int l1,l2,r1,r2;scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		if(test1){
			printf("%lld\n",(ll)ask_a_max(l1,r1)*(ll)ask_b_min(l2,r2));
		}else{
			if(l1==r1){
				if(a_max[l1][0]>0)printf("%lld\n",(ll)a_max[l1][0]*(ll)ask_b_min(l2,r2));
				if(a_max[l1][0]==0)printf("0\n");
				if(a_max[l1][0]<0)printf("%lld\n",(ll)a_max[l1][0]*(ll)ask_b_max(l2,r2));
			}else if(l2==r2){
				if(b_max[l2][0]>0)printf("%lld\n",(ll)b_max[l2][0]*(ll)ask_a_max(l1,r1));
				if(b_max[l2][0]==0)printf("0\n");
				if(b_max[l2][0]<0)printf("%lld\n",(ll)b_max[l2][0]*(ll)ask_a_min(l1,r1));
			}
		}
	}
	return 0;
} 
/*
5 1 10
3 5 2 7 3
1

*/
