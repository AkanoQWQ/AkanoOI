#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=5e5+10;
int n,m,q;
set<int>com1[N];set<int>com[N];
set<int>to[N];int can[N];
bool ans(){
	for(int i=1;i<=n;i++){
		if(com[i].size()>1)return 0;
		can[i]=0;
	}
	return 1;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		int x,y;scanf("%d%d",&x,&y);
		com[x].insert(y);com1[x].insert(y);
		to[y].insert(x);
	}
	scanf("%d",&q);
	while(q--){
		int op;scanf("%d",&op);
		if(op==1){
			int u,v;scanf("%d%d",&u,&v);
			com[u].erase(v);to[v].erase(u);
		}
		if(op==2){
			int u;scanf("%d",&u);
			com[u].clear();
		}
		if(op==3){
			int u,v;scanf("%d%d",&u,&v);
			com[u].insert(v);to[v].insert(u);
		}
		if(op==4){
			int u;scanf("%d",&u);
			com[u]=com1[u];
		}
		if(ans())puts("YES");
		else puts("NO");
	}
	return 0;
} 
