#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=2510;
int n,m,k;
ll v[N];ll ans=0;
vector<int>e[N];
set<int>to;
void dfs(int now,ll sum,int sk){
	if(to.size()==5){
		if(now!=1)return ;
		ans=max(ans,sum);
		return ;
	}
	for(int i=0;i<e[now].size();i++){
		if(sk)dfs(e[now][i],sum,sk-1);
		if(to.count(e[now][i]))continue;
		to.insert(e[now][i]);
		dfs(e[now][i],sum+v[e[now][i]],k);
		to.erase(e[now][i]);
	}
}

int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<n;i++){
		scanf("%lld",&v[i+1]);
	}
	for(int i=1;i<=m;i++){
		int x,y;scanf("%d%d",&x,&y);
		e[x].push_back(y);e[y].push_back(x);
	}
	dfs(1,0,k);
	printf("%lld",ans);		

	return 0;
} 
