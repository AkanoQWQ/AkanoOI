#include<bits/stdc++.h>
using namespace std;
int n,m,l;
int dis[2505][2505];
long long point[2505];
int srt[5][2505];
int book[2505];
int cont[10];
int i11,j11,k11,m11;
long long ans,ans1;
const int maxn=120;
void rad(int dep){
	srand(time(0));
	for(int i=2;i<=n;i++)
	{
		int j=rand()%(n-1)+2;
		while(book[j]==1)
		{
			j++;
			if(j==n+1)
				j=2;
		}
		srt[dep][i-1]=j;
	}
	return;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>l;
	for(int i=2;i<=n;i++)
		cin>>point[i];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
		{
			if(i!=j)
				dis[i][j]=10000;
		}
	for(int i=1;i<=m;i++)
	{
		int x,y;
		cin>>x>>y;
		dis[x][y]=1;
		dis[y][x]=1;
	}
	for(int k=1;k<=n;k++)
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				if(dis[i][j]>dis[i][k]+dis[j][k])
					dis[i][j]=dis[i][k]+dis[j][k];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(dis[i][j]<=l+1)
				dis[i][j]=1;
			else
				dis[i][j]=0;
	for(int i=1;i<=n;i++)
	{
		//srt[i]=i;
		dis[i][i]=0;
	}
	rad(1);
	rad(2);
	rad(3);
//	if(n<=80){
		for(int i=2;i<=n;i++)
		{
			cont[2]=0;
			if(cont[1]>=maxn)
				break;
			ans1=0;
			i11=srt[1][i];
			if(dis[1][i11]==0)
				continue;
			cont[1]++;
			ans1+=point[i11];
			for(int j=2;j<=n;j++)
			{
				cont[3]=0;
				j11=srt[2][j];
				if(cont[2]>=maxn)
					break;
				if(dis[i11][j11]==0)
					continue;
				cont[2]++;
				ans1+=point[j11];
				for(int k=2;k<=n;k++)
				{
					k11=srt[3][k];
					if(cont[3]>=maxn)
						break;
					
					if(dis[j11][k11]==0||k11==i11)
						continue;
					cont[3]++;
					ans1+=point[k11];
					for(int m=2;m<=n;m++){
						m11=m;
						if(dis[k11][m11]==0||dis[1][m11]==0||m11==i11||m11==j11)
							continue;
						ans1+=point[m11];
						if(ans1>ans)
							ans=ans1;
						ans1-=point[m11];
					}
					ans1-=point[k11];
				}
				ans1-=point[j11];
			}
		}
		cout<<ans;
//	}
	return 0;
}
