#include<bits/stdc++.h>
using namespace std;
#define int long long
int sp1;
long long ans1,ans2,ans;
const int MAXn=1000000001;
int l1,l2,r1,r2;
int spa,spb;
int a[100005],b[100005];
int m,n,k;
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>m>>n>>k;
	for(int i=1;i<=m;i++)
	{
		cin>>a[i];
		if(a[i]<=0)
			sp1=1;
	}
	for(int i=1;i<=n;i++)
	{
		cin>>b[i];
		if(b[i]<=0)
			sp1=1;
	}
	
	for(int i=1;i<=k;i++)
	{
		int limit[10]={0,0,MAXn,MAXn*-1,0,0,MAXn,MAXn*-1,0};
		//a++,a+-,a-+,a--,b...
		cin>>l1>>r1>>l2>>r2;
		ans1=0;
		ans2=0;
		spa=7,spb=7;
		if(sp1==0)
		{
			for(int t=l1;t<=r1;t++)
			{
				if(a[t]>limit[1])
				limit[1]=a[t];
			}
			for(int t=l2;t<=r2;t++)
			{
				if(b[t]>limit[5])
				limit[5]=b[t];
			}
			ans1=limit[1];
			ans2=limit[5];
			ans=ans1*ans2;
		}
		else{
			for(int t=l1;t<=r1;t++)
			{
				if(a[t]>0)
					spa=spa&6;
				else if(a[t]!=0)
					spa=spa&5;
				else
					spa=spa&3;
				if(a[t]>limit[1])
					limit[1]=a[t];
				if(a[t]>0&&a[t]<limit[2])
					limit[2]=a[t];
				if(a[t]<0&&a[t]>limit[3])
					limit[3]=a[t];
				if(a[t]<limit[4])
					limit[4]=a[t];
			}
			for(int t=l2;t<=r2;t++)
			{
				if(b[t]>limit[5])
					limit[5]=b[t];
				if(b[t]>0&&b[t]<limit[6])
					limit[6]=b[t];
				if(b[t]<0&&b[t]>limit[7])
					limit[7]=b[t];
				if(b[t]<limit[8])
					limit[8]=b[t];
				if(b[t]>0)
					spb=spb&6;
				else if(b[t]!=0)
					spb=spb&5;
				else
					spb=spb&3;
			}
			if(((spa&1)==spb&1||!(spb&2))&&((spa&2)==spb&2||!(spb&1)))
			{
				ans1=limit[2]*limit[8];
				ans2=limit[3]*limit[5];
				ans=ans1>ans2?ans1:ans2;
				if(spa/4==0)
				    ans=0;
				//cout<<ans1<<" "<<ans2;
			}
			else
			{
				if(limit[6]!=MAXn)
					ans1=limit[1]*limit[6];
				if(limit[7]!=MAXn*-1)
					ans2=limit[4]*limit[7];
				ans=ans1==0?ans2:ans1;
			}
		}
		//cout<<spa<<" "<<spb<<" ";
		cout<<ans<<endl;
	}
	return 0;
}
/*
6 4 5
3 �\1 �\2 1 2 0
1 2 �\1 �\3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3

3 2 2
0 1 �\2
3 4
1 3 1 2
2 3 2 2*/
