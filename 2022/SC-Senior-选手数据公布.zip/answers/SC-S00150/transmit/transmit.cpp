#include<bits/stdc++.h>
using namespace std;
int n,m,l;
long long dis[1000][1000];
long long disf[1000][1000];
long long point[1000];
long long ans;
int st,fi;
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>m>>l;
	for(int i=1;i<=n;i++)
		cin>>point[i];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
		{
			dis[i][j]=10000;
			disf[i][j]=10000000000000;
		}
	for(int i=1;i<=n-1;i++)
	{
		int x,y;
		cin>>x>>y;
		dis[x][y]=1;
		dis[y][x]=1;
	}
	for(int k=1;k<=n;k++)
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				if(dis[i][j]>dis[i][k]+dis[j][k])
					dis[i][j]=dis[i][k]+dis[j][k];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(dis[i][j]<=l)
			{
				dis[i][j]=1;
				disf[i][j]=0;			
			}
			else
				dis[i][j]=0;
	for(int k=1;k<=n;k++)
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				if(dis[i][k]==1&&dis[j][k]==1&&disf[i][j]>disf[i][k]+disf[j][k]+point[k])
					disf[i][j]=disf[i][k]+disf[j][k]+point[k];
	for(int i=1;i<=m;i++)
	{
		cin>>st>>fi;
		ans=point[st]+point[fi]+disf[st][fi];
		//ans=disf[st][fi];
		cout<<ans<<endl ;
	}
	return 0;
}
