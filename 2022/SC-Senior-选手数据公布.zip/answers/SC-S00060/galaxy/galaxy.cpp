#include<bits/stdc++.h>
using namespace std;
#define inf 0x3f3f3f3f
#define fir first
#define sec second
#define ll long long
template<class T> inline void read(T &x) {
	x = 0; int f = 0; char ch = getchar();
	while(ch < '0' || ch > '9') {
		f |= ch == '-';
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	x = f ? -x : x; return;
}
#define N 500005
int n, m, q;
map<pair<int, int>, int> eid;
vector<int> edfr[N];
int st[N], ed[N];
int okndcnt;
#define lc (rt << 1)
#define rc (rt << 1 | 1)
int val[N << 2];
inline void update(int bl, int id, int v) {
	val[st[bl] + id - 1] = v; return;
}
inline int qsum(int L, int R) {
	int res = 0;
	for(int i = L; i <= R; i++) res += val[i];
	return res;
}
inline void cover(int bl, int col) {
	for(int i = st[bl]; i <= ed[bl]; i++) {
		val[i] = col;
	}
	return;
}
signed main() {
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	read(n), read(m);
	int x, y; for(int i = 1; i <= m; i++) {
		read(x), read(y);
		edfr[y].emplace_back(x);
	}
	for(int i = 1; i <= n; i++) {
		st[i] = ed[i - 1] + 1;
		sort(edfr[i].begin(), edfr[i].end());
		ed[i] = st[i] + edfr[i].size() - 1;
		okndcnt += (edfr[i].size() == 1);
	}
	read(q); int op; while(q--) {
		read(op);
		if(op == 1) {
			read(x), read(y);
			int xp = lower_bound(edfr[y].begin(), edfr[y].end(), x) - edfr[y].begin() + 1;
			okndcnt -= (qsum(st[y], ed[y]) == 1);
			update(y, xp, 0);
			okndcnt += (qsum(st[y], ed[y]) == 1);
		}
		else if(op == 2) {
			read(x);
			okndcnt -= (qsum(st[x], ed[x]) == 1);
			cover(y, 0);
		}
		else if(op == 3) {
			read(x), read(y);
			int xp = lower_bound(edfr[y].begin(), edfr[y].end(), x) - edfr[y].begin() + 1;
			okndcnt -= (qsum(st[y], ed[y]) == 1);
			update(y, xp, 1);
			okndcnt += (qsum(st[y], ed[y]) == 1);
		}
		else if(op == 4) {
			read(x);
			okndcnt -= (qsum(st[x], ed[x]) == 1);
			cover(y, 1);
			okndcnt += (qsum(st[x], ed[x]) == 1);
		}
		if(qsum(1, m) == n) {
			puts("YES");
		}
		else puts("NO");
	}
	return 0;
}
