#include<bits/stdc++.h>
using namespace std;
#define inf 0x3f3f3f3f3f3f3f3f
#define fir first
#define sec second
#define int long long
template<class T> inline void read(T &x) {
	x = 0; int f = 0; char ch = getchar();
	while(ch < '0' || ch > '9') {
		f |= ch == '-';
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	x = f ? -x : x; return;
}
#define N 100005
int n, m, q;
int a[N], b[N];
int lg[N];
int bmn[N][21], bmx[N][21];
int amxz[N][21], amxf[N][21];
int amnz[N][21], amnf[N][21];
int a0[N], b0[N];
inline int ca0(int L, int R) {
	return a0[R] - a0[L - 1];
}
inline int cb0(int L, int R) {
	return b0[R] - b0[L - 1];
}
inline void init() {
	lg[0] = -1;
	for(int i = 1; i <= max(n, m); i++) {
		lg[i] = lg[i >> 1] + 1;
	}
	for(int i = 1; i <= n; i++) {
		amxz[i][0] = 0;
		amnz[i][0] = inf;
		amxf[i][0] = -inf;
		amnf[i][0] = 0;
		if(a[i] > 0) {
			amxz[i][0] = amnz[i][0] = a[i];
		}
		if(a[i] < 0) {
			amxf[i][0] = amnf[i][0] = a[i];
		}
	}
	for(int i = 1; i <= m; i++) {
		bmx[i][0] = bmn[i][0] = b[i];
	}
	for(int j = 1; j <= 20; j++) {
		for(int i = 1; i + (1 << j) - 1 <= n; i++) {
			amxz[i][j] = max(amxz[i][j - 1], amxz[i + (1 << (j - 1))][j - 1]);
			amxf[i][j] = max(amxf[i][j - 1], amxf[i + (1 << (j - 1))][j - 1]);
			amnz[i][j] = min(amnz[i][j - 1], amnz[i + (1 << (j - 1))][j - 1]);
			amnf[i][j] = min(amnf[i][j - 1], amnf[i + (1 << (j - 1))][j - 1]);
		}
	}
	for(int j = 1; j <= 20; j++) {
		for(int i = 1; i + (1 << j) - 1 <= m; i++) {
			bmx[i][j] = max(bmx[i][j - 1], bmx[i + (1 << (j - 1))][j - 1]);
			bmn[i][j] = min(bmn[i][j - 1], bmn[i + (1 << (j - 1))][j - 1]);
		}
	}
	return;
}
inline int qamxz(int L, int R) {
	int len = lg[R - L + 1];
	return max(amxz[L][len], amxz[R - (1 << len) + 1][len]);
}
inline int qamxf(int L, int R) {
	int len = lg[R - L + 1];
	return max(amxf[L][len], amxf[R - (1 << len) + 1][len]);
}
inline int qamnz(int L, int R) {
	int len = lg[R - L + 1];
	return min(amnz[L][len], amnz[R - (1 << len) + 1][len]);
}
inline int qamnf(int L, int R) {
	int len = lg[R - L + 1];
	return min(amnf[L][len], amnf[R - (1 << len) + 1][len]);
}
inline int qbmx(int L, int R) {
	int len = lg[R - L + 1];
	return max(bmx[L][len], bmx[R - (1 << len) + 1][len]);
}
inline int qbmn(int L, int R) {
	int len = lg[R - L + 1];
	return min(bmn[L][len], bmn[R - (1 << len) + 1][len]);
}
signed main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	read(n), read(m), read(q);
	for(int i = 1; i <= n; i++) {
		read(a[i]);
		a0[i] = a0[i - 1] + (a[i] == 0);
	}
	for(int i = 1; i <= m; i++) {
		read(b[i]);
		b0[i] = b0[i - 1] + (b[i] == 0);
	}
	init();
	int la, ra, lb, rb; while(q--) {
		read(la), read(ra), read(lb), read(rb);
//		int amxz = 0, amnz = inf, amxf = -inf, amnf = 0, bmx = -inf, bmn = inf;
		int amxz = qamxz(la, ra);
		int amnz = qamnz(la, ra);
		int amxf = qamxf(la, ra);
		int amnf = qamnf(la, ra);
		int bmx = qbmx(lb, rb);
		int bmn = qbmn(lb, rb);
		int res = -inf;
		if(amxz) {
			if(bmn < 0) res = max(res, amnz * bmn);
			if(bmn > 0) res = max(res, amxz * bmn);
		}
		if(amnf) {
			if(bmx > 0) res = max(res, amxf * bmx);
			if(bmx < 0) res = max(res, amnf * bmx);
		}
		if(ca0(la, ra)) res = max(res, 0ll);
		if(cb0(lb, rb)) res = min(res, 0ll);
		printf("%lld\n", res);
	}
	return 0;
}
