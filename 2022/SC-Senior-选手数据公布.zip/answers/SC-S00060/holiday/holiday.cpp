#include<bits/stdc++.h>
using namespace std;
#define inf 0x3f3f3f3f
#define fir first
#define sec second
#define ll long long
template<class T> inline void read(T &x) {
	x = 0; int f = 0; char ch = getchar();
	while(ch < '0' || ch > '9') {
		f |= ch == '-';
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	x = f ? -x : x; return;
}
#define N 2505
#define M 10005
int n, m, K; ll a[N];
vector<int> G[N];
int dis[N][N], vis[N]; queue<int> q;
inline void bfs(int S) {
	memset(dis[S], 0x3f, sizeof(dis[S]));
	memset(vis, 0, sizeof(vis));
	dis[S][S] = 0; q.push(S);
	while(q.size()) {
		int u = q.front(); q.pop();
		if(vis[u]) continue; vis[u] = 1;
		for(auto v : G[u]) {
			if(dis[S][u] + 1 < dis[S][v]) {
				dis[S][v] = dis[S][u] + 1;
				q.push(v);
			}
		}
	}
	for(int i = 1; i <= n; i++) dis[S][i]--;
	return;
}
struct value {
	ll v[4]; int fr[4];
	inline void update(ll V, int Fr) {
		if(V >= v[1]) {
			v[3] = v[2], fr[3] = fr[2];
			v[2] = v[1], fr[2] = fr[1];
			v[1] = V, fr[1] = Fr;
		}
		else if(V >= v[2]) {
			v[3] = v[2], fr[3] = fr[2];
			v[2] = V, fr[2] = Fr;
		}
		else if(V > v[3]) {
			v[3] = V; fr[3] = Fr;
		}
		return;
	}
} g[N];
inline bool chk(int B, int C, int stB, int stC) {
	int A = g[B].fr[stB], D = g[C].fr[stC];
	if(!A || !D) return 0;
	return (A != C && A != D && B != D);
}
signed main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	read(n), read(m), read(K);
	for(int i = 2; i <= n; i++) {
		read(a[i]);
	}
	int x, y;
	for(int i = 1; i <= m; i++) {
		read(x), read(y);
		G[x].emplace_back(y);
		G[y].emplace_back(x);
	}
	for(int i = 1; i <= n; i++) bfs(i);
	for(int i = 2; i <= n; i++) {
		if(dis[1][i] > K) continue;
		for(int j = 2; j <= n; j++) {
			if(i == j) continue;
			if(dis[i][j] > K) continue;
			g[j].update(a[i] + a[j], i);
		}
	}
	ll ans = 0;
	for(int B = 2; B <= n; B++) {
		for(int C = 2; C <= n; C++) {
			if(B == C) continue;
			if(dis[B][C] > K) continue;
			for(int stB = 1; stB <= 3; stB++) {
				for(int stC = 1; stC <= 3; stC++) {
					if(chk(B, C, stB, stC)) {
						ans = max(ans, g[B].v[stB] + g[C].v[stC]);
					}
				}
			}
		}
	}
	printf("%lld", ans);
	return 0;
}
