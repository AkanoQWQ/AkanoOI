#include<bits/stdc++.h>
using namespace std;
#define inf 0x3f3f3f3f3f3f3f3f
#define fir first
#define sec second
#define int long long
template<class T> inline void read(T &x) {
	x = 0; int f = 0; char ch = getchar();
	while(ch < '0' || ch > '9') {
		f |= ch == '-';
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - 48;
		ch = getchar();
	}
	x = f ? -x : x; return;
}
#define N 200005
int n, Q, K, a[N], vv[N];
int first[N], Next[N << 1], to[N << 1], tot;
inline void add(int x, int y) {
	Next[++tot] = first[x];
	first[x] = tot;
	to[tot] = y;
	return;
}
int dep[N], fa[N], siz[N], hson[N], sum[N];
void predfs(int u) {
	siz[u] = 1; sum[u] += a[u];
	for(int i = first[u]; i; i = Next[i]) {
		int v = to[i]; if(!dep[v]) {
			dep[v] = dep[u] + 1; fa[v] = u;
			sum[v] = sum[u];
			predfs(v); siz[u] += siz[v];
			if(siz[hson[u]] < siz[v])
				hson[u] = v;
		}
	}
	return;
}
int top[N];
void gettop(int u, int fr) {
	top[u] = fr;
	if(hson[u]) gettop(hson[u], fr);
	for(int i = first[u]; i; i = Next[i]) {
		int v = to[i]; if(v != fa[u] && v != hson[u])
			gettop(v, v);
	}
	return;
}
inline int lca(int x, int y) {
	while(top[x] != top[y]) {
		if(dep[top[x]] > dep[top[y]]) swap(x, y);
		y = fa[top[y]];
	}
	if(dep[x] > dep[y]) swap(x, y);
	return x;
}
namespace sol_for_K_eq_1 {
	inline void work() {
		int x, y; while(Q--) {
			read(x), read(y);
			int lc = lca(x, y);
			printf("%lld\n", sum[x] + sum[y] - sum[lc] - sum[fa[lc]]);
		}
		return;
	}
};
namespace sol_bf {
	int tmp[N], sz, f[N], g[N];
	inline void work() {
		for(int u = 1; u <= n; u++) {
			vv[u] = a[u];
			for(int i = first[u]; i; i = Next[i]) {
				int v = to[i]; vv[u] = min(vv[u], a[v]);
			}
		}
		int x, y; while(Q--) {
			read(x), read(y);
			int lc = lca(x, y);
			sz = dep[x] + dep[y] - 2 * dep[lc] + 1;
			int tp = 0;
			while(x != fa[lc]) {
				tmp[++tp] = x;
				x = fa[x];
			}
			tp = 0;
			while(y != lc) {
				tmp[sz - tp++] = y;
				y = fa[y];
			}
			if(K == 2) {
				f[1] = a[tmp[1]];;
				for(int i = 2; i <= sz; i++) {
					f[i] = inf;
					for(int pr = 1; pr <= K && i - pr >= 1; pr++) {
						f[i] = min(f[i], f[i - pr] + a[tmp[i]]);
					}
				}
				printf("%lld\n", f[sz]);
				continue;
			}
			f[1] = a[tmp[1]]; g[1] = a[tmp[1]] + vv[tmp[1]];
			for(int i = 2; i <= sz; i++) {
				f[i] = g[i] = inf;
				for(int pr = 1; pr <= K && i - pr >= 1; pr++) {
					if(pr < K) {
						f[i] = min(f[i], g[i - pr] + a[tmp[i]]);
						g[i] = min(g[i], min(f[i - pr], g[i - pr]) + vv[tmp[i]]);
//						g[i] = min(g[i], g[i - pr] + vv[tmp[i]]);
					}
					f[i] = min(f[i], f[i - pr] + a[tmp[i]]);
				}
			}
			printf("%lld\n", f[sz]);
		}
		return;
	}
}
signed main() {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	read(n), read(Q), read(K);
	for(int i = 1; i <= n; i++) read(a[i]);
	int x, y; for(int i = 1; i < n; i++) {
		read(x), read(y);
		add(x, y), add(y, x);
	}
	predfs(dep[1] = 1); gettop(1, 1);
	if(K == 1) {
		sol_for_K_eq_1::work();
		return 0;
	}
	int mxdep = 0;
	for(int i = 1; i <= n; i++) mxdep = max(mxdep, dep[i]);
	if(n <= 2000 || mxdep <= 500) {
		sol_bf::work(); return 0;
	}
	return 0;
}
