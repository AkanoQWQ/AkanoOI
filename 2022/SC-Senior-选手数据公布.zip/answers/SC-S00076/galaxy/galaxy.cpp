#include <cstdio>
#include <vector>
using namespace std;

const int N=5e5+9;
struct E{
	int v;
	bool used;
};
vector <E> G[N];
int n,m,q,deg[N],qu;
bool vis[N];
void work(int u){
	if(deg[u]==1){
		qu--;
		vis[u]=true;
	}
	else if(vis[u]){
		qu++;
		vis[u]=false;
	}
	return;
}

int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		G[v].push_back((E){u,true});
		deg[u]++;
	}
	for(int i=1;i<=n;i++)
		if(deg[i]==1)vis[i]=true;
		else qu++;
	scanf("%d",&q);
	for(int i=1;i<=q;i++){
		int oper,u,v;
		scanf("%d",&oper);
		if(oper==1){
			scanf("%d%d",&u,&v);
			deg[u]--;
			for(int j=0;j<(int)G[v].size();j++){
				if(G[v][j].v==u){
					G[v][j].used=false;
					break;
				}
			}
			work(u);
		}
		if(oper==2){
			scanf("%d",&u);
			for(int j=0;j<(int)G[u].size();j++){
				if(G[u][j].used){
					G[u][j].used=false;
					deg[G[u][j].v]--;
					work(G[u][j].v);
				}
			}
		}
		if(oper==3){
			scanf("%d%d",&u,&v);
			deg[u]++;
			for(int j=0;j<(int)G[v].size();j++){
				if(G[v][j].v==u){
					G[v][j].used=true;
					break;
				}
			}
			work(u);
		}
		if(oper==4){
			scanf("%d",&u);
			for(int j=0;j<(int)G[u].size();j++){
				if(!G[u][j].used){
					G[u][j].used=true;
					deg[G[u][j].v]++;
					work(G[u][j].v);
				}
			}
		}
		if(!qu)printf("YES\n");
		else printf("NO\n");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
