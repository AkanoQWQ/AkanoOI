#include <cstdio>
#include <algorithm>
#define int long long
using namespace std;

const int N=1e5+9,inf=1e18+7;
int n,m,q,a[N],b[N];

signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	for(int i=1;i<=n;i++)scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++)scanf("%lld",&b[i]);
	for(int i=1;i<=q;i++){
		int l1,r1,l2,r2;
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		int MAX=-inf;
		for(int i=l1;i<=r1;i++){
			int res=inf;
			for(int j=l2;j<=r2;j++){
				res=min(res,a[i]*b[j]);
			}
			MAX=max(res,MAX);
		}
		printf("%lld\n",MAX);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
