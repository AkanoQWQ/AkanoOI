#include <cstdio>
#include <vector>
#include <cstring>
using namespace std;

const int N=2009;
vector <int> G[N];
int n,q,k,v[N],fa[N],dep[N],sq[N],len,f[N];
void dfs(int s,int fath){
	dep[s]=dep[fath]+1;
	fa[s]=fath;
	for(int i=0;i<(int)G[s].size();i++){
		if(G[s][i]!=fath)dfs(G[s][i],s);
	}
	return;
}
int LCA(int x,int y){
	while(x!=y){
		if(dep[x]>dep[y])x=fa[x];
		else y=fa[y];
	}
	return x;
}
void make(int s,int t){
	len=0;
	int lca=LCA(s,t);
	for(int i=s;i!=lca;i=fa[i])sq[++len]=i;
	sq[++len]=lca;
	len+=dep[t]-dep[lca];
	int cnt=-1;
	for(int i=t;i!=lca;i=fa[i])sq[len-(++cnt)]=i;
}
void DP(){
	memset(f,0,sizeof f);
	for(int i=len;i>=1;i--){
		if(i==len)f[i]=v[sq[i]];
		else{
			f[i]=0x3f3f3f3f;
			for(int j=1;i+j<=len&&j<=k;j++){
				f[i]=min(f[i+j],f[i]);
			}
			f[i]+=v[sq[i]];
		}
	}
	printf("%d\n",f[1]);
	return;
}

int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++){
		scanf("%d",&v[i]);
	}
	for(int i=1;i<n;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		G[u].push_back(v);
		G[v].push_back(u);
	}
	dfs(1,1);
	for(int i=1;i<=q;i++){
		int s,t;
		scanf("%d%d",&s,&t);
		make(s,t);
		DP();
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
