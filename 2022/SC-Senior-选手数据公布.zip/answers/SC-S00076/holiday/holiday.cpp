#include <cstdio>
#include <vector>
#include <queue>
#include <cstring>
#define int long long 
using namespace std;

const int N=29,inf=1e18+7;
vector <int> G[N];
int n,m,k,v[N],MAX,dist[N][N];
bool vis[N];
int rec[N][N][N][N];
bool used[N][N][N][N];
void unknown_algorithm(){
	memset(dist,0x3f,sizeof dist);
	for(int s=1;s<=n;s++){
		memset(vis,false,sizeof vis);
		queue <int> q;
		q.push(s);
		dist[s][s]=0;
		vis[s]=true;
		while(!q.empty()){
			int u=q.front();
			q.pop();
			vis[u]=false;
			for(int i=0;i<(int)G[u].size();i++){
				int v=G[u][i];
				if(vis[v])continue;
				if(dist[s][v]>dist[s][u]+1){
					dist[s][v]=dist[s][u]+1;
					vis[v]=true;
					q.push(v);
				}
			}
		}
	}
	return;
}
int dfs(int a,int b,int c,int d,int t){
	if(used[a][b][c][d])return rec[a][b][c][d];
	used[a][b][c][d]=true;
	int MAX=-inf;
	if(t==3){
		for(int i=2;i<=n;i++){
			if(i==a||dist[a][i]>k)continue;
			MAX=max(MAX,dfs(a,i,0,0,2)+v[i]);
		}
	}
	if(t==2){
		for(int i=2;i<=n;i++){
			if(i==a||i==b||dist[b][i]>k)continue;
			MAX=max(MAX,dfs(a,b,i,0,1)+v[i]);
		}
	}
	if(t==1){
		for(int i=2;i<=n;i++){
			if(i==a||i==b||i==c||dist[c][i]>k||dist[i][1]>k)continue;
			MAX=max(MAX,v[i]);
		}
	}
	return rec[a][b][c][d]=MAX;
}

signed main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	for(int i=2;i<=n;i++)
		scanf("%lld",&v[i]);
	for(int i=1;i<=m;i++){
		int u,v;
		scanf("%lld%lld",&u,&v);
		G[u].push_back(v);
		G[v].push_back(u);
	}
	unknown_algorithm();// min dist
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			dist[i][j]--;// change to k
	for(int i=2;i<=n;i++){
		if(dist[1][i]<=k)MAX=max(dfs(i,0,0,0,3)+v[i],MAX);
	}
	printf("%lld",MAX);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
