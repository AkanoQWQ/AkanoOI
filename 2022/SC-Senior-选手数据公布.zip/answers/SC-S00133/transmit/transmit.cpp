#include<cstdio>
#include<algorithm>
#include<vector>
const int M=2e5+5;
inline int read(){
	int x(0),op(0);
	char ch=getchar();
	while(ch<'0'||ch>'9')op|=(ch=='-'),ch=getchar();
	while(ch>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
	return op?-x:x;
}
int dep[M],dis[M],fa[M][21],w[M];
std::vector<int> T[M];
void dfs(int x,int f){
	dep[x]=dep[f]+1;dis[x]=dis[f]+w[x];fa[x][0]=f;
	for(int i=1;i<=20;++i)fa[x][i]=fa[fa[x][i-1]][i-1];
	for(auto i:T[x])if(i!=f)dfs(i,x);
}
int LCA(int u,int v){
	if(dep[u]<dep[v])std::swap(u,v);
	for(int i=20;dep[u]>dep[v];i--)if(dep[fa[u][i]]>=dep[v])u=fa[u][i];
	if(u==v)return u;
	for(int i=20;i;i--)if(fa[u][i]!=fa[v][i])u=fa[u][i],v=fa[v][i];
	return fa[u][0];
}
int dist(int u,int v){
	return dis[u]+dis[v]-2*dis[LCA(u,v)]+w[LCA(u,v)];
}
int n,q,k;
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=read();q=read();k=read();
	for(int i=1;i<n;++i){
		int u=read(),v=read();
		T[u].push_back(v);T[v].push_back(u);
	}
	dfs(1,1);
	for(int i=1;i<=q;++i){
		int u=read(),v=read();
		printf("%d\n",dist(u,v));
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
