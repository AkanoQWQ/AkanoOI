#include<cstdio>
#include<algorithm>
#include<cstring>
#include<vector>
typedef long long ll;
const int M=1e4+5;
inline int read(){
	int x(0),op(0);
	char ch=getchar();
	while(ch<'0'||ch>'9')op|=(ch=='-'),ch=getchar();
	while(ch>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
	return op?-x:x;
}
inline ll readll(){
	ll x(0),op(0);
	char ch=getchar();
	while(ch<'0'||ch>'9')op|=(ch=='-'),ch=getchar();
	while(ch>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
	return op?-x:x;
}
int a[2505][2505],n,m,k;
ll W[M];
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read();m=read();k=read()+1;
	for(int i=2;i<=n;++i)W[i]=readll();
	memset(a,0x3f,sizeof(a));
	for(int i=1;i<=n;++i)a[i][i]=0;
	for(int i=1;i<=m;++i){
		int u=read(),v=read();
		a[u][v]=a[v][u]=1;
	}
	for(int k=1;k<=n;++k){
		for(int i=1;i<=n;++i){
			for(int j=1;j<=n;++j){
				a[i][j]=std::min(a[i][j],a[i][k]+a[k][j]);
			}
		}
	}
	ll ans=0;
	for(int x=2;x<=n;++x){
		for(int y=2;y<=n;++y){
			for(int z=2;z<=n;++z){
				for(int w=2;w<=n;++w){
					if(a[1][x]<=k&&a[x][y]<=k&&a[y][z]<=k&&a[z][w]<=k&&a[w][1]<=k&&x!=y&&y!=z&&z!=w&&x!=z&&y!=w&&x!=w){
						ans=std::max(ans,W[x]+W[y]+W[z]+W[w]);
					}
				}
			} 
		}
	}
	printf("%lld\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
