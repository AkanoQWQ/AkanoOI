#include<cstdio>
#include<cstring> 
const int M=5e5+5;
inline int read(){
	int x(0),op(0);
	char ch=getchar();
	while(ch<'0'||ch>'9')op|=(ch=='-'),ch=getchar();
	while(ch>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
	return op?-x:x;
}
struct edge{
	int v,nxt;
	bool ok;
}e[M<<1];
int etot,h[M];
int n,m,q;
void adde(int u,int v){
	e[++etot]=(edge){v,h[u],1};
	h[u]=etot; 
}
int oud[M];
bool ring[M];
int next[M];
bool vis[M];
void dfs(int p){
//	printf("%d\n",p);
	if(ring[p])return;
	if(vis[p]){
//		puts("qwq");
		int pos=p;
		do{
			ring[pos]=1;
			pos=next[pos];
//			printf("%d\n",pos);
		}while(pos!=p);
		return;
	}
	vis[p]=1;
	dfs(next[p]);
	ring[p]=ring[next[p]];
}
bool check(){
	bool flag=1;
	for(int i=1;i<=n;++i)flag&=(oud[i]==1);
	if(flag){
		memset(vis,0,sizeof(vis));memset(ring,0,sizeof(ring));
		for(int i=1;i<=n;++i){
			for(int j=h[i];j;j=e[j].nxt){
				if(e[j].ok){
					next[i]=e[j].v;
					break;
				}
			}
		}
		for(int i=1;i<=n;++i)if(!vis[i])dfs(i);
		for(int i=1;i<=n;++i)flag&=ring[i];
	}
	return flag;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=m;++i){
		int u=read(),v=read();
		adde(u,v);
		oud[u]++; 
	}
	int q=read();
	for(int kk=1;kk<=q;++kk){
//		printf("%d\n",kk);
		int op=read(),u=read();
		if(op&1){
			int v=read();
			for(int j=h[u];j;j=e[j].nxt)if(e[j].v==v){
				e[j].ok=(op==1?0:1);
				oud[u]+=(op==1?-1:1);
				break;
			}
		}
		else{
			for(int i=1;i<=n;++i)
			for(int j=h[i];j;j=e[j].nxt)if(e[j].v==u){
				if(op==2){
					if(e[j].ok){
						e[j].ok=0;
						oud[i]--;
					}
				}
				else{
					if(!e[j].ok){
						e[j].ok=1;
						oud[i]++;
					}
				}
				break;
			}
		}
//		puts("!!");
//		for(int i=1;i<=n;++i)printf("%d ",oud[i]);
//		puts("");
		puts(check()?"YES":"NO");
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
