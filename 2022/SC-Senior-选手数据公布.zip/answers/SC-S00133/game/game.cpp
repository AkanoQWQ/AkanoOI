#include<cstdio>
#include<algorithm>
typedef long long ll;
const int M=1e5+5;
inline int read(){
	int x(0),op(0);
	char ch=getchar();
	while(ch<'0'||ch>'9')op|=(ch=='-'),ch=getchar();
	while(ch>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
	return op?-x:x;
}
int a[M],b[M],n,m,q;
namespace SGT1{
	#define LS p<<1
	#define RS (p<<1)|1
	#define MID ((s+t)>>1)
	int Tmin[M<<2],Tmax[M<<2],h0[M<<2],zheng[M<<2],fu[M<<2];
	void pushup(int p){
		Tmin[p]=std::min(Tmin[LS],Tmin[RS]);
		Tmax[p]=std::max(Tmax[LS],Tmax[RS]);
		h0[p]=h0[LS]|h0[RS];
		zheng[p]=std::min(zheng[LS],zheng[RS]);
		fu[p]=std::max(fu[LS],fu[RS]);
	}
	void build(int p=1,int s=1,int t=n){
		if(s==t){
			Tmin[p]=Tmax[p]=a[s];h0[p]=(a[s]==0);
			if(a[s]>0)zheng[p]=a[s],fu[p]=-0x3f3f3f3f;
			else if(a[s]==0)zheng[p]=fu[p]=0;
			else zheng[p]=0x3f3f3f3f,fu[p]=a[s];
			return;
		}
		build(LS,s,MID);build(RS,MID+1,t);
		pushup(p);
	}
	int querymax(int l,int r,int p=1,int s=1,int t=n){
		if(l>t||s>r)return -0x3f3f3f3f;
		if(l<=s&&t<=r)return Tmax[p];
		return std::max(querymax(l,r,LS,s,MID),querymax(l,r,RS,MID+1,t));
	}
	int querymin(int l,int r,int p=1,int s=1,int t=n){
		if(l>t||s>r)return 0x3f3f3f3f;
		if(l<=s&&t<=r)return Tmin[p];
		return std::min(querymin(l,r,LS,s,MID),querymin(l,r,RS,MID+1,t));
	}
	int queryzero(int l,int r,int p=1,int s=1,int t=n){
		if(l>t||s>r)return 0;
		if(l<=s&&t<=r)return h0[p];
		return queryzero(l,r,LS,s,MID)|queryzero(l,r,RS,MID+1,t);
	}
	int queryzheng(int l,int r,int p=1,int s=1,int t=n){
		if(l>t||s>r)return 0x3f3f3f3f;
		if(l<=s&&t<=r)return zheng[p];
		return std::min(queryzheng(l,r,LS,s,MID),queryzheng(l,r,RS,MID+1,t));
	}
	int queryfu(int l,int r,int p=1,int s=1,int t=n){
		if(l>t||s>r)return -0x3f3f3f3f;
		if(l<=s&&t<=r)return fu[p];
		return std::max(queryfu(l,r,LS,s,MID),queryfu(l,r,RS,MID+1,t));
	}
}
namespace SGT2{
	#define LS p<<1
	#define RS (p<<1)|1
	#define MID ((s+t)>>1)
	int Tmin[M<<2],Tmax[M<<2],h0[M<<2];
	void pushup(int p){
		Tmin[p]=std::min(Tmin[LS],Tmin[RS]);
		Tmax[p]=std::max(Tmax[LS],Tmax[RS]);
		h0[p]=h0[LS]|h0[RS];
	}
	void build(int p=1,int s=1,int t=m){
		if(s==t){
			Tmin[p]=Tmax[p]=b[s];h0[p]=(b[s]==0);
			return;
		}
		build(LS,s,MID);build(RS,MID+1,t);
		pushup(p);
	}
	int querymax(int l,int r,int p=1,int s=1,int t=m){
		if(l>t||s>r)return -0x3f3f3f3f;
		if(l<=s&&t<=r)return Tmax[p];
		return std::max(querymax(l,r,LS,s,MID),querymax(l,r,RS,MID+1,t));
	}
	int querymin(int l,int r,int p=1,int s=1,int t=m){
		if(l>t||s>r)return 0x3f3f3f3f;
		if(l<=s&&t<=r)return Tmin[p];
		return std::min(querymin(l,r,LS,s,MID),querymin(l,r,RS,MID+1,t));
	}
	int queryzero(int l,int r,int p=1,int s=1,int t=m){
		if(l>t||s>r)return 0;
		if(l<=s&&t<=r)return h0[p];
		return queryzero(l,r,LS,s,MID)|queryzero(l,r,RS,MID+1,t);
	}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;++i)a[i]=read();
	for(int i=1;i<=m;++i)b[i]=read();
	SGT1::build();SGT2::build();
	while(q--){
		int l1=read(),r1=read(),l2=read(),r2=read();
		ll amax=SGT1::querymax(l1,r1),amin=SGT1::querymin(l1,r1),azero=SGT1::queryzero(l1,r1);
		ll bmax=SGT2::querymax(l2,r2),bmin=SGT2::querymin(l2,r2);
		ll ans=0;
		if(amin>=0){
			if(azero){
				if(bmin>0){
					ans=amax*bmin;
				}
				else{
					ans=0;
				}
			}
			else{
				if(bmin>0){
					ans=amax*bmin;
				}
				else{
					ans=amin*bmin;
				}
			}
		}
		else if(amax<=0){
			if(azero){
				if(bmax<0){
					ans=amin*bmax;
				}
				else{
					ans=0;
				}
			}
			else{
				if(bmax<0){
					ans=amin*bmax;
				}
				else{
					ans=amax*bmax;
				}
			}
		}
		else{
			if(azero){
				if(bmin*bmax>0){
					if(bmax>0)ans=amax*bmin;
					else ans=amin*bmax;
				}
				else ans=0;
			}
			else{
				if(bmin*bmax>0){
					if(bmax>0)ans=amax*bmin;
					else ans=amin*bmax;
				}
				else{
					ans=std::max(SGT1::queryzheng(l1,r1)*bmin,SGT1::queryfu(l1,r1)*bmax);
				}
			}
		}
		printf("%lld\n",ans);
	} 
	fclose(stdin);fclose(stdout);
	return 0;
}
