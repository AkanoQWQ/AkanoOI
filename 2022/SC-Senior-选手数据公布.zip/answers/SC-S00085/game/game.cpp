
// author : black_trees

#include <bits/stdc++.h>

using namespace std;
using i64 = long long;

const int si = 1e5 + 10;
const int inf = 0x3f3f3f3f;

int n, m, q;
int a[si], b[si], c[si];
//
//class SegTree {
//private:
//    struct Node {
//        int l, r;
//        int miv, mav;
//        bool h_Zero, tmi, tma;
//    }t[si << 2];
//public:
//    void pushup(int p) {
//        if(!t[p << 1].tmi && !t[p << 1 | 1].tmi)
//            t[p].miv = min(t[p <<1].miv, t[p << 1 | 1].miv);
//        else {
//            if(!t[p << 1].tmi) t[p].miv = t[p <<1].miv;
//            else if(!t[p << 1 |1].tmi) t[p].miv = t[p << 1 | 1].miv;
//            else t[p].miv = inf;
//        }
//        if(!t[p << 1].tma && !t[p << 1 | 1].tma)
//            t[p].mav = max(t[p <<1].mav, t[p << 1 | 1].mav);
//        else {
//            if(!t[p << 1].tma) t[p].mav = t[p <<1].mav;
//            else if(!t[p << 1 |1].tma) t[p].mav = t[p << 1 | 1].mav;
//            else t[p].mav = inf;
//        }
//        t[p].tmi = t[p << 1].tmi & t[p << 1 | 1].tmi;
//        t[p].tma = t[p << 1].tma & t[p << 1 | 1].tma;
//        t[p].h_Zero = t[p << 1].h_Zero | t[p << 1 | 1].h_Zero;
//    }
//    void build(int p, int l, int r, int val[]) {
//        t[p].l = l, t[p].r = r;
//        if(l == r) {
//            t[p].miv = t[p].mav = val[l];
//            if(val[l] == 0) t[p].h_Zero = true;
//            if(val[l] == inf) t[p].tma = true;
//            if(val[l] == -inf) t[p].tmi = true;
//            return;
//        }
//        int mid = (l + r) >> 1;
//        build(p << 1, l, mid, val), build(p << 1 | 1, mid + 1, r, val);
//        pushup(p);
//    }
//    std::pair<int, bool> qmin(int p, int ql, int qr) {
//        int l = t[p].l, r = t[p].r;
//        if(ql <= l && r <= qr) {
//            return make_pair(t[p].miv, t[p].tmi);
//        }
//        bool ff = true;
//        int mid = (l + r) >> 1, ret = inf;
//        if(ql <= mid) {
//            std::pair<int, bool> tmp = qmin(p << 1, ql, qr);
//            int vv = tmp.first;
//            if(!tmp.second) ff = false;
//            if(vv != -inf) ret = min(ret, vv);
//        }
//        if(qr > mid) {
//            std::pair<int, bool> tmp = qmin(p << 1 | 1, ql, qr);
//            int vv = tmp.first;
//            if(!tmp.second) ff = false;
//            if(vv != -inf) ret = min(ret, vv);
//        }
//        return {ret, ff};
//    }
//    std::pair<int, bool> qmax(int p, int ql, int qr) {
//        int l = t[p].l, r = t[p].r;
//        if(ql <= l && r <= qr) return make_pair(t[p].mav, t[p].tma);
//        int mid = (l + r) >> 1, ret = -inf;
//        bool ff = true;
//        if(ql <= mid) {
//            std::pair<int, bool> tmp = qmax(p << 1, ql, qr);
//            int vv = tmp.first;
//            if(!tmp.second) ff = false;
//            if(vv != -inf) ret = max(ret, vv);
//        }
//        if(qr > mid) {
//            std::pair<int, bool> tmp = qmax(p << 1 | 1, ql, qr);
//            int vv = tmp.first;
//            if(!tmp.second) ff = false;
//            if(vv != -inf) ret = max(ret, vv);
//        }
//        return {ret, ff};
//    }
//    bool qzero(int p, int ql, int qr) {
//        int l = t[p].l, r = t[p].r;
//        if(ql <= l && r <= qr) return t[p].h_Zero;
//        int mid = (l + r) >> 1, ret = 0;
//        if(ql <= mid) ret |= qzero(p << 1, ql, qr);
//        if(qr > mid)  ret |= qzero(p << 1 | 1, ql, qr);
//        return ret;
//    }
//} tr[3], tre[3]; // 0 -> max, 1 -> min, 2 -> all;


class SegT {
public:
    struct Node {
        int l, r;
        int miv, mav;
        bool h_Zero, tmi, tma;
    }t[si << 2];
    void pushup(int p) {
        t[p].miv = min(t[p <<1].miv, t[p << 1 | 1].miv);
        t[p].mav = max(t[p <<1].mav, t[p << 1 | 1].mav);
        t[p].h_Zero = t[p << 1].h_Zero | t[p << 1 | 1].h_Zero;
    }
    void build(int p, int l, int r, int val[]) {
        t[p].l = l, t[p].r = r;
        if(l == r) {
            t[p].miv = t[p].mav = val[l];
            if(val[l] == 0) t[p].h_Zero = true;
            return;
        }
        int mid = (l + r) >> 1;
        build(p << 1, l, mid, val), build(p << 1 | 1, mid + 1, r, val);
        pushup(p);
    }
    int qmax(int p, int ql, int qr) {
        int l = t[p].l, r = t[p].r;
        if(ql <= l && r <= qr) {
            return t[p].mav;
        }
        int mid = (l + r) >> 1;
        int ret = -inf;
        if(ql <= mid) ret = max(ret, qmax(p << 1, ql, qr));
        if(qr > mid) ret = max(ret, qmax(p << 1 | 1, ql, qr));
        return ret;
    }
    int qmin(int p, int ql, int qr) {
        int l = t[p].l, r = t[p].r;
        if(ql <= l && r <= qr) {
            return t[p].miv;
        }
        int mid = (l + r) >> 1;
        int ret = inf;
        if(ql <= mid) ret = min(ret, qmin(p << 1, ql, qr));
        if(qr > mid) ret = min(ret, qmin(p << 1 | 1, ql, qr));
        return ret;
    }
    bool qzero(int p, int ql, int qr) {
        int l = t[p].l, r = t[p].r;
        if(ql <= l && r <= qr) return t[p].h_Zero;
        int mid = (l + r) >> 1, ret = 0;
        if(ql <= mid) ret |= qzero(p << 1, ql, qr);
        if(qr > mid)  ret |= qzero(p << 1 | 1, ql, qr);
        return ret;
    }
}tr[3], tre[3];

int main() {

    freopen("game.in", "r", stdin);
    freopen("game.out", "w", stdout);

    cin >> n >> m >> q;
    for(int i = 1; i <= n; ++i)
        cin >> a[i];
    tr[2].build(1, 1, n, a);
    for(int i = 1; i <= m; ++i)
        cin >> b[i];
    tre[2].build(1, 1, m, b);

    memset(c, -0x3f, sizeof c);
    for(int i = 1; i <= n; ++i) {
        if(a[i] > 0) c[i] = a[i];
    }
    tr[0].build(1, 1, n, c);
    memset(c, 0x3f, sizeof c);
    for(int i = 1; i <= n; ++i) {
        if(a[i] <= 0) c[i] = a[i];
    }
    tr[1].build(1, 1, n, c);

    memset(c, -0x3f, sizeof c);
    for(int i = 1; i <= m; ++i) {
        if(b[i] > 0) c[i] = b[i];
    }
    tre[0].build(1, 1, m, c);
    memset(c, 0x3f, sizeof c);
    for(int i = 1; i <= m; ++i) {
        if(b[i] <= 0) c[i] = b[i];
    }
    tre[1].build(1, 1, m, c);

    while(q--) {
        int l, r, ll, rr;
        cin >> l >> r >> ll >> rr;
        int Amiv = tr[2].qmin(1, l, r);
        int Amav = tr[2].qmax(1, l, r);
        int Bmiv = tre[2].qmin(1, ll, rr);
        int Bmav = tre[2].qmax(1, ll, rr);
        if(l == r) {
            cout << 1ll * a[l] * 1ll * Bmiv << endl;
            continue;
        }
        if(ll == rr) {
            if(b[ll] == 0) {
                cout << "0" << endl;
            }
            else if(b[ll] > 0){
                cout << 1ll * Amav * 1ll * b[ll] << endl;
            }
            else {
                cout << 1ll * Amiv * 1ll * b[ll] << endl;
            }
            continue;
        }

        if(Amav <= 0) {
            if(Bmav <= 0) {
                cout << (1ll * Amiv * 1ll * Bmav) << endl;
            }
            else if(Bmiv > 0) {
                cout << (1ll * Amiv * 1ll * Bmav) << endl;
            }
            else {
                cout << (1ll * Amiv * 1ll * Bmav) << endl;
            }
        } // A only neg & 0
        else if(Amiv > 0) {
            if(Bmav <= 0) {
                cout << (1ll * Amiv * 1ll * Bmiv) << endl;
            }
            else if(Bmiv > 0) {
                cout << (1ll * Amav * 1ll * Bmiv) << endl;
            }
            else {
                cout << (1ll * Amiv * 1ll * Bmiv) << endl;
            }
        } // A only pos
        else {
            if(Bmav <= 0) {
                cout << (1ll * Amiv * 1ll * Bmav) << endl;
            }
            else if(Bmiv > 0) {
                cout << (1ll * Amav * 1ll * Bmiv) << endl;
            }
            else {
//                int A_neg_max = tr[1].qmax(1, l, r).first;
//                int A_neg_min = tr[1].qmin(1, l, r).first;
//                int A_pos_max = tr[0].qmax(1, l, r).first;
//                int A_pos_min = tr[0].qmin(1, l, r).first;
//                int B_neg_max = tre[1].qmax(1, ll, rr).first;
//                int B_neg_min = tre[1].qmin(1, ll, rr).first;
//                int B_pos_max = tre[0].qmax(1, ll, rr).first;
//                int B_pos_min = tre[0].qmin(1, ll, rr).first;
                int A_neg_max = -inf, A_neg_min = inf, A_pos_min = inf, A_pos_max = -inf, B_neg_max = -inf, B_neg_min = inf, B_pos_min = inf, B_pos_max = -inf;
                for(int i = l; i <= r; ++i) {
                    if(a[i] > 0) A_pos_max = max(A_pos_max, a[i]), A_pos_min = min(A_pos_min, a[i]);
                    if(a[i] <= 0) A_neg_max = max(A_neg_max, a[i]), A_neg_min = min(A_neg_min, a[i]);
                }
                for(int i = ll; i <= rr; ++i) {
                    if(b[i] > 0) B_pos_max = max(B_pos_max, b[i]), B_pos_min = min(B_pos_min, b[i]);
                    if(b[i] <= 0) B_neg_max = max(B_neg_max, b[i]), B_neg_min = min(B_neg_min, b[i]);
                }
//                cout << A_neg_max << " " << A_neg_min << " " << A_pos_max << " " << A_pos_min << " " << B_neg_max << " " << B_neg_min << " " << B_pos_max << " " << B_pos_min << endl;
                if(tr[2].qzero(1, l, r) == true) {
                    cout << "0" << endl;
                    continue;
                }
                i64 ans1 = 1ll * A_neg_max * 1ll * B_pos_max;
                i64 ans2 = 1ll * A_pos_min * 1ll * B_neg_min;
                cout << max(ans1, ans2) << endl;
            }
        }
    }

    return 0;
}

