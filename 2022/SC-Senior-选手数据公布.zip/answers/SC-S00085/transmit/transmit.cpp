


// author : black_trees

#include <bits/stdc++.h>

using namespace std;
using i64 = long long;

int main() {

    freopen("transmit.in", "r", stdin);
    freopen("transmit.out", "w", stdout);

    cout << "no time, but it does not matter." <<endl;

    return 0;
}
