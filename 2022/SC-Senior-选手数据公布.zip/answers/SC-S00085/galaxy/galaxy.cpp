

// author : black_trees

#include <bits/stdc++.h>

using namespace std;
using i64 = long long;

int main() {

    freopen("galaxy.in", "r", stdin);
    freopen("galaxy.out", "w", stdout);

    cout << "no time, but it does not matter." <<endl;

    return 0;
}
