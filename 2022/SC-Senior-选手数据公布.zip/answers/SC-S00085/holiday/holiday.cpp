
// author : black_trees

#include <bits/stdc++.h>

using namespace std;
using i64 = long long;

const int si = 2500 + 1;
const int sii = 1e4 + 1;
const int inf = 0x3f3f3f3f;

int n, m, qr;
i64 a[si];
int tot = 0, head[si];
struct Edge { int ver, Next; } e[sii << 1];
inline void add(int u, int v) { e[tot] = (Edge){v, head[u]}, head[u] = tot++; }

std::bitset<si>vis;
int dis[si][si];
std::priority_queue<std::pair<int, int> > q;
void dijkstra(int s) {
    for(int i = 1; i <= n; ++i) vis[i] = false;
    for(int i = 1; i <= n; ++i) dis[s][i] = inf;
    dis[s][s] = 0, q.push(make_pair(dis[s][s], s));
    while(!q.empty()) {
        int u = q.top().second;
        int val = q.top().first;
        q.pop();
        if(vis[u]) continue;
        vis[u] = true;
        for(int i = head[u]; ~i; i = e[i].Next) {
            int v = e[i].ver;
            if(dis[s][v] > dis[s][u] + 1) {
                dis[s][v] = dis[s][u] + 1;
                if(!vis[v]) q.push(make_pair(-dis[s][v], v));
            }
        }
    }
}
i64 dp[si][5];

namespace bf1 {
    i64 ans = -1;
    void dfs(int now, int x[5], i64 sum) {
        if(now == 5) {
            if(dis[1][x[4]] <= qr)
                ans = max(ans, sum);
            return;
        }
        for(int i = 2; i <= n; ++i) {
            bool f = false;
            for(int j = 1; j < now; ++j) {
                if(i == x[j]) { f = true; break; }
            }
            if(f) continue;
            if(dis[x[now - 1]][i] > qr) continue;
            x[now] = i;
            dfs(now + 1, x, sum + a[i]);
        }
    }
    void solve() {
        int y[5];
        for(int i = 2; i <= n; ++i) {
            if(dis[1][i] > qr) continue;
            y[1] = i;
            dfs(2, y, a[i]);
        }
        cout << ans << endl;
    }
}

std::set<int> pat[si][si];

int main() {

    freopen("holiday.in", "r", stdin);
    freopen("holiday.out", "w", stdout);

    memset(head, -1, sizeof head);

    cin >> n >> m >> qr, qr ++;
    for(int i = 2; i <= n; ++i)
        cin >> a[i];
    for(int i = 1; i <= m; ++i) {
        int u, v;
        cin >> u >> v;
        add(u, v), add(v, u);
    }

    for(int i = 1; i <= n; ++i) dijkstra(i);

    if(n <= 20) return bf1::solve(), 0;

    memset(dp, -0x3f, sizeof dp);
    dp[1][0] = 0;
    for(int i = 2; i <= n; ++i)
        if(dis[1][i] <= qr) dp[i][1] = a[i], pat[i][1].insert(i);
    for(int j = 2; j <= 4; ++j) {
        for(int i = 2; i <= n; ++i) {
            for(int k = 2; k <= n; ++k) {
                if(i == k) continue;
                if(dis[i][k] > qr) continue;
                if(pat[k][j - 1].find(i) != pat[k][j - 1].end()) continue;
                if(dp[k][j - 1] + a[i] > dp[i][j]) {
                    pat[i][j] = pat[k][j - 1]; pat[i][j].insert(i);
                    dp[i][j] = dp[k][j - 1] + a[i];
//                    cout << "[" << k << ", " << j - 1 << "] ->" << "[" << i << ", " << j << "]" << " ";
//                    cout << "dp[" << i << ", " << j << "] = " << dp[i][j] << endl;
                }
            }
        }
    }
    i64 mx = -1;
    for(int i = 2; i <= n; ++i) {
        if(dis[1][i] > qr) continue;
        mx = max(mx, dp[i][4]);
    }
    cout << mx << endl;

    return 0;
}
