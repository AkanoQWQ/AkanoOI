#include <iostream>
#include <cstdio>
#include <cstring>
#include <queue>
using namespace std;
typedef long long ll;
const int N = 2505, M = 1e5 + 5;
int n, m, K, f[N][N];
ll val[N], ans;
int dot[N][4];
int head[N], cnt;
struct edge{
	int nxt, to;
}e[M << 1];
void add(int u, int v){
	e[++cnt].nxt = head[u], e[cnt].to = v, head[u] = cnt;
}
queue <int> q;
void bfs(int s){
	memset(f[s], -1, sizeof(f[s]));
	f[s][s] = 0, q.push(s);
	while(!q.empty()){
		int u = q.front(); q.pop();
		for(int i = head[u]; i; i = e[i].nxt){
			int v = e[i].to;
			if(f[s][v] != -1) continue;
			f[s][v] = f[s][u] + 1, q.push(v);
		}
	}
}
int main(){
	freopen("holiday.in", "r", stdin); freopen("holiday.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &K);
	for(int i = 2; i <= n; i++) scanf("%lld", &val[i]);
	for(int i = 1, u, v; i <= m; i++) scanf("%d%d", &u, &v), add(u, v), add(v, u);
	for(int i = 1; i <= n; i++) bfs(i);
	for(int i = 2; i <= n; i++)
		for(int j = 2; j <= n; j++){
			if(j == i || f[i][j] - 1 > K || f[1][j] - 1 > K) continue;
			if(val[j] > val[dot[i][0]]) dot[i][2] = dot[i][1], dot[i][1] = dot[i][0], dot[i][0] = j;
			else if(val[j] > val[dot[i][1]]) dot[i][2] = dot[i][1], dot[i][1] = j;
			else if(val[j] > val[dot[i][2]]) dot[i][2] = j;
		}
	for(int i = 2; i <= n; i++)
		for(int j = 2; j <= n; j++){
			if(j == i || f[i][j] - 1 > K) continue;
			ll now = 0;
			for(int a = 0; a < 3; a++)
				for(int b = 0; b < 3; b++){
					if(dot[i][a] == j || dot[j][b] == i || dot[i][a] == dot[j][b] || !dot[i][a] || !dot[j][b]) continue;
					now = max(now, val[i] + val[j] + val[dot[i][a]] + val[dot[j][b]]);
				}
			ans = max(ans, now);
		}
	printf("%lld\n", ans);
	return 0;
}
