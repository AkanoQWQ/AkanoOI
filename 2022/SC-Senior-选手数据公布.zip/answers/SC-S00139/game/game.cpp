#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
typedef long long ll;
const int N = 1e5 + 5, inf = 1e9 + 1;
const ll INF = 1e18;
int n, m, q;
struct ST{
	int len, v[N], lg[N], mx1[N][19], mn1[N][19], mx2[N][19], mn2[N][19];
	bool z[N][19];
	void build(){
		for(int i = 2; i <= len; i++) lg[i] = lg[i >> 1] + 1;
		for(int i = 1; i <= len; i++)
			for(int j = 0; j <= lg[len]; j++)
				mx1[i][j] = 0, mn1[i][j] = inf, mx2[i][j] = -inf, mn2[i][j] = 0, z[i][j] = false;
		for(int i = 1; i <= len; i++){
			if(!v[i]) z[i][0] = true;
			else if(v[i] > 0) mx1[i][0] = mn1[i][0] = v[i];
			else if(v[i] < 0) mx2[i][0] = mn2[i][0] = v[i];
		}
		for(int j = 1; j <= lg[len]; j++)
			for(int i = 1; i + (1 << j) - 1 <= len; i++){
				z[i][j] = z[i][j - 1] | z[i + (1 << (j - 1))][j - 1];
				mx1[i][j] = max(mx1[i][j - 1], mx1[i + (1 << (j - 1))][j - 1]);
				mn1[i][j] = min(mn1[i][j - 1], mn1[i + (1 << (j - 1))][j - 1]);
				mx2[i][j] = max(mx2[i][j - 1], mx2[i + (1 << (j - 1))][j - 1]);
				mn2[i][j] = min(mn2[i][j - 1], mn2[i + (1 << (j - 1))][j - 1]);
			}
	}
	bool qz(int x, int y){
		int k = lg[y - x + 1];
		return z[x][k] | z[y - (1 << k) + 1][k];
	}
	int qmx1(int x, int y){
		int k = lg[y - x + 1];
		return max(mx1[x][k], mx1[y - (1 << k) + 1][k]);
	}
	int qmn1(int x, int y){
		int k = lg[y - x + 1];
		return min(mn1[x][k], mn1[y - (1 << k) + 1][k]);
	}
	int qmx2(int x, int y){
		int k = lg[y - x + 1];
		return max(mx2[x][k], mx2[y - (1 << k) + 1][k]);
	}
	int qmn2(int x, int y){
		int k = lg[y - x + 1];
		return min(mn2[x][k], mn2[y - (1 << k) + 1][k]);
	}
}a, b;
int main(){
	freopen("game.in", "r", stdin); freopen("game.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &q);
	a.len = n, b.len = m;
	for(int i = 1; i <= n; i++) scanf("%d", &a.v[i]);
	for(int i = 1; i <= m; i++) scanf("%d", &b.v[i]);
	a.build(), b.build();
	for(int i = 1, l1, r1, l2, r2; i <= q; i++){
		scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
		int A = b.qmx1(l2, r2), B = b.qmn1(l2, r2), C = b.qmx2(l2, r2), D = b.qmn2(l2, r2);
		bool flag = b.qz(l2, r2);
		int mx1 = a.qmx1(l1, r1), mn1 = a.qmn1(l1, r1), mx2 = a.qmx2(l1, r1), mn2 = a.qmn2(l1, r1);
		bool z = a.qz(l1, r1);
		ll ans = -INF;
		if(mn2){
			if(A) ans = max(ans, (ll)A * mx2);
			else if(flag) ans = max(ans, 0ll);
			else ans = max(ans, (ll)C * mn2);
		}
		if(mx1){
			if(D) ans = max(ans, (ll)D * mn1);
			else if(flag) ans = max(ans, 0ll);
			else ans = max(ans, (ll)B * mx1);
		}
		if(ans < 0 && z) ans = 0;
		printf("%lld\n", ans);
	}
	return 0; 
}
