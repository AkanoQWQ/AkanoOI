#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <unordered_map>
#include <queue>
using namespace std;
const int N = 5e5 + 5, M = 5e5 + 5;
int n, m, Q;
struct Edge{
	int u, v;
}E[M];
int head[N], cnt;
struct edge{
	int nxt, to, id;
}e[M << 1];
void add(int u, int v, int id){
	e[++cnt].nxt = head[u], e[cnt].to = v, e[cnt].id = id, head[u] = cnt;
}
vector <int> idx[N];
unordered_map <int, int> ID[N];
bool tag[M];
int pdfn, dfn[N], low[N], scc, sc[N], stk[N], top, sz[N];
bool used[N];
void dfs(int u){
	dfn[u] = low[u] = ++pdfn, used[stk[++top] = u] = true;
	for(int i = head[u]; i; i = e[i].nxt){
		if(tag[e[i].id]) continue;
		int v = e[i].to;
		if(!dfn[v]) dfs(v), low[u] = min(low[u], low[v]);
		else if(!sc[v]) low[u] = min(low[u], low[v]);
	}
	if(dfn[u] == low[u]){
		++scc;
		while(used[u]){
			int now = stk[top];
			used[now] = false, sc[now] = scc;
			top--;
		}
	}
}
vector <int> g[N];
int in[N];
bool f[N];
queue <int> q;
void topo_sort(){
	for(int i = 1; i <= scc; i++) if(!in[i]) f[i] = (sz[i] > 1), q.push(i);
	while(!q.empty()){
		int u = q.front(); q.pop();
		for(int v : g[u]){
			f[v] |= f[u], in[v]--;
			if(!in[v]) q.push(v);
		}
	}
}
void work(){
	for(int u = 1; u <= n; u++){
		int num = 0;
		for(int i = head[u]; i; i = e[i].nxt) if(!tag[e[i].id]) num++;
		if(num != 1){
			puts("NO"); return;
		}
	}
	pdfn = scc = top = 0;
	for(int i = 1; i <= n; i++) dfn[i] = low[i] = sc[i] = stk[i] = sz[i] = in[i] = 0, f[i] = used[i] = false, g[i].clear();
	for(int i = 1; i <= n; i++) if(!dfn[i]) dfs(i);
	for(int i = 1; i <= n; i++) sz[sc[i]]++;
	for(int u = 1; u <= n; u++)
		for(int i = head[u]; i; i = e[i].nxt){
			if(tag[e[i].id]) continue;
			int v = e[i].to;
			if(sc[u] == sc[v]) continue;
			g[sc[v]].push_back(sc[u]), in[sc[u]]++;
		}
	topo_sort();
	for(int i = 1; i <= n; i++) if(!f[sc[i]]){
		puts("NO"); return;
	}
	puts("YES");
}
int main(){
	freopen("galaxy.in", "r", stdin); freopen("galaxy.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= m; i++) scanf("%d%d", &E[i].u, &E[i].v), add(E[i].u, E[i].v, i), idx[E[i].v].push_back(i), ID[E[i].u][E[i].v] = i;
	scanf("%d", &Q);
	for(int i = 1, opt, u, v; i <= Q; i++){
		scanf("%d", &opt);
		if(opt == 1) scanf("%d%d", &u, &v), tag[ID[u][v]] = true;
		else if(opt == 2){
			scanf("%d", &u);
			for(int id : idx[u]) tag[id] = true;
		}
		else if(opt == 3) scanf("%d%d", &u, &v), tag[ID[u][v]] = false;
		else{
			scanf("%d", &u);
			for(int id : idx[u]) tag[id] = false;
		}
		work();
	}
	return 0;
}
