#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <queue>
using namespace std;
typedef long long ll;
const int N = 2e5 + 5, M = 2e3 + 5;
const ll inf = 1e18;
int n, Q, k;
int val[N];
vector <int> t[N];
int fa[N][20], dep[N];
ll sum[N];
void dfs(int u){
	for(int i = 1; i <= 18; i++) fa[u][i] = fa[fa[u][i - 1]][i - 1];
	for(int v : t[u]){
		if(v == fa[u][0]) continue;
		fa[v][0] = u, dep[v] = dep[u] + 1, sum[v] = sum[u] + val[v];
		dfs(v);
	}
}
int lca(int u, int v){
	if(dep[u] < dep[v]) swap(u, v);
	for(int i = 18; i >= 0; i--) if(dep[fa[u][i]] >= dep[v]) u = fa[u][i];
	if(u == v) return u;
	for(int i = 18; i >= 0; i--) if(fa[u][i] != fa[v][i]) u = fa[u][i], v = fa[v][i];
	return fa[u][0];
}
int head[M], cnt;
struct edge{
	int nxt, to, w;
}e[N];
void add(int u, int v, int w){
	e[++cnt].nxt = head[u], e[cnt].to = v, e[cnt].w = w, head[u] = cnt;
}
struct node{
	int id;
	ll w;
	node(int a, ll b){
		id = a, w = b;
	}
	bool operator < (const node &k) const {
		return w > k.w;
	} 
};
priority_queue <node> q;
ll dis[M][M];
bool vis[M];
void dijkstra(int s){
	for(int i = 1; i <= n; i++) dis[s][i] = inf, vis[i] = false;
	dis[s][s] = 0, q.push(node(s, dis[s][s]));
	while(!q.empty()){
		int u = q.top().id; q.pop();
		if(vis[u]) continue;
		for(int i = head[u]; i; i = e[i].nxt){
			int v = e[i].to, w = e[i].w;
			if(dis[s][u] + w < dis[s][v]){
				dis[s][v] = dis[s][u] + w;
				if(!vis[v]) q.push(node(v, dis[s][v]));
			}
		}
	}
}
int main(){
	freopen("transmit.in", "r", stdin); freopen("transmit.out", "w", stdout);
	scanf("%d%d%d", &n, &Q, &k);
	for(int i = 1; i <= n; i++) scanf("%d", &val[i]);
	for(int i = 1, u, v; i < n; i++) scanf("%d%d", &u, &v), t[u].push_back(v), t[v].push_back(u);
	dep[1] = 1, sum[1] = val[1], dfs(1);
	if(k == 1){
		for(int i = 1, u, v; i <= Q; i++){
			scanf("%d%d", &u, &v);
			int x = lca(u, v);
			printf("%lld\n", sum[u] + sum[v] - sum[x] - sum[fa[x][0]]);
		}
		return 0;
	}
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= n; j++) if(j != i){
			int x = lca(i, j);
			if(dep[i] + dep[j] - 2 * dep[x] > k) continue;
			add(i, j, val[j]);
		}
	for(int i = 1; i <= n; i++) dijkstra(i);
	for(int i = 1, u, v; i <= Q; i++){
		scanf("%d%d", &u, &v);
		printf("%lld\n", dis[u][v] + val[u]);
	}
	return 0;
}
