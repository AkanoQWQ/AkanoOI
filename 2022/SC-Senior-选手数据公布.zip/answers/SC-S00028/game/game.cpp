#include "bits/stdc++.h"
using namespace std;
const int N = 1e5 + 5;

int a[N], b[N];

#define c(x, y) (a[x] * b[y])

//lȡX QȡY

int main()
{
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	int n, m, q;
	cin >> n >> m >> q;
	for (int i = 1; i <= n; ++i)
		scanf("%d", a + i);
	for (int i = 1; i <= m; ++i)
		scanf("%d", b + i);

	while (q--)
	{
		int l1, r1, l2, r2;
		scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
		int res = -0x3f3f3f3f;
		for (int i = l1; i <= r1; ++i)
		{
			if (a[i] > 0)
			{
				int m = 0x3f3f3f3f;
				for (int j = l2; j <= r2; ++j)
					m = min(m, b[j]);
				res = max(res, m * a[i]);
			}
			else
			{
				int m = -0x3f3f3f3f;
				for (int j = l2; j <= r2; ++j)
					m = max(m, b[j]);
				res = max(res, m * a[i]);
			}
		}
		cout << res << endl;
	}
	return 0;
}
