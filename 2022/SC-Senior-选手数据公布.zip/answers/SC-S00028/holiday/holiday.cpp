#include "bits/stdc++.h"
using namespace std;

const int N = 2505, M = 15005;
int g[N][N], p[N];

int main()
{
    freopen("holiday.in", "r", stdin);
    freopen("holiday.out", "w", stdout);
    memset(g, 0x3f, sizeof g);
    int n, m, k;
    cin >> n >> m >> k;
    for (int i = 2; i <= n; ++i)
         scanf("%d", p + i);
    for (int i = 0; i < m; ++i)
    {
        int f, t;
        scanf("%d%d", &f, &t);
        g[f][t] = 1;
        g[t][f] = 1;
    }

    sort(p, p + n);
    cout << p[0] + p[1] + p[2] + p[3] << endl;
    return 0;
}
//̫���� 
