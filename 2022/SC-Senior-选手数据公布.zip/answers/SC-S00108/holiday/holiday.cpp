#include<bits/stdc++.h>
using namespace std;
#define ll long long 
const int N=1e5+10,INF=1e9+10;
int h[N],ne[N],e[N],idx;
int d[N];
bool vis[N],ft[N];
int n,m,k;
ll s[N],ans;
typedef pair<ll,int>pii;
void init(int s){
	priority_queue<pii,vector<pii > ,greater<pii> >q;
	memset(d,0x3f,sizeof d);
	memset(vis,0,sizeof vis);
	q.push({0,s});d[s]=-1;
	while(q.size()){
		int u=q.top().second;
		q.pop();
		if(vis[u])continue;
		vis[u]=1;
		for(int i=h[u];~i;i=ne[i]){
			int v=e[i];
			if(d[v]>d[u]+1){
				d[v]=d[u]+1;
				q.push({d[v],v});
			}
		}
	}
}
ll read(){
	char x=getchar();
	ll ret=0,f=1;
	while(!isdigit(x))if(x=='-')f=-1,x=getchar();else x=getchar();
	while(isdigit(x))ret=ret*10+x-'0',x=getchar();
	return ret*f;
}
void add(int a,int b){
	e[idx]=b,ne[idx]=h[a];h[a]=idx++;
}
void dfs(int u,int num,ll sum){
	init(u);
	if(num==4){
		if(d[1]<=k)
			ans=max(ans,sum);
		return ;
	}
	for(int i=1;i<=n;++i)
		if(d[i]<=k && (!ft[i])){
			ft[i]=1;
			dfs(i,num+1,sum+s[i]);
			ft[i]=0;
		}
}
void dfs1(int u,int num,ll sum){
	init(u);
	if(num==4){
		if(d[1]<=k)
			ans=max(ans,sum);
//		return ;
	}
	if(num==5)return ;
	for(int i=1;i<=n;++i)
		if(d[i]==1 && (!ft[i])){
			ft[i]=1;
			dfs(i,num+1,sum+s[i]);
			ft[i]=0;
		}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	memset(h,-1,sizeof h);
	n=read();m=read();k=read();
	for(int i=2;i<=n;++i)s[i]=read();
	for(int i=1;i<=m;++i){
		int a,b;
		a=read(),b=read();
		add(a,b);add(b,a);
	}
	if(k==1){
		dfs1(1,0,0);
		cout<<ans;
		return 0;
	}
	dfs(1,0,0);
	cout<<ans;
	return 0;
}
