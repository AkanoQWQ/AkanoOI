#include<bits/stdc++.h>
using namespace std;
int n,m;
const int mod=998244353;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	int a,b;
	for(int i=1;i<=m;i++)cin>>a>>b;
	int q;
	cin>>q;
	srand(time(0));
	for(int i=1;i<=q;i++)
		cout<<((rand()%2)?"NO":"YES")<<endl;
}
