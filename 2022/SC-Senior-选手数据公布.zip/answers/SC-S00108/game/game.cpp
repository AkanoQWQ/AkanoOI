#include<bits/stdc++.h>
using namespace std;
#define ll long long 
const int N=1e3+10;
int a[N],b[N];
ll c[N][N];
int n,m,q;
ll read(){
	char x=getchar();
	ll ret=0,f=1;
	while(!isdigit(x))if(x=='-')f=-1,x=getchar();else x=getchar();
	while(isdigit(x))ret=ret*10+x-'0',x=getchar();
	return ret*f;
}
inline ll solve(int l,int r,int lll,int rr){
	if(l==r){
		ll ans=0x7f7f7f7f;
		for(int i=lll;i<=rr;i++)
			ans=min(c[l][i],ans);
		return ans;
	}
	else {
		ll ans=-0x7f7f7f7f;
		for(int i=l;i<=r;i++){
			ans=max(c[i][rr],ans);
		}
		return ans;
	}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;++i)
		a[i]=read();
	for(int i=1;i<=m;++i)
		b[i]=read();
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
			c[i][j]=a[i]*b[j];
	for(int i=1;i<=q;++i){
		int l,r,lll,rr;
		l=read(),r=read();lll=read();rr=read();
		cout<<solve(l,r,lll,rr)<<endl;
	}
	return 0;
}
