#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10; 
#define ll long long
#define INF 0x7f7f7f7f
ll v[N];
ll ans=INT_MAX;
int n,q,k;
int h[N],ne[N<<1],w[N<<1],e[N<<1],idx;
void add(int a,int b,int c){
	e[idx]=b,w[idx]=c;ne[idx]=h[a],h[a]=idx++;
}
ll read(){
	char x=getchar();
	ll ret=0,f=1;
	while(!isdigit(x))if(x=='-')f=-1,x=getchar();else x=getchar();
	while(isdigit(x))ret=ret*10+x-'0',x=getchar();
	return ret*f;
}
ll d[N],dis[N];bool vis[N];
void di(int s){
	fill(d+1,d+1+n,INF);
	fill(dis+1,dis+1+n,INF);
	fill(vis+1,vis+1+n,0);
	typedef pair<int,int>pii;
	priority_queue<pii,vector<pii>,greater<pii> >q;
	q.push({0,s});d[s]=v[s];dis[s]=0;
	while(q.size()){
		int u=q.top().second;q.pop();
		if(vis[u])continue;
		vis[u]=1;
		for(int i=h[u];~i;i=ne[i]){
			int j=e[i];
			if(d[j]>d[u]+v[j]){
				d[j]=d[u]+v[j];
				dis[j]=dis[u]+1;
				q.push({d[j],j});
			}
		}
	}
}
bool ft[N];
void dfs(int s,int e,int now){
	if(s==e)return ;
	di(s);
	if(dis[e]<=k){
		ans=min(ans,1ll*(now+d[e]));
	}
	for(int i=1;i<=n;i++){
		if(dis[i]<=k && (!ft[i]))
			ft[i]=1,dfs(i,e,now+d[i]),ft[i]=0;
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	memset(h,-1,sizeof h);
	n=read(),q=read(),k=read();
	for(int i=1;i<=n;i++)v[i]=read();
	for(int i=1;i<n;i++){
		int a,b;
		a=read();b=read();
		add(a,b,1);add(b,a,1);
	}
	for(int i=1;i<=q;i++){
		int s,t;
		s=read();t=read();
		fill(ft+1,ft+1+n,0);
		ans=0x7f7f7f7f7f;
		if(k==1){
			di(s);
			ans=d[t];
		}
		dfs(s,t,0);
		cout<<ans<<endl;
	}
	return 0;
}
