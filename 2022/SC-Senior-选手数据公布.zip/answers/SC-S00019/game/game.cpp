#include<iostream>
#include<cstdio>
using namespace std;
int n,m,q,l1,l2,r1,r2;
long long a[100005],b[100005],ans,nowans;
inline long long max(long long a,long long b){return a>b?a:b;}
inline long long min(long long a,long long b){return a<b?a:b;}
int main(){
	freopen("game.in","r",stdin);freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++)scanf("%lld",&b[i]);
	while(q--){
		scanf("%d%d%d%d",&l1,&l2,&r1,&r2);
		ans=-0x3f1f1f1f1f1f1f1f;
		for(int i=l1;i<=l2;i++){
			nowans=0x3f1f1f1f1f1f1f1f;
			for(int j=r1;j<=r2;j++)
				nowans=min(nowans,a[i]*b[j]);
			ans=max(ans,nowans);}
		printf("%lld\n",ans);}
	return 0;}
