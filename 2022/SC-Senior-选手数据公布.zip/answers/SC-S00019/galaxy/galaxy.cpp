#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,m,u,v,t,q;
bool now,ini[1005][1005],mp[1005][1005],des[1005];
bool findloop(int now,int lay){
	if(lay>n)return true;
	for(int i=1;i<=n;i++){if(mp[now][i])return findloop(i,lay+1);}
	return false;}
bool judge(){
	int now=0;
	for(int i=1;i<=n;i++){now=0;
		for(int j=1;j<=n;j++){if(mp[i][j])now++;if(now>=2)return false;}}
	for(int i=1;i<=n;i++){if(findloop(i,0)==false)return false;}
	return true;}
int main(){
	freopen("galaxy.in","r",stdin);freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){scanf("%d%d",&u,&v);ini[u][v]=mp[u][v]=true;}
	scanf("%d",&q); 
	while(q--){
		scanf("%d",&t);
		if(t==1){scanf("%d%d",&u,&v);mp[u][v]=0;}
		if(t==2){scanf("%d",&u);for(int i=1;i<=n;i++)mp[i][u]=0;}
		if(t==3){scanf("%d%d",&u,&v);mp[u][v]=1;}
		if(t==4){scanf("%d",&u);for(int i=1;i<=n;i++)mp[i][u]=ini[i][u];}
		puts(judge()==0?"NO":"YES");}
	return 0;}


