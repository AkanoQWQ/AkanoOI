#include<iostream>
#include<cstdio>
#include<vector>
#include<queue>
using namespace std;
vector<vector<int> >V,w;
queue<pair<int,int> >q;pair<int,int>now;
int a,b,n,Q,k,v[205];
bool vis[205],vst[205][205];
long long ans=0x3f1f1f1f1f1f1f1f;
void dfs(int now,int tar,long long sco){vis[now]=true;
	if(now==tar){ans=min(ans,sco);return;}
	for(int i=0;i<w[now].size();i++){
		if(vis[w[now][i]])continue;vis[w[now][i]]=true;
		dfs(w[now][i],tar,sco+v[w[now][i]]);vis[w[now][i]]=false;}
	return;}
void bfs(int st){
	while(!q.empty())q.pop();q.push({st,1});
	while(!q.empty()){now=q.front();q.pop();if(now.second>k){while(!q.empty())q.pop();return;}
		for(int i=0;i<V[now.first].size();i++)if(vst[st][V[now.first][i]]==false){vst[st][V[now.first][i]]=true;
			w[st].push_back(V[now.first][i]);q.push({V[now.first][i],now.second+1});}}
	return;}
int main(){
	freopen("transmit.in","r",stdin);freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&Q,&k);V.resize(n+1);w.resize(n+1);
	for(int i=1;i<=n;i++)scanf("%d",&v[i]);
	for(int i=1;i<n;i++){scanf("%d%d",&a,&b);V[a].push_back(b);V[b].push_back(a);}
	for(int i=1;i<=n;i++)bfs(i);
	while(Q--){ans=0x3f1f1f1f1f1f1f1f;scanf("%d%d",&a,&b);if(a>b)swap(a,b);dfs(a,b,v[a]);printf("%lld\n",ans);}
	return 0;}
