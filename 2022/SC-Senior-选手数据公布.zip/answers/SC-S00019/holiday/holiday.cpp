#include<iostream>
#include<vector>
#include<cstdio>
#include<queue>
#include<algorithm>
#include<cstdlib>
using namespace std;
vector<vector<int> >v,w;
queue<pair<int,int> >q;pair<int,int>now;
int n,m,k,From,To,vis[2505];
long long a[2505],score;
bool vst[2505][2505];
void bfs(int st){
	while(!q.empty())q.pop();q.push({st,0});
	while(!q.empty()){now=q.front();q.pop();if(now.second>k){while(!q.empty())q.pop();return;}
		for(int i=0;i<v[now.first].size();i++)if(vst[st][v[now.first][i]]==false){vst[st][v[now.first][i]]=true;
			w[st].push_back(v[now.first][i]);q.push({v[now.first][i],now.second+1});}}
	return;}
void dfs(int now,int lay,long long sco){
	if(lay==5&&now==1){score=max(score,sco);return;}
	for(int i=0;i<w[now].size();i++){if(vis[w[now][i]])continue;
		vis[w[now][i]]=true;dfs(w[now][i],lay+1,sco+a[w[now][i]]);vis[w[now][i]]=false;}
	return;}
int main(){
	freopen("holiday.in","r",stdin);freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);v.resize(n+1);w.resize(n+1);
	for(int i=2;i<=n;i++)scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++){scanf("%d%d",&From,&To);v[From].push_back(To);v[To].push_back(From);}
	for(int i=1;i<=n;i++)bfs(i);dfs(1,0,0);
	printf("%lld",score);
	return 0;}
