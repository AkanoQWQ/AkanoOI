#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+12;
int l[maxn];

int q[maxn];

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,p;
	scanf("%d%d%d",&n,&m,&p);
	int k;
	for(int i=1;i<=n;i++)
		scanf("%d",&l[i]);
	for(int i=1;i<=m;i++)
		scanf("%d",&q[i]);
	int lmin,qmin,lco1,lco2;
	int lmax,qmax;
	int l1,l2,q1,q2;
	while(p--)
	{
		lmax=-0x3f3f3f3f,qmin=0x3f3f3f3f,lco1=0x3f3f3f3f,lco2=-0x3f3f3f3f,lmin=0x3f3f3f3f,qmax=-0x3f3f3f3f;
		int ans=0;
		scanf("%d%d%d%d",&l1,&l2,&q1,&q2);
		for(int i=l1;i<=l2;i++)
		{
			lmax=max(lmax,l[i]);
			lmin=min(lmin,l[i]);
			if(lco1==0)
				continue;
			if(l[i]<0)
				lco2=max(lco2,l[i]);
			else if(l[i]>0)
				lco1=min(lco1,l[i]);
			else
			{
				lco1=0;
				lco2=0;
			}
			
			
		}
		for(int i=q1;i<=q2;i++)
		{
			qmax=max(qmax,q[i]);
			qmin=min(qmin,q[i]);
		}
		if(lmax>0&&qmin>0)
			ans=lmax*qmin;
		else if(qmin<0&&lmin>0)
			ans=lmin*qmin;
		else if(lmax<0&&qmax>0)
			ans=lmax*qmax;
		else if(lmin<0&&qmax<0)
			ans=lmin*qmax;
		else
			ans=max(lco1*qmin,lco2*qmax);
		printf("%d\n",ans);
	}
	return 0;
}
