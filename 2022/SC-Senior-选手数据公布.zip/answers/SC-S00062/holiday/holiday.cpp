#include<bits/stdc++.h>
using namespace std;
const int maxn=2534;
const int maxm=1e4+23;
int f[maxn][105][4];
struct place{
	int z;int ad;
};
place pl[maxn];
int ed[maxn];
struct edge{
	int to,next;
};
int cnt=0;
int head[maxn];
edge eg[maxm<<1];
	int n,m,k;
void add(int x,int y)
{
	cnt++;
	eg[cnt].to=y;
	eg[cnt].next=head[x];
	head[x]=cnt;
}
int ans=-114;
void find(int noww,int lesk)
{
	ed[noww]=1;
	if(lesk>0)
		for(int i=head[noww];i!=-1;i=eg[i].next)
			find(eg[i].to,lesk-1);
}

void dfs(int noww,int lesk,int lespl,int w)
{
	if(lespl==0)
	{
		if(ed[noww]==1)
			ans=max(ans,w);
		return;
	}
	for(int i=head[noww];i!=-1;i=eg[i].next)
	{
		if(noww!=1&&!pl[noww].ad)
		{
			pl[noww].ad=1;
			dfs(eg[i].to,k,lespl-1,w+pl[noww].z);
			pl[noww].ad=0;
		}
		if(lesk>0)
			dfs(eg[i].to,lesk-1,lespl,w);
	}
		
}





int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	memset(head,-1,sizeof(head));
	scanf("%d%d%d",&n,&m,&k);
	int t,x,y;
	for(int i=2;i<=n;i++)
	{
		scanf("%d",&t);
		pl[i].z=t;
	}	
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);	
	}
	find(1,k+1);
	dfs(1,k+1,4,0);
	printf("%d",ans);
	return 0;
}
