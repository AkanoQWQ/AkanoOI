#include<bits/stdc++.h>
using namespace std;
const int maxn=5e5+10;
int fa[maxn];
int beg[maxn];
struct edge{
	int to,next,noww;
};
int cnt=0;
int head[maxn];
edge eg[maxn];
void add(int x,int y)
{
	cnt++;
	eg[cnt].to=y;
	eg[cnt].noww=1;
	eg[cnt].next=head[x];
	head[x]=cnt;
}
int find(int x)
{
	if(x==fa[x])
		return x;
	else
	{
		fa[x]=find(fa[x]);
		return fa[x];
	}
		
}
void unon(int a,int b)
{
	int x=find(a);
	int y=find(b);
	if(x!=y) fa[x]=y;
}




int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		fa[i]=i;
	int x,y;
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&x,&y);
		add(y,x);//��X��Y 
	}
	int q,t,u,v;
	scanf("%d",&q);
	while(q--)
	{
		scanf("%d",&t);
		if(t==1)
		{
			scanf("%d%d",&u,&v);
			for(int i=head[v];i!=-1;i=eg[i].next)
			{
				if(eg[i].to==u)
				{
					eg[i].noww=0;
					break;
				}
			}
		}
		if(t==2)
		{
			scanf("%d",&u);
			for(int i=head[u];i!=-1;i=eg[i].next)
				eg[i].noww=0;
		}
		if(t==3)
		{
			scanf("%d%d",&u,&v);
			for(int i=head[v];i!=-1;i=eg[i].next)
			{
				if(eg[i].to==u)
				{
					eg[i].noww=1;
					break;
				}
			}
		}
		if(t==4)
		{
			scanf("%d",&u);
			for(int i=head[u];i!=-1;i=eg[i].next)
				eg[i].noww=1;	
		}
		int ans=1;
		memset(beg,0,sizeof(beg));
		for(int i=1;i<=n;i++)
		{
			for(int j=head[i];j!=-1;j=eg[j].next)
			{
				if(eg[j].noww==1)
				{
					beg[eg[j].to]++;
					unon(i,eg[j].to);
					if(beg[eg[j].to]>1)
					{
						ans=0;
						break;
					}	
				}		
			}
			if(ans==0)
				break;	
		}
		if(ans==0)
		{
			printf("NO\n");
			continue;
		}
		int csa=fa[1];
		for(int i=1;i<=n;i++)
		{
			if(csa!=fa[i])
			{
				ans=0;
				break;
			}
		}
		if(ans==0)
		{
			printf("NO\n");
			continue;
		}
		printf("YES\n");
	}
	return 0;
}



