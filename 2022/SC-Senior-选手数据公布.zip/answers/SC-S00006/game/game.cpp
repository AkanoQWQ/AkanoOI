#include<iostream>
#include<climits>
using namespace std;

typedef long long ll;

const int N = 1e5 + 10;
int n, m, q;
int A[N], B[N];

void work(int l1, int r1, int l2, int r2);

int main( ) {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	
	cin >> n >> m >> q;
	for(int i = 1; i <= n; i++) cin >> A[i];
	for(int i = 1; i <= m; i++) cin >> B[i];
	
	for(int i = 1; i <= q; i++) {
		int l1, r1, l2, r2;
		cin >> l1 >> r1 >> l2 >> r2;
		work(l1, r1, l2, r2);
	}
	return 0;
}

void work(int l1, int r1, int l2, int r2) {
	bool act1 = false, nag1 = false, zero1 = false, act2 = false, nag2 = false, zero2 = false;
	int Max1 = INT_MIN, Min1 = INT_MAX, absMin1 = INT_MAX, Max2 = INT_MIN, Min2 = INT_MAX, absMin2 = INT_MAX;
	for(int i = l1; i <= r1; i++) {
		if(A[i] > 0) act1 = true;
		if(A[i] < 0) nag1 = true;
		if(A[i] == 0) zero1 = true;
		Max1 = max(Max1, A[i]);
		Min1 = min(Min1, A[i]);
		if(abs(absMin1) >= abs(A[i])) absMin1 = A[i];
	}
	for(int	i = l2; i <= r2; i++) {
		if(B[i] > 0) act2 = true;
		if(B[i] < 0) nag2 = true;
		if(B[i] == 0) zero2 = true;
		Max2 = max(Max2, B[i]);
		Min2 = min(Min2, B[i]);
		if(abs(absMin2) >= abs(B[i])) absMin2 = B[i];
	}
	int c1, c2;
	if(act2 && nag2) c1 = absMin1;
	if(act1 && nag1) c2 = absMin2;
	if(act2 && !nag2) c1 = Max1;
	if(act1 && !nag1) c2 = Min2;
	if(!act2 && nag2) c1 = Min1;
	if(!act1 && nag1) c2 = Max2;
	cout << c1 * c2 << endl;
}
