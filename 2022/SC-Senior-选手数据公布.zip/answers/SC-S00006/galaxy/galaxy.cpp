#include<iostream>
#include<cstring>
using namespace std;

const int N = 1e5 + 10, M = 5e5 + 10;
int n, m, q;
int head[N], d[N], Index;
bool vis[N], f;

struct Edge {
	int a, to;
	int Next;
	bool des;
}e[M];

void add(int a, int b);
void dfs(int u);

int main( ) {
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	
	cin >> n >> m;
	for(int i = 1; i <= m; i++) {
		int a, b;
		cin >> a >> b;
		add(a, b);
	}
	cin >> q;
	for(int i = 1; i <= q; i++) {
		int t;
		cin >> t;
		if(t == 1) {
			int u, v;
			cin >> u >> v;
			for(int i = 1; i <= Index; i++)
				if(e[i].a == u && e[i].to == v) {
					d[e[i].a]--;
					e[i].des = true;
				}
		}
		if(t == 2) {
			int u;
			cin >> u;
			for(int i = 1; i <= Index; i++)
				if(e[i].to == u) {
					if(!e[i].des) d[e[i].a]--;
					e[i].des = true;
				}
		}
		if(t == 3) {
			int u, v;
			cin >> u >> v;
			for(int i = 1; i <= Index; i++)
				if(e[i].a == u && e[i].to == v) {
					d[e[i].a]++;
					e[i].des = false;
				}
		}
		if(t == 4) {
			int u;
			cin >> u;
			for(int i = 1; i <= Index; i++)
				if(e[i].to == u) {
					if(e[i].des) d[e[i].a]++;
					e[i].des = false;
				}
		}
		bool flag = true;
		for(int i = 1; i <= n; i++)
			if(d[i] != 1) {
				cout << "NO" << endl;
				flag = false;
				break;
			}
		if(!flag) continue;
		for(int i = 1; i <= n; i++) {
			dfs(i);
			if(!f) {
				cout << "NO" << endl;
				flag = false;
				break;
			}
		}
		if(flag) cout << "YES" << endl;
	}
	return 0;
}

void add(int a, int b) {
	e[++Index].a = a, e[Index].to = b;
	e[Index].Next = head[a], head[a] = Index;
	d[a]++;
}

void dfs(int u) {
	for(int i = head[u]; i; i = e[i].Next) {
		if(vis[e[i].to]) f = true;
		if(e[i].des || vis[e[i].to]) continue;
		vis[e[i].to] = true;
		dfs(e[i].to);
		vis[e[i].to] = false;
	}
}
