#include<iostream>
using namespace std;

typedef long long ll;

const int N = 3000, M = 2e4 + 10;
int head[N], to[M], Next[M], Index;
int n, m, k;
ll ans, val[N];
bool vis[N];
int f[N][N];

void add(int a, int b);
void dfs(int u, int step, int v, ll tot);
void work1( );
void work2( );

int main( ) {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	
	cin >> n >> m >> k;
	if(n <= 90) work2( );
	else work1( );
	return 0;
}

void add(int a, int b) {
	to[++Index] = b;
	Next[Index] = head[a], head[a] = Index;
}

void dfs(int u, int step, int v, ll tot) {
	if(v == 5) {
		if(u == 1) ans = max(ans, tot);
		return ;
	}
	for(int i = head[u]; i; i = Next[i]) {
		int j = to[i];
		if(!vis[j]) {
			vis[j] = true;
			dfs(j, 0, v + 1, tot + val[j]);
			vis[j] = false;
		}
		if(step < k) dfs(j, step + 1, v, tot);
	}
}

void work1( ) {
	for(int i = 2; i <= n; i++) cin >> val[i];
	for(int i = 1; i <= m; i++) {
		int a, b;
		cin >> a >> b;
		add(a, b), add(b, a);
	}
	
	dfs(1, 0, 0, 0);
}

void work2( ) {
	memset(f, 0x3f, sizeof f);
	
	for(int i = 2; i <= n; i++) cin >> val[i];
	
	for(int i = 1; i <= m; i++) {
		int a, b;
		cin >> a >> b;
		f[a][b] = 1;
		f[b][a] = 1;
	}
	
	for(int k = 1; k <= n; k++)
		for(int i = 1; i <= n; i++)
			for(int j = 1; j <= n; j++) 
				f[i][j] = min(f[i][j], f[i][k] + f[k][j]);
	
	for(int a = 1; a <= n; a++)
		for(int b = 1; b <= n; b++) {
			if(b == a) continue;
			for(int c = 1; c <= n; c++) {
				if(c == a || c == b) continue;
				for(int d = 1; d <= n; d++) {
					if(d == a || d == b || d == c) continue;
					if(f[1][a] <= k + 1 && f[a][b] <= k + 1 && f[b][c] <= k + 1 && f[c][d] <= k + 1 && f[d][1] <= k + 1)
						ans = max(ans, val[a] + val[b] + val[c] + val[d]);
				}
			}
		}
	
	cout << ans << endl;
}
