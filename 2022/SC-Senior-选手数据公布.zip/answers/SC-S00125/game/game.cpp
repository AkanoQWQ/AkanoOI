#include <bits/stdc++.h>
using namespace std;
int n,m,q;
long long a[100005],b[100005],l1[100005],r1[100005],l2[100005],r2[100005],minc[100005],maxc=-pow(2,62);
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	for(int i=1;i<=n;++i){
		scanf("%lld",&a[i]);
	}
	for(int i=1;i<=m;++i){
		scanf("%lld",&b[i]);
	}
	for(int i=1;i<=q;++i){
		scanf("%lld%lld%lld%lld",&l1[i],&r1[i],&l2[i],&r2[i]);
		memset(minc,0x3f3f3f3f,sizeof(minc));
		maxc=-pow(2,62);
		for(int j=l1[i];j<=r1[i];++j){
			for(int k=l2[i];k<=r2[i];++k){
				minc[j]=min(minc[j],a[j]*b[k]);
			}
			maxc=max(maxc,minc[j]);
		}
		printf("%lld\n",maxc);
	}
	return 0;
}
