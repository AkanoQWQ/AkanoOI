#include <bits/stdc++.h>
using namespace std;
int n,m,q,d[10005][10005],dd[10005][10005],p[10005][10005];
int dp(){
	for(int i=1;i<=n;++i){
		int sum=0;
		for(int j=1;j<=n;j++){
			if(d[i][j]==1){
				++sum;
			}
			if(sum==2){
				return 0;
			}
		}
	}
	for(int i=1;i<=n;++i){
		for(int j=1;j<=n;++j){
			dd[i][j]=d[i][j];
			if(i!=j && d[i][j]==1 && d[j][i]==1){
				return 1;
			}
		}
	}
	for(int i=1;i<=n;++i){
		for(int j=1;j<=n;++j){
			if(dd[i][j]==1){
				dd[j][i]=dd[i][j];
			}
		}
	}
	for(int i=1;i<=n;++i){
		for(int j=1;j<=n;++j){
			if(dd[i][j]==0 && i!=j){
				return 0;
			}
		}
	}
	return 1;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;++i){
		int u,v;
		scanf("%d%d",&u,&v);
		d[u][v]=1;
		p[u][v]=1;
	}
	scanf("%d",&q);
	while(q--){
		int t,u,v;
		scanf("%d",&t);
		if(t==1){
			scanf("%d%d",&u,&v);
			d[u][v]=0;
		}
		else if(t==2){
			scanf("%d",&u);
			for(int i=1;i<=n;++i){
				d[i][u]=0;
			}
		}
		else if(t==3){
			scanf("%d%d",&u,&v);
			d[u][v]=1;
		}
		else if(t==4){
			scanf("%d",&u);
			for(int i=1;i<=n;++i){
				if(p[i][u]==1){
					d[i][u]=1;
				}
			}
		}
		if(dp()==1){
			printf("YES\n");
		}
		else{
			printf("NO\n");
		}
	}
	return 0;
}
