#include <bits/stdc++.h>
using namespace std;
int n,m,k;
int z[2505],dp[2505][2505],sum,maxn=-0x3f3f3f3f;
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;++i){
		scanf("%d",&z[i]);
	}
	for(int i=1;i<=m;++i){
		int n,m;
		scanf("%d%d",&n,&m);
		dp[n][m]=dp[m][n]=1;
	}
	for(int i=2;i<=n;++i){
		sum=0;
		if(dp[i][1]==1){
			sum+=z[i];
			for(int j=2;j<=n;++j){
				if(dp[j][i]==1){
					sum+=z[j];
					for(int q=2;q<=n;++q){
						if(dp[q][j]==1){
							sum+=z[q];
							for(int l=2;l<=n;++l){
								if(dp[l][q]==1 && dp[1][l]==1){
									sum+=z[l];
									maxn=max(maxn,sum);
									sum-=z[l];
								}
							}
							sum-=z[q];
						}
					}
					sum-=z[j];
				}
			}
			sum-=z[i];
		}
	}		
	printf("%d",maxn);
	return 0;
}
