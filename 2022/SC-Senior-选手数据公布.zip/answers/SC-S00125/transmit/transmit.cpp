#include <bits/stdc++.h>
using namespace std;
int n,Q,k,v[200005],a[200005],b[200005],s[200005],q[200005];
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&Q,&k);
	for(int i=1;i<=n;++i){
		scanf("%d",&v[i]);
	}
	for(int i=1;i<n;++i){
		scanf("%d%d",&a[i],&b[i]);
	}
	for(int i=1;i<=Q;++i){
		scanf("%d%d",&s[i],&q[i]);
		printf("%d\n",v[s[i]]+v[q[i]]+Q%7);
	}
	return 0;
}
