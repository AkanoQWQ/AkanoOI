#include<bits/stdc++.h>
using namespace std;
const int N=100005,INF=1000000080;
int n,m,q;
int a[N],b[N];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)scanf("%d",&b[i]);
	while(q--){
		int l1,l2,r1,r2;
		long long ans=-INF;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		for(int i=l1;i<=r1;i++){
			long long res;
			if(a[i]>0){
				int mmin=INF;
				for(int j=l2;j<=r2;j++){
					mmin=min(mmin,b[j]);
				}
				res=mmin*a[i];
			}
			else if(a[i]<0){
				int mmax=-INF;
				for(int j=l2;j<=r2;j++){
					mmax=max(mmax,b[j]);
				}
				res=mmax*a[i];
			}
			else {
				//a[i]==0
				res=0;
			}
			ans=max(ans,res);
		}
		cout<<ans<<'\n'; 
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

