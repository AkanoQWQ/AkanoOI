// ǰ���Ƿ�������ģ� Ӯٸ����,����Ϊ����������ʿ 
#include<bits/stdc++.h>
using namespace std;
const int N=500005;
int n,m,q;
bool vis[N];
int rd[N],cd[N];
struct node{
	int to;
	bool broken;
};
vector <node> g[N];
void update(int x,int y){
	++rd[y];
	++cd[x];
	node t;
	t.broken=false;
	t.to=y;
	g[x].push_back(t);
	return ;
}
void kill(int u,int v){
	for(int i=0;i<g[u].size();i++)if(g[u][i].to==v&&!g[u][i].broken){
		g[u][i].broken=true;
		--cd[u];
		--rd[v];
		break;
	}
	return ;
}
void kill_all(int u){
	for(int i=1;i<=n;i++){
		kill(i,u);
	}
	return ;
}
void repair(int u,int v){
	for(int i=0;i<g[u].size();i++)if(g[u][i].to==v&&g[u][i].broken){
		g[u][i].broken=false;
		++cd[u];
		++rd[v];
		break;
	}
	return ;
}
void repair_all(int u){
	for(int i=1;i<=n;i++){
		repair(i,u);
	}
	return ;
}
bool fight(int now){
	if(cd[now]==0)return false;
	bool flag=false;
	for(int i=0;i<g[now].size();i++){
		node u=g[now][i];
		if(u.broken)continue;
		if(vis[u.to])return true;
		vis[u.to]=true;
		if(fight(u.to)){
			flag=true;
			break;
		}
		vis[u.to]=false;
	}
	return flag;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		update(u,v);
	}
	scanf("%d",&q);
	while(q--){
		for(int i=1;i<=n;i++)vis[i]=false;
		int opt;
		scanf("%d",&opt);
		if(opt==1){
			int u,v;
			scanf("%d%d",&u,&v);
			kill(u,v);
		}
		if(opt==2){
			int u;
			scanf("%d",&u);
			kill_all(u); 
		}
		if(opt==3){
			int u,v;
			scanf("%d%d",&u,&v);
			repair(u,v);
		}
		if(opt==4){
			int u;
			scanf("%d",&u);
			repair_all(u);
		}
		
//		if(q==8)
//			for(int i=1;i<=n;i++){
//				for(int j=0;j<g[i].size();j++){
//					node oo=g[i][j];
//					cout<<i<<' '<<oo.to;
//					if(oo.broken)cout<<" broken\n";
//					else cout<<'\n';
//				}
//			}
//			for(int i=1;i<=n;i++){
//				cout<<i<<" cd:"<<cd[i]<<'\n';
//			}	
		bool res=true;
		for(int i=1;i<=n;i++){
			if(!fight(i)||cd[i]!=1){
				res=false;
				break;
			}
		}
		if(res)printf("YES\n");
		else printf("NO\n");
	}
	fclose(stdin);
	fclose(stdout); 
	return 0;
}

