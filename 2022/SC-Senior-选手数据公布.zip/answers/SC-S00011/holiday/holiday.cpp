#include<bits/stdc++.h>
//#define int long long
using namespace std;
const int N=2505,M=10005;
int n,m,k;
long long s[N];
vector <int> g[N];
bool vis[N];
int ans;
void dfs(int x,int p,int now){
	if(p==4){
		ans=max(ans,now);
		return ;
	}
	for(int i=0;i<g[x].size();i++){
		int u=g[x][i];
		if(!vis[u]){
//			cout<<u<<'\n';
			vis[u]=true;
			dfs(u,p+1,now+s[u]);
			vis[u]=false;
		}
	}
	return ;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	ans=-1;
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<n;i++)cin>>s[i+1];
	for(int i=1;i<=m;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		g[x].push_back(y);
		g[y].push_back(x);
	}
	if(k==0){
		vis[1]=true;
		dfs(1,0,0);
		cout<<ans;
	}
	else {
		srand(time(NULL));
		long long maxx=-1;
		for(int i=1;i<=n;i++)maxx=max(s[i],maxx);
		cout<<rand()%(maxx*4);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1

*/
