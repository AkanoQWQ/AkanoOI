#include<bits/stdc++.h>
using namespace std;
#define ll long long

const int N=2509,M=40000000;
int n,m,k,xx;
ll a[N],dis[N],ans,maxx;
bool vis[N];
vector<int> e[N];
vector<pair<ll,int> > in[N];

void bfs(int s){
	memset(vis,0,sizeof(vis));
	for(int i=1;i<=n;i++) dis[i]=1e5;
	queue<int> q;
	q.push(s);
	vis[s]=1;dis[s]=-1;
	while(!q.empty()){
		int u=q.front();q.pop();
		for(int v:e[u]){
			if(!vis[v]){
				vis[v]=1;
				dis[v]=dis[u]+1;
				q.push(v);
				if(dis[v]<=k) in[s].push_back(make_pair(a[v],v));
			}
		}
	}
}
void dfs(int u,int cnt,ll num){
	if(xx>=M) return;
	xx++;
	for(auto x:in[u]){
		int v=x.second;
		if(!vis[v]){
			if(cnt==3){
				if(dis[v]<=k) ans=max(ans,num+a[v]);
				return;
			}
			if(cnt==2&&num+a[v]<ans-maxx) continue;
			vis[v]=1;
			dfs(v,cnt+1,num+a[v]);
			vis[v]=0;
		}
	}
}

int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++) scanf("%lld",&a[i]),maxx=max(a[i],maxx);
	int u,v;
	for(int i=1;i<=m;i++){
		scanf("%d%d",&u,&v);
		e[u].push_back(v);
		e[v].push_back(u);
	}
	for(int i=n;i>=1;i--) bfs(i),sort(in[i].begin(),in[i].end(),greater<pair<ll,int>>());
	memset(vis,0,sizeof(vis));
	vis[1]=1;
	dfs(1,0,0);
	printf("%lld",ans);
	return 0;
}
