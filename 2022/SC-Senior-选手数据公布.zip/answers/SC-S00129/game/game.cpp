#include<bits/stdc++.h>
using namespace std;
#define ll long long

const int N=1e5+9;
int n,m,q;
ll a[N],b[N];
struct seg{
	ll n,m;
}x[N<<2],y[N<<2];

void pushup(int u,bool type){
	if(type){
		y[u].m=max(y[u<<1].m,y[u<<1|1].m);
		y[u].n=min(y[u<<1].n,y[u<<1|1].n);
	}
	else{
		x[u].m=max(x[u<<1].m,x[u<<1|1].m);
		x[u].n=min(x[u<<1].n,x[u<<1|1].n);
	}
}
void build(int u,int l,int r,bool type){//0a,1b
	if(l==r){
		if(type) y[u].m=y[u].n=b[l];
		else x[u].m=x[u].n=a[l];
		return;
	}
	int mid=(l+r)>>1;
	build(u<<1,l,mid,type);
	build(u<<1|1,mid+1,r,type);
	pushup(u,type);
}
seg query(int u,int l,int r,int s,int t,bool type){
	if(s<=l&&r<=t){
		if(type) return y[u];
		else return x[u];
	}
	int mid=(l+r)>>1;
	seg ans,x=(seg){INT_MAX,INT_MIN},y=(seg){INT_MAX,INT_MIN};
	if(s<=mid) x=query(u<<1,l,mid,s,t,type);
	if(mid<t) y=query(u<<1|1,mid+1,r,s,t,type);
	ans.n=min(x.n,y.n);
	ans.m=max(x.m,y.m);
	return ans;
}

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	build(1,1,n,0);
	for(int i=1;i<=m;i++) scanf("%lld",&b[i]);
	build(1,1,n,1);
	int l1,r1,l2,r2;
	while(q--){
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		if(l1==r1){
			if(a[l1]>=0) printf("%lld\n",a[l1]*query(1,1,n,l2,r2,1).n);
			else printf("%lld\n",a[l1]*query(1,1,n,l2,r2,1).m);
		}
		else if(l2==r2){
			if(b[l2]>=0) printf("%lld\n",b[l2]*query(1,1,n,l1,r1,0).m);
			else printf("%lld\n",b[l2]*query(1,1,n,l1,r1,0).n);
		}
		else printf("%lld\n",query(1,1,n,l1,r1,0).m*query(1,1,n,l2,r2,1).n);
	}
	return 0;
}
