#include<bits/stdc++.h>
using namespace std;

const int N=2e3+9;
int n,m,q,d[N],cd[N];
int st[N],dfn[N],low[N],id[N],sz[N],tot,top,cnt;
bool ed[N][N],in[N];
vector<int> e[N],r[N];

void tarjan(int u){
	dfn[u]=low[u]=++tot;
	st[++top]=u;in[u]=1;
	for(int v:e[u]){
		if(!ed[u][v]) continue;
		if(!dfn[v]) tarjan(v),low[u]=min(low[u],low[v]);
		else if(in[v]) low[u]=min(low[u],dfn[v]);
	}
	if(dfn[u]==low[u]){
		int t;
		cnt++;
		do{
			t=st[top--];
			in[t]=0;
			id[t]=cnt;
			sz[t]++;
		}while(t!=u);
	}
}

bool check(){
	for(int i=1;i<=n;i++) if(d[i]!=1) return 0;
	top=tot=cnt=0;
	memset(dfn,0,sizeof(dfn));
	memset(cd,0,sizeof(cd));
	memset(in,0,sizeof(in));
	memset(sz,0,sizeof(sz));
	for(int i=1;i<=n;i++){
		if(!dfn[i]) tarjan(i);
	}
	if(cnt==n) return 0;
	for(int i=1;i<=n;i++){
		for(int v:e[i]){
			if(!ed[i][v]) continue;
			int x=id[i],y=id[v];
			if(x!=y) cd[x]++;
		}
	}
	for(int i=1;i<=cnt;i++) if(cd[i]>0&&sz[i]>1) return 0;
	return 1;
}

int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	int u,v;
	for(int i=1;i<=m;i++){
		scanf("%d%d",&u,&v);
		e[u].push_back(v);
		r[v].push_back(u);
		ed[u][v]=1;
		d[u]++;
	}
	scanf("%d",&q);
	int opt;
	while(q--){
		scanf("%d%d",&opt,&u);
		if(opt==1){
			scanf("%d",&v);
			ed[u][v]=0,d[u]--;
		}
		if(opt==2){
			for(int v:r[u]){
				if(ed[v][u]) ed[v][u]=0,d[v]--;
			}
		}
		if(opt==3){
			scanf("%d",&v);
			ed[u][v]=1,d[u]++;
		}
		if(opt==4){
			for(int v:r[u]){
				if(!ed[v][u]) ed[v][u]=1,d[v]++;
			}
		}
		if(check()) printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
