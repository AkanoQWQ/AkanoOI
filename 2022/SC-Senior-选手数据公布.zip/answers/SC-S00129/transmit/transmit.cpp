#include<bits/stdc++.h>
using namespace std;
#define ll long long

const int N=2e3+9;
int n,q,k;
ll val[N],dis[N],dep[N];
bool vis[N];
vector<int> st[N];
vector<pair<int,ll> > e[N];

void bfs(int s){
	queue<int> q;
	memset(vis,0,sizeof(vis));
	vis[s]=1;
	dis[s]=dep[s]=0;
	q.push(s);
	while(!q.empty()){
		int u=q.front();q.pop();
		for(int v:st[u]){
			if(!vis[v]){
				vis[v]=1;
				dep[v]=dep[u]+1;
				if(dep[v]>k) break;
				dis[v]=dis[u]+val[u];
				e[u].push_back(make_pair(v,dis[v]));
			}
		}
	}
}
void spfa(int s){
	memset(vis,0,sizeof(vis));
	for(int i=1;i<=n;i++) dis[i]=2e9;
	dis[s]=0;
	queue<int> q;
	q.push(s);
	while(!q.empty()){
		int u=q.front();q.pop();
		vis[u]=0;
		for(auto x:e[u]){
			int v=x.first,w=x.second;
			if(dis[v]>dis[u]+w){
				dis[v]=dis[u]+w;
				if(!vis[v]) vis[v]=1,q.push(v);
			}
		}
	}
}

int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++) scanf("%lld",&val[i]);
	int a,b,s,t;
	for(int i=1;i<n;i++){
		scanf("%d%d",&a,&b);
		st[a].push_back(b);
		st[b].push_back(a);
	}
	for(int i=1;i<=n;i++) bfs(i);
	while(q--){
		scanf("%d%d",&s,&t);
		spfa(s);
		printf("%lld\n",dis[t]+val[t]);
	}
	return 0;
}
