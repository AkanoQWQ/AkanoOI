#include<cstdio>
#define max(a,b) (a<b?b:a)
#define min(a,b) (a<b?a:b)
#define ll long long
using namespace std;
int a[100001],b[100001],r[2][2][100001][17];//С0��1��n0m1 
int gotw(int n){
	if(n==0) return -1;
	int ans=0;
	n=2*n-1;
	while(n>>=1) ans++;
	return ans;
}
int rmq(bool m,bool n,int f,int l){
	int x=gotw(l-f+1)-1;
	//printf("11 %d %d %d 11",r[m][n][f][x],r[m][n][l-1<<x][x],x);
	return (m?max(r[m][n][f][x],r[m][n][l-(1<<x>>1)][x]):min(r[m][n][f][x],r[m][n][l-(1<<x>>1)][x]));
}//m:1��0С 
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	for(int i=0;i<2;i++) for(int j=0;j<2;j++) for(int x=0;x<100001;x++) for(int y=0;y<17;y++) r[i][j][x][y]=i?-114514:114514;
	int n,m,q,ln=1,lm=1;
	scanf("%d%d%d",&n,&m,&q);
	ln=gotw(n);
	lm=gotw(m);
	for(int i=0;i<n;i++) scanf("%d",a+i);
	for(int j=0;j<m;j++) scanf("%d",b+j);
	for(int i=0;i<ln;i++){
		if(!i){
			for(int j=0;j<n;j++){
				r[0][0][j][0]=a[j];
				r[1][0][j][0]=a[j];
			}
			continue;
		}
		for(int j=0;j<max(0,n-(1<<i>>1));j++){
			r[1][0][j][i]=max(r[1][0][j][i-1],r[1][0][j+(1<<i>>1)][i-1]);
			r[0][0][j][i]=min(r[0][0][j][i-1],r[0][0][j+(1<<i>>1)][i-1]);
		}
	}
	for(int i=0;i<lm;i++){
		if(!i){
			for(int j=0;j<n;j++){
				r[0][1][j][0]=b[j];
				r[1][1][j][0]=b[j];
			}
			continue;
		}
		for(int j=0;j<=max(0,m-((1<<i>>1)));j++){
			r[1][1][j][i]=max(r[1][1][j][i-1],r[1][1][j+(1<<i>>1)][i-1]);
			r[0][1][j][i]=min(r[0][1][j][i-1],r[0][1][j+(1<<i>>1)][i-1]);
		}
	}//Ԥ����rmq 
	//printf("%d ",rmq(1,1,0,1));
	while(q--){
		int l1=0,r1=0,l2=0,r2=0;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		l1--,l2--,r1--,r2--;
		ll ans=-114514;
		for(int i=l1;i<=r1;i++){
			ans=max(ans,min(rmq(1,1,l2,r2)*a[i],rmq(0,1,l2,r2)*a[i]));
		}
		printf("%d\n",ans);
	}
} 
//9 1 0 1 2 0 8 6 7 0 9 10 1
/*3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2*/
