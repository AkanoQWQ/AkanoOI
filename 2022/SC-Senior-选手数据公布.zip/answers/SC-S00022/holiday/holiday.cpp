//ͼ�鱣��
//ף�ұ����ܹ�5���� 
#include<bits/stdc++.h>
using namespace std;
int dis[2550][2550],book[2550],n,m,k,inf=999999999;
long long s[2550],ans=0,cnt=0;
void flo(){
	for(int a=1;a<=n;a++){
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
			
				if(i!=j)
				dis[i][j]=min(dis[i][j],dis[i][a]+dis[a][j]);
			}
		}
	}
}

void dfs(int temp,int num){
	if(num==4) {
		if(dis[temp][1]<=k+1)
			ans=max(ans,cnt);
		return;
	}
	
	for(int i=1;i<=n;i++){
		if(dis[temp][i]<=k+1&&book[i]!=1){
			cnt+=s[i];
			book[i]=1;
			//printf("%d %lld\n",temp,cnt);
			dfs(i,num+1);
			cnt-=s[i];
			book[i]=0;
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++) scanf("%lld",&s[i]);
	memset(dis,0x3f,sizeof dis);
	int a,b;
	for(int i=1;i<=m;i++){
		scanf("%d%d",&a,&b);
		dis[a][b]=dis[b][a]=1;
	}
	book[1]=1;
	flo();

	/*for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++) 	printf("%d    ",dis[i][j]);
		puts("");
	}*/
	
	dfs(1,0);
	printf("%lld",ans);
 	return 0;
}

