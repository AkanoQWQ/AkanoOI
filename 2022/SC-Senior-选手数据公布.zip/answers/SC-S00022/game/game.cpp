//ͼ�鱣��
//ף�ұ����ܹ�5���� 
#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
//priority_queue<pair<int,int>> la,sa,lb,sb;
long long a[N],b[N],inf=1000000001;
int n,m,q,flag1=0,flag2=0;
int l1,r1,l2,r2; 
int maxn,minn;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
		if(a[i]<=0) {
			flag1=1;	
		}
	} 
	for(int i=1;i<=m;i++){
		scanf("%lld",&b[i]);

	}
	long long xa1,ya1,ya2,xa2,xb1,yb1,yb2,xb2,a1,b1,a2,b2;
	while(q--)
	{
		xa1=inf,ya1=-inf,ya2=inf,xa2=-inf,xb1=inf,yb1=-inf,yb2=inf,xb2=-inf,a1=0,b1=0,a2=0,b2=0;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		for(int i=l1;i<=r1;i++){
			if(a[i]>0){
				a1=1;
				ya2=min(ya2,a[i]);
				xa2=max(xa2,a[i]);
			}
			else{
				a2=1;
				xa1=min(xa1,a[i]);
				ya1=max(ya1,a[i]);
			}
		}
		for(int i=l2;i<=r2;i++){
			if(b[i]>0){
				b1=1;
				yb2=min(yb2,b[i]);
				xb2=max(xb2,b[i]);
			}
			else{
				b2=1;
				xb1=min(xb1,b[i]);
				yb1=max(yb1,b[i]);
			}
		}
		//printf("%lld %lld %lld %lld %lld %lld %lld %lld\n",xa1,ya1,ya2,xa2,xb1,yb1,yb2,xb2);
		if(a1==1&&a2==1){
			if(b1==1&&b2==1){
				printf("%lld\n",max(ya1*xb2,ya2*xb1));
			} 
			else if(b1==1){
				printf("%lld\n",xa2*yb2);
			}
			else printf("%lld\n",xa1*yb1);
		}
		else if(a1==1){
			if(b1==1&&b2==1){
				printf("%lld\n",ya2*xb1);
			} 
			else if(b1==1){
				printf("%lld\n",xa2*yb2);
			}
			else printf("%lld\n",ya2*xb1);
		}
		else{
			if(b1==1&&b2==1){
				printf("%lld\n",ya1*xb2);
			} 
			else if(b1==1){
				printf("%lld\n",ya1*xb2);
			}
			else printf("%lld\n",xa1*yb1);
		}
	}
	return 0;
}

