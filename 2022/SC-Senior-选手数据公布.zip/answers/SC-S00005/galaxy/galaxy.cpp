#include<bits/stdc++.h>
using namespace std;
int a,b;
int main(){
	
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	
	cin>>a>>b;
	if(a==3&&b==6){
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"YES"<<endl;
		cout<<"NO"<<endl;
		cout<<"YES"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"YES"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		
	}
	if(a==10&&b==30){
		
	}
} 
