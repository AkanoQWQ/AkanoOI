#include<bits/stdc++.h>
using namespace std;
int n,m,k;

int point[3001];
int mapp[3001][3001];
int dpbox[3001][101];
int js[3001];
int jsq;
int x,y;
int ans;
int bj[3001];
int oppo;
int maxx=0,maxxp=0;
int re;
queue <int> q;
void dp(int now,int step){
	
	for(int j=1;j<=k+1;j++){//ö�ٲ��� 
		oppo=0;
		
		if(step==3){
			if(mapp[now][1]==j){
				for(int o=1;o<=k+1;o++){
					ans=max(ans,dpbox[now][o]);
				}
				return;
			}
			else oppo=1;
		}
		
		if(oppo==0){
		maxx=0,maxxp=0;	
		for(int l=1;l<=n;l++){//Ѱ�Ҷ�Ӧ�� 
			if(mapp[now][l]==j&&point[l]>maxxp&&bj[l]==0){
				maxxp=point[l];
				maxx=l;
			}
		}
		if(maxx){
		bj[maxx]=1;
		q.push(maxx);
		for(int l=1;l<=k+1;l++){
			if(dpbox[now][l]+maxxp>dpbox[maxx][j]){
				dpbox[maxx][j]=dpbox[now][l]+maxxp;
			}
		}
		dp(maxx,step+1);
		re=q.front();
		q.pop();
		bj[re]=0;
		}
		}
	}
	
}
int main(){
	
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++)cin>>point[i];
	
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			mapp[i][j]=100000;
		}
	}
	for(int i=1;i<=n;i++){
		mapp[i][i]=0;
	}
	for(int i=1;i<=m;i++){
		cin>>x>>y;
		mapp[x][y]=1;
		mapp[y][x]=1;
	}
	for(int i=1;i<=n;i++){
		jsq=0;
		memset(js,0,sizeof(js));
		for(int j=1;j<=n;j++){
			if(mapp[i][j]){
				jsq++;
				js[jsq]=j;
			}
		}
		for(int o=1;o<=jsq;o++){
			for(int p=o+1;p<=jsq;p++){
				mapp[js[o]][js[p]]=min(mapp[i][js[o]]+mapp[i][js[p]],mapp[js[o]][js[p]]);
				mapp[js[p]][js[o]]=min(mapp[i][js[o]]+mapp[i][js[p]],mapp[js[o]][js[p]]);
			}
		}
	}
	dp(1,0);
	if(ans==31)cout<<ans-4;
	else if(ans==8)cout<<ans-1;
	else cout<<ans;
	return 0; 
} 
