#include<bits/stdc++.h>
using namespace std;
long long int m,n,q;
long long int a[100001];
long long int b[100001];
long long int c[1001][1001];
long long int now[1001][1001];
long long int l1,r1,l2,r2;
long long int x,y;
long long int hangmin[1001];
int main(){
	
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	
	cin>>m>>n>>q;
	for(int i=1;i<=m;i++)cin>>a[i];
	for(int i=1;i<=n;i++)cin>>b[i];
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			c[i][j]=a[i]*b[j];
			
		}
	}
	for(int i=1;i<=q;i++){
		memset(now,0,sizeof(now));
		
		cin>>l1>>r1>>l2>>r2;
		if(l1==r1){
			long long int maxx=-1e18;
			for(int o=l2;o<=r2;o++)maxx=max(maxx,c[l1][o]);
			cout<<maxx<<endl;
			continue;
		}
		if(l2==r2){
			long long int maxx=-1e18;
			for(int o=l1;o<=r1;o++)maxx=max(maxx,c[r1][o]);
			cout<<maxx<<endl;
			continue;
		}
		x=1;
		for(int o=l1;o<=r1;o++){
			y=1;
			for(int p=l2;p<=r2;p++){
				now[x][y]=c[o][p];
				y++;
			}
			x++;
		}
		x--;
		y--;
		for(int p=1;p<=x;p++)hangmin[p]=1e18;
		long long int choose=-1e18;
		for(int o=1;o<=x;o++){
			for(int p=1;p<=y;p++){
				hangmin[o]=min(hangmin[o],now[o][p]);
			}
		}
		for(int o=1;o<=x;o++){
			if(hangmin[o]>choose){
				choose=hangmin[o];
			}
		}
		cout<<choose<<endl;
	}
	
} 
