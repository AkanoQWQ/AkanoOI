#include<bits/stdc++.h>

using namespace std;

const int N=100010;
typedef long long LL;
struct Yan
{
	int l,r;
	int min1,max1;
	int is_0;
	int zmax=INT_MIN,zmin=INT_MAX;
	int fmax=INT_MIN,fmin=INT_MAX;
}tr1[4*N],tr2[4*N];
int a[N],b[N];int n,m,q;
LL maxx(LL a,LL b)
{
	return a<b?b:a;
}
void pushup(Yan &u,Yan &l,Yan &r)
{
	u.min1=min(l.min1,r.min1);
	u.zmax=max(l.zmax,r.zmax);
	u.fmax=max(l.fmax,r.fmax);
	u.max1=max(r.max1,l.max1);
	u.fmin=min(l.fmin,r.fmin);
	u.zmin=min(l.zmin,r.zmin);
	u.is_0=l.is_0|r.is_0;
}
void pushup(int u,int is)
{
	if(is==1)
	pushup(tr1[u],tr1[u<<1],tr1[u<<1|1]);
	else 
	pushup(tr2[u],tr2[u<<1],tr2[u<<1|1]);
}
void build1(int u,int l,int r)
{
	if(l==r) 
	{
		tr1[u].l=l,tr1[u].r=r,tr1[u].max1=a[l],tr1[u].min1=a[l];
		if(a[l]==0) tr1[u].is_0=1,tr1[u].fmax=0,tr1[u].fmin=0,tr1[u].zmax=0,tr1[u].zmin=0;
		else if(a[l]>0) tr1[u].zmax=a[l],tr1[u].zmin=a[l];
		else tr1[u].fmax=a[l],tr1[u].fmin=a[l];
		return;
	}
	tr1[u].l=l,tr1[u].r=r;
	int mid=(l+r)>>1;
	build1(u<<1,l,mid);
	build1(u<<1|1,mid+1,r);
	pushup(u,1);
	return;
}
void build2(int u,int l,int r)
{
	if(l==r) 
	{
		tr2[u].l=l,tr2[u].r=r,tr2[u].max1=b[l],tr2[u].min1=b[l];
		if(b[l]==0) tr2[u].is_0=1,tr2[u].fmax=0,tr2[u].fmin=0,tr2[u].zmax=0,tr2[u].zmin=0;
		else if(b[l]>0) tr2[u].zmax=b[l],tr2[u].zmin=b[l];
		else tr2[u].fmax=b[l],tr2[u].fmin=b[l];
		return;
	}
	tr2[u].l=l,tr2[u].r=r;
	int mid=(l+r)>>1;
	build2(u<<1,l,mid);
	build2(u<<1|1,mid+1,r);
	pushup(u,2);
	return;
}
Yan query1(int u,int l,int r)
{
	if(tr1[u].l>=l&&tr1[u].r<=r) return tr1[u];
	else
	{
		int mid=(tr1[u].l+tr1[u].r)>>1;
		if(mid<l) return query1(u<<1|1,l,r);
		else if(mid>=r) return query1(u<<1,l,r); 
		else 
		{
			Yan res;
			Yan x=query1(u<<1,l,r),y=query1(u<<1|1,l,r);
			pushup(res,x,y);
			return res;
		}
	}
}
Yan query2(int u,int l,int r)
{
	if(tr2[u].l>=l&&tr2[u].r<=r) return tr2[u];
	else
	{
		int mid=(tr2[u].l+tr2[u].r)>>1;
		if(mid<l) return query2(u<<1|1,l,r);
		else if(mid>=r) return query2(u<<1,l,r); 
		else 
		{
			Yan res;
			Yan x=query2(u<<1,l,r),y=query2(u<<1|1,l,r);
			pushup(res,x,y);
			return res;
		}
	}
}

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=m;i++) scanf("%d",&b[i]);
//	if(n<=200&&m<=200)
//	{
//		while(q--)
//		{
//			int h,j,k,l;
//			scanf("%d%d%d%d",&h,&j,&k,&l);
//			LL ans=-999999999999;
//			for(int i=h;i<=j;i++)
//			{
//				for(int o=k;o<=l;o++)
//				{
//					ans=maxx(ans,a[i]*b[i]);
//				}
//			}
//		}
//	}
	build1(1,1,n);
	build2(1,1,m);
	
	while(q--)
	{
		int h,j,k,l;
		scanf("%d%d%d%d",&h,&j,&k,&l);
		Yan A=query1(1,h,j);
		Yan B=query2(1,k,l);
//		printf("%d %d %d %d %d %d \n",A.max1,A.min1,A.fmax,A.fmin,A.zmax,A.zmin);
//		printf("%d %d %d %d %d %d \n",B.max1,B.min1,B.fmax,B.fmin,B.zmax,B.zmin);
		if(A.max1<0&&B.max1<0) printf("%lld\n",(LL)A.min1*B.max1);
		else if(A.min1>0&&B.min1>0) printf("%lld\n",(LL)A.max1*B.min1);
		else if(B.min1>0&&A.max1>0) printf("%lld\n",(LL)A.max1*B.min1);
		else if(B.max1<0&&A.min1<0) printf("%lld\n",(LL)B.max1*A.min1);
		else if(A.is_0|B.is_0) printf("0\n");
		else 
		{
			LL nn=A.fmin*B.zmin,oo=A.zmin*B.fmin;
			printf("%lld\n",max(nn,oo));
		}
//		LL nn=A.max*B.min,oo=A.max*B.max,ii=A.min*B.max,pp=A.min*B.min;
//		printf("%lld\n",maxx(nn,maxx(oo,maxx(ii,pp))));
	}
	return 0;
}
