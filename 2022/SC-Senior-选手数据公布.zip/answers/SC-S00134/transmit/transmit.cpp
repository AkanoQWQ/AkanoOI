#include<bits/stdc++.h>

using namespace std;

int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++) printf("%d",i);
	return 0;
}
