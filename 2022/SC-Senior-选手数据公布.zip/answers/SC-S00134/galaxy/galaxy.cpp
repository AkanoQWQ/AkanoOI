#include<bits/stdc++.h>

using namespace std;

const int N=500010;
int p[N];
int find(int x)
{
	if(p[x]!=x) p[x]=find(p[x]);
	return p[x];
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) p[i]=i;
	for(int i=1;i<=m;i++) 
	{
		int x,y;
		scanf("%d%d",&x,&y);
		p[x]=y;
	}
	int q;
	scanf("%d",&q);
	for(int i=1;i<=q;i++)
	{
		int t;
		scanf("%d",&t);
		printf("No\n");
	}
	return 0;
}
