#include<bits/stdc++.h>

using namespace std;

const int N=10010;
int n,m,k;
int a[N];

int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++) scanf("%d",&a[i]);
	sort(a+2,a+n+1);
	int ans;
	ans=a[n]+a[n-1]+a[n-2]+a[n-3];
	printf("%d",ans);
	return 0;
}
