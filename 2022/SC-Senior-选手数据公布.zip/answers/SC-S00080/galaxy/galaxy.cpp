#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	for(int i=1;i<=5e5;i++)cout<<"NO\n";
	fclose(stdin);
	fclose(stdout);
}
