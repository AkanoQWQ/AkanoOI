#include<bits/stdc++.h>
using namespace std;
#define N 10010
#define ll long long
int n,m,k,vis[N]={},tot=0,b1[N]={},f[N][N];
ll a[N],ret=0,ans=0;
ll max(ll a,ll b)
{
	return a>b?a:b;
}
bool pd(int s,int t,int q)
{
	b1[s]=1;
	if(q-1<=k&&s==t)
	{
		return true;
	}
	for(int i=1;i<=n;i++)
	{
		if(f[s][i]==0&&!b1[i])
		{
			pd(i,t,q+1);
			b1[i]=0;
		}
	}
	if(q>k&&s!=t)return false;
}
void bfs(int xb)
{
	if(tot>=5)
	{
		
		if(xb==1)ans=max(ans,ret);
		return ;
	}
	for(int i=1;i<=n;i++)
	{
		memset(b1,0,sizeof(b1));
		if(!vis[i]&&xb!=i)
		{
			if(pd(xb,i,0))
			{
				ret+=a[i];
				vis[i]=1;
				tot++;
				bfs(i);
				tot--;
				ret-=a[i];
				vis[i]=0;
			}
		}
	}
	return ;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	memset(f,-1,sizeof(f));
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++)
		scanf("%d",a+i);
	for(int i=1;i<=m;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		f[x][y]=f[y][x]=0;
	}
	vis[1]=1;
	bfs(1);
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1
*/
