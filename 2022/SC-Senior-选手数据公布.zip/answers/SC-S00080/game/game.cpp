#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=1e4+510;
int n,m,q,a[N],b[N];
ll c[N][N],minl[N],maxn;
ll min(ll a,ll b)
{
	return a<b?a:b;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)
		scanf("%d",a+i);
	for(int i=1;i<=m;i++)
		scanf("%d",b+i);
	int l1,r1,l2,r2;
	for(int k=1;k<=q;k++)
	{
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		for(int i=l1;i<=r1;i++)
		{
			minl[i]=a[i]*b[l2];
			for(int j=l2;j<=r2;j++)
			{
				c[i][j]=a[i]*b[j];
				minl[i]=min(minl[i],c[i][j]);
			}
			if(i==l1)maxn=minl[i];
			else maxn=max(maxn,minl[i]);
		}
		printf("%lld\n",maxn);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
