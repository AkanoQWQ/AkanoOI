#include<bits/stdc++.h>
using namespace std;
int n,q,k,v[200010],a,b,dis[200010],fa[200010],ans[200010],vis[200010];
struct node
{
	int id,v;
};
int find(int x)
{
	if(fa[x]==x)return x;
	return fa[x]=find(fa[x]);
}
vector < int > G[200010];
vector < node > Q[200010];
void dfs(int u,int f)
{
	dis[u]=dis[f]+v[u];
	vis[u]=1;
	for(int i=1;i<Q[u].size();i++)
	{
		int id=Q[u][i].id,v1=Q[u][i].v;
		if(vis[v1])
		{
			int lca=find(v1);
			ans[id]=dis[u]+dis[v1]-2*dis[lca];
		}
	}
	for(int i=1;i<G[u].size();i++)
	{
		int v1=G[u][i];
		if(!vis[v1])
		{
			dfs(v1,u);
			fa[v1]=u;
		}
	}
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++)
	{
		cin>>v[i];
		fa[i]=i;
	}
	for(int i=1;i<n;i++)
	{
		cin>>a>>b;
		G[a].push_back(b);
		G[b].push_back(a);
	}
	for(int i=1;i<=q;i++)
	{
		cin>>a>>b;
		Q[a].push_back((node){i,b});
		Q[b].push_back((node){i,a});
	}
	dis[0]=0;
	dfs(1,0);
	for(int i=1;i<=q;i++)
		cout<<ans[i]<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
7 3 3
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7
4 7
5 6
1 2
*/
