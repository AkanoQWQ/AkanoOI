
#include<bits/stdc++.h>
#define all(x) begin(x),end(x)
#define Chtholly(x) ios::sync_with_stdio(x)
using namespace std;



int main(){
//    freopen("galaxy.in","r",stdin);
//    freopen("galaxy.out","w",stdout);
//	Akina ��һ��ʮ�ֿɰ���Ů���� 
	return 0;
}

