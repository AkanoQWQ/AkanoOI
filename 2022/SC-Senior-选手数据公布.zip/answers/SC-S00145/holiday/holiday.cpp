
#include<bits/stdc++.h>
#define all(x) begin(x),end(x)
#define Chtholly(x) ios::sync_with_stdio(x)
using namespace std;

const int N=3e3+123;

int n,m,k,dis[N][N],vis[N];
long long s[N],f[N][N];
vector<int> ed[N];
vector<pair<long long,int>> F[N];

bool cmp(pair<long long ,int>X,pair<long long,int>Y){
	return X.first>Y.first;
}
// I love Akina forever
int main(){
    freopen("holiday.in","r",stdin);
    freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++)
		scanf("%lld",&s[i]);
	for(int x,y,i=1;i<=m;i++)
		scanf("%d%d",&x,&y),ed[x].push_back(y),ed[y].push_back(x);
	for(int nowst=1;nowst<=n;nowst++){
		queue<int> q;
		q.push(nowst);
		for(int i=1;i<=n;i++)
			vis[i]=0;
		vis[nowst]=1;
		while(q.size()){
			int u=q.front();q.pop();
			for(auto v:ed[u]){
				if(vis[v]) continue;
				dis[nowst][v]=dis[nowst][u]+1;
				vis[v]=1;q.push(v);
			}
		}
	}
	if(n<=20){
		long long ans=0;
		for(int pA=2;pA<=n;pA++){
			for(int pB=2;pB<=n;pB++){
				if(pB==pA) continue ;
				for(int pC=2;pC<=n;pC++){
					if(pC==pA || pC==pB) continue ;
					for(int pD=2;pD<=n;pD++){
						if(pD==pA || pD==pB || pD==pC) continue;
						if(dis[1][pA]<=k+1 && dis[pA][pB]<=k+1 && dis[pB][pC]<=k+1 && dis[pC][pD]<=k+1 && dis[pD][1]<=k+1){
							ans=max(ans,s[pA]+s[pB]+s[pC]+s[pD]);
						}
					}
				}
			}
		}
		printf("%lld",ans);	
		return 0;
	}
	else {
		//���Ƕ�ÿ��j��������ܵ�ת�� 
		for(int i=2;i<=n;i++){
			for(int j=2;j<=n;j++){
				if(i==j) continue;
				if(dis[1][i]<=k+1 && dis[i][j]<=k+1)
					f[i][j]=s[i]+s[j],F[j].push_back({f[i][j],i});
			}
		}
		long long ans=0;
		for(int i=2;i<=n;i++)
			sort(begin(F[i]),end(F[i]),cmp);
		for(int i=2;i<=n;i++){
			for(int j=2;j<=n;j++){
				if(i==j) continue;
				if(dis[i][j]<=k+1){
					int jdge=0;
					for(auto nowi:F[i]){
						if(nowi.second==i || nowi.second==j) continue;
						for(auto nowj:F[j]){
							if(nowj.second==i || nowj.second==j) continue;
							long long vali=nowi.first,valj=nowj.first;
							int idi=nowi.second,idj=nowj.second;
							if(i!=idi && i!=idj && j!=idi && j!=idj && idi!=idj){
								jdge=1;
								ans=max(ans,vali+valj);
							}
							if(jdge) break;
						}
						if(jdge) break;
					}
					for(auto nowj:F[j]){
						if(nowj.second==i || nowj.second==j) continue;
						for(auto nowi:F[i]){
							if(nowi.second==i || nowi.second==j) continue;
							long long vali=nowi.first,valj=nowj.first;
							int idi=nowi.second,idj=nowj.second;
							if(i!=idi && i!=idj && j!=idi && j!=idj && idi!=idj){
								jdge=1;
								ans=max(ans,vali+valj);
							}
							if(jdge) break;
						}
						if(jdge) break;
					}
				}
			}
		}
		printf("%lld",ans);
	}
	return 0;
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1

*/
/*
7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4

*/
