
#include<bits/stdc++.h>
#define all(x) begin(x),end(x)
#define Chtholly(x) ios::sync_with_stdio(x)
using namespace std;
//If I can't reach the line of 1=,Rice_Porridge will wear Lolita after NOIP.
const int N=1e5+123;

int n,m,p;
long long mn[N],a[N],b[N];
long long mpt[1111][1111];

struct A_lovely_ST{
	long long s[11][1111];
	long long query(int l,int r){
		int len=__lg(r-l+1);
		return min(s[len][l],s[len][r-(1<<len)+1]);
	}
}T[1111];

struct A_cute_ST{
	long long s[16][N];
	long long query(int l,int r){
		int len=__lg(r-l+1);
		return min(s[len][l],s[len][r-(1<<len)+1]);
	}
}STmn,Smn;

struct A_goodlooking_ST{
	long long s[16][N];
	long long query(int l,int r){
		int len=__lg(r-l+1);
		return max(s[len][l],s[len][r-(1<<len)+1]);
	}	
}STmx,Smx;

bool judgemenT1(){
	for(int i=1;i<=n;i++)
		if(a[i]<=0) return 0;
	for(int i=1;i<=m;i++)
		if(b[i]<=0) return 0;
	return 1;
}

int main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&p);
	for(int i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++)
		scanf("%lld",&b[i]);
	if(n<=200 && m<=200 && p<=200){
		while(p--){
			long long ans=-1e18-123;
			int l1,l2,r1,r2;
			scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
			for(int i=l1;i<=r1;i++){
				long long res=1e18+123;
				for(int j=l2;j<=r2;j++)
					res=min(res,a[i]*b[j]);
				ans=max(ans,res);
			}
			printf("%lld\n",ans);
		}
		return 0;
	}
	if(n<=1000 && m<=1000 && p<=1000){
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				mpt[i][j]=a[i]*b[j];
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++)
				T[i].s[0][j]=mpt[i][j];
			for(int k=1;k<=10;k++)
				for(int j=1;j<=m-(1<<k)+1;j++)
					T[i].s[k][j]=min(T[i].s[k-1][j],T[i].s[k-1][j+(1<<k-1)]);
		}
		while(p--){
			int l1,l2,r1,r2;
			long long ans=-1e18-123;
			scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
			for(int i=l1;i<=r1;i++){
				long long res=1e18+123;
				ans=max(ans,T[i].query(l2,r2));
			}
			printf("%lld\n",ans);
		}
		return 0;
	}
	if(judgemenT1()){
		for(int i=1;i<=n;i++)
			STmx.s[0][i]=a[i],Smn.s[0][i]=a[i];
		for(int i=1;i<=m;i++)
			STmn.s[0][i]=b[i],Smx.s[0][i]=b[i];
		for(int k=1;k<=15;k++)
			for(int j=1;j<=m-(1<<k)+1;j++)
				STmn.s[k][j]=min(STmn.s[k-1][j],STmn.s[k-1][j+(1<<k-1)]),
				Smx.s[k][j]=max(Smx.s[k-1][j],Smx.s[k-1][j+(1<<k-1)]);
		for(int k=1;k<=15;k++)
			for(int j=1;j<=n-(1<<k)+1;j++)
				STmx.s[k][j]=max(STmx.s[k-1][j],STmx.s[k-1][j+(1<<k-1)]),
				Smn.s[k][j]=min(Smn.s[k-1][j],Smn.s[k-1][j+(1<<k-1)]);
		while(p--){
			int l1,l2,r1,r2;
			scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
			printf("%lld\n",STmn.query(l2,r2)*STmx.query(l1,r1));
		}
		return 0;
	}
	else {
		for(int i=1;i<=n;i++)
			STmx.s[0][i]=a[i],Smn.s[0][i]=a[i];
		for(int i=1;i<=m;i++)
			STmn.s[0][i]=b[i],Smx.s[0][i]=b[i];
		for(int k=1;k<=15;k++)
			for(int j=1;j<=m-(1<<k)+1;j++)
				STmn.s[k][j]=min(STmn.s[k-1][j],STmn.s[k-1][j+(1<<k-1)]),
				Smx.s[k][j]=max(Smx.s[k-1][j],Smx.s[k-1][j+(1<<k-1)]);
		for(int k=1;k<=15;k++)
			for(int j=1;j<=n-(1<<k)+1;j++)
				STmx.s[k][j]=max(STmx.s[k-1][j],STmx.s[k-1][j+(1<<k-1)]),
				Smn.s[k][j]=min(Smn.s[k-1][j],Smn.s[k-1][j+(1<<k-1)]);
		while(p--){
			int l1,l2,r1,r2;
			scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
			if(l1==r1){
				if(a[l1]>0) printf("%lld\n",a[l1]*STmn.query(l2,r2));
				else printf("%lld\n",a[l1]*Smx.query(l2,r2));
			}
			else if(l2==r2){
				if(b[l2]>0) printf("%lld\n",b[l2]*STmx.query(l1,r1));
				else printf("%lld\n",b[l2]*Smn.query(l1,r1));
			}
		}
	}
	return 0;
}
/*
6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3


*/

