
#include<bits/stdc++.h>
#define all(x) begin(x),end(x)
#define Chtholly(x) ios::sync_with_stdio(x)
using namespace std;

const int N=2e5+123;

int n,q,k,w[N],dis[33][33],vis[N],lim,gt[N];
long long f[N];
long long ans=1e18+123;
vector<int > ed[N];
//Lolita is not cheap,so I don't want to pay the bill.
void dfs(int u){
	if(u==lim+1) {
		for(int i=0;i<=lim;i++)
			if(dis[gt[i]][gt[i+1]]>k) return ;
		long long res=0;
		for(int i=0;i<=lim+1;i++)
			res+=w[gt[i]];
		ans=min(ans,res);
	}
	for(int i=1;i<=n;i++){
		if(vis[i]) continue;
		gt[u]=i,vis[i]=1;
		dfs(u+1);
		vis[i]=0;
	}
}

void DFS(int u,int fa){
	for(auto v:ed[u]){
		if(v==fa) continue;
		f[v]=f[u]+w[v];
		DFS(v,u);
	}
}

int main(){
    freopen("transmit.in","r",stdin);
    freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++)
		scanf("%d",&w[i]);
	for(int i=1;i<n;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		ed[x].push_back(y);
		ed[y].push_back(x);
	}
	if(k==1){
		while(q--){
			int st,ed;
			scanf("%d%d",&st,&ed);
			for(int i=1;i<=n;i++) f[i]=w[st];
			DFS(st,0);
			printf("%lld\n",f[ed]);
		}
		return 0;
	}
	for(int nowst=1;nowst<=n;nowst++){
		queue<int> q;
		q.push(nowst);
		for(int i=1;i<=n;i++)
			vis[i]=0;
		vis[nowst]=1;
		while(q.size()){
			int u=q.front();q.pop();
			for(auto v:ed[u]){
				if(vis[v]) continue;
			dis[nowst][v]=dis[nowst][u]+1;
				vis[v]=1;q.push(v);
			}
		}
	}
	while(q--){
		int st,ed;
		scanf("%d%d",&st,&ed);
		vis[st]=vis[ed]=1;
		lim=0;
		for(int i=1;i<=n;i++)
			vis[i]=0;
		for(lim=0;lim<=n-2;lim++)
			gt[0]=st,gt[lim+1]=ed,dfs(1);
		for(int i=1;i<=n;i++)
			vis[i]=0;
		printf("%lld\n",ans);
	}
	return 0;
}
/*
7 3 1
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7
4 7
5 6
1 2

*/
