#include<bits/stdc++.h>
using namespace std;
const int MAXN = 1e5 + 5;
typedef long long ll;
ll f[MAXN][17],mf[MAXN][17];//f:maxval   mf:minval 
int n,m,q;
ll a[MAXN],b[MAXN];
int max2(ll x)
{
	ll num = 1;
	int cnt = 0;
	while(num <= x)
	{
		num = num * 2;
		++cnt; 
	}
	return cnt - 1;
}
void ST()
{
	for(int i=1;i<=n;i++)
		f[i][0] = a[i];
	int k=max2(n);
	for(int j=1;j<=k;j++)
	{
		ll l=(ll)(pow(2,j));
		for(int i=1;i<=n - l + 1;i++)
		{
			f[i][j] = max(f[i][j - 1],f[i + l/2][j - 1]);
		}
	}
	for(int i=1;i<=m;i++)
		mf[i][0] = b[i];
	k=max2(m);
	for(int j=1;j<=k;j++)
	{
		ll l=(ll)(pow(2,j-1));
		for(int i=1;i<=m - l;i++)
		{
			mf[i][j] = min(mf[i][j - 1],mf[i + l][j - 1]);
		}
	}
}
ll findmax(int l,int r)
{
	int k = max2(r - l + 1);
	return max(f[l][k],f[r - (ll)(pow(2,k)) + 1][k]);
}
ll findmin(int l,int r)
{
	int k = max2(r - l + 1);
	return min(mf[l][k],mf[r - (ll)(pow(2,k)) + 1][k]);
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=m;i++) scanf("%d",&b[i]);
	int l1,r1,l2,r2;
	ST();
	for(int i=1;i<=q;i++)
	{
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		ll maxn,minn;
		maxn = findmax(l1,r1);
		minn = findmin(l2,r2);
		ll res = maxn * minn;
		printf("%lld\n",res);
	} 
	return 0;
}
