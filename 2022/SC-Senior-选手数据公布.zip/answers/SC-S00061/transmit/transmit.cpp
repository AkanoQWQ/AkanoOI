#include<bits/stdc++.h>
using namespace std;
int n,q,k,v[10001],a,b,head[10001];
struct edge{
	int s,t,next;
}e[10001];
int key = 0,ans = 0;
int psed[10001];
int tot = 0;
inline void search(int pos,int now)
{
	tot ++;
	if(key == 1) return;
	psed[pos] = 1;
	if(pos == b)
	{
		ans = now;
		key = 1;
		psed[pos] = 0;
		return;
	}
	for(int i = head[pos]; i != -1;i = e[i].next)
	{
		if(key == 1)
		{
			psed[pos] = 0;
			return;
		}
		if(psed[e[i].t] == 1) continue;
		search(e[i].t,now + v[e[i].t]); 
	}
	psed[pos] = 0;
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	memset(psed,0,sizeof(psed));
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++) cin>>v[i];
	for(int i=1;i<=n;i++) head[i] = -1;
	for(int i=1;i<=n-1;i++)
	{
		cin>>a>>b;
		e[i].s = a;
		e[i].t = b;
		e[i].next = head[a];
		head[a] = i;
		e[i+n-1].s = b;
		e[i+n-1].t = a;
		e[i+n-1].next = head[b]; 
		head[b] = i+n-1;
	}
	int m = n-1+n-1;
	for(int i=1;i<=q;i++)
	{
		cin>>a>>b;
		key = 0;
		ans = 0;
		search(a,v[a]);
		cout<<ans<<endl;
	}
	return 0;
}
