#include<bits/stdc++.h>
using namespace std;
const int MAXN = 2510;
int n,m,k,head[MAXN];
typedef long long ll;
ll a[MAXN];
struct edge{
	int s,t,w,next;
}e[20005];
ll ans = 0;
int psd[MAXN];
long long dis[MAXN];
inline void search(int x,int dep,ll cnt)
{
//	printf("%d %d %lld \n",x,dep,cnt);
	if(dep == 0)
	{
		if(x != 1) return;
		ans = max(ans,cnt);
		return;
	}
	if(dis[x] > dep) return;
	psd[x] = 1;
	for(int i = head[x]; i != -1 ;i = e[i].next)
	{
		if((psd[e[i].t] == 1 && e[i].t != 1) || (dep > 1 && e[i].t == 1)) continue;
		if(dep == 1 && e[i].t != 1) continue;
		search(e[i].t,dep - 1,cnt + a[x]);
	}
	psd[x] = 0;
}
struct p{
	int first,second;
	bool operator <(const p &a) const{
		return a.first < first;
	}
};
void dijkstra()
{
	priority_queue <p> q;
	int blue[MAXN];
	memset(blue,0,sizeof(blue));
	for(int i=1;i<=MAXN;i++) dis[i] = 1e18;
	p add;
	add.first = 0;
	add.second = 1;
	q.push(add);
	blue[1] = 1;
	dis[1] = 0;
	while(!q.empty())
	{
		p pp = q.top();
		q.pop();
		int val = pp.first,num = pp.second;
		blue[num] = 0;
		for(int i = head[num]; i != -1 ;i = e[i].next)
		{
			if(val + e[i].w < dis[e[i].t])
			{
				dis[e[i].t] = val + e[i].w;
				p add;
				add.first = dis[e[i].t];
				add.second = e[i].t;
				q.push(add);
			}
		}
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	memset(psd,0,sizeof(psd));
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++)
		scanf("%lld",&a[i]);
	for(int i=1;i<=n;i++) head[i] = -1;
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&e[i].s,&e[i].t);
		e[i].w = 1;
		e[i].next = head[e[i].s];
		head[e[i].s] = i;
		e[i+m].s = e[i].t;
		e[i+m].t = e[i].s;
		e[i+m].w = 1;
		e[i+m].next = head[e[i+m].s];
		head[e[i+m].s] = i+m;
	}
	m *= 2;
	dijkstra();
	search(1,5,0);
	printf("%lld",ans);
	return 0;
}
