#include<bits/stdc++.h>
using namespace std;
long long l[100006],r[100006],n,m,q,a[1006][1006];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	if(n<=1000&&m<=1000&&q<=1000)
	{
		for(int i=1;i<=n;i++) cin>>l[i];
		for(int i=1;i<=m;i++) cin>>r[i];
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				a[i][j]=l[i]*r[j];
		while(q--)
		{
			long long mx=-0x7f7f7f7f7f7f7f7f;
			int l1,l2,r1,r2;
			cin>>l1>>r1>>l2>>r2;
			for(int i=l1;i<=r1;i++)
			{
				long long mn=0x7f7f7f7f7f7f7f7f;
				for(int j=l2;j<=r2;j++) mn=min(mn,a[i][j]);
				mx=max(mn,mx);
			}
			cout<<mx<<endl;
		}
	}
	else
	{
		int flag=1;
		for(int i=1;i<=n;i++)
		{
			scanf("%lld",&l[i]);
			if(l[i]<=0) flag=0;
		}
		for(int i=1;i<=m;i++)
		{
			scanf("%lld",&r[i]);
			if(r[i]<=0) flag=0;
		}
		//if(flag==1) cout<<"��ϲ�㣬���������ػ��ء�����1����";
		while(q--)
		{
			int l1,l2,r1,r2;
			scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
			if(l1==r1)
			{
				long long mn=0x7f7f7f7f7f7f7f7f;
				for(int i=l2;i<=r2;i++) mn=min(mn,i*l[l1]);
				printf("%lld\n",mn);
				continue;
			}
			if(l2==r2)
			{
				long long mx=-0x7f7f7f7f7f7f7f7f;
				for(int i=l1;i<=r1;i++) mx=max(mx,i*r[l2]);
				printf("%lld\n",mx);
				continue;
			}
			if(flag==1)
			{
				long long mn=0x7f7f7f7f7f7f7f7f;
				long long mx=-0x7f7f7f7f7f7f7f7f;
				for(int i=l1;i<=r1;i++) mx=max(mx,l[i]);
				for(int i=l2;i<=r2;i++) mn=min(mn,r[i]);
				printf("%lld\n",mx*mn);
			}
			cout<<"I CANT SOLVE IT";
		}
	}
	return 0;
}
//will I in the SC-qi-pa-xing-wei-da-shang-csp-j/s-2022?
//beiguan:50pts
//leguan:65pts
