#include<bits/stdc++.h>
using namespace std;
int n,q,k,x,y,g[1006][1006],b[1006];
long long v[1006],mn=0x7f7f7f7f7f7f7f7f;
void dfs(int x,int y,long long timee,int wx)
{
	if(wx>k) return;
	if(x==y)
	{
		mn=min(mn,timee);
		return;
	}
	for(int i=1;i<=n;i++)
		if(g[x][i]==1&&b[i]==0)
		{
			b[i]=1;
			dfs(i,y,timee,wx+1);
			dfs(i,y,timee+v[i],0);
			b[i]=0;
		}
	return;
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++) scanf("%lld",&v[i]);
	for(int i=1;i<=n-1;i++)
	{
		scanf("%d%d",&x,&y);
		g[x][y]=g[y][x]=1;
	}
	while(q--)
	{
		mn=0x7f7f7f7f7f7f7f7f;
		scanf("%d%d",&x,&y);
		for(int i=1;i<=n;i++) b[i]=0;
		b[x]=1;
		dfs(x,y,v[x]+v[y],0);
		printf("%lld\n",mn);
	}
	return 0;
}//8pts,I think. 
