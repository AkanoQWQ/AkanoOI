//just pianfen eryi(Me is a UK men)
#include<bits/stdc++.h>
using namespace std;
bool g[1006][1006],can[1006][1006],b[1006];
int n,m,q,u,v;
bool fanji(int x)
{
	if(b[x]==1) return 1;
	for(int i=1;i<=n;i++)
		if(can[x][i]==1)
		{
			b[x]=1;
			if(fanji(i)==1) return 1;
			b[x]=0;
		}
	return 0;
}
bool chuansuo(int x)
{
	int cnt=0;
	for(int i=1;i<=n;i++)
		if(can[x][i]==1) cnt++;
	if(cnt==1) return 1;
	return 0;
}
bool fangong()
{
	for(int i=1;i<=n;i++)
		if(chuansuo(i)==0||fanji(i)==0) return 0;
	return 1;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	while(m--)
	{
		scanf("%d%d",&u,&v);
		g[u][v]=1;
		can[u][v]=1;
	}
	cin>>q;
	while(q--)
	{
		int opt;
		scanf("%d",&opt);
		if(opt==1)
		{
			scanf("%d%d",&u,&v);
			can[u][v]=0;
			if(fangong()==1) printf("YES\n");
			else printf("NO\n");
		}
		if(opt==2)
		{
			scanf("%d",&u);
			for(int i=1;i<=n;i++) can[i][u]=0;
			if(fangong()==1) printf("YES\n");
			else printf("NO\n");
		}
		if(opt==3)
		{
			scanf("%d%d",&u,&v);
			can[u][v]=1;
			if(fangong()==1) printf("YES\n");
			else printf("NO\n");
		}
		if(opt==4)
		{
			scanf("%d",&u);
			for(int i=1;i<=n;i++)
				if(g[i][u]==1) can[i][u]=1;
			if(fangong()==1) printf("YES\n");
			else printf("NO\n");
		}
	}
	return 0;
}
//only moni.
//problems are always about the universe.
//beiguan:15pts
//leguan:40pts
