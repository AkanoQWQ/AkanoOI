#include<bits/stdc++.h>
using namespace std;
long long n,m,k,mx,b[2506];
struct senery{
	long long point,g[2506],canuse[2506],gs;
}a[2506];
void floyd()//I forget how to write Dijksta!
{
	for(int k=1;k<=n;k++)
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				if(i!=j&&j!=k&&i!=k) a[i].g[j]=min(a[i].g[j],a[i].g[k]+a[k].g[j]+1);
	return;
}
bool pd(int x)
{
	for(int i=1;i<=a[x].gs;i++)
		if(a[x].canuse[i]==1) return 1;
	return 0;
}
void dfs(int s,long long point,int x)
{
	if(s==4)
	{
		if(pd(x)==1) mx=max(point,mx);
		return;
	}
	for(int i=1;i<=a[x].gs;i++)
		if(b[a[x].canuse[i]]==0)
		{
			b[a[x].canuse[i]]=1;
			dfs(s+1,point+a[a[x].canuse[i]].point,a[x].canuse[i]);
			b[a[x].canuse[i]]=0;
		}
	return;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++) cin>>a[i].point;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(i!=j) a[i].g[j]=0x3f3f3f3f3f3f3f3f;
	while(m--)
	{
		int x,y;
		cin>>x>>y;
		a[x].g[y]=0;
		a[y].g[x]=0;
	}
	floyd();
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++) cout<<a[i].g[j]<<" ";
		cout<<"\n";
	}
	cout<<"\n";
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(a[i].g[j]<=k&&i!=j) a[i].canuse[++a[i].gs]=j;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=a[i].gs;j++) cout<<a[i].canuse[j]<<" ";
		cout<<"\n";
	}
	b[1]=1;
	dfs(0,0,1);
	cout<<mx;
	return 0;
}
//Oh my god,please give me 2nd!
//beiguan:40pts
//leguan:55pts
//I am SC-J00080
