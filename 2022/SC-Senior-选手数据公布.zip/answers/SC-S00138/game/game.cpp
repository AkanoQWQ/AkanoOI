#include <bits/stdc++.h>

using namespace std;

const int N = 1e6;

int x[N], y[N];
int p = 0;

int main()
{
	freopen("game.in", "r", stdin);
	freopen("game.our", "w", stdout);
	int n, m, k;
	cin >> n >> m >> k;
	
	for (int i = 1; i <= n; i ++ ) 
	{
		cin >> x[i];
		if (x[i] < 0) p = 1;
	}
	
	for (int i = 1; i <= m; i ++ ) 
	{
		cin >> y[i];
		if (y[i] < 0) p = 1;
	}
	
	while (k -- )
	{
		y[0] = 1e9 + 10;
		int a, b, c, d;
		cin >> a >> b >> c >> d;
		
		if (!p)
		{
			int l = 0, r = 0;
			for (int i = a; i <= b; i ++ ) 
			    if (x[l] < x[i]) l = i;
			for (int i = c; i <= d; i ++ )
			    if (y[r] > x[i]) r = i;
			cout << x[l] * y[r] << endl;
		}
		else if (a == b)
		{
			if (x[a] == 0)
			{
				cout << 0 << endl;
				continue;
			}
			int t = 1e9 + 10;
			if (x[a] > 0)
			{
				for (int i = c; i <= d; i ++ )
					if (t > y[i]) t = y[i]; 
			}
			else
			{
				t = -t;
				for (int i = c; i <= d; i ++ )
				    if (t < y[i]) t = y[i];
			}
			cout << t * x[a] << endl;
		}
		else if (c == d)
		{
			if (y[c] == 0)
			{
				cout << 0 << endl;
				continue;
			}
			int t = 1e9 + 10;
			if (y[c] > 0)
			{
				for (int i = a; i <= b; i ++ )
					if (t > x[i]) t = x[i]; 
			}
			else
			{
				t = -t;
				for (int i = a; i <= b; i ++ )
				    if (t < x[i]) t = x[i];
			}
			cout << t * y[c] << endl;
		}
	}
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
