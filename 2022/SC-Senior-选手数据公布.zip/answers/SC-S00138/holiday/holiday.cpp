#include <bits/stdc++.h>

using namespace std;

const int N = 1e6 + 10;

struct node
{
	int x, y;
};

node w[N];

int h[N], e[N], ne[N], idx, d[N];
int t;

void add(int a, int b)
{
	e[idx] = b;
	ne[idx] = h[a];
	h[a] = idx ++ ;
}

int n, m, k;
bool st[N], dist[N];

bool cmp(node i, node j)
{
	return i.x > j.x;
}

void dfs(int u, int p, int l, int a)
{
	if (p > k) return ;
	if (a == 4)
	{
		if (dist[u]) t = max(t, l);
		return ;
    }
    if (a > 4) return ;
	for (int i = h[u]; ~i; i = ne[i])
	{
		int j = e[i];
		if (st[j]) continue;
		st[j] = 1;
		dfs(j, p + 1, l, a);
		dfs(j, p, l + w[d[j]].x, a + 1);
		st[j] = 0;
	}
}

int main()
{
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	
	for (int i = 1; i < n; i ++ )
	{
		int a;
		scanf("%d", &a);
		w[i].x = a;
		w[i].y = i;
	}
	
	while (m -- )
	{
		int a, b;
		scanf("%d%d", &a, &b);
		if (a == 1) dist[b] = 1;
		if (b == 1) dist[a] = 1;
		add(a, b);
		add(b, a);
	}
	
	sort(w + 1, w + n, cmp);
	for (int i = 1; i < n; i ++ ) d[w[i].y] = i;
	dfs(1, 0, 0, 0);
	
	printf("%d", t);
	
	fclose(stdin);
	fclose(stdout);
}
