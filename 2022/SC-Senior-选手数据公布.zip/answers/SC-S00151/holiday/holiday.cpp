#include<iostream>
#include<cstdio>
#include<queue>
using namespace std;
bool pd[2505][2505];
int po[2505],dp[2505][5];
struct fun{
	int t,p,g[8];
	long long sc;
};
queue<fun> q;
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int n,m,k;
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++){
		scanf("%d",&po[i]);
	}
	po[1]=0;
	for(int i=1;i<=m;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		pd[x][y]=1;
		pd[y][x]=1;
	}
	for(int i=1;i<=n;i++){
		fun th;
		th.p=1;
		th.t=1;
		th.sc=0;
		th.g[0]=1;
		if(pd[1][i]){
			th.g[th.t]=i;
			q.push(th);
		}
	}
	long long maxx=0;
	while(!q.empty()){
		fun th=q.front();
		q.pop();
		if(th.t==4){
			th.p=th.g[th.t];
			th.sc+=po[th.p];
			if(th.g[0]!=th.g[1]&&th.g[0]!=th.g[2]&&th.g[0]!=th.g[3]&&th.g[0]!=th.g[4]&&th.g[1]!=th.g[2]&&th.g[1]!=th.g[3]&&th.g[1]!=th.g[4]&&th.g[2]!=th.g[3]&&th.g[2]!=th.g[4]&&th.g[4]!=th.g[3]){
				maxx=max(th.sc,maxx);
			}
			continue;
		}
		th.p=th.g[th.t];
		th.sc+=po[th.p];
		th.t++;
		for(int i=1;i<=n;i++){
			if(pd[th.p][i]){
				th.g[th.t]=i;
				q.push(th);
			}
		}
	}
	cout<<maxx;
	return 0;
}
