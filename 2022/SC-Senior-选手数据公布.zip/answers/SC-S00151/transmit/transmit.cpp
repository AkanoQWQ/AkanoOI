#include<iostream>
#include<cstdio>
using namespace std;
int v[200005];
bool pd[2005][2005];
int n,q,k;
long long dfs(int x,int y){
	long long minn=v[y];
	for(int i=1;i<=n;i++){
		if(pd[i][y]){
			pd[y][i]=0;
			minn+=min(minn,dfs(x,i));
			pd[y][i]=1;
		}
	}
	return minn;
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++){
		scanf("%d",&v[i]);
	}
	for(int i=1;i<n;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		pd[x][y]=1;
		pd[y][x]=1;
	}
	for(int _=1;_<=q;_++){
		int x,y;
		scanf("%d%d",&x,&y);
		printf("%d\n",dfs(x,y));
	}
	return 0;
}
