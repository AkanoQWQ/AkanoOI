#include<iostream>
#include<cstdio>
using namespace std;
int po[1005][1005],lt[1005];
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int q,n,m;
	cin>>n>>m;
	if(n>1000){
		for(int i=1;i<=m;i++){
			int u,v;
			scanf("%d%d",&u,&v);
		}
		cin>>q;
		for(int _=1;_<=q;_++){
			int t,u,v;
			scanf("%d%d",&t,&u);
			if(t==1||t==3){
				scanf("%d",&v);
			}
			cout<<"NO"<<'\n';
		}
		return 0;
	}
	for(int i=1;i<=m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		po[u][v]=1;
		po[u][0]++;
	}
	cin>>q;
	for(int _=1;_<=q;_++){
		int t,u,v;
		scanf("%d%d",&t,&u);
		if(t==1){
			scanf("%d",&v);
			po[u][v]=2;
			po[u][0]--;
		}
		else if(t==2){
			for(int i=1;i<=n;i++){
				if(po[i][u]==1){
					po[i][u]=2;
					po[i][0]--;
				}
			}
		}
		else if(t==3){
			scanf("%d",&v);
			po[u][v]=1;
			po[u][0]++;
		}
		else if(t==4){
			for(int i=1;i<=n;i++){
				if(po[i][u]==2){
					po[i][u]=1;
					po[i][0]++;
				}
			}
		}
		bool isd=1;
		for(int i=1;i<=n;i++){
			if(po[i][0]!=1){
				isd=0;
				cout<<"NO"<<'\n';
				break;
			}
		}
		if(isd)  cout<<"YES"<<'\n';
	}
	return 0;
}//fanji
