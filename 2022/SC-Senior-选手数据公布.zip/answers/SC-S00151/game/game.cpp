#include<iostream>
#include<cstdio>
using namespace std;
int a[1005],b[1005];
long long c[1005][1005];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q;
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	for(int i=1;i<=m;i++){
		scanf("%d",&b[i]);
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			c[i][j]=a[i];
			c[i][j]*=b[j];
		}
	}
	for(int _=1;_<=q;_++){
		int l1,r1,l2,r2;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		long long maxx=-1e18;
		for(int i=l1;i<=r1;i++){
			long long minn=1e18;
			for(int j=l2;j<=r2;j++){
				minn=min(minn,c[i][j]);
			}
			maxx=max(maxx,minn);
		}
		cout<<maxx<<'\n';
	}
	return 0;
}
