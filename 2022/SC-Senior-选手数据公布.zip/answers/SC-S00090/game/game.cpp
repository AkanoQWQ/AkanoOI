#include<bits/stdc++.h>
#define ll long long
using namespace std;
int n,m,q;
ll a[2][101000];
const ll I=2e9,II=2e18;
struct qq{
	ll mi0,mi1,mx0,mx1;
	bool yk;
};
qq operator + (const qq &e,const qq &b){
	qq c;
	c.mi0=min(e.mi0,b.mi0);
	c.mi1=min(e.mi1,b.mi1);
	c.mx0=max(e.mx0,b.mx0);
	c.mx1=max(e.mx1,b.mx1);
	c.yk=e.yk|b.yk;
	return c;
}
struct SGT{
	qq t[401000];
	inline void build(int ty,int p,int l,int r){
		if(l==r){
			ll z=a[ty][l];
			t[p].yk=(z==0);
			if(z<0)t[p].mi0=t[p].mx0=z;
			else t[p].mi0=I,t[p].mx0=-I;
			if(z>0)t[p].mi1=t[p].mx1=z;
			else t[p].mi1=I,t[p].mx1=-I;
			return;
		}
		int mid=(l+r)>>1;
		build(ty,p<<1,l,mid),build(ty,p<<1|1,mid+1,r);
		t[p]=t[p<<1]+t[p<<1|1];
	}
	inline qq ask(int p,int l,int r,int x,int y){
		if(x<=l&&r<=y)return t[p];
		int mid=(l+r)>>1;
		if(y<=mid)return ask(p<<1,l,mid,x,y);
		if(x>mid)return ask(p<<1|1,mid+1,r,x,y);
		return ask(p<<1,l,mid,x,y)+ask(p<<1|1,mid+1,r,x,y);
	}
}T[2];
vector<ll>cl (qq e){
	vector<ll>b;
	if(e.yk)b.push_back(0);
	if(e.mi0!=I)b.push_back(e.mi0);
	if(e.mi1!=I)b.push_back(e.mi1);
	if(e.mx0!=-I)b.push_back(e.mx0);
	if(e.mx1!=-I)b.push_back(e.mx1);
	return b;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)scanf("%lld",&a[0][i]);
	for(int i=1;i<=m;i++)scanf("%lld",&a[1][i]);
	T[0].build(0,1,1,n),T[1].build(1,1,1,m);
	for(int i=1,l1,r1,l2,r2;i<=q;i++){
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		qq e=T[0].ask(1,1,n,l1,r1),b=T[1].ask(1,1,m,l2,r2);
		vector<ll>x,y;
		x=cl(e),y=cl(b);
		ll ans=-II;
		for(ll j:x){
			ll now=II;
			for(ll k:y)now=min(now,j*k);
			ans=max(ans,now);
		}
		printf("%lld\n",ans);
	}
	return 0;
} 
