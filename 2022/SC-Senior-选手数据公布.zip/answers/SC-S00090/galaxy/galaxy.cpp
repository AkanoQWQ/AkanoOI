#include<bits/stdc++.h>
#define ll long long
using namespace std;
int n,m,sz[500100],su[501000];
ll a[501000],ot[500100],on[501000];
ll bigrand(){int A=rand(),B=rand();return ((1ll*A)<<30)^(1ll*B);}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	srand(time(0));
	scanf("%d%d",&n,&m);
	ll all=0;
	for(int i=1;i<=n;i++)a[i]=bigrand(),all^=a[i];
	int sum=m;ll al=0;
	for(int i=1,u,v;i<=m;i++){
		scanf("%d%d",&u,&v);
		al^=a[u],ot[v]^=a[u],on[v]^=a[u],sz[v]++,su[v]++;
	}
	int q;scanf("%d",&q);
	for(int i=1,op,x,y;i<=q;i++){
		scanf("%d%d",&op,&x);
		if(op==1){
			scanf("%d",&y);
			on[y]^=a[x],al^=a[x];
			su[y]--,sum--;
		}
		if(op==3){
			scanf("%d",&y);
			on[y]^=a[x],al^=a[x];
			su[y]++,sum++;
		}
		if(op==2){
			al^=on[x],on[x]=0;
			sum-=su[x],su[x]=0;
		}
		if(op==4){
			al^=on[x],on[x]=ot[x],al^=on[x];
			sum+=sz[x]-su[x],su[x]=sz[x];
		}
		if(sum==n&&all==al)printf("YES\n");
		else printf("NO\n");
	}
	return 0;
} 
