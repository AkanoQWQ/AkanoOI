#include<bits/stdc++.h>
#define ll long long
using namespace std;
int n,Q,K;
ll a[201000];
vector<int>g[201000];
int f[201000][20],d[201000];
ll ds[201000];
void dfs(int x){
	for(int v:g[x])if(f[x][0]!=v){
		f[v][0]=x,d[v]=d[x]+1;
		ds[v]=ds[x]+a[v];
		for(int i=1;i<20;i++)f[v][i]=f[f[v][i-1]][i-1];
		dfs(v);
	}
}
int lca(int u,int v){
	if(d[u]<d[v])swap(u,v);int a=d[u]-d[v];
	for(int i=19;i>=0;i--)if((a>>i)&1)u=f[u][i];
	if(u==v)return u;
	for(int i=19;i>=0;i--)if(f[u][i]!=f[v][i])u=f[u][i],v=f[v][i];
	return f[u][0];
}
void pts16(){
	for(int u,v,i=1;i<=Q;i++){
		scanf("%d%d",&u,&v);int lc=lca(u,v);
		printf("%lld\n",ds[u]+ds[v]-ds[lc]-ds[f[lc][0]]);
	}
}
const ll I=1e18;
struct qq{
	ll a[3][3];
}w1[201000][20],w2[201000][20];
void cl(qq &x){
	for(int i=0;i<K;i++)for(int j=0;j<K;j++)x.a[i][j]=I;
}
qq mul(qq a,qq b){
	qq c;cl(c);
	for(int k=0;k<K;k++)for(int i=0;i<K;i++)for(int j=0;j<K;j++)
		c.a[i][j]=min(c.a[i][j],a.a[i][k]+b.a[k][j]);
	return c;
}
int id[201000][3][3];
ll val[201000][3][3];
ll wW[201000][3];
ll ex1(int x,int v,int d){
	if(id[x][d][0]!=v)return val[x][d][0];
	return val[x][d][1]; 
}
ll ex2(int x,int v1,int v2,int d){
	if(id[x][d][0]!=v1&&id[x][d][0]!=v2)return val[x][d][0];
	if(id[x][d][1]!=v1&&id[x][d][1]!=v2)return val[x][d][1];
	return val[x][d][2]; 
}
void dfs2(int x){
	val[x][0][0]=a[x],id[x][0][0]=x;
	for(int v:g[x])if(v!=f[x][0]){
		dfs2(v);
		for(int i=1;i<K;i++){
			ll os=val[v][i-1][0];
			for(int j=0;j<3;j++)if(!id[x][i][j]||os<val[x][i][j]){
				for(int k=2;k>j;k--)id[x][i][k]=id[x][i][k-1],val[x][i][k]=val[x][i][k-1];
				val[x][i][j]=os,id[x][i][j]=v;
				break;
			}
		}
	}
	if(f[x][0]){
		wW[x][1]=a[f[x][0]];
		wW[x][2]=ex1(f[x][0],x,1);
		if(f[x][1])wW[x][2]=min(wW[x][2],a[f[x][1]]);
	}
}
void dfs3(int x){
	for(int v:g[x])if(v!=f[x][0]){
		cl(w1[v][0]);
		for(int i=0;i<K;i++)for(int j=0;j<K;j++)if(i+j+1<=K)
		w1[v][0].a[i][j]=min(w1[v][0].a[i][j],ex1(x,v,j));
		for(int i=0;i+1<K;i++)w1[v][0].a[i][i+1]=0;
		w2[v][0]=w1[v][0];
		for(int i=1;i<20;i++)if(f[v][i])w1[v][i]=mul(w1[v][i-1],w1[f[v][i-1]][i-1]),w2[v][i]=mul(w2[f[v][i-1]][i-1],w2[v][i-1]);
		dfs3(v);
	}
}
void pts84(){
	dfs2(1);dfs3(1);
	for(int u,v,ee=1;ee<=Q;ee++){
		scanf("%d%d",&u,&v);
		if(d[u]<d[v])swap(u,v);
		int lc=lca(u,v);
		qq now;cl(now);now.a[0][0]=a[u];
		if(lc==v){
			int kb=d[u]-d[v]-1,o=u;
			for(int j=19;j>=0;j--)if((kb>>j)&1) 
				now=mul(now,w1[o][j]),o=f[o][j];
		}
		else{
			int o=u,kb=d[u]-d[lc]-1;
			for(int j=19;j>=0;j--)if((kb>>j)&1)
				now=mul(now,w1[o][j]),o=f[o][j];
			int ou=o;
			o=v,kb=d[v]-d[lc]-1;
			qq p2;bool az=0;
			for(int j=19;j>=0;j--)if((kb>>j)&1){
				if(!az)p2=w2[o][j],az=1;
				else p2=mul(w2[o][j],p2);
				o=f[o][j];
			}
			if(!az){
				cl(p2);
				for(int i=0;i<K;i++)p2.a[i][i]=0;
			}
			o=v,kb=d[v]-d[lc]-1;
			for(int j=19;j>=0;j--)if((kb>>j)&1)o=f[o][j];
			int ov=o;
			ll r[3]={a[lc],I,I};
			for(int i=1;i<K;i++)r[i]=min(ex2(lc,ou,ov,i),wW[lc][i]);
			qq ks;cl(ks);
			for(int i=0;i+1<K;i++)ks.a[i][i+1]=0;
			for(int i=0;i<K;i++)for(int j=0;j<K;j++)if(i+j+1<=K)
				ks.a[i][j]=min(ks.a[i][j],r[j]);
			now=mul(now,ks);
			now=mul(now,p2);
		}
		ll ans=I;
		for(int i=0;i<K;i++)ans=min(ans,now.a[0][i]);
		printf("%lld\n",ans+a[v]);
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&Q,&K);
	for(int i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	for(int u,v,i=1;i<n;i++){
		scanf("%d%d",&u,&v);
		g[u].push_back(v),g[v].push_back(u);
	}
	for(int i=1;i<=n;i++)for(int j=0;j<3;j++)for(int k=0;k<3;k++)val[i][j][k]=I;
	for(int i=1;i<=n;i++)for(int j=0;j<3;j++)wW[i][j]=I;
	ds[1]=a[1];dfs(1);
	if(K==1)pts16();
	else pts84();
	return 0;
}
