#include<bits/stdc++.h>
#define ll long long
using namespace std;
bool di[2510][2510];
int n,m,K;
int head[2510],to[20100],nxt[20100],c;
void add(int u,int v){
	to[++c]=v,nxt[c]=head[u],head[u]=c;
}
queue<int>q;
int d[2510];
ll a[2510];
int mx[2510][3];
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&K);
	for(int i=2;i<=n;i++)scanf("%lld",&a[i]);
	for(int i=1,u,v;i<=m;i++){
		scanf("%d%d",&u,&v);
		add(u,v),add(v,u); 
	}
	for(int s=1;s<=n;s++){
		memset(d,0,sizeof(d));
		d[s]=1;
		while(!q.empty())q.pop();
		q.push(s);
		while(!q.empty()){
			int u=q.front();
			q.pop();
			di[s][u]=1;
			if(d[u]-1==K+1)continue;
			for(int i=head[u];i;i=nxt[i])if(!d[to[i]])
				d[to[i]]=d[u]+1,q.push(to[i]);
		}
	}
	for(int i=2;i<=n;i++){
		for(int j=1;j<=n;j++)if(i!=j&&di[i][j]&&di[j][1]){
			for(int k=0;k<3;k++)if(a[j]>a[mx[i][k]]){
				for(int k2=2;k2>k;k2--)mx[i][k2]=mx[i][k2-1];
				mx[i][k]=j;break;
			}
		}
	}
	ll ans=0;
	for(int i=2;i<=n;i++)for(int j=i+1;j<=n;j++)if(di[i][j]){
		for(int k=0;k<3;k++)if(mx[i][k])
			for(int k2=0;k2<3;k2++)if(mx[j][k2]){
				int A=mx[i][k],B=i,C=j,D=mx[j][k2];
				if(A!=D&&A!=C&&B!=D)
				ans=max(ans,a[A]+a[B]+a[C]+a[D]);
			}
	}
	return printf("%lld",ans),0;
}
