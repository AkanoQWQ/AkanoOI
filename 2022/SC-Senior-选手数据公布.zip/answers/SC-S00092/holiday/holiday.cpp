#include<bits/stdc++.h>
using namespace std;
int n,m,K,h[30001],tooo[300001],ne[300001],idx,viss[3001],diss[3001][3001];
long long a[30001],MAX;
void add(int x,int y){
	tooo[++idx]=y,ne[idx]=h[x],h[x]=idx;
}
void dfs(int f){
	deque<int>q;
	q.push_back(f);
	while(!q.empty()){
		int fro=q.front();
		q.pop_front();
		viss[fro]=1;
		for(int i=h[fro];i;i=ne[i]){
			if(!diss[f][tooo[i]])diss[f][tooo[i]]=diss[f][fro]+1;
			if(!viss[tooo[i]])q.push_back(tooo[i]);
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>K;
	for(int i=2;i<=n;i++)cin>>a[i],MAX=max(MAX,a[i]);
	for(int i=1;i<=m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v),add(v,u);
	}
	for(int i=1;i<=n;i++){
		memset(viss,0,sizeof viss);
		dfs(i);
	}
	long long ans=0;
	for(int i=2;i<=n;i++){
		if(diss[i][1]-1>K)continue;
		if(a[i]<ans-MAX*3)continue;
		for(int j=2;j<=n;j++){
			if(diss[i][j]-1>K||i==j)continue;
			if(a[i]+a[j]<ans-MAX*2)continue;
			for(int k=2;k<=n;k++){
				if(diss[j][k]-1>K||i==k||j==k)continue;
				if(a[i]+a[j]+a[k]<ans-MAX)continue;
				for(int p=2;p<=n;p++){
					if(diss[p][k]-1>K||i==p||j==p||k==p)continue;
					if(diss[1][p]-1>K)continue;
					ans=max(ans,a[i]+a[j]+a[k]+a[p]);
				}
			}
		}
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
