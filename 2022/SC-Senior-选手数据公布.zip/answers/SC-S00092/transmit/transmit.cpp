#include<bits/stdc++.h>
using namespace std;
int n,q,k,FF[440001][33],dep[440001],h[440001],idx,tooo[440001],ne[440001];
long long sum[440001],a[440001];
void add(int x,int y){
	tooo[++idx]=y,ne[idx]=h[x],h[x]=idx;
}
void dfs(int x,int f){
	dep[x]=dep[f]+1;
	sum[x]=sum[f]+a[x];
	for(int i=1;i<=30;i++){
		FF[x][i]=FF[FF[x][i-1]][i-1];
	}
	for(int i=h[x];i;i=ne[i]){
		if(tooo[i]!=f)FF[tooo[i]][0]=x,dfs(tooo[i],x);
	}
}
int LCA(int x,int y){
	if(dep[x]<dep[y])swap(x,y);
	for(int i=30;i>=0;i--){
		if(dep[FF[x][i]]>=dep[y])x=FF[x][i];
	}
	if(x==y)return x;
	for(int i=30;i>=0;i--){
		if(FF[x][i]!=FF[y][i]){
			x=FF[x][i],y=FF[y][i];
		}
	}
	return FF[x][0];
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=n-1;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v),add(v,u);
	}
	dfs(1,0);
	while(q--){
		int x,y;
		cin>>x>>y;
		int lca=LCA(x,y);
		cout<<(sum[x]+sum[y]-sum[lca]*2+a[lca])<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
