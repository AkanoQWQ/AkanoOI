#include<bits/stdc++.h>
using namespace std;
int n,m,q,a[300001],b[300001];
struct shu{
	long long MAX,MIN,zhen,fu,ling;
}tree[500001][2],yuan;
bool operator==(shu a,shu b){
	return (a.MAX==b.MAX&&a.fu==b.fu&&a.ling==b.ling&&a.zhen==b.zhen&&a.MIN==b.MIN);
}
void up(long long id){
	for(long long op=0;op<=1;op++){
		tree[id][op].MAX=max(tree[id*2][op].MAX,tree[id*2+1][op].MAX);
		tree[id][op].MIN=min(tree[id*2][op].MIN,tree[id*2+1][op].MIN);
		tree[id][op].ling=tree[id*2][op].ling+tree[id*2+1][op].ling;
		long long q=tree[id*2][op].zhen,w=tree[id*2+1][op].zhen;
		if(q&&w)tree[id][op].zhen=min(q,w);
		else if(q)tree[id][op].zhen=q;
		else tree[id][op].zhen=w;
		q=tree[id*2][op].fu,w=tree[id*2+1][op].fu;
		if(q&&w)tree[id][op].fu=max(q,w);
		else if(q)tree[id][op].fu=q;
		else tree[id][op].fu=w;
	}	
}
void build(long long x,long long y,long long id){
	if(x==y){
		tree[id][0]=(shu){a[x],a[x],(a[x]>0)*(a[x]),(a[x]<0)*(a[x]),(a[x]==0)};
		tree[id][1]=(shu){b[x],b[x],(b[x]>0)*(b[x]),(b[x]<0)*(b[x]),(b[x]==0)};
		return ;
	}
	else{
		long long mid=(x+y)/2;
		if(x<=mid)build(x,mid,id*2);
		if(mid+1<=y)build(mid+1,y,id*2+1);
		up(id);
	}
}
shu query(long long x,long long y,long long l,long long r,long long id){
	if(y<l||x>r)return yuan;
	if(l>=x&&r<=y)return tree[id][0];
	shu res=yuan,b=yuan,a=yuan;
	long long mid=(l+r)/2;
	if(l<=mid)a=query(x,y,l,mid,id*2);
	if(mid+1<=r)b=query(x,y,mid+1,r,id*2+1);
	if(a==yuan)return b;
	else if(b==yuan)return a;
	else{
		res.MAX=max(a.MAX,b.MAX);
		res.MIN=min(a.MIN,b.MIN);
		res.ling=a.ling+b.ling;
		long long q=a.zhen,w=b.zhen;
		if(q&&w)res.zhen=min(q,w);
		else if(q)res.zhen=q;
		else res.zhen=w;
		q=a.fu,w=b.fu;
		if(q&&w)res.fu=max(q,w);
		else if(q)res.fu=q;
		else res.fu=w;
		return res;
	}
}
shu query1(long long x,long long y,long long l,long long r,long long id){
	if(y<l||x>r)return yuan;
	if(l>=x&&r<=y)return tree[id][1];
	shu res=yuan,b=yuan,a=yuan;
	long long mid=(l+r)/2;
	if(l<=mid)a=query1(x,y,l,mid,id*2);
	if(mid+1<=r)b=query1(x,y,mid+1,r,id*2+1);
	if(a==yuan)return b;
	else if(b==yuan)return a;
	else{
		res.MAX=max(a.MAX,b.MAX);
		res.MIN=min(a.MIN,b.MIN);
		res.ling=a.ling+b.ling;
		long long q=a.zhen,w=b.zhen;
		if(q&&w)res.zhen=min(q,w);
		else if(q)res.zhen=q;
		else res.zhen=w;
		q=a.fu,w=b.fu;
		if(q&&w)res.fu=max(q,w);
		else if(q)res.fu=q;
		else res.fu=w;
		return res;
	}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	yuan=(shu){0,0,0,0,0};
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)scanf("%d",&b[i]);
	build(1,n,1);
	while(q--){
		long long l11,r11,l22,r22;
		cin>>l11>>r11>>l22>>r22;
		shu A=query(l11,r11,1,n,1);
		shu B=query1(l22,r22,1,n,1);
		if(B.MAX<=0&&A.MAX<0){
			cout<<(long long)A.MIN*B.MAX<<endl;
		}
		else if(B.MAX<=0&&A.MIN<0){
			cout<<(long long)B.MAX*A.MIN<<endl;
		}
		else if(B.MIN>=0&&A.MAX>0){
			cout<<(long long)B.MIN*A.MAX<<endl;
		}
		else if(B.MIN>=0&&A.MAX<=0){
			cout<<(long long)B.MAX*A.MAX<<endl;
		}
		else if(A.ling==0){
			if(A.fu&&A.zhen)cout<<max((long long)A.zhen*B.MIN,(long long)A.fu*B.MAX)<<endl;
			else if(A.zhen)cout<<(long long)A.zhen*B.MIN<<endl;
			else cout<<(long long)A.fu*B.MAX<<endl;
		}
		else{
			cout<<"0\n";
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
