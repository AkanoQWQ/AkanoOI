#include<bits/stdc++.h>
using namespace std;
const int N=112555;
int n,m,k,a[N],b[N];
int amal[N],bmal[N];//���������� ������== 
int amil[N],bmil[N];//�����С���� 
int amiz[N],bmiz[N];//С���� 
int amaf[N],bmaf[N];//����
int maxx,minn,minz,maxf;
int l,r,l2,r2;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	minz=1e9;
	maxf=-1e9;
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		if(a[i]>maxx&&a[i]>=0){
			maxx=a[i];
			amal[i]=i;
		}
		else {
			int j=i-1;
			while(a[j]<a[i]||a[j]<0){
				j=amal[j];
				if(amal[j]==j)break;
			}
			amal[i]=j;
		}
		if(a[i]<minn&&a[i]<=0){
			minn=a[i];
			amil[i]=i;
		}
		else {
			int j=i-1;
			while(a[j]>a[i]||a[j]>0){
				j=amil[j];
				if(amil[j]==j)break;
			}
			amil[i]=j;
		}
		
		if(a[i]<minz&&a[i]>=0){
			minz=a[i];
			amiz[i]=i;
		}
		else {
			int j=i-1;
			while(a[j]>a[i]||a[j]<0){
				j=amiz[j];
				if(amiz[j]==j)break;
			}
			amiz[i]=j;
		}
		
		if(a[i]>maxf&&a[i]<=0){
			maxf=a[i];
			amaf[i]=i;
		}
		else {
			int j=i-1;
			while(a[j]<a[i]||a[j]>0){
				j=amaf[j];
				if(amaf[j]==j)break;
			}
			amaf[i]=j;
		}
	}
	maxx=0;
	minn=0;
	minz=1e9;
	maxf=-1e9;
	for(int i=1;i<=m;i++){
		scanf("%d",&b[i]);
		if(b[i]>maxx&&b[i]>=0){
			maxx=b[i];
			bmal[i]=i;
		}
		else {
			int j=i-1;
			while(b[j]<b[i]||b[j]<=0){
				j=bmal[j];
				if(bmal[j]==j)break;
			}
			bmal[i]=j;
		}
		
		if(b[i]<minn&&b[i]<0){
			minn=b[i];
			bmil[i]=i;
		}
		else {
			int j=i-1;
			while(b[j]>b[i]||b[j]>0){
				j=bmil[j];
				if(bmil[j]==j)break;
			}
			bmil[i]=j;
		}
		
		if(b[i]<minz&&b[i]>=0){
			minz=b[i];
			bmiz[i]=i;
		}
		else {
			int j=i-1;
			while(b[j]>b[i]||b[j]<0){
				j=bmiz[j];
				if(bmiz[j]==j)break;
			}
			bmiz[i]=j;
		}
		
		if(b[i]>maxf&&b[i]<=0){
			maxf=b[i];
			bmaf[i]=i;
		}
		else {
			int j=i-1;
			while(b[j]<b[i]||b[j]>0){
				j=bmaf[j];
				if(bmaf[j]==j)break;
			}
			bmaf[i]=j;
		}
	}
	
	for(int i=1;i<=k;i++){
		scanf("%d%d%d%d",&l,&r,&l2,&r2);
		int j;
		int amaz,bmaz;//����� 
		j=r;
		while(amal[j]>=l&&amal[j]!=j)j=amal[j];
		if(a[j]>0)amaz=a[j];
		else amaz=0;
		j=r2;
		while(bmal[j]>=l2&&bmal[j]!=j)j=bmal[j];
		if(b[j]>0)bmaz=b[j];
		else bmaz=0;
		
		int amif,bmif;//��С�� 
		j=r;
		while(amil[j]>=l&&amil[j]!=j)j=amil[j];
		if(a[j]<0)amif=a[j];
		else amif=0;
		j=r2;
		while(bmil[j]>=l2&&bmil[j]!=j)j=bmil[j];
		if(b[j]<0)bmif=b[j];
		else bmif=0;
		
		int amizz,bmizz;//��С�� 
		j=r;
		while(amiz[j]>=l&&amiz[j]!=j)j=amiz[j];
		amizz=a[j];
		j=r2;
		while(bmiz[j]>=l2&&bmiz[j]!=j)j=bmiz[j];
		bmizz=b[j];
		
		int amaff,bmaff;//��� 
		j=r;
		while(amaf[j]>=l&&amaf[j]!=j)j=amaf[j];
		amaff=a[j];
		j=r2;
		while(bmaf[j]>=l2&&bmaf[j]!=j)j=bmaf[j];
		bmaff=b[j];
		
		if(l==r){
			amif=0;
			amaff=0;
			amaz=0;
			amizz=0;
			if(a[l]>0){
				amaz=a[l];
				amizz=a[l];
			}
			if(a[l]<0){
				amif=a[l];
				amaff=a[l];
			}
		}
		if(l2==r2){
			bmif=0;
			bmaff=0;
			bmaz=0;
			bmizz=0;
			if(b[l]>0){
				bmaz=b[l];
				bmizz=b[l];
			}
			if(b[l]<0){
				bmif=b[l];
				bmaff=b[l];
			}
		}
		
		if(bmif==0){//bֻ���� 
			if(amaz==0){//aֻ�и�
				printf("%lld\n",amaff*bmaz); 
			}
			else {//a����
				printf("%lld\n",amaz*bmizz);
			}
		}
		else if(bmaz==0){//bֻ�и�
			if(amif==0){//aֻ����
				printf("%lld\n",amizz*bmif);
			}
			else {//a�и�
				printf("%lld\n",amif*bmaff); 
			}
		}
		else {//b���� �и� 
			if(amif==0){//aֻ����
				printf("%lld\n",amizz*bmif);
			}
			if(amaz==0){//aֻ�и�
				printf("%lld\n",amaff*bmaz); 
			}
			else {//a�и����� 
			long long f=amizz*bmif,f2=amaff*bmaz;
				if(f<=f2)printf("%lld\n",f2);
				else printf("%lld\n",f);
			}
		}
	}
}
