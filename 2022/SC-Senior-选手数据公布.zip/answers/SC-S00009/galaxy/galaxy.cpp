#include<bits/stdc++.h>
using namespace std;
int n,m,q,x,y,z,cd[551111];
int idx,h[555555],e[551111],ne[551111],w[551111],v2[551111];
queue<int> g;
int v[551111],ans[551111],d[551111];
void add(int x,int y){
	idx++;
	e[idx]=y;
	ne[idx]=h[x];
	h[x]=idx;
}
int idx2,h2[555555],e2[551111],ne2[551111],w2[551111];
void add2(int x,int y){
	idx2++;
	e2[idx2]=y;
	ne2[idx2]=h2[x];
	h2[x]=idx2;
}
void hui(int x,int y,int z){
	for(int i=h[x];i;i=ne[i]){
		if(e[i]==y){
			cd[x]-=z-w[i];
			w[i]=z;
			break;
		}
	}
}
void cui(int x,int y){
	for(int i=h2[x];i;i=ne2[i]){
		hui(e2[i],x,y);
	}
}
int fx(int x){
	for(int i=1;i<=n;i++){
		v[i]=0;
		ans[i]=0;
		d[i]=0;
		v2[i]=0;
	}
	while(!g.empty())g.pop();
	g.push(x);
	v[x]=1;
	ans[x]++;
	int flag=0;
	while(!g.empty()){
		int t=g.front();
		g.pop();
		v[t]=0;
		for(int i=h[t];i;i=ne[i]){
			if(w[i])continue;
			if(d[e[i]]<d[t]+1){
				d[e[i]]=d[t]+1;
				ans[e[i]]++;
				if(ans[e[i]]>=2*n){
					if(cd[e[i]]!=1)return 1;
					else flag=1;
					v2[e[i]]=1;
				}
				if(!v[e[i]]&&!v2[e[i]]){
					v[e[i]]=1;
					g.push(e[i]);
				}
			}
		}
	}
	if(flag==0)return 1;
	else return 2;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&x,&y);
		add(x,y);
		add2(y,x);
		cd[x]++;
	}
	scanf("%d",&q);
	for(int i=1;i<=q;i++){
		scanf("%d",&x);
		if(x==1){
			scanf("%d%d",&y,&z);
			hui(y,z,1);
		}
		if(x==3){
			scanf("%d%d",&y,&z);
			hui(y,z,0);
		}
		if(x==2){
			scanf("%d",&y);
			cui(y,1);
		}
		if(x==4){
			scanf("%d",&y);
			cui(y,0);
		}
		int flag=0;
		for(int j=1;j<=n;j++){
			if(fx(j)==1){
				flag=1;
				printf("NO\n");
				break;
			}
		}
		if(flag==0)printf("YES\n");
	}
}
