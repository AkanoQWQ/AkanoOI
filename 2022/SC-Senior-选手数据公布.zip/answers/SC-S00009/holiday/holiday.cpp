#include<bits/stdc++.h>
using namespace std;
int n,m,k;
long long s[2555];
int idx,h[2555],e[11111],ne[11111];
long long f[2555][6][111],maxx;
int v[2555],v2[2555],v3[2555];
void add(int x,int y){
	idx++;
	e[idx]=y;
	ne[idx]=h[x];
	h[x]=idx;
}
void dfs(int p,int ans,int zhuan,long long sum){//p�� ѡ��ans���� ����sum
	if(ans==4&&v2[p]){
		maxx=max(maxx,sum);
		return ;
	}
	if(sum<f[p][ans][zhuan])return ;
	f[p][ans][zhuan]=sum;
	for(int i=h[p];i;i=ne[i]){
		int j=e[i];
		if(ans<4&&!v[j]){
			v[j]=1;
			for(int r=1;r<=n;r++)v3[r]=0;
			dfs(j,ans+1,0,sum+s[j]);
			v[j]=0;
		}
		if(zhuan<k&&!v3[j]){
			v3[j]=1;
			dfs(j,ans,zhuan+1,sum);
		}
	}
}
void yanzheng(int x,int y){
	for(int i=h[x];i;i=ne[i]){
		if(v2[e[i]]==0){
			v2[e[i]]=1;
			if(y<=k)yanzheng(e[i],y+1);
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++){
		scanf("%lld",&s[i]);
	}
	for(int i=1;i<=m;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
	}
	yanzheng(1,0);
	dfs(1,0,0,0);
	printf("%lld",maxx);
}
