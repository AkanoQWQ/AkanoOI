#include<bits/stdc++.h>
using namespace std;

int read () {
	int a = 1, x = 0;
	char c = getchar();
	while (!isdigit(c)) a = (c == '-' ? -a : a), c = getchar();
	while (isdigit(c)) x = (x << 3) + (x << 1) + (c ^ 48), c = getchar();
	return a * x;
}

void write(int x) {
	if (x < 0) putchar('-'), x = -x;
	if (x > 9) write(x / 10);
	putchar(x % 10 + 48);
}

const int MAXN = 500005;
int n, m, q, num, out[MAXN]; 
set<int> s[MAXN];
set<int> d[MAXN];
void add(int x, int y) {
	if (out[x] == 1) num--;
	s[y].insert(x);
	out[x]++;
	if (out[x] == 1) num++;
}
void destroy(int x, int y) {
	if (out[x] == 1) num--;
	s[y].erase(s[y].find(x));
	d[y].insert(x);
	out[x]--;
	if (out[x] == 1) num++;
}
int main () {
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	cin >> n >> m;
	int u, v;
	for (int i = 1;i <= m;i++) {
		cin >> u >> v;
		add(u, v);
	}
	cin >> q;
	int op;
	set<int> tmp;
	while (q--) {
		cin >> op;
		switch (op) {
			case 1: {
				cin >> u >> v;
				destroy(u, v);
				break;
			}
			case 2: {
				cin >> u;
				for (int p: s[u]) {
					tmp.insert(p);
				}
				for (int p: tmp) {
					destroy(p, u);
				}
				tmp.clear();
				break;
			}
			case 3: {
				cin >> u >> v;
				add(u, v);
				break;
			}
			case 4: {
				cin >> u;
				for (int p: d[u]) {
					tmp.insert(p);
				}
				for (int p: tmp) {
					add(p, u);
					d[u].erase(d[u].find(p));
				}
				tmp.clear();
				break;
			}
		}
		if (num == n) cout << "YES" << endl;
		else cout << "NO" << endl;
	}
	return 0;
}

