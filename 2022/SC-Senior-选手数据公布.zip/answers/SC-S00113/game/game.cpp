#include<bits/stdc++.h>
using namespace std;

const int inf = 0x3f3f3f3f;
const long long sqinf = 1LL * inf * inf;
struct node {
	int lb, rb;
	long long mx, mi;
	node *ls, *rs;
	node () {
		ls = rs = NULL;
		lb = rb;
		mx = -inf, mi = inf;
	}
};
node *build (int lb, int rb) {
	node *newnode = new node;
	newnode -> lb = lb;
	newnode -> rb = rb;
	if (lb != rb) {
		int mid = (lb + rb) >> 1;
		newnode -> ls = build(lb, mid);
		newnode -> rs = build(mid+1, rb);
	}
	return newnode;
}
void pushup(node *cur) {
	cur -> mx = max(cur -> ls -> mx, cur -> rs -> mx);
	cur -> mi = min(cur -> ls -> mi, cur -> rs -> mi);
}
void modify(node *cur, int p, int x) {
	if (cur -> lb == p && cur -> rb == p) {
		cur -> mx = cur -> mi = x;
	}
	else {
		int mid = (cur -> lb + cur -> rb) >> 1;
		if (p <= mid) modify(cur -> ls, p, x);
		else modify(cur -> rs, p, x);
		pushup(cur);
	}
}
long long querymx(node *cur, int lb, int rb) {
	if (cur -> lb == lb && cur -> rb == rb) return cur -> mx;
	else {
		int mid = (cur -> lb + cur -> rb) >> 1;
		long long ans = -inf;
		if (lb <= mid) ans = max(ans, querymx(cur -> ls, lb, min(rb, mid)));
		if (rb > mid) ans = max(ans, querymx(cur -> rs, max(mid+1, lb), rb));
		return ans;
	}
}
long long querymi(node *cur, int lb, int rb) {
	if (cur -> lb == lb && cur -> rb == rb) return cur -> mi;
	else {
		int mid = (cur -> lb + cur -> rb) >> 1;
		long long ans = inf;
		if (lb <= mid) ans = min(ans, querymi(cur -> ls, lb, min(rb, mid)));
		if (rb > mid) ans = min(ans, querymi(cur -> rs, max(mid+1, lb), rb));
		return ans;
	}
}
bool v(long long x) {
	return x < inf && x > -inf;
}
const int MAXN = 100005;
node *ap, *an, *br;
int n, m, q, tmp, a[MAXN], b[MAXN];
signed main () {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin >> n >> m >> q;
	ap = build(1, n);
	an = build(1, n);
	br = build(1, m);
	for (int i = 1;i <= n;i++) {
		cin >> tmp;
		a[i] = tmp;
		if (tmp >= 0) {
			modify(ap, i, tmp);
		}
		if (tmp <= 0) {
			modify(an, i, tmp);
		}
	}
	for (int i = 1;i <= m;i++) {
		cin >> tmp;
		b[i] = tmp;
		modify(br, i, tmp);
	}
	int l1, l2, r1, r2;
	while (q--) {
		cin >> l1 >> r1 >> l2 >> r2;
		long long apmx = querymx(ap, l1, r1), anmx = querymx(an, l1, r1);
		long long apmi = querymi(ap, l1, r1), anmi = querymi(an, l1, r1);
		long long bmx = querymx(br, l2, r2);
		long long bmi = querymi(br, l2, r2);
		long long at = -sqinf;
		if (v(apmx)) at = max(at, apmx * bmi);
		if (v(apmi)) at = max(at, apmi * bmi);
		if (v(anmx)) at = max(at, anmx * bmx);
		if (v(anmi)) at = max(at, anmi * bmx);
		cout << at << endl;
	}
	return 0;
}

