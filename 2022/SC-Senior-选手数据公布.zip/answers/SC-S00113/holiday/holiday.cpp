#include<bits/stdc++.h>
using namespace std;

int read () {
	int a = 1, x = 0;
	char c = getchar();
	while (!isdigit(c)) a = (c == '-' ? -a : a), c = getchar();
	while (isdigit(c)) x = (x << 3) + (x << 1) + (c ^ 48), c = getchar();
	return a * x;
}

void write(int x) {
	if (x < 0) putchar('-'), x = -x;
	if (x > 9) write(x / 10);
	putchar(x % 10 + 48);
}

const int MAXN = 2005;
int f[MAXN][MAXN], n, m, k_;
long long sc[MAXN];
vector<int> to[MAXN]; 
int main () {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin >> n >> m >> k_;
	int lmt = k_ + 1;
	for (int i = 2;i <= n;i++) cin >> sc[i];
	int x, y;
	memset(f, 0x3f, sizeof(f));
	for (int i = 1;i <= m;i++) {
		cin >> x >> y;
		f[x][y] = f[y][x] = 1;
	}
	for (int i = 1;i <= n;i++) f[i][i] = 0;
	if (lmt > 1) for (int k = 1;k <= n;k++) {
		for (int i = 1;i <= n;i++) {
			for (int j = 1;j <= n;j++) {
				f[i][j] = min(f[i][j], f[i][k] + f[k][j]);
			}
		}
	}
	long long ans = 0;
	for (int i = 2;i <= n;i++) {
		if (f[1][i] > lmt) continue;
		for (int j = 2;j <= n;j++) {
			if (j == i) continue;
			if (f[i][j] > lmt) continue;
			for (int k = 2;k <= n;k++) {
				if (k == i || k == j) continue;
				if (f[j][k] > lmt) continue;
				for (int l = 2;l <= n;l++) {
					if (l == i || l == j || l == k) continue;
					if (f[k][l] > lmt || f[l][1] > lmt) continue;
					ans = max(ans, sc[i] + sc[j] + sc[k] + sc[l]);
				}
			}
		}
	}
	cout << ans;
	return 0;
}

