#include<bits/stdc++.h>
#define pli pair<long long, int> 
using namespace std;

int read () {
	int a = 1, x = 0;
	char c = getchar();
	while (!isdigit(c)) a = (c == '-' ? -a : a), c = getchar();
	while (isdigit(c)) x = (x << 3) + (x << 1) + (c ^ 48), c = getchar();
	return a * x;
}

void write(int x) {
	if (x < 0) putchar('-'), x = -x;
	if (x > 9) write(x / 10);
	putchar(x % 10 + 48);
}

const int MAXN = 200005;
int n, q, k, v[MAXN], vis[MAXN], fa[MAXN][20], dep[MAXN];
long long dist[MAXN], cdep[MAXN];
vector<int> to[MAXN];
set<int> acq;
void find(int x, int d) {
	acq.insert(x);
	if (d == 0) return;
	for (int p: to[x]) {
		if (acq.count(p)) continue;
		find(p, d - 1);
	}
}
void build(int x) {
	dep[x] = dep[fa[x][0]] + 1;
	cdep[x] = cdep[fa[x][0]] + v[x];
	for (int i = 1;i < 20;i++) fa[x][i] = fa[fa[x][i-1]][i-1];
	for (int p: to[x]) {
		if (p == fa[x][0]) continue;
		fa[p][0] = x;
		build(p);
	}
}
int findlca(int x, int y) {
	if (dep[x] < dep[y]) swap(x, y);
	for (int i = 19;i >= 0;i--) {
		if (dep[fa[x][i]] >= dep[y]) x = fa[x][i];
	}
	if (x == y) return x;
	for (int i = 19;i >= 0;i--) {
		if (fa[x][i] != fa[y][i]) {
			x = fa[x][i];
			y = fa[y][i];
		}
	}
	return fa[x][0];
}
int online(int p, int q, int r) {
	return findlca(p, r) == findlca(p, q) || findlca(q, r) == findlca(p, q);
}
int main () {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin >> n >> q >> k;
	for (int i = 1;i <= n;i++) {
		cin >> v[i];
	}
	int a, b;
	for (int i = 1;i < n;i++) {
		cin >> a >> b;
		to[a].push_back(b);
		to[b].push_back(a);
	}
	int s, t;
	build(1);
	while (q--) {
		cin >> s >> t;
		if (k != 1) {
			for (int i = 1;i <= n;i++) dist[i] = 0x3f3f3f3f3f3f3f3fLL, vis[i] = false;
			priority_queue<pli, vector<pli>, greater<pli> > pq;
			dist[s] = v[s];
			pq.push({v[s], s});
			while (pq.size()) {
				pli t2 = pq.top();
				pq.pop();
				if (vis[t2.second]) continue;
				vis[t2.second] = true;
				find(t2.second, k);
				for (auto p = acq.begin();p != acq.end();acq.erase(p++)) {
					if (dist[*p] > dist[t2.second] + v[*p]) {
						if (!online(s, t, *p) && !online(s, t, t2.second)) continue;
						dist[*p] = dist[t2.second] + v[*p];
						pq.push({dist[*p], *p});
					}
				}
			}
			cout << dist[t] << endl;
		}
		else {
			cout << cdep[s] + cdep[t] - 2 * cdep[findlca(s, t)] + v[findlca(s, t)] << endl;
		}
	}
	return 0;
}

