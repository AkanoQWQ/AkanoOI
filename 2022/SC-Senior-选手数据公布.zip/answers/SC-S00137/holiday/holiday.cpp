#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=2500+10,M=10000+10;
int n,m,d[N][N],cnt,h[M*2],k;
int b[N][5];
ll a[N*2],ans;
struct edge{
	int nxt,t;
}e[M*2];
ll max_(ll x,ll y)
{
	if(x>y)return x;
	else return y;
}
void add_(int x,int y)
{
	e[++cnt].t=y;
	e[cnt].nxt=h[x];
	h[x]=cnt;
}
ll read()
{
	ll x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){c=getchar();}
	while(c>='0'&&c<='9')x=x*10ll+c-'0',c=getchar();
	return x;
}
int read2()
{
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){c=getchar();}
	while(c>='0'&&c<='9')x=x*10+c-'0',c=getchar();
	return x;
}
void bfs(int s)
{
	queue<int>q;
	q.push(s);
	while(!q.empty())
	{
		int x=q.front();q.pop();
		for(int i=h[x];i;i=e[i].nxt)
		{
			int to=e[i].t;
			if(d[s][to]||to==s)continue;
			d[s][to]=d[s][x]+1;
			q.push(to);
		}
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;k++;
	for(int i=1;i<n;i++)
	{
		a[i+1]=read();
	}
	for(int i=1;i<=m;i++)
	{
		int x=read2(),y=read2();
		add_(x,y);
		add_(y,x);
	}
	for(int i=1;i<=n;i++)bfs(i);
	for(int i=2;i<=n;i++)
	{
		for(int j=2;j<=n;j++)
		{
			if(i==j)continue;
			if(d[1][j]>k||d[j][i]>k)continue;
			if(a[b[i][1]]<a[j])
			{
				b[i][3]=b[i][2];
				b[i][2]=b[i][1];
				b[i][1]=j;
			}
			else if(a[b[i][2]]<a[j])
			{
				b[i][3]=b[i][2];
				b[i][2]=j;
			}
			else if(a[b[i][3]]<a[j])
			{
				b[i][3]=j;
			}
		}
	}
	for(int i=2;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			if(i==j)continue;
			if(d[i][j]>k)continue;
			for(int ii=1;ii<=3;ii++)
				for(int jj=1;jj<=3;jj++)
				{
					if(b[i][ii]==b[j][jj]||b[i][ii]==j||b[j][jj]==i||b[i][ii]==0||b[j][jj]==0)continue;
					ans=max_(ans,a[i]+a[j]+a[b[i][ii]]+a[b[j][jj]]);
				}
		}
	 }
	 cout<<ans;
	 return 0;
}
