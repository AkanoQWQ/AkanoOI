#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e5+10;
int n,m,q;
int a[N],b[N];
int c[N][10];
struct T{
	int l,r,ma;
}tr[N*4][10];
void build(int x,int l,int r,int p)
{
	tr[x][p].l=l;tr[x][p].r=r;
	if(l==r)
	{
		tr[x][p].ma=c[l][p];
		return;
	}
	int mid=l+r>>1;
	build(x*2,l,mid,p);
	build(x*2+1,mid+1,r,p);
	if(p<=3)tr[x][p].ma=max(tr[x*2][p].ma,tr[x*2+1][p].ma);
	else tr[x][p].ma=min(tr[x*2][p].ma,tr[x*2+1][p].ma);
}
int qu(int x,int l,int r,int p)
{
	int nl=tr[x][p].l,nr=tr[x][p].r;
	if(nl>=l&&nr<=r)
	{
		return tr[x][p].ma;
	}
	int mid=nl+nr>>1;
	if(r<=mid)return qu(x*2,l,r,p);
	if(l>mid)return qu(x*2+1,l,r,p);
	if(p<4)return max(qu(x*2,l,mid,p),qu(x*2+1,mid+1,r,p));
	else return min(qu(x*2,l,mid,p),qu(x*2+1,mid+1,r,p));
}
signed main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
		c[i][1]=c[i][4]=a[i];
		c[i][7]=abs(a[i]);
		if(a[i]>0)c[i][6]=a[i],c[i][3]=-1e13;
		else c[i][3]=a[i],c[i][6]=1e13;
	}
	for(int i=1;i<=m;i++)
	{
		scanf("%lld",&b[i]);
		c[i][2]=c[i][5]=b[i];
	}
	build(1,1,n,1);build(1,1,n,3);build(1,1,n,4);build(1,1,n,6);build(1,1,n,7);
	build(1,1,m,2);build(1,1,m,5);
	while(q--)
	{
		int ln,rn,lm,rm;
		int ans=0;
		scanf("%lld%lld%lld%lld",&ln,&rn,&lm,&rm);
		int an=qu(1,ln,rn,1),am=qu(1,lm,rm,2),f=qu(1,ln,rn,3);
		int in=qu(1,ln,rn,4),im=qu(1,lm,rm,5),z=qu(1,ln,rn,6),ij=qu(1,ln,rn,7);
		if(am>0&&im<0)
		{
			if(ij==0)ans=0;
			else if(f<=-1e11||(z*im>f*am&&z<1e13))ans=z;
			else ans=f;
		}
		else if(am>0)ans=an;
		else if(im<0)ans=in;
		else ans=0;
		if(ans>0)ans*=im;
		else if(ans<0)ans*=am;
		else ans=0;
		printf("%lld\n",ans);
	}
	return 0;
}
