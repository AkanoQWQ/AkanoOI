#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
int n,m,fa[N][30],dep[N],cnt,h[N*2],k,a[N],f[N];
struct edge{
	int nxt,t;
}e[N*2];
void add_(int x,int y)
{
	e[++cnt].nxt=h[x];e[cnt].t=y;
	h[x]=cnt;
}
void dfs(int x)
{
	for(int j=1;fa[x][j]=fa[fa[x][j-1]][j-1];j++)
	{
		fa[x][j]=fa[fa[x][j-1]][j-1];
	}
	for(int i=h[x];i;i=e[i].nxt)
	{
		int to=e[i].t;
		if(to==fa[x][0])continue;
		fa[to][0]=x;
		dep[to]=dep[x]+1;
		f[to]=f[x]+a[to];
		dfs(to);
	}
}
int lca(int x,int y)
{
	if(dep[x]<dep[y])swap(x,y);
	for(int i=20;i>=0;i--)
	{
		if(fa[x][i]==0)continue;
		if(dep[fa[x][i]]>=dep[y])x=fa[x][i];
	}
	for(int i=20;i>=0;i--)
	{
		if(fa[x][i]!=fa[y][i])x=fa[x][i],y=fa[y][i];
	}
	return fa[x][0];
}
int main()
{	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<n;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		add_(x,y);add_(y,x);
	}
	f[1]=a[1];
	dfs(1);
	for(int i=1;i<=m;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		int l=lca(x,y);
		printf("%d\n",f[x]+f[y]-2*f[l]+a[l]);
	}
	return 0;
}
