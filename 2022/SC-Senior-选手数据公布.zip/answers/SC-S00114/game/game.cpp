#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,m,q;
long long a[100086],b[100086];
long long w[100086];
struct Node{
	int l,r;
	long long w; 
}seg[1086][4086];
void build(int x,int pos,int l,int r){
	seg[pos][x].l=l;seg[pos][x].r=r;
	if(l==r){
		seg[pos][x].w=w[l];
		return ;
	}
	int mid=(l+r)>>1;
	build(x<<1,pos,l,mid);
	build(x<<1|1,pos,mid+1,r);
	seg[pos][x].w=min(seg[pos][x<<1].w,seg[pos][x<<1|1].w);
}
long long query(int x,int pos,int l,int r){
	if(l<=seg[pos][x].l&&seg[pos][x].r<=r){
		return seg[pos][x].w;
	}
	long long res=1e18;
	int mid=(seg[pos][x].l+seg[pos][x].r)>>1;
	if(l<=mid)
	    res=min(res,query(x<<1,pos,l,r));
	if(r>mid)
	    res=min(res,query(x<<1|1,pos,l,r));
	return res;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)
	    scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++)
	    scanf("%lld",&b[i]);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++)
		    w[j]=a[i]*b[j];
		build(1,i,1,m);
	}
	for(int i=1;i<=q;i++){
		int l1,r1,l2,r2;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		long long ans=-1e18;
		for(int j=l1;j<=r1;j++){
			ans=max(ans,query(1,j,l2,r2));
		}
		printf("%lld\n",ans);
	}
	return 0;
}
/*
3 2 2
0 1 -2
-3 4
1 2 1 2
2 3 2 2

6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3
*/
