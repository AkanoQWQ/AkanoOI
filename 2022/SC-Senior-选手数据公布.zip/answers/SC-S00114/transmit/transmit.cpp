#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,q,k;
int w[200086];
struct Edge{
	int u,v;
	int nex;
}tr[400086];
int head[200086],tot;
void add(int u,int v){
	tr[++tot].u=u;
	tr[tot].v=v;
	tr[tot].nex=head[u];
	head[u]=tot;
}
int fa[200086][28],dep[200086];
void dfs(int x,int f){
	fa[x][0]=f;
	dep[x]=dep[f]+1;
	for(int i=head[x];i;i=tr[i].nex){
		int v=tr[i].v;
		if(v==f)continue;
		dfs(v,x);
	}
}
int LCA(int x,int y){
	if(dep[x]<dep[y])
	    swap(x,y);
	for(int i=25;i>=0;i--){
		if(dep[fa[x][i]]<dep[y])
		    continue;
		else
		    x=fa[x][i];
	}
	if(x==y)
	    return x;
	for(int i=25;i>=0;i--){
		if(fa[x][i]==fa[y][i])
		    continue;
		else
		     x=fa[x][i],y=fa[y][i];
	}
	return fa[x][0];
}
int cnt,val[200086];
int work(int a,int b,int f){
	int x=a,y=b;
	cnt=0;
	while(a!=f){
		a=fa[a][0];
		val[++cnt]=w[a];
	}
	while(b!=f){
		b=fa[b][0];
		if(b!=f)
		    val[++cnt]=w[b];
	}
	int s=cnt/k;
	sort(val+1,val+cnt+1);
	long long res=0;
	for(int i=1;i<=s;i++)
	    res+=val[i];
	return res+w[x]+w[y];
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++){
		scanf("%d",&w[i]);
	}
	for(int i=1;i<n;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
		add(v,u);
	}
	dep[1]=1;
	dfs(1,0);
	for(int i=1;i<=25;i++){
		for(int j=1;j<=n;j++)
		    fa[j][i]=fa[fa[j][i-1]][i-1];
	}
	for(int i=1;i<=q;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		int lca=LCA(x,y);
		printf("%d\n",work(x,y,lca));
	}
	return 0;
}
/*
7 3 3
1 2 3 4 5 6 7 
1 2
1 3
2 4
2 5
3 6
3 7
4 7
5 6
1 2
*/
