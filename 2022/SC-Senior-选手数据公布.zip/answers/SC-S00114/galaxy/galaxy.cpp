#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,m,q;
bool e[1086][1086];
struct Edge{
	int u,v;
	int nex;
}tr[500086];
int tot,head[500086];
void add(int u,int v){
	tr[++tot].u=u;
	tr[tot].v=v;
	tr[tot].nex=head[u];
	head[u]=tot;
	e[u][v]=true;
}
bool flag1,flag2,visp[1086],vise[10086];
int egcn[500086],cnt,dfn[10086];
void dfs(int x,int to,int num){
	if(flag1||cnt>1)
	    return;
	visp[x]=true;
	for(int i=head[x];i;i=tr[i].nex){
		int v=tr[i].v;
		if(!e[x][v])continue;
		if(vise[i]){
			flag2=true;
			if(dfn[i]==dfn[to])cnt++;
			continue;
		}
		egcn[x]++;
		if(egcn[x]>2){
			flag1=true;
			return;
		}
		vise[i]=true;dfn[i]=num;
		dfs(v,i,num);
	}
	
}
bool check(){
	memset(visp,0,sizeof visp);
	memset(vise,0,sizeof vise);
	memset(egcn,0,sizeof egcn);
	memset(dfn,0,sizeof dfn);
	flag1=false;cnt=0;
	int k=0;
	for(int i=1;i<=n;i++){
		flag2=false;
		if(!visp[i]){
			k++;
			dfs(i,0,k);
			if(!flag2)
			    return false;
		}
		if(flag1||cnt>1)
		    return false;
	}
	if(cnt!=1)
	    return false;
	return true;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
	}
	scanf("%d",&q);
	if(q<=1000)for(int i=1;i<=q;i++){
		int opt,u,v;
		scanf("%d%d",&opt,&u);
		if(opt==1){
			scanf("%d",&v);
			e[u][v]=false;
		}
		if(opt==2){
			for(int j=1;j<=n;j++)
			    e[j][u]=false;
		}
		if(opt==3){
			scanf("%d",&v);
			e[u][v]=true;
		}
		if(opt==4){
			for(int j=1;j<=n;j++)
			    e[j][u]=true;
		}
		if(check())
		    printf("YES\n");
		else
		    printf("NO\n");
	}
	else{
		puts("NO");
	}
	return 0;
}
/*
3 6
2 3
2 1
1 2
1 3
3 1
3 2
11
1 3 2
1 2 3
1 1 3
1 1 2
3 1 3
3 3 2
2 3
1 3 1
3 1 3
4 2
1 3 2
*/
