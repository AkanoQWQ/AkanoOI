#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,m,k;
long long w[2586];
struct Edge{
	int u,v;
	int nex;
}tr[200086];
int tot,head[2586];
void add(int u,int v){
	tr[++tot].u=u;
	tr[tot].v=v;
	tr[tot].nex=head[u];
	head[u]=tot;
}
long long ans;
bool vis[2586];
void dfs(int x,long long val,int cnt,int step){
	if(step>k||cnt>4)return ;
	if(x==1&&cnt==4){
		ans=max(ans,val);
		return ;
	}
	for(int i=head[x];i;i=tr[i].nex){
		int v=tr[i].v;
		if(!vis[v]){
			vis[v]=true;
			dfs(v,val+w[v],cnt+1,0);
			vis[v]=false;
		}
		dfs(v,val,cnt,step+1);
		if(cnt==4&&v==1){
			dfs(v,val,cnt,step);
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++){
		scanf("%lld",&w[i]);
	}
	for(int i=1;i<=m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
		add(v,u);
	}
	if(k>=n-1){
		sort(w+1,w+n+1);
		ans=w[n]+w[n-1]+w[n-2]+w[n-3];
		printf("%lld",ans);
		return 0;
	}
	vis[1]=true;
	dfs(1,0,0,0);
	printf("%lld",ans);
	return 0;
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1

7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4
*/
