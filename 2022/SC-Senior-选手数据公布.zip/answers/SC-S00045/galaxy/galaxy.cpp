#include<bits/stdc++.h>
using namespace std;
const int N=500010;
struct Edge{
	int v,nextt;
	bool fine;
}e[N];
int cnt,head[N],chu[N],chuisnot,n,m,q,num;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=0,x,y;i<m;i++){
		scanf("%d%d",&x,&y);
		e[++cnt]=(Edge){x,head[y],true};
		chu[x]++;
		if(chu[x]==2){
			chuisnot++;
		}
		head[y]=cnt;
	}
	scanf("%d",&q);
	num=m;
	for(int z=0,u,v,t;z<q;z++){
		scanf("%d",&t);
		if(t==1){
			scanf("%d%d",&u,&v);
			for(int i=head[v];i;i=e[i].nextt){
				if(e[i].v==u){
					if(e[i].fine==true){
						e[i].fine=false;
						chu[u]--;
						num--;
						
						if(chu[u]==0){
							chuisnot++;
						}
						
						if(chu[u]==1){
							chuisnot--;
						}
					}
				}
			}
		}
		if(t==2){
			scanf("%d",&v);
			for(int i=head[v];i;i=e[i].nextt){
				if(e[i].fine==true){
					e[i].fine=false;
					u=e[i].v;
					chu[u]--;
					if(chu[u]==0){
						chuisnot++;
					}
					if(chu[u]==1){
						chuisnot--;
					}
					num--;
				}
			}
		}
		if(t==3){
			scanf("%d%d",&u,&v);
			for(int i=head[v];i;i=e[i].nextt){
				if(e[i].v==u){
					if(e[i].fine==false){
						e[i].fine=true;
						chu[u]++;
						if(chu[u]==2){
							chuisnot++;
						}
						if(chu[u]==1){
							chuisnot--;
						}
						num++;
					}
				}
			}
		}
		if(t==4){
			scanf("%d",&v);
			for(int i=head[v];i;i=e[i].nextt){
				if(e[i].fine==false){
					e[i].fine=true;
					u=e[i].v;
					chu[u]++;
					if(chu[u]==2){
						chuisnot++;
					}
					if(chu[u]==1){
						chuisnot--;
					}
					num++;
				}
			}
		}
		if(chuisnot==0&&num==n){
			printf("YES\n");
		}
		else{
			printf("NO\n");
		}
	}
	return 0;
}
