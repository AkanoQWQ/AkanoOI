#include<bits/stdc++.h>
using namespace std;
const int N=2555,INF=1000000000;
int dis[N][N],n,m,k;
long long a[N],f[N][2][2],ans;
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	k++;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			dis[i][j]=INF;
		}
	}
	for(int i=2;i<=n;i++){
		scanf("%lld",&a[i]);
	}
	for(int i=0,x,y;i<m;i++){
		scanf("%d%d",&x,&y);
		dis[x][y]=1;
		dis[y][x]=1;
	}
	for(int z=1;z<=n;z++){
		for(int x=1;x<=n;x++){
			if(dis[x][z]>k){
				continue;
			}
			for(int y=1;y<=n;y++){
				if(dis[z][y]>k){
					continue;
				}
				if(dis[x][y]>dis[x][z]+dis[z][y]){
					dis[x][y]=dis[x][z]+dis[z][y];
				}
			}
		}
	}
	/*for(int i=2;i<=n;i++){
		if(dis[1][i]>k){
			continue;
		}
		for(int j=2;j<=n;j++){
			if(dis[i][j]>k||i==j){
				continue;
			}
			for(int x=2;x<=n;x++){
				if(dis[j][x]>k||i==x||j==x){
					continue;
				}
				for(int y=2;y<=n;y++){
					if(dis[x][y]>k||dis[y])
				}
			}
		}
	}*/
	for(int i=2;i<=n;i++){
		if(dis[1][i]>k){
			continue;
		}
		for(int j=2;j<=n;j++){
			if(dis[i][j]>k||i==j){
				continue;
			}
			if(f[j][1][0]<a[i]+a[j]){
				f[j][1][0]=a[i]+a[j];
				f[j][1][1]=i;
				if(f[j][0][0]<f[j][1][0]){
					swap(f[j][0],f[j][1]);
				}
			}
		}
	}
	for(int i=2;i<=n;i++){
		for(int j=2;j<=n;j++){
			if(i==j||dis[i][j]>k){
				continue;
			}
			for(int x=0;x<=1;x++){
				for(int y=0;y<=1;y++){
					if(f[i][x][1]==j||f[i][x][1]==f[j][y][1]||i==f[j][y][1]){
						continue;
					}
					ans=max(ans,f[i][x][0]+f[j][y][0]);
				}
			}
		}
	}
	/*for(int i=2;i<=n;i++){
		for(int x=0;x<2;x++){
			for(int y=0;y<2;y++){
				cout << f[i][x][y]<<' ';
			}
			cout << endl;
		}
		cout << endl<<endl;
	}*/
	printf("%lld",ans);
	return 0;
} 
