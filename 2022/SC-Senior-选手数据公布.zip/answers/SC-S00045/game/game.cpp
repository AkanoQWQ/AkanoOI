#include<bits/stdc++.h>
using namespace std;
const int N=100010;
const long long INF=100000000000000000;
int n,m,q;
long long a[2][N];
struct node{
	long long maxx,minn,l0,s0;
}tree[2][N*4];
void buildtree(int l,int r,int now,int op){
	if(l==r){
		if(a[op][l]>0){
			tree[op][now]=(node){a[op][l],a[op][l],a[op][l],-INF};
		}
		else if(a[op][l]<0){
			tree[op][now]=(node){a[op][l],a[op][l],INF,a[op][l]};
		}
		else{
			tree[op][now]=(node){a[op][l],a[op][l],0,0};
		}
		return;
	}
	int mid=(l+r)>>1;
	buildtree(l,mid,now<<1,op);
	buildtree(mid+1,r,now<<1|1,op);
	tree[op][now].maxx=max(tree[op][now<<1].maxx,tree[op][now<<1|1].maxx);
	tree[op][now].minn=min(tree[op][now<<1].minn,tree[op][now<<1|1].minn);
	tree[op][now].s0=max(tree[op][now<<1].s0,tree[op][now<<1|1].s0);
	tree[op][now].l0=min(tree[op][now<<1].l0,tree[op][now<<1|1].l0);
	return;
}
long long findma(int l,int r,int now,int fl,int fr,int op){
	if(fl<=l&&r<=fr){
		return tree[op][now].maxx;
	}
	int mid=(l+r)>>1;
	long long anss=-INF;
	if(fl<=mid){
		anss=max(anss,findma(l,mid,now<<1,fl,min(mid,fr),op));
	}
	if(mid+1<=fr){
		anss=max(anss,findma(mid+1,r,now<<1|1,max(mid+1,fl),fr,op));
	}
	//cout << "findma"<<l<<' '<<r<<' '<<fl<<' '<<fr<<' '<<anss<<endl;
	return anss;
}
long long findmi(int l,int r,int now,int fl,int fr,int op){
	if(fl<=l&&r<=fr){
		return tree[op][now].minn;
	}
	int mid=(l+r)>>1;
	long long anss=INF;
	if(fl<=mid){
		anss=min(anss,findmi(l,mid,now<<1,fl,min(mid,fr),op));
	}
	if(mid+1<=fr){
		anss=min(anss,findmi(mid+1,r,now<<1|1,max(mid+1,fl),fr,op));
	}
	return anss;
}
long long finds0(int l,int r,int now,int fl,int fr,int op){
	if(fl<=l&&r<=fr){
		return tree[op][now].s0;
	}
	int mid=(l+r)>>1;
	long long anss=-INF;
	if(fl<=mid){
		anss=max(anss,finds0(l,mid,now<<1,fl,min(mid,fr),op));
	}
	if(mid+1<=fr){
		anss=max(anss,finds0(mid+1,r,now<<1|1,max(mid+1,fl),fr,op));
	}
	return anss;
}
long long findl0(int l,int r,int now,int fl,int fr,int op){
	if(fl<=l&&r<=fr){
		return tree[op][now].l0;
	}
	int mid=(l+r)>>1;
	long long anss=INF;
	if(fl<=mid){
		anss=min(anss,findl0(l,mid,now<<1,fl,min(mid,fr),op));
	}
	if(mid+1<=fr){
		anss=min(anss,findl0(mid+1,r,now<<1|1,max(mid+1,fl),fr,op));
	}
	return anss;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[0][i]);
	}
	for(int i=1;i<=m;i++){
		scanf("%lld",&a[1][i]);
	}
	buildtree(1,n,1,0);
	buildtree(1,m,1,1);
	int l1,r1,l2,r2;
	for(int z=1;z<=q;z++){
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		long long ans=-INF;
		long long ma1=findma(1,n,1,l1,r1,0);
		long long mi1=findmi(1,n,1,l1,r1,0);
		long long s01=finds0(1,n,1,l1,r1,0);
		long long l01=findl0(1,n,1,l1,r1,0);
		long long ma2=findma(1,m,1,l2,r2,1);
		long long mi2=findmi(1,m,1,l2,r2,1);
		long long s02=finds0(1,m,1,l2,r2,1);
		long long l02=findl0(1,m,1,l2,r2,1);
		//cout << "here"<<endl;
		//cout << ma1<<' '<<mi1<<' '<<l01<<' '<<s01<<endl;
		//cout << ma2<<' '<<mi2<<' '<<l02<<' '<<s02<<endl;
		if(ma1<=0){
			if(ma2<=0){
				ans=mi1*ma2;
			}
			else if(mi2>=0){
				ans=ma1*ma2;
			}
			else{
				ans=ma1*ma2;
			}
		}
		else if(mi1>=0){
			
			if(ma2<=0){
				ans=mi1*mi2;
			}
			else if(mi2>=0){
				ans=ma1*mi2;
			}
			else{
				ans=mi1*mi2;
			}
		}
		else{
			if(ma2<=0){
				ans=mi1*ma2;
			}
			else if(mi2>=0){
				ans=ma1*mi2;
			}
			else{
				/*cout << "here"<<endl;
				cout << ma1<<' '<<mi1<<' '<<l01<<' '<<s01<<endl;
				cout << ma2<<' '<<mi2<<' '<<l02<<' '<<s02<<endl;*/
				ans=max(ans,l01*mi2);
				ans=max(ans,s01*ma2);
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
}
/*
5 5 1
-2 -1 0 1 2
-2 -1 0 1 2
2 2 4 4
*/
