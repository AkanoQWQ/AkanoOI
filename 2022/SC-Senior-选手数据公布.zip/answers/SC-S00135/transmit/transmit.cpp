#include <bits/stdc++.h>
#include <cstdio>
using namespace std;
int n,m,w;
int a[10000],b[1e5],c[1e5];
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>m>>w;
	cout<<"nothing"<<endl;
	return 0;
} 
