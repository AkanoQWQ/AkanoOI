#include <bits/stdc++.h>
#include <cstdio>
#include <queue>
using namespace std;
typedef pair<int,int>node;
const int N=2505,M=2e4+5;
int h[N],e[M],ne[M],w[N],num;
long long maxx;
int n,m,k;
long long ans;
bool vis[N];
void add(int a,int b)
{
	e[num]=b;
	ne[num]=h[a];
	h[a]=num++;
}
bool find(int la,int ke)
{
	int st[N];
	st[la]=1;
	queue<node>q;
	q.push({la,ke});
	while(!q.empty())
	{
		node u=q.front();
		int a=u.first,b=u.second;
		q.pop();  
		for(int i=h[a];i!=-1;i=ne[i])
	    {
		    int to=e[i];
		    if(to==1&&b<=k)return 1;
		    else if(to==1)return 0;
		    else if(!st[to])q.push({to,ke+1}),st[to]=1;
	    }
	}
	return 0;
}
void dfs(int la,int ke,int ti,long long s)
{
	if(ti==4&&s<ans)return;
	if(ti==4)
	{
		if(find(la,ke))
		{
			ans=s;
		}
		return;
	}
	if(ti==3&&(s+maxx)<=ans)return;
	if(ke>k)return;
	for(int i=h[la];i!=-1;i=ne[i])
	{
		int to=e[i];
		if(ke<k)dfs(to,ke+1,ti,s);
		if(!vis[to])
		{
			vis[to]=1;
			dfs(to,0,ti+1,s+w[to]);
			vis[to]=0;
		}
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	memset(h,-1,sizeof(h));
	w[1]=0;
	for(int i=2;i<=n;i++)
	{
		cin>>w[i];
		if(w[i]>maxx)maxx=w[i];
	}
	for(int i=1;i<=m;i++)
	{
		int a,b;
		cin>>a>>b;
		add(a,b);
		add(b,a);
	}
	vis[1]=1;
	dfs(1,0,0,0);
	cout<<ans;
	return 0;
} 
