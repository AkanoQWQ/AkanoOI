#include <bits/stdc++.h>
#include <cstdio>
using namespace std;
int n,m,q;
int A[10005],B[10005]; 
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)
	{
		cin>>A[i];
	}
	for(int i=1;i<=m;i++)
	{
		cin>>B[i];
	}
	for(int i=1;i<=q;i++)
	{
		int a,b,x,y;
		cin>>a>>b>>x>>y;
		long long loww=-0x3f3f3f;
		for(int j=a;j<=b;j++)
		{
			long long lj=0x3f3f3f;
			for(int k=x;k<=y;k++)
			{
				long long tt=A[j]*B[k];
				if(lj>tt)lj=tt;
			}
			if(lj>loww)loww=lj;
		}
		cout<<loww<<endl;
	}
	return 0;
} 
