#include <bits/stdc++.h>
#include <cstdio>
#include <queue>
using namespace std;
const int N=5e5+1,M=5e5+1;
int n,m,q;
int h[N],e[M],w[M],ne[M],num,d[N];
int bh[N],be[M],bne[M];
typedef pair<int,int>node;
void add(int a,int b)
{
	w[num]=1;
	e[num]=b;
	ne[num]=h[a];
	h[a]=num++;
	d[a]++;
	be[num-1]=a;
	bne[num-1]=bh[b];
	bh[b]=num-1;
}
void onee(int t,int x,int y)
{
		for(int i=h[x];i!=-1;i=ne[i])
		{
			int to=e[i];
			if(to==y)
			{
				if(t)w[i]=1,d[x]++;
				else w[i]=0,d[x]--;
				return;
			}
		}
}
void twoo(int t,int x)
{
	for(int i=bh[x];i!=-1;i=bne[i])
		{
			if(t)
			{
				if(w[i]=0)d[be[i]]++;
				w[i]=1;
			}
			else
			{
				if(w[i]=1)d[be[i]]--;
				w[i]=0;
			} 
		}
}
int check1()
{
	for(int i=1;i<=n;i++)
	{
		if(d[i]!=1)return 0;
	}
	return 1;
}
int check2()
{
	for(int i=1;i<=n;i++)
	{
		queue<node>q;
		int ifff=0;
		q.push({i,0});
		while(q.size())
		{
			node u=q.front();
			q.pop();
			int a=u.first;
			int b=u.second;
			for(int i=h[a];i!=-1;i=ne[i])
	    	{
		    	if(w[i])
		    	{
		    		if(b==1)
					{
					    ifff=1;
						break;
					}
					int to=e[i];
		    		q.push({to,b+1});
				}
	    	}
	    	if(ifff)break;
		}
		if(!ifff)return 0;
	}
	return 1;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	memset(h,-1,sizeof(h));
	memset(bh,-1,sizeof(bh));
	for(int i=1;i<=m;i++)
	{
		int a,b;
		cin>>a>>b;
		add(a,b);
	}
	cin>>q;
	while(q--)
	{
		int t,iff;
		cin>>t;
		if(t&1)
		{
			int x,y;
			cin>>x>>y;
			onee(t/2,x,y);
		}
		else
		{
			int x;
			cin>>x;
			twoo(t/2-1,x);
		}
		if(check1())
		{
			if(check2())
			{
				cout<<"YES"<<endl;
				continue;
			}
		}
		cout<<"NO"<<endl;
	}
	return 0;
} 
