#include <bits/stdc++.h>
using namespace std;
long long a[100005], b[100005], tc, q, na, nb;
long long c[1005][1005];
int l1, r1, l2, r2;
int main () {
	freopen ("game.in", "r", stdin);
	freopen ("game.out", "w", stdout);
	long long MMAX=0, MMIN=1;
	MMIN<<=62;
	ios::sync_with_stdio(0);
	
	cin >> na >> nb >> q;
	for (int i=1; i<=na; ++i)
		cin >> a[i];
	for (int j=1; j<=nb; ++j)
		cin >> b[j];
		
	for (int i=1; i<=q; ++i) {
		cin >> l1 >> r1 >> l2 >> r2;
		if (l1==r1) {
			MMAX=0, MMIN=1, MMIN<<=62;
			for (int i=l2; i<=r2; ++i)
				MMAX=max(b[i], MMAX), MMIN=min(b[i], MMIN);
			if (a[l1]<0) cout << MMAX*a[l1] << endl;
			else cout << MMIN*a[l1] << endl;
		}
		else if (l2==r2) {
			MMAX=0, MMIN=1, MMIN<<=62;
			for (int i=l1; i<=r1; ++i)
				MMAX=max(a[i], MMAX), MMIN=min(a[i], MMIN);
			if (b[l2]<0) cout << MMIN*b[l2] << endl;
			else cout << MMAX*b[l2] << endl;
		}
		else {
			long long AMIN=1<<30, AMAX=-1<<30, AZMIN=1<<30, BZMIN=1<<30, AZMAX=-1<<30, BZMAX=-1<<30, BMIN=1<<30, BMAX=-1<<30;
			for (int i=l1; i<=r1; ++i) {
				AMIN=min(AMIN, a[i]), AMAX=max(AMAX, a[i]);
				if (a[i]>=0) AZMIN=min(AZMIN, a[i]);
				if (a[i]<=0) AZMAX=max(AZMAX, a[i]);
			}
			for (int i=l2; i<=r2; ++i) {
				BMIN=min(BMIN, b[i]), BMAX=max(BMAX, b[i]);
				if (b[i]>=0) BZMIN=min(BZMIN, b[i]);
				if (b[i]<=0) BZMAX=max(BZMAX, b[i]);
			}
					
			if (BMAX<0&&AMIN<0) cout << BMAX*AMIN << endl;
			else if (BMAX<0) cout << BMIN*AMIN << endl;
			else if (BMIN>0&&AMAX>0) cout << BMIN*AMAX << endl;
			else if (BMIN>0) cout << BMAX*AMAX << endl;
			else if (AMAX<0) cout << AMAX*BMAX << endl;
			else if (AMIN>0) cout << AMIN*BMIN << endl;
			else cout << max(AZMIN*BMIN, AZMAX*BMAX) << endl;
		}
	}
	return 0;
}
/*
60
*/
