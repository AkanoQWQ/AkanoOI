#include <bits/stdc++.h>
using namespace std;
int n, m, q, x, y, t;
map<int, map<int, int> > p;
int g[200005][2]; //0->in, 1->out
bool check () {
	for (int i=1; i<=n; ++i)
		if (g[i][1]!=1) {
			cout << "NO" << endl;
			return 0;
		}
	cout << "YES" << endl;
	return 1;
}
int main () {
	freopen ("galaxy.in", "r", stdin);
	freopen ("galaxy.out", "w", stdout);
	cin >> n >> m;
	for (int i=0; i<m; ++i) {
		cin >> x >> y;
		++g[x][1], ++g[y][0];
		p[x][++p[x][-1]]=y;
	}
	cin >> q;
	for (int i=0; i<q; ++i) {
		
		cin >> t;
		if (t==1) {
			cin >> x >> y;
			g[x][1]--, g[y][0]--;
			check();
		}
		else if (t==3) {
			cin >> x >> y;
			g[x][1]++, g[y][0]++;
			check();
		}
		else if (t==2) {
			cin >> x;
			g[x][0]=0;
			for (int i=1; i<=p[x][-1]; ++i)
				g[p[x][i]][1]--;
			check();
		}
		else if (t==4) {
			cin >> x;
			g[x][0]=p[x][-1];
			for (int i=1; i<=p[x][-1]; ++i)
				g[p[x][i]][1]++;
			check();
		}
	}
	return 0;
}

