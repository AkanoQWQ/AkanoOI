#include <bits/stdc++.h>
using namespace std;
int N, M, K;
int score[2505], x, y, MAXX;
int k[2505][2505];
int MMAX[10005], q[10005];
//queue <int> q;
int mfind (int r) {
	for (int i=1; i<=k[1][2502]; ++i)
		if (k[1][i]==r) return i;
}
int dfs (int r, int f) {
	int sc=0;
	if (f==4&&mfind(r)) return score[r];
	else if (f==4) return 0;
	for (int i=1; i<=k[r][2502]; ++i)
		sc=max(dfs(k[r][i], f+1), sc);
	sc+=score[r];
	return sc;
}
int solve() {
	bool diff[10005];
	int dif[10005], tot=0;
	memset(diff, 0, 10005);
	int head=0, tail=1;
	q[0]=1;
	while (head<tail) {
		for (int i=1; i<=k[q[head]][2502]; ++i) {
			if (diff[k[q[head]][i]]==0)
				q[tail]=k[q[head]][i], ++tail;
		}
		diff[q[head]]=1;
		++head;
	}
	for (int i=1; i<10000; ++i)
		if (diff[i]==1) dif[++tot]=i;
	sort(dif+1, dif+tot+1);
	return dif[tot]+dif[tot-1]+dif[tot-2]+dif[tot-3];
}
int main () {
	freopen ("holiday.in", "r", stdin);
	freopen ("holiday.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> N >> M >> K;
	for (int i=2; i<=N; ++i)	
		cin >> score[i];
	
	for (int i=1; i<=M; ++i) {
		cin >> x >> y;
		if (x>y) swap(x, y);
		k[x][++k[x][2502]]=y;
		MAXX=max(MAXX, x);
	}
	cout << k[5][1] << endl << endl;
	if (K>=M) {
		cout << solve();
		return 0;
	}
	cout << dfs(1, 0);
	return 0;
}
/*
7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4

10 8 10
2 3 4 5 6 7 8 9
1 2
2 3
3 4
9 10
4 5
3 6
6 1
5 1

60
*/

