#include<bits/stdc++.h>
#define debug(x) std::cerr<<#x<<":"<<x<<'\n'
using namespace std;
using ll=long long;
using ull=unsigned long long;
template<typename _Tp>inline void read(_Tp &x)
{
	x=0;int f=1;char ch=getchar();
	while(ch<48){if(ch=='-')f=-1;ch=getchar();}
	while(ch>47)x=x*10+(ch^48),ch=getchar();
	x*=f;
}
template<typename _Tp>inline void write(_Tp x)
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar((x%10)|48);
}
const int N=5e5+5;
bool isok;
int n,m,q;
int head[N],fr[N],nxt[N],to[N],cnt;
int outd[N];
bitset<N>bad,vis;
inline void create(int ff,int tt){nxt[++cnt]=head[ff],head[ff]=cnt,to[cnt]=tt,fr[cnt]=ff;}
inline void dfs1(int pos)
{
	vis[pos]=1;
	for(int i=head[pos];i;i=nxt[i])
	{
		if(bad[i])continue;
		if(vis[to[i]]){isok=1;continue;}
		dfs1(to[i]);
	}
}
inline void dfs2(int pos)
{
	vis[pos]=1;
	for(int i=head[pos];i;i=nxt[i])
	{
		if(bad[i])continue;
		if(vis[to[i]]){isok=1;continue;}
		dfs2(to[i]);
	}
}
signed main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	read(n),read(m);
	for(int i=1,t1,t2;i<=m;++i) read(t1),read(t2),create(t1,t2),++outd[t1];
	int opt,x,y;
	read(q);
	while(q--)
	{
		read(opt);
		if(opt==1)
		{
			read(x),read(y);
			for(int i=head[x];i;i=nxt[i])
				if(to[i]==y)
				{
					bad[i]=1;
					break;
				}
			--outd[x];
		}
		else if(opt==2)
		{
			read(x);
			for(int i=1;i<=m;++i)
				if(to[i]==x&&!bad[i])bad[i]=1,--outd[fr[i]];
		}
		else if(opt==3)
		{
			read(x),read(y);
			for(int i=head[x];i;i=nxt[i])
				if(to[i]==y)
				{
					bad[i]=0;
					break;
				}
			++outd[x];
		}
		else if(opt==4)
		{
			read(x);
			for(int i=1;i<=m;++i)
				if(to[i]==x&&bad[i])bad[i]=0,++outd[fr[i]];
		}
		isok=1;
		for(int i=1;i<=n;++i)
		{
			if(outd[i]!=1)
			{
				isok=0;
				break;
			}
		}
		if(!isok){puts("NO");continue;}
		vis.reset();
		isok=0;
		dfs1(1);
		if(!isok){puts("NO");continue;}
		for(int i=2;i<=n;++i)
		{
			if(!vis[i])
			{
				isok=0;
				dfs2(i);
				if(!isok)break;
			}
		}
		if(!isok) puts("NO");
		else puts("YES");
	}
	return 0;
}

