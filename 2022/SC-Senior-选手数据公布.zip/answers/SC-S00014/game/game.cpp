#include<bits/stdc++.h>
#define debug(x) std::cerr<<#x<<":"<<x<<'\n'
using namespace std;
using ll=long long;
using ull=unsigned long long;
template<typename _Tp>inline void read(_Tp &x)
{
	x=0;int f=1;char ch=getchar();
	while(ch<48){if(ch=='-')f=-1;ch=getchar();}
	while(ch>47)x=x*10+(ch^48),ch=getchar();
	x*=f;
}
template<typename _Tp>inline void write(_Tp x)
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar((x%10)|48);
}
const int N=1e5+5,INF=2e9;
int n,m,q;
int a[N],b[N];
struct Tree
{
	struct Node
	{
		int mx,mn;
		int sp1,sp2;
		bool zero;
		Node()=default;
	}node[N<<2];
	inline void update(int pos)
	{
		node[pos].mx=max(node[pos<<1].mx,node[pos<<1|1].mx);
		node[pos].mn=min(node[pos<<1].mn,node[pos<<1|1].mn);
		node[pos].zero=(node[pos<<1].zero||node[pos<<1|1].zero);
		node[pos].sp1=min(node[pos<<1].sp1,node[pos<<1|1].sp1);
		node[pos].sp2=max(node[pos<<1].sp2,node[pos<<1|1].sp2);
	}
	inline void build(int pos,int l,int r,bool opt)
	{
		if(l==r)
		{
			if(opt) node[pos].mn=node[pos].mx=a[l];
			else node[pos].mn=node[pos].mx=b[l];
			node[pos].sp1=INF,node[pos].sp2=-INF;
			if(!node[pos].mn)node[pos].zero=1;
			else if(node[pos].mn>0)node[pos].sp1=node[pos].mn;
			else node[pos].sp2=node[pos].mn;
			return;
		}
		int mid=(l+r)>>1;
		build(pos<<1,l,mid,opt);
		build(pos<<1|1,mid+1,r,opt);
		update(pos);
	}
	inline int qmax(int pos,int l,int r,int L,int R)
	{
		if(L<=l&&r<=R)return node[pos].mx;
		int mid=(l+r)>>1,ans=-INF;
		if(L<=mid)ans=max(ans,qmax(pos<<1,l,mid,L,R));
		if(R>mid)ans=max(ans,qmax(pos<<1|1,mid+1,r,L,R));
		return ans;
	}
	inline int qmin(int pos,int l,int r,int L,int R)
	{
		if(L<=l&&r<=R)return node[pos].mn;
		int mid=(l+r)>>1,ans=INF;
		if(L<=mid)ans=min(ans,qmin(pos<<1,l,mid,L,R));
		if(R>mid)ans=min(ans,qmin(pos<<1|1,mid+1,r,L,R));
		return ans;
	}
	inline bool qzero(int pos,int l,int r,int L,int R)
	{
		if(L<=l&&r<=R)return node[pos].zero;
		int mid=(l+r)>>1;
		bool ans=0;
		if(L<=mid)if(qzero(pos<<1,l,mid,L,R))ans=1;
		if(R>mid)if(qzero(pos<<1|1,mid+1,r,L,R))ans=1;
		return ans;
	}
	inline int q1(int pos,int l,int r,int L,int R)
	{
		if(L<=l&&r<=R)return node[pos].sp1;
		int mid=(l+r)>>1,ans=INF;
		if(L<=mid)ans=min(ans,q1(pos<<1,l,mid,L,R));
		if(R>mid)ans=min(ans,q1(pos<<1|1,mid+1,r,L,R));
		return ans;
	}
	inline int q2(int pos,int l,int r,int L,int R)
	{
		if(L<=l&&r<=R)return node[pos].sp2;
		int mid=(l+r)>>1,ans=-INF;
		if(L<=mid)ans=max(ans,q2(pos<<1,l,mid,L,R));
		if(R>mid)ans=max(ans,q2(pos<<1|1,mid+1,r,L,R));
		return ans;
	}
}T1,T2;
signed main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	read(n),read(m),read(q);
	for(int i=1;i<=n;++i)read(a[i]);
	for(int i=1;i<=m;++i)read(b[i]);
	T1.build(1,1,n,1),T2.build(1,1,m,0);
	int l1,r1,l2,r2,mx1,mx2,mn1,mn2;
	bool z1;
	while(q--)
	{
		read(l1),read(r1),read(l2),read(r2);
		mx1=T1.qmax(1,1,n,l1,r1);
		mn1=T1.qmin(1,1,n,l1,r1);
		z1=T1.qzero(1,1,n,l1,r1);
		mx2=T2.qmax(1,1,m,l2,r2);
		mn2=T2.qmin(1,1,m,l2,r2);
//		debug(mx1),debug(mn1),debug(mx2),debug(mn2),debug(z1),debug(z2);
		if(mn1>=0&&mn2>=0)
		{
			write(1ll*mx1*mn2);
			putchar('\n');
			continue;
		}
		if(mx1<=0&&mx2<=0)
		{
			write(1ll*mn1*mx2);
			putchar('\n');
			continue;
		}
		if(mn1>=0&&mx2<=0)
		{
			write(1ll*mn1*mn2);
			putchar('\n');
			continue;
		}
		if(mx1<=0&&mn2>=0)
		{
			write(1ll*mx1*mx2);
			putchar('\n');
			continue;
		}
		if(mx2>0&&mn2<0)
		{
			if(z1)putchar('0');
			else
			{
				if(mx1<0) write(1ll*mx1*mx2);
				else if(mn1>0) write(1ll*mn1*mn2);
				else if(mx1>0&&mn1<0) write(max(1ll*T1.q1(1,1,n,l1,r1)*mn2,1ll*T1.q2(1,1,n,l1,r1)*mx2));
			}
			putchar('\n');
			continue;
		}
		if(mx2<=0) write(1ll*mn1*mx2);
		else write(1ll*mx1*mn2);
		putchar('\n');
	}
	return 0;
}
