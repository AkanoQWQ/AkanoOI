#include<bits/stdc++.h>
#define debug(x) std::cerr<<#x<<":"<<x<<'\n'
using namespace std;
using ll=long long;
using ull=unsigned long long;
template<typename _Tp>inline void read(_Tp &x)
{
	x=0;int f=1;char ch=getchar();
	while(ch<48){if(ch=='-')f=-1;ch=getchar();}
	while(ch>47)x=x*10+(ch^48),ch=getchar();
	x*=f;
}
template<typename _Tp>inline void write(_Tp x)
{
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar((x%10)|48);
}
const int N=2.5e3+5,M=2e4+5,INF=1e9;
int n,m,k;
//int head[N],nxt[M],to[M],cnt;
//inline void create(int ff,int tt){nxt[++cnt]=head[ff],head[ff]=cnt,to[cnt]=tt;}
int v[N],mx=-1;
bitset<N>edge[N];
int dis[N][N];
inline bool isok(int x,int y){return dis[x][y]-1<=k;}
int pur[5];
bitset<N>vis;
ull ans;
const auto MAXTIME=1.9*CLOCKS_PER_SEC; 
inline void check()
{
	if(isok(1,pur[0])&&isok(pur[0],pur[1])&&isok(pur[1],pur[2])&&isok(pur[2],pur[3])&&isok(pur[3],1))
		ans=max(ans,(ull)v[pur[0]]+(ull)v[pur[1]]+(ull)v[pur[2]]+(ull)v[pur[3]]);
}
inline void dfs(int step,ull sum=0)
{
	if(clock()>MAXTIME)return;
	if(sum+(ull)mx*(4ull-step)<=ans)return;
	if(step==3)
	{
		for(int i=2;i<=n;++i)
		{
			if(vis[i]) continue;
			pur[step]=i;
			check();
		}
		return;
	}
	int mid=(n+2)>>1;
	for(int i=mid;i>=2;--i)
	{
		if(clock()>MAXTIME)return;
		if(vis[i]) continue;
		vis[i]=1,pur[step]=i;
		dfs(step+1,sum+v[i]);
		vis[i]=0;
	}
	for(int i=mid+1;i<=n;++i)
	{
		if(clock()>MAXTIME)return;
		if(vis[i]) continue;
		vis[i]=1,pur[step]=i;
		dfs(step+1,sum+v[i]);
		vis[i]=0;
	}
}
signed main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	read(n),read(m),read(k);
	for(int i=2;i<=n;++i)read(v[i]),mx=max(mx,v[i]);
//	for(int i=1,t1,t2;i<=m;++i)read(t1),read(t2),create(t1,t2),create(t2,t1);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j)
			if(i!=j)dis[i][j]=INF;
	for(int i=1,t1,t2;i<=m;++i)
		read(t1),read(t2),edge[t1][t2]=edge[t2][t1]=1,dis[t1][t2]=dis[t2][t1]=1;
	if(k)
	{
		for(int kk=1;kk<=n;++kk)
			for(int i=1;i<=n;++i)
				for(int j=1;j<=n;++j)
					dis[i][j]=min(dis[i][kk]+dis[kk][j],dis[i][j]);
	}
//	for(int i=1;i<=n;++i,putchar('\n'))
//		for(int j=1;j<=n;++j)write(dis[i][j]),putchar(' ');
	dfs(0);
	write(ans);
	putchar('\n'); 
	return 0;
}
