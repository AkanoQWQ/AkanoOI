#include<bits/stdc++.h>
using namespace std;
const int mx=1e5+100;
typedef long long ll;
unsigned int n,m,q,x,y;
ll a[mx],b[mx],ma[mx];
ll c[10000][10000];

ll z(int l1,int r1,int l2,int r2){
	memset(ma,0,sizeof(ma));
	for(int i=l1;i<=r1;i++){
		ma[i]=9223372036854775807;
		for(int j=l2;j<=r2;j++){
			ma[i]=min(ma[i],c[i][j]);
		}
	}
	ll s=-9223372036854775807;
	for(int i=l1;i<=r1;i++){
		if(ma[i]>=s)s=ma[i],x=i;
	}
	s=9223372036854775807;
	for(int j=l2;j<=r2;j++){
		if(c[x][j]<=s)s=c[x][j],y=j;
	}
	return c[x][y];
}

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int l1,l2,r1,r2;
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++){
		scanf("%lld",a+i);
	}
	for(int i=1;i<=m;i++){
		scanf("%lld",b+i);
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			c[i][j]=a[i]*b[j];
		}
	}
	for(int i=1;i<=q;i++){
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		printf("%lld\n",z(l1,r1,l2,r2));
	}
	return 0;
} 
