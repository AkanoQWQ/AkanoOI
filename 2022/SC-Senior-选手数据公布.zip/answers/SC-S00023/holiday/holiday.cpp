#include<bits/stdc++.h>
using namespace std;
const int mx=1e4+100;
int n,m,k,x,y;
long long ans,ma[mx],s,cnt;
int a[mx],b[mx][mx];

int z(int i,int j){
	cnt++;
	if(cnt<=k){
		for(int i1=1;i1<=m;i1++){
			if(b[j][i1]!=0){
				ans=max((ans+b[i][j]),(ans+z(j,i1)));
			}
		}
		if(cnt==k)cnt=0;
	}
	return ans;
}

int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	a[1]=0;
	for(int i=2;i<=n;i++){
		scanf("%d",a+i);
	}
	for(int i=1;i<=m;i++){
		cin>>x>>y;
		b[x][y]=a[y];
	}
	for(int j=1;j<=m;j++){
		if(b[1][j]!=0)ma[j]=z(1,j);
	}
	for(int i=1;i<=m;i++){
		s=max(ma[i],s);
	}
	printf("%lld",s);
//	int c=4; 
//	int i,j,j1;
//	for(i=1;i<=n;i++){
//		for(j=1;j<=n;j++){
//			ma[i]=max(b[i][j],ma[i]);
//		}
//	}
//	sort(ma,ma+1+n);
//	for(int i=1;i<=4;i++){
//		ans+=ma[i];
//	}
//	cout<<ans;
	return 0;
} 
