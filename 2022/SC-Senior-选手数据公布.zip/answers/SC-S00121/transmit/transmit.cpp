#include<bits/stdc++.h>
using namespace std;
int tot,first[200010],nnext[400010],to[400010],dep[200010],f[200010][20];
long long w[200010];
void add(int a,int b){
	nnext[++tot]=first[a];
	first[a]=tot;
	to[tot]=b;
}
void init(int p,int fa){
	dep[p]=dep[fa]+1;
	w[p]+=w[fa];
	for(int e=first[p];e;e=nnext[e]){
		if(to[e]!=fa){
			f[to[e]][0]=p;
			init(to[e],p);
		}
	}
}
int LCA(int a,int b){
	if(dep[a]<dep[b]){
		swap(a,b);
	}
	for(int i=18;i>=0;i--){
		if(dep[f[a][i]]>=dep[b]){
			a=f[a][i];
		}
	}
	if(a==b){
		return a;
	}
	for(int i=18;i>=0;i--){
		if(f[a][i]!=f[b][i]){
			a=f[a][i];
			b=f[b][i];
		}
	}
	return f[a][0];
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int n,q,k,a,b,c;
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++){
		scanf("%lld",&w[i]);
	}
	for(int i=1;i<=n-1;i++){
		scanf("%d%d",&a,&b);
		add(a,b);
		add(b,a);
	}
	init(1,0);
	for(int i=1;i<=18;i++){
		for(int j=1;j<=n;j++){
			f[j][i]=f[f[j][i-1]][i-1];
		}
	}
	while(q--){
		scanf("%d%d",&a,&b);
		c=LCA(a,b);
		if(k==1){
			printf("%lld\n",w[a]+w[b]-w[c]);
		}
	}
}
