#include<bits/stdc++.h>
using namespace std;
int n,tot,q,first[2510],nnext[20010],to[20010],f[2510][2510],t[5],f1[2510];
long long s[2510],ans;
void add(int a,int b){
	nnext[++tot]=first[a];
	first[a]=tot;
	to[tot]=b;
}
void dfs1(int st,int p,int fa,int ma){
	if(ma<0){
		return;
	}
	f[st][p]=f[p][st]=1;
	for(int e=first[p];e;e=nnext[e]){
		if(to[e]!=fa){
			dfs1(st,to[e],p,ma-1);
		}
	}
}
void dfs3(int p,int fa,int ma){
	if(ma<0){
		return;
	}
	f1[p]=1;
	for(int e=first[p];e;e=nnext[e]){
		if(to[e]!=fa){
			dfs3(to[e],p,ma-1);
		}
	}
}
void dfs2(int p,int fa,int ste){
	if(ste==4){
		ans=max(ans,s[t[1]]+s[t[2]]+s[t[3]]+s[t[4]]);
		return;
	}
	for(int i=2;i<=n;i++){
		int r=1;
		for(int j=1;j<=ste;j++){
			if(t[j]==i){
				r=0;
				break;
			}
		}
		if(r==1&&i!=p&&i!=fa&&f[i][p]){
			if(ste==3){
				if(!f[1][i]){
					continue;
				}
			}
			if(ste==2){
				if(!f1[i]){
					continue;
				}
			}
			t[ste+1]=i;
			dfs2(i,p,ste+1);
			t[ste+1]=0;
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int m,a,b;
	scanf("%d%d%d",&n,&m,&q);
	for(int i=2;i<=n;i++){
		scanf("%lld",&s[i]);
	}
	for(int i=1;i<=m;i++){
		scanf("%d%d",&a,&b);
		add(a,b);
		add(b,a);
	}
	for(int i=1;i<=n;i++){
		dfs1(i,i,0,q+1);
	}
	dfs3(1,0,2*(q+1));
	dfs2(1,0,0);
	printf("%lld",ans);
}
