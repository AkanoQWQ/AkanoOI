#include<bits/stdc++.h>
using namespace std;
int a[400010],b[400010],p[400010],q[400010],h[400010],s[400010],f[400010];
void build1(int l,int r,int rt){
	int mid;
	if(l==r){
		scanf("%d",&a[rt]);
		if(a[rt]<0){
			p[rt]=-a[rt];
			q[rt]=1e9;
		}
		else if(a[rt]>0){
			q[rt]=a[rt];
			p[rt]=1e9;
		}
		else{
			p[rt]=q[rt]=1e9;
			s[rt]=1;
		}
		f[rt]=a[rt];
		return;
	}
	mid=(l+r)>>1;
	build1(l,mid,rt<<1);
	build1(mid+1,r,rt<<1|1);
	p[rt]=min(p[rt<<1],p[rt<<1|1]);
	q[rt]=min(q[rt<<1],q[rt<<1|1]);
	s[rt]=max(s[rt<<1],s[rt<<1|1]);
	a[rt]=max(a[rt<<1],a[rt<<1|1]);
	f[rt]=min(f[rt<<1],f[rt<<1|1]);
}
void build2(int l,int r,int rt){
	int mid;
	if(l==r){
		scanf("%d",&b[rt]);
		h[rt]=b[rt];
		return;
	}
	mid=(l+r)>>1;
	build2(l,mid,rt<<1);
	build2(mid+1,r,rt<<1|1);
	b[rt]=min(b[rt<<1],b[rt<<1|1]);
	h[rt]=max(h[rt<<1],h[rt<<1|1]);
}
int queryb(int ll,int rr,int l,int r,int rt){
	int mid,ans=1e9;
	if(ll<=l&&rr>=r){
		return b[rt];
	}
	mid=(l+r)>>1;
	if(ll<=mid){
		ans=min(ans,queryb(ll,rr,l,mid,rt<<1));
	}
	if(rr>mid){
		ans=min(ans,queryb(ll,rr,mid+1,r,rt<<1|1));
	}
	return ans;
}
int queryp(int ll,int rr,int l,int r,int rt){
	int mid,ans=1e9;
	if(ll<=l&&rr>=r){
		return p[rt];
	}
	mid=(l+r)>>1;
	if(ll<=mid){
		ans=min(ans,queryp(ll,rr,l,mid,rt<<1));
	}
	if(rr>mid){
		ans=min(ans,queryp(ll,rr,mid+1,r,rt<<1|1));
	}
	return ans;
}
int queryq(int ll,int rr,int l,int r,int rt){
	int mid,ans=1e9;
	if(ll<=l&&rr>=r){
		return q[rt];
	}
	mid=(l+r)>>1;
	if(ll<=mid){
		ans=min(ans,queryq(ll,rr,l,mid,rt<<1));
	}
	if(rr>mid){
		ans=min(ans,queryq(ll,rr,mid+1,r,rt<<1|1));
	}
	return ans;
}
int queryf(int ll,int rr,int l,int r,int rt){
	int mid,ans=1e9;
	if(ll<=l&&rr>=r){
		return f[rt];
	}
	mid=(l+r)>>1;
	if(ll<=mid){
		ans=min(ans,queryf(ll,rr,l,mid,rt<<1));
	}
	if(rr>mid){
		ans=min(ans,queryf(ll,rr,mid+1,r,rt<<1|1));
	}
	return ans;
}
int querya(int ll,int rr,int l,int r,int rt){
	int mid,ans=-1e9;
	if(ll<=l&&rr>=r){
		return a[rt];
	}
	mid=(l+r)>>1;
	if(ll<=mid){
		ans=max(ans,querya(ll,rr,l,mid,rt<<1));
	}
	if(rr>mid){
		ans=max(ans,querya(ll,rr,mid+1,r,rt<<1|1));
	}
	return ans;
}
int queryh(int ll,int rr,int l,int r,int rt){
	int mid,ans=-1e9;
	if(ll<=l&&rr>=r){
		return h[rt];
	}
	mid=(l+r)>>1;
	if(ll<=mid){
		ans=max(ans,queryh(ll,rr,l,mid,rt<<1));
	}
	if(rr>mid){
		ans=max(ans,queryh(ll,rr,mid+1,r,rt<<1|1));
	}
	return ans;
}
int querys(int ll,int rr,int l,int r,int rt){
	int mid,ans=-1e9;
	if(ll<=l&&rr>=r){
		return s[rt];
	}
	mid=(l+r)>>1;
	if(ll<=mid){
		ans=max(ans,querys(ll,rr,l,mid,rt<<1));
	}
	if(rr>mid){
		ans=max(ans,querys(ll,rr,mid+1,r,rt<<1|1));
	}
	return ans;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q,u,y,w,l1,l2,r1,r2,v,sum=0,ui;
	scanf("%d%d%d",&n,&m,&q);
	build1(1,n,1);
	build2(1,m,1);
	while(q--&&++sum){
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		u=queryb(l2,r2,1,m,1);
		v=queryh(l2,r2,1,m,1);
		if(u<0&&v>0){
			if(querys(l1,r1,1,n,1)){
				printf("0\n");
			}
			else{
				y=queryp(l1,r1,1,n,1);
				w=queryq(l1,r1,1,n,1);
				if(y==0){
					printf("%lld\n",(long long)(w)*u);
				}
				else if(w==0){
					printf("%lld\n",(long long)(-y)*queryh(l2,r2,1,m,1));
				}
				else{
					printf("%lld\n",max((long long)(w)*u,(long long)(-y)*v));
				}
			}
		}
		else if(v<0){
			ui=queryf(l1,r1,1,n,1);
			if(ui<0){
				printf("%lld\n",(long long)ui*v);
			}
			else{
				printf("%lld\n",(long long)ui*u);
			}
		}
		else{
			ui=querya(l1,r1,1,n,1);
			if(ui<0){
				printf("%lld\n",(long long)ui*v);
			}
			else{
				printf("%lld\n",(long long)ui*u);
			}
		}
	}
}
