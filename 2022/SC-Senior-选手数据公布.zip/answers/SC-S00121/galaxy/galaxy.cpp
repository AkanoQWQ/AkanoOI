#include<bits/stdc++.h>
using namespace std;
int tot,first[500010],nnext[500010],to[500010],br[500010];
vector<int>fro[500010];
map<int,int>mapp;
void add(int a,int b){
	nnext[++tot]=first[a];
	first[a]=tot;
	to[tot]=b;
	fro[b].push_back(tot);
}
int fan(int p){
	int sum=0;
	for(int e=first[p];e;e=nnext[e]){
		if(!br[e]){
			sum++;
			if(sum>=2){
				return 0;
			}
		}
	}
	if(sum==0){
		return 0;
	}
	if(mapp.count(p)){
		return 1;
	}
	mapp[p]=1;
	return fan(to[first[p]]);
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m,q,a,b,op,u,v,p;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&a,&b);
		add(a,b);
	}
	scanf("%d",&q);
	while(q--){
		p=1;
		scanf("%d%d",&op,&u);
		if(op==1){
			scanf("%d",&v);
			for(int e=first[u];e;e=nnext[e]){
				if(to[e]==v){
					br[e]=1;
					break;
				}
			}
		}
		else if(op==2){
			for(int i=0;i<fro[u].size();i++){
				br[fro[u][i]]=1;
			}
		}
		else if(op==3){
			scanf("%d",&v);
			for(int e=first[u];e;e=nnext[e]){
				if(to[e]==v){
					br[e]=0;
					break;
				}
			}
		}
		else{
			for(int i=0;i<fro[u].size();i++){
				br[fro[u][i]]=0;
			}
		}
		for(int i=1;i<=n;i++){
			mapp.clear();
			if(!fan(i)){
				p=0;
				break;
			}
		}
		printf(p?"YES\n":"NO\n");
	}
}
