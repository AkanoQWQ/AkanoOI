//��������ǿ�� 
#include<bits/stdc++.h>
#define N 100005
#define INF 0x3f3f3f3f
#define ll long long 
using namespace std;
int n,m,q;
int a[N],b[N];
int maxn[N][25][2],minn[N][25][2],mx[N][25][2],mi[N][25][2];
int gmaxn(int l,int r,int k){
	int t=log(r-l+1)/log(2);
	return max(maxn[l][t][k],maxn[r-(1<<t)+1][t][k]);
} 
int gminn(int l,int r,int k){
	int t=log(r-l+1)/log(2);
	return min(minn[l][t][k],minn[r-(1<<t)+1][t][k]);
}
int gmx(int l,int r,int k){
	int t=log(r-l+1)/log(2);
	return max(mx[l][t][k],mx[r-(1<<t)+1][t][k]);
}
int gmi(int l,int r,int k){
	int t=log(r-l+1)/log(2);
	return min(mi[l][t][k],mi[r-(1<<t)+1][t][k]);
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=m;i++) scanf("%d",&b[i]);
	for(int i=1;i<=n;i++) maxn[i][0][0]=minn[i][0][0]=a[i];
	for(int i=1;i<=m;i++) maxn[i][0][1]=b[i],minn[i][0][1]=b[i];
	for(int i=1;i<=n;i++){
		if(a[i]>=0){
			mi[i][0][0]=a[i];//����С 
			mx[i][0][0]=-INF;//����� 
		}
		else{
			mi[i][0][0]=INF;
			mx[i][0][0]=a[i];
		}
	}
	for(int j=1;j<=21;j++){
		for(int i=1;i<=n&&(i+(1<<j)-1)<=n;i++){
			maxn[i][j][0]=max(maxn[i][j-1][0],maxn[i+(1<<(j-1))][j-1][0]);
			minn[i][j][0]=min(minn[i][j-1][0],minn[i+(1<<(j-1))][j-1][0]);
			mi[i][j][0]=min(mi[i][j-1][0],mi[i+(1<<(j-1))][j-1][0]);
			mx[i][j][0]=max(mx[i][j-1][0],mx[i+(1<<(j-1))][j-1][0]); 
		} 
	}
	for(int j=1;j<=21;j++){
		for(int i=1;i<=m&&(i+(1<<j)-1)<=m;i++){
			maxn[i][j][1]=max(maxn[i][j-1][1],maxn[i+(1<<(j-1))][j-1][1]);
			minn[i][j][1]=min(minn[i][j-1][1],minn[i+(1<<(j-1))][j-1][1]);
		}
	} 
//	cout<<"qwq"<<endl;
//	gmi(1,5,0);
	while(q--){
		int l1,r1,l2,r2;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		ll ans=-0x3f3f3f3f3f3f3f3f;
		if(gmaxn(l1,r1,0)>=0){
			if(gminn(l2,r2,1)>=0) ans=max(ans,1ll*gmaxn(l1,r1,0)*gminn(l2,r2,1));
			else ans=max(ans,1ll*gmi(l1,r1,0)*gminn(l2,r2,1));
		}
		if(gminn(l1,r1,0)<0){
			if(gmaxn(l2,r2,1)<0) ans=max(ans,1ll*gminn(l1,r1,0)*gmaxn(l2,r2,1));
			else ans=max(ans,1ll*gmx(l1,r1,0)*gmaxn(l2,r2,1));
		}
		printf("%lld\n",ans);
	}
	
	return 0;
} 
/*
6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3

*/
