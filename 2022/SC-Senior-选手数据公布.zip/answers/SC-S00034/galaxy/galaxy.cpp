#include<bits/stdc++.h>
#define N 500006
#define pii pair<int,int>
#define mp make_pair
#define pb push_back 
using namespace std;
int head[N],idx;
int n,m,q;
struct edge{
	int x,y;
}e[N];
map<pii,int> v;
vector<int> in[N];
bool vis[N];
int deg[N],tot=0;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&e[i].x,&e[i].y);
		v[mp(e[i].x,e[i].y)]=i;
		in[e[i].y].pb(i);
		deg[e[i].x]++;
	}
	for(int i=1;i<=n;i++) if(deg[i]==1) tot++;
	scanf("%d",&q);
	while(q--){
		int t,x,y;
		scanf("%d",&t);
		if(t==1){
			scanf("%d%d",&x,&y);
			int id=v[mp(x,y)];
			deg[x]--;
			if(deg[x]==0) tot--;
			if(deg[x]==1) tot++;
			vis[id]=1;
			
		}
		if(t==2){
			scanf("%d",&x);
			for(int i=0;i<in[x].size();i++){
				if(!vis[in[x][i]]){
					vis[in[x][i]]=1;
					deg[e[in[x][i]].x]--;
					if(deg[e[in[x][i]].x]==0) tot--;
					if(deg[e[in[x][i]].x]==1) tot++;
				}
			}
		} 
		if(t==3){
			scanf("%d%d",&x,&y);
			int id=v[mp(x,y)];
			deg[x]++;
			if(deg[x]==2) tot--;
			if(deg[x]==1) tot++;
			vis[id]=0;
		}
		if(t==4){
			scanf("%d",&x);
			for(int i=0;i<in[x].size();i++){
				if(vis[in[x][i]]){
					vis[in[x][i]]=0;
					deg[e[in[x][i]].x]++;
					if(deg[e[in[x][i]].x]==2) tot--;
					if(deg[e[in[x][i]].x]==1) tot++;
				}
			}
		}
		//cout<<tot<<endl;
		if(tot==n) puts("YES");
		else puts("NO");
		
	}
	
	return 0;
}
/*
3 6
2 3
2 1
1 2
1 3
3 1
3 2
11
1 3 2
1 2 3
1 1 3
1 1 2
3 1 3
3 3 2
2 3
1 3 1
3 1 3
4 2
1 3 2
*/
