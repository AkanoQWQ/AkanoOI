#include<bits/stdc++.h>
#define N 2505
#define pb push_back
#define ll long long 
using namespace std;
int n,m,k;
int head[N],idx;
struct edge{
	int v,next;
}e[N<<1];
void add(int u,int v){
	e[++idx].v=v;
	e[idx].next=head[u];
	head[u]=idx;
}
bool g[N][N];
struct node{
	ll m,v;
}p[N][4];
ll w[N];
bool cmp(node x,node y){
	if(x.m!=y.m)return x.m>y.m;
	return x.v<y.v;
}
int dis[N],vis[N];
void bfs(int s){
	memset(dis,0,sizeof(dis));
	memset(vis,0,sizeof(vis));
	queue<int> q;q.push(s);
	vis[s]=1;
 	while(!q.empty()){
 		int x=q.front();q.pop();
		for(int i=head[x];i;i=e[i].next){
			int y=e[i].v;
			if(vis[y]) continue;
			dis[y]=dis[x]+1;
			vis[y]=1;
			g[s][y]=1;
			if(dis[y]<k) q.push(y); 
		}
	}
} 
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	k++;
	for(int i=2;i<=n;i++) scanf("%lld",&w[i]);
	for(int i=1;i<=m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
		add(v,u);
	} 
	for(int i=1;i<=n;i++) bfs(i);
	for(int i=1;i<=n;i++){
		p[i][0].m=p[i][0].v=p[i][1].m=p[i][1].v=p[i][2].m=p[i][2].v=0;
		for(int j=1;j<=n;j++){
			if(i==j||!g[i][j]||!g[1][j]) continue;
			p[i][3].m=w[j];
			p[i][3].v=j;
			sort(p[i],p[i]+4,cmp);
		}
	}
	ll ans=0;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(i==j||!g[i][j]) continue;
			for(int a=0;a<=2;a++){
				for(int b=0;b<=2;b++){
					if(p[i][a].v!=j&&p[i][a].v!=p[j][b].v&&p[j][b].v!=i&&p[i][a].v!=0&&p[j][b].v!=0){
					//	if(w[i]+w[j]+p[i][a].m+p[j][b].m==8) cout<<p[i][a].v<<' '<<i<<' '<<j<<' '<<p[j][b].v<<endl;
						ans=max(ans,w[i]+w[j]+p[i][a].m+p[j][b].m);
					}
				}
			}
		}
	}

	cout<<ans<<endl;
	return 0;
} 
/*
7 9 0
1 1 1 2 3 4
1 2
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4

*/
