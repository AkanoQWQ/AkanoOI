#include<bits/stdc++.h>
#define N 200005
#define ll long long 
using namespace std;
int n,k,q;
int head[N],idx;
struct edge{
	int v,next;
}e[N<<1];
void add(int u,int v){
	e[++idx].v=v;
	e[idx].next=head[u];
	head[u]=idx;
} 
ll w[N];
int fa[N][25],dep[N];
ll sum[N];
void dfs(int x,int f){
	fa[x][0]=f;dep[x]=dep[f]+1;
	sum[x]=sum[f]+w[x];
	for(int i=1;i<=21;i++) fa[x][i]=fa[fa[x][i-1]][i-1];
	for(int i=head[x];i;i=e[i].next){
		int y=e[i].v;
		if(y==f) continue;
		dfs(y,x); 
	}
}
int lca(int x,int y){
	if(dep[x]<dep[y]) swap(x,y);
	for(int i=21;i>=0;i--) if(dep[fa[x][i]]>=dep[y]) x=fa[x][i];
	if(x==y) return x;
	for(int i=21;i>=0;i--) if(fa[x][i]!=fa[y][i]) x=fa[x][i],y=fa[y][i];
	return fa[x][0];
}
ll f[N];
int a[N],len,vis[N];
ll dp(){
	f[1]=w[a[1]];
	for(int i=2;i<=len;i++){
		f[i]=0x3f3f3f3f3f3f3f3f;
		for(int j=1;j<=k;j++){
			if(i-j>0)f[i]=min(f[i],f[i-j]);
		}
		f[i]+=w[a[i]];
	}
	return f[len];
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++) scanf("%d",&w[i]);
	for(int i=1;i<n;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
		add(v,u);
	}
	dfs(1,0);
	while(q--){
		int x,y;
		if(k==1){
			scanf("%d%d",&x,&y);
			int z=lca(x,y);
			printf("%lld\n",sum[x]+sum[y]-sum[z]-sum[fa[z][0]]);
		}
		else{
			memset(vis,0,sizeof(vis));
			scanf("%d%d",&x,&y);
			int z=lca(x,y);
			len=0;
			while(x!=z){
				a[++len]=x;
				x=fa[x][0];
			}
			a[++len]=z;
			len+=dep[y]-dep[z];
			int t=len;
			while(y!=z){
				a[t]=y;
				t--;
				y=fa[y][0];
			}
			printf("%lld\n",dp());
		}
	}
	return 0;
}
/*
10 10 3
835701672 912572995 368308854 156367225 251245604 788978650 385396264 960190423 51944511 479806606
2 1
3 2
4 2
5 3
6 3
7 2
8 7
9 1
10 9
1 7
1 5
2 1
1 9
10 5
3 10
2 9
10 2
1 4
4 7
*/
