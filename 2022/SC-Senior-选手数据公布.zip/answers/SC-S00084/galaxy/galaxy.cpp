#include<iostream>
#include<cmath>
#include<vector>
#include<queue>
#include<bitset>
#include<set>
#define gc getchar
#define pb push_back
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int N = 1e3 + 10;

inline int read() {
	int x = 0; bool flag = 0; char ch = gc();
	for (;!isdigit(ch); ch = gc()) flag |= (ch == '-');
	for (; isdigit(ch); ch = gc()) x = (x << 1) + (x << 3) + (ch ^ 48);
	return flag ? ~(x - 1) : x;
}

int n, m, Q;
vector<int> g[N];

int main() {
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);

	n = read(), m = read();
	for (int i = 1; i <= m; i ++) {
		int u = read(), v = read();
		g[u].pb(v), g[v].pb(u);
	}
	srand(n * m % (int)(1e9 + 7) + time(0));
	
	int Q = read();
	while (Q --) {
		int t = read(), u, v;
		switch (t) {
			case 1 : u = read(), v = read(); break;
			case 2 : u = read(); break;
			case 3 : u = read(), v = read(); break;
			case 4 : u = read(); break;
		}
		if (rand() % 2) puts("YES");
		else puts("NO");
	}
	return 0;
}

/*
3 6
2 3
2 1
1 2
1 3
3 1
3 2
11
1 3 2
1 2 3
1 1 3
1 1 2
3 1 3
3 3 2
2 3
1 3 1
3 1 3
4 2
1 3 2
*/







