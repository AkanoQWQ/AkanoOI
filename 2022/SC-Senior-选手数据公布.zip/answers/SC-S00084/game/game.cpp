#include<iostream>
#include<cmath>
#include<vector>
#include<queue>
#include<bitset>
#include<set>
#define gc getchar
#define pb push_back
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int N = 1e3 + 10;

inline int read() {
	int x = 0; bool flag = 0; char ch = gc();
	for (;!isdigit(ch); ch = gc()) flag |= (ch == '-');
	for (; isdigit(ch); ch = gc()) x = (x << 1) + (x << 3) + (ch ^ 48);
	return flag ? ~(x - 1) : x;
}

int n, m, Q, is, cur;
int a[N], b[N];
ll c[2][N][N];

inline void mini(ll &x, ll y) {x = min(x, y);}
inline void maxi(ll &x, ll y) {x = max(x, y);}

namespace Segment {
	struct tree {
		int l, r;
		ll val, dat;
		
		#define l(p) tr[is][cur][p].l
		#define r(p) tr[is][cur][p].r
		#define val(p) tr[is][cur][p].val
		#define dat(p) tr[is][cur][p].dat
		
		inline tree operator + (const tree &x) {
			tree res;
			res.l = min(l, x.l), res.r = max(r, x.r);
			res.val = min(val, x.val), res.dat = max(dat, x.dat);
			return res;
		}
	} tr[2][N][N << 2];
	
	inline void pushup(int p) {
		#define ls p << 1
		#define rs p << 1 | 1
		mini(val(p), min(val(ls), val(rs)));
		maxi(dat(p), max(dat(ls), dat(rs)));
	}
	
	inline void build(int p, int l, int r) {
		tr[is][cur][p] = {l, r, c[is][cur][l], c[is][cur][l]};
		if (l == r) return ;
		
		int mid = l + r >> 1;
		build(ls, l, mid), build(rs, mid + 1, r);
		pushup(p);
	}
	
	inline tree query(int p, int l, int r) {
		if (l(p) >= l && r(p) <= r) return tr[is][cur][p];
		
		tree res;
		int mid = l(p) + r(p) >> 1;
		if (l <= mid) res = res + query(ls, l, r);
		if (r > mid) res = res + query(rs, l, r);
		return res;
	}
}

inline ll score(int l1, int r1, int l2, int r2) {
	using namespace Segment;
	int x = 0, y = 0;
	ll res[2] = {LLONG_MIN, LLONG_MAX};
	
	for (cur = l1, is = 0; cur <= r1; cur ++) {
		ll t = query(1, l2, r2).val;
		if (res[0] < t) res[0] = t, x = cur;
	}
	for (cur = l2, is = 1; cur <= r2; cur ++) {
		ll t = query(1, l1, r1).dat;
		if (res[1] > t) res[1] = t, y = cur;
	}
//	printf("%d %d: \n", x, y);
	return c[0][x][y];
}

int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);

	n = read(), m = read(), Q = read();
	for (int i = 1; i <= n; i ++) a[i] = read();
	for (int i = 1; i <= m; i ++) b[i] = read();
	for (int i = 1; i <= n; i ++)
		for (int j = 1; j <= m; j ++)
			c[0][i][j] = c[1][j][i] = 1ll * a[i] * b[j];
	for (cur = 1, is = 0; cur <= n; cur ++) Segment::build(1, 1, m);
	for (cur = 1, is = 1; cur <= m; cur ++) Segment::build(1, 1, n);
//	for (cur = 1, is = 0; cur <= n; cur ++) {
//		for (int j = 1; j <= m; j ++) printf("%d ", Segment::query(1, j, j).val);
//		puts("");
//	}
		
	while (Q --) {
		int l1 = read(), r1 = read(), l2 = read(), r2 = read();
		printf("%lld\n", score(l1, r1, l2, r2));
	}
	return 0;
}

/*
3 2 2
0 1 �\2
�\3 4
1 3 1 2
2 3 2 2
*/







