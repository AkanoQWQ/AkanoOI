#include<iostream>
#include<cmath>
#include<vector>
#include<queue>
#include<bitset>
#include<set>
#define gc getchar
#define pb push_back
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int N = 2.5e3 + 10;

inline int read() {
	int x = 0; bool flag = 0; char ch = gc();
	for (;!isdigit(ch); ch = gc()) flag |= (ch == '-');
	for (; isdigit(ch); ch = gc()) x = (x << 1) + (x << 3) + (ch ^ 48);
	return flag ? ~(x - 1) : x;
}

int n, m, k, idx;
int a[N], dis[N][N];
vector<int> g[N];
bitset<N> vis;

inline void path(int src) {
	vis.reset(); dis[src][src] = 0;
	priority_queue<pii> q; q.push({0, src});
	
	while (!q.empty()) {
		int u = q.top().second; q.pop();
		if (vis[u]) continue; vis[u] = 1;
		for (int v : g[u]) {
			if (vis[v]) continue;
			if (dis[src][v] > dis[src][u] + 1) {
				dis[src][v] = dis[src][u] + 1;
				q.push({-dis[src][v], v});
			}
		}
	}
}

inline int find() {
	int ans = 0;
	queue<pii> q[N], A, D, tmp, tmpp;
	for (int u = 2; u <= n; u ++) {
		if (dis[1][u] > k + 1) continue;
		A.push({a[u], u}); D.push({a[u], u});
	}
	
	while (!A.empty()) {
		int u = A.front().second; A.pop();
		for (int v = 2; v <= n; v ++) {
			if (u == v || dis[u][v] > k + 1) continue;
			q[u].push({a[v], v});
		}
	}
	
	A = D; D.pop();
	while (!A.empty()) {
		int u = A.front().second; A.pop();
		while (!D.empty()) {
			int v = D.front().second; D.pop();
			if (v == u) continue;
			if (dis[u][v] > 3 * (k + 1)) continue;
			tmpp = q[u];
			while (!q[u].empty()) {
				int x = q[u].front().second; q[u].pop();
				if (x == v || x == u) continue;
				tmp = q[v];
				while (!q[v].empty()) {
					int y = q[v].front().second; q[v].pop();
					if (y == x || y == v || y == u) continue;
					if (dis[x][y] > k + 1) continue;
					ans = max(ans, a[u] + a[x] + a[y] + a[v]);
				}
				q[v] = tmp;
			}
			q[u] = tmpp;
		}
		D = A; D.pop();
	}
	return ans;
}

int main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	
	n = read(), m = read(), k = read();
	for (int i = 2; i <= n; i ++) a[i] = read();
	for (int i = 1; i <= m; i ++) {
		int u = read(), v = read();
		g[u].pb(v), g[v].pb(u);
	}
	memset(dis, 0x3f, sizeof dis);
	for (int i = 1; i <= n; i ++) path(i);
	printf("%d\n", find());
	return 0;
}

/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1
*/


















