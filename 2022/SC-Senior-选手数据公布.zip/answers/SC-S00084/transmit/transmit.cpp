#include<iostream>
#include<cmath>
#include<vector>
#include<queue>
#include<bitset>
#include<set>
#define gc getchar
#define pb push_back
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
const int N = 1e3 + 10;

inline int read() {
	int x = 0; bool flag = 0; char ch = gc();
	for (;!isdigit(ch); ch = gc()) flag |= (ch == '-');
	for (; isdigit(ch); ch = gc()) x = (x << 1) + (x << 3) + (ch ^ 48);
	return flag ? ~(x - 1) : x;
}

int n, Q, k;
int v[N], fa[N], dis[N];
vector<int> g[N];

namespace cut {
	int son[N], siz[N], top[N];
	inline void dfs1(int u, int f) {
		fa[u] = f, siz[u] = 1;
		dis[u] = dis[f] + 1;
		
		for (int v : g[u]) {
			if (v == f) continue;
			dfs1(v, u);
			siz[u] += siz[v];
			if (siz[son[u]] < siz[v]) son[u] = v;
		}
	}
	
	inline void dfs2(int u, int tp) {
		top[u] = tp;
		if (!son[u]) return ;
		dfs2(son[u], tp);
		
		for (int v : g[u]) {
			if (v == son[u] || v == fa[u]) continue;
			dfs2(v, v);
		}
	}
	inline void cutting() {dfs1(1, 0); dfs2(1, 1);}
	
	inline int lca(int u, int v) {
		while (top[u] != top[v]) {
			if (dis[top[u]] < dis[top[v]]) swap(u, v);
			u = fa[top[u]];
		}
		if (dis[u] < dis[v]) return u;
		return v;
	}
}

inline int dist(int u, int v) {
	int lca = cut::lca(u, v);
	return dis[u] + dis[v] - dis[lca] * 2;
}

vector<int> vec, tmp;
inline bool dfs(int u, int aim) {
	if (u == aim) return vec.pb(u), 1;
	for (int v : g[u]) {
		if (v == fa[u]) continue;
		if (dfs(v, aim)) return vec.pb(u), 1;
	}
	return 0;
}

inline int calc(int len) {
	int S = 1 << len; ll ans = LLONG_MAX;
	for (int s = 1 << len - 1; s < S; s ++) {
		if (!(s & 1)) continue;
		bool flag = 1; ll res = 0;
		for (int i = 0, lst = 0; i < len; i ++) {
			if (!(s >> i & 1)) continue;
			if (dist(lst, tmp[i]) > k) {flag = 0; break;}
			lst = tmp[i]; res += v[tmp[i]];
		}
		if (flag) ans = min(ans, res);
	}
	return ans;
}

inline void solve(int s, int t) {
	int lca = cut::lca(s, t); ll ans = 0;
	dfs(lca, s); tmp = vec; vec.clear();
	dfs(lca, t);
	for (int i = vec.size() - 1; ~i; i --) tmp.pb(vec[i]);
	
	int len = tmp.size();
	if (tmp.size() <= 25) ans = calc(len);
	else for (int i = 0, j = len - 1; i < j; i ++)
		if (i % k == 0) ans += v[i] + v[j];
	printf("%lld\n", ans);
}

int main() {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);

	n = read(), Q = read(), k = read();
	for (int i = 1; i <= n; i ++) v[i] = read();
	for (int i = 1; i < n; i ++) {
		int u = read(), v = read();
		g[u].pb(v), g[v].pb(u);
	}
	cut::cutting();
	while (Q --) {
		int s = read(), t = read();
		if (dist(s, t) <= k) printf("%lld\n", v[s] + v[t]);
		else solve(s, t);
	}
	return 0;
}

/*
7 3 3
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7
4 7
5 6
1 2
*/







