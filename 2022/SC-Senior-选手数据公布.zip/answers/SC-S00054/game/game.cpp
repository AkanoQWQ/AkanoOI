#include<bits/stdc++.h>
#define voidDing void
#define int long long
using namespace std;
typedef long long xt;
const int N = 3e5+10;
int n, m, q;
int a[N], b[N], za[N], zb[N];
int ab(int x) {
	return x>0?x:-x;
}
struct st {
	int n, t;
	int f[N][18];
	int g[N][18];
	int h[N][18];
	int o[N][18];
	int lg[N];
	void init(int lth, int *a) {
		n = lth;
		lg[1] = 0;
		for(int i=2; i<=n; ++i) { lg[i] = lg[i>>1] + 1; }
		for(int i=1; i<=n; ++i) { f[i][0] = g[i][0] = a[i]; }
		for(int i=1; i<=n; ++i) {
			o[i][0] = a[i] <= 0? a[i]: 1e9;
			h[i][0] = a[i] >= 0? a[i]:-1e9;
		}
		t = lg[n];
		int r;
		for(int j=1; j<=t; ++j) {
			for(int i=1; i<=n-(1<<j)+1; ++i) {
				r = i + (1<<j) - 1;
				if(r > n) break;
				f[i][j] = max(f[i][j-1], f[i+(1<<(j-1))][j-1]);
				g[i][j] = min(g[i][j-1], g[i+(1<<(j-1))][j-1]);
				if(ab(h[i][j-1]) < ab(h[i+(1<<(j-1))][j-1]) || (ab(h[i][j-1]) == ab(h[i+(1<<(j-1))][j-1]) && h[i][j-1] > 0)) {
					h[i][j] = h[i][j-1];
				} else h[i][j] = h[i+(1<<(j-1))][j-1];
				if(ab(o[i][j-1]) < ab(o[i+(1<<(j-1))][j-1]) || (ab(o[i][j-1]) == ab(o[i+(1<<(j-1))][j-1]) && o[i][j-1] < 0)) {
					o[i][j] = o[i][j-1];
				} else o[i][j] = o[i+(1<<(j-1))][j-1];
			}
		}
		return;
	}
	int iqf(int l, int r) {
		int h = lg[(r-l+1)];
		return max(f[l][h], f[r-(1<<h)+1][h]);
	}
	int iqg(int l, int r) {
		int h = lg[(r-l+1)];
		return min(g[l][h], g[r-(1<<h)+1][h]);
	}
	int iqo(int l, int r) {
		int k = lg[(r-l+1)];
		if(ab(o[l][k]) < ab(o[r-(1<<k)+1][k]) || (ab(o[l][k]) == ab(o[r-(1<<k)+1][k]) && o[l][k] < 0)) {
			return o[l][k];
		} else return o[r-(1<<k)+1][k];
	}
	int iqh(int l, int r) {
		int o = lg[(r-l+1)];
		if(ab(h[l][o]) < ab(h[r-(1<<o)+1][o])|| (ab(h[l][o]) == ab(h[r-(1<<o)+1][o]) && h[l][o] > 0)) {
			return h[l][o];
		} else return h[r-(1<<o)+1][o];
	}
}A, B;
signed main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	scanf("%lld%lld%lld", &n, &m, &q);
	for(int i=1; i<=n; ++i) scanf("%lld", a+i), za[i] = za[i-1] + bool(a[i] == 0);
	for(int i=1; i<=m; ++i) scanf("%lld", b+i), zb[i] = zb[i-1] + bool(a[i] == 0);

	A.init(n, a); B.init(m, b);
	int x, y, l, r, tmp, ans1, ans2, i=0;
	while(q--) { ++i;
		scanf("%lld%lld%lld%lld", &x, &y, &l, &r);
		if(B.iqf(l, r) <= 0) {
			printf("%lld\n", A.iqg(x, y) * B.iqf(l, r));
		}
		else if(B.iqg(l, r) >= 0) {
			printf("%lld\n", A.iqf(x, y) * B.iqg(l, r));
		} else {
			tmp = A.iqh(x, y);
			if(tmp > 0) {
				ans1 = tmp * B.iqg(l, r);
			} else {
				ans1 = tmp * B.iqf(l, r);
			}
			tmp = A.iqo(x, y);
			if(tmp > 0) {
				ans2 = tmp * B.iqg(l, r);
			} else {
				ans2 = tmp * B.iqf(l, r);
			}
			printf("%lld\n", max(ans1, ans2));

		}
	}
	return 0;
}

