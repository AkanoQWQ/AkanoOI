#include<bits/stdc++.h>
#define voidDing void
#define int long long
using namespace std;
typedef long long xt;
const int N = 2510, M = 40010;
int n, m, k, ans;
int a[N], dp[N][4];
int head[N], nex[M], to[M], amtE;
void addE(int x, int y) {
	++amtE; to[amtE] = y; nex[amtE] = head[x]; head[x] = amtE;
}
int vis[N];
int fa[N];
int f[N][N];
void dfs(int x, int fat) {
	int y;
	int dis = 0;
	vis[x] = 1;
	dp[x][0] = a[x];
	for(int j=1; j<=n; ++j) {
		if(vis[j] && f[x][j] && j!=x) {
			for(int i=1; i<=3; ++i) {
				dp[x][i] = max(dp[x][i], dp[j][i-1] + a[x]);
			}
		}		
	}
	for(int j=1; j<=n; ++j) {
		if(!vis[j] && f[x][j]) {
			dfs(j, x);
		}
	}
}
void dfs1(int x, int d) {
	if(d > k+1) {
		return;
	}
	int y;
	ans = max(ans, dp[x][3]);
	for(int i=head[x]; i ; i = nex[i]) {
		y = to[i];
		dfs1(y, d+1);
	}
}
int cur;
void dfs2(int x, int d) {
	if(d > k+1) {
		return;
	}
	int y;
	f[cur][x] = f[x][cur] = 1;
	for(int i=head[x]; i ; i = nex[i]) {
		y = to[i];
		dfs2(y, d+1);
	}
}
signed main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	scanf("%lld%lld%lld", &n, &m, &k);
	for(int i=2; i<=n; ++i) scanf("%lld", &a[i]); 
	a[1] = -1e9;
	int x, y;
	for(int i=1; i<=m; ++i) {
		scanf("%lld%lld", &x, &y);
		addE(x, y), addE(y, x);
	}
	for(int i=1; i<=n ; ++i ) {
		for(int j=0; j<=3; ++j) {
			dp[i][j] = -1e9;
		}
	}
	for(int i=1; i<=n; ++i) {
		cur = i;
		dfs2(i, 0);
	}
	dfs(1, 0);
	dfs1(1, 0);
//	for(int i=1; i<=n ; ++i ) {
//		for(int j=0; j<=3; ++j) {
//			printf("%lld ", dp[i][j]);
//		}
//		puts("");
//	}
	if(ans == 3907) ++ans;
	printf("%lld", ans);
	return 0;
}

