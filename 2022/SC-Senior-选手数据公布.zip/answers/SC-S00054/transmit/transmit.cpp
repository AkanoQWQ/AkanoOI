#include<bits/stdc++.h>
#define voidDing void
#define int long long
using namespace std;
typedef long long xt;
const int N = 2e3+10;
int n, q, k;
int v[N];
int f[N][N], g[N][N];
signed main() {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	int x, y;
	scanf("%lld%lld%lld", &n, &q, &k);
	for(int i=1; i<=n; ++i) {
		scanf("%lld", &v[i]);
	}
	for(int i=1; i<=n; ++i) {
		for(int j=1; j<=n; ++j) {
			f[i][j] = +1e17;
			g[i][j] = +1e17;
		}
	}
	for(int i=1; i<=n-1; ++i) {
		scanf("%lld%lld", &x, &y);
		f[y][x] = f[x][y] = 1; g[y][x] = g[x][y] = v[x] + v[y];
	}
	for(int k=1; k<=n; ++k) {
		for(int i=1; i<=n; ++i) {
			for(int j=1; j<=n; ++j) {
				f[i][j] = min(f[i][j], f[i][k]+f[k][j]);
			}
		}
	}
	for(int i=1; i<=n; ++i) {
		for(int j=1; j<=n; ++j) {
			if(f[i][j] <= k) {
				g[i][j] = min(g[i][j], v[i] + v[j]);
			}
		}
	}
	for(int ke=1; ke<=n; ++ke) {
		for(int i=1; i<=n; ++i) {
			for(int j=1; j<=n; ++j) {
				if(i!=j && j!=ke && i!=ke) {
					g[i][j] = min(g[i][j], g[i][ke] + g[ke][j] - v[ke]);
				}
			}
		}
	}
	
	for(int i=1; i<=q; ++i) {
		scanf("%lld%lld", &x, &y);
		printf("%lld\n", g[x][y]);
	}
	return 0;
}

