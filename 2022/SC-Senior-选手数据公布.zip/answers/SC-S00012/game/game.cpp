#include <bits/stdc++.h>
using namespace std;

int const MAXN = 1e5+10;

int n,m,q;
int l1,r1,l2,r2;
int a1,b1;
int a[MAXN];
int b[MAXN];
int ans;

bool allz(int l,int r,int num[]){
	for(int i = l;i<=r;l++) if(num[i]<0) return 0;
	return 1;
}
bool allf(int l,int r,int num[]){
	for(int i = 1;i<=r;l++) if(num[i]) return 0;
	return 1;
}

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	
	cin >> n >> m >> q;
	for(int i = 1;i<=n;i++){
		cin >> a[i];
	}
	for(int j = 1;j<=m;j++){
		cin >> b[j];
	}
	while(q--){
		 cin >> l1 >> r1 >> l2 >> r2;
		 ans = 0;
		 if(l1==r1){
		 	a1 = a[l1];
		 	b1=b[l2];
		 	for(int i = l2+1;i<=r2;i++) b1 = min(b1,b[i]);
		 	cout << a1*b1 << endl;
		 	continue;
		 }else if(l2==r2){
		 	b1=b[l2];
		 	a1=a[l1];
		 	for(int i = l1+1;i<=r1;i++) a1 = max(a1,a[i]);
		 	cout << a1*b1 << endl;
		 	continue;
		 }else if(allz(l2,r2,b)){
		 	a1 = a[l1];
		 	for(int i = l1+1;i<=r1;i++) a1 = max(a1,a[i]);
		 	b1 = b[l2];
		 	for(int i = l2+1;i<=r2;i++) b1 = min(b1,b[i]);
		 	cout << a1*b1 << endl;
		 	continue;
		 }else if(allf(l2,r2,b)){
		 	a1=a[l1];
		 	for(int i = l1+1;i<=r1;i++) a1 = min(a1,a[i]);
		 	b1 = b[l2];
		 	for(int i =l2+1;i<=r2;i++) b1 = max(b1,b[i]);
		 	cout << a1*b1 << endl;
		 	continue;
		 }else {
		 	a1=0;
		 	for(int i = l1;i<=r1;i++) if(a[i]) a1 = min(a1,a[i]);
		 	b1=0;
		 	for(int i = l2;i<=r2;i++) if(b[i]<0) b1 = max(b1,b[i]);
		 	cout << a1*b1 << endl;
		 	continue;
		 }
	}
	
}
