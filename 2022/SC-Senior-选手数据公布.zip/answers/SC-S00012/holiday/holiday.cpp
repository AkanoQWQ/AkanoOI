#include <bits/stdc++.h>
using namespace std;

int const MAXN = 2510;
int const MAXM = 10000+10;

int n;//duo shao ge dian
int m;//duo shao tiao bian
int k;//zui duo zhuan xiang ci shu
int a,b;
int cnt=0;
int p[MAXN];//ji lu jing dian fen shu
int fi[MAXM];
int ans;
int c[MAXM][MAXM];
struct cr{
	int from;
	int to;//dao na li
	int nx;//shang yi tiao bian
}h[MAXM];

void pr(int fromm,int too){
	cnt++;
	h[cnt].from = fromm;
	h[cnt].to = too;
	h[cnt].nx = fi[a];
	fi[a] = cnt;
	c[fromm][too] = 1; 
	c[too][fromm] = 1;
}


int dfs(int l,int cal){
	cal++;
	int tot=0;
	if(cal==3){
		for(int i = l+1;i<=n;i++){
			if(c[i][1]&&c[l][i]) tot = max(tot,p[i]);
		}
		return tot;
	}
		
	for(int i = l+1;i<=n;i++){
		if(c[l][i]){
			tot = max(p[i] + dfs(i,cal),tot);
		}
	}
	return tot;
}

int main(){
	freopen("holiday.in","r",stdin);
//	freopen("holiday.out","w",stdout);
	
	cin >> n >> m >> k;
	p[1] = 0;
	for(int i = 2;i<=n;i++){
		cin >> p[i];
	}
	
	for(int i = 1;i<=m;i++){
		cin >> a >> b;
		pr(a,b);		
	}
	
	for(int i = 1;i<=n;i++){
		for(int j = 1;j<=n;j++){
			if(c[i][j]!=0) continue;
			if(i==j) continue;
			int tmp = 0;
			int xx = j;
			int yy = i;
			if(i<j){
				xx = i;
				yy = j;
			}
			for(int p = fi[xx];h[p].to!=yy;p = h[p].nx) tmp++;
			if(tmp>k+1){
				c[i][j] = -1;
			}
			else{
				c[i][j] = 1;
			}
		} 
	}
	
	int cal=1;
	for(int i = 1;i<=n;i++){
		if(c[1][i]) ans = max(ans,p[i]+dfs(i,cal));
	}
	
	cout << ans;
	
}
