#include <bits/stdc++.h>
using namespace std;

int n,m;
int u,v;
int q;
int t,a,b;

int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin >> n >> m;
	cin >> u >> v;
	cin >> q;
	while(q--){
		cin >> t;
		if(t==1) cin >>a >> b;
		else cin >> a;
		cout << "NO" << endl;
	}
}
