#include <bits/stdc++.h>
typedef long long ll;
#define E(i, l, r) for (int i = l; i <= r; ++ i)
const int N = 5e5 + 5, N1 = 1e3 + 5, M1 = 1e4 + 5;
int n, m, q;
int dist[N1][N1], out[N], f[N1], t[N1];
std::vector<int> T[N1];
bool dfs(int cur) {
	t[cur] = 1;
	E(i, 0, (int)T[cur].size() - 1) {
		int go = T[cur][i];
		if (dist[cur][go] != 1) continue;
		if (t[go] == 1) {
			f[cur] = 1;
			continue;
		}
		f[cur] |= dfs(go); 
	}
	return f[cur];
}
int main() {
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	scanf("%d%d", &n, &m);
	E(i, 1, m) {
		int x, y; scanf("%d%d", &x, &y);
		dist[x][y] = 1;
		T[x].push_back(y); ++ out[x];
	}
	scanf("%d", &q);
	while (q --) {
		int pos; scanf("%d", &pos);
		if (pos == 1) {
			int x, y; scanf("%d%d", &x, &y);
			dist[x][y] = 2;
			-- out[x];
		}
		else if (pos == 2) {
			int x; scanf("%d", &x);
			E(i, 1, n)
				if (dist[i][x] == 1) {
					dist[i][x] = 2;
					-- out[i];
				}
		}
		else if (pos == 3) {
			int x, y; scanf("%d%d", &x, &y);
			dist[x][y] = 1;
			++ out[x];
		}
		else {
			int x; scanf("%d", &x);
			E(i, 1, n)
				if (dist[i][x] == 2) {
					dist[i][x] = 1;
					++ out[i];
				}
		}
		memset(f, 0, sizeof f);
		memset(t, 0, sizeof t);
		E(i, 1, n)
			if (!t[i])
				dfs(i);
		bool flag = 0;
		E(i, 1, n)
			if (out[i] != 1 || f[i] == 0) {
				flag = 1;
				break;
			}
		if (!flag) printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
//I'm Nahida's dog!
//If I get tg1=, Kaka'll wear Lolita 114514times!(Kaka is not me actually)
//Perhaps I will be involved in moral dilemma... 
