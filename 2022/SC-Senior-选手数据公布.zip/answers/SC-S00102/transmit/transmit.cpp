#include <bits/stdc++.h>
typedef long long ll;
#define E(i, l, r) for (int i = l; i <= r; ++ i)
const int N = 2e5 + 5;
int n, q, k, dep[N], fat[N];
ll w[N], f[N][2], mins[N];
int way[N], cnt;
int h[N], e[N * 2], ne[N * 2], idx;
std::deque<int> Q1, Q2;
void dfs(int cur, int fa) {
	mins[cur] = 1e15;
	fat[cur] = fa;
	dep[cur] = dep[fa] + 1;
	for (int i = h[cur]; ~i; i = ne[i]) {
		int go = e[i];
		if (go == fa) continue;
		dfs(go, cur);
		mins[cur] = std::min(mins[cur], w[go]);
	}
}
void add(int x, int y) {
	ne[idx] = h[x];
	e[idx] = y;
	h[x] = idx ++;
} 
int main() {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	scanf("%d%d%d", &n, &q, &k);
	memset(h, -1, sizeof h);
	E(i, 1, n) scanf("%lld", w + i);
	E(i, 1, n - 1) {
		int x, y; scanf("%d%d", &x, &y);
		add(x, y); add(y, x);
	}
	dfs(1, 0);
	while (q --) {
		int x, y; scanf("%d%d", &x, &y);
		while (x != y) {
			if (dep[x] > dep[y]) {
				Q1.push_back(x);
				x = fat[x];
			}
			else {
				Q2.push_front(y);
				y = fat[y];
			}
		}
		cnt = 0;
		while (!Q1.empty()) {
			way[++ cnt] = Q1.front();
			Q1.pop_front();
		} way[++ cnt] = x;
		while (!Q2.empty()) {
			way[++ cnt] = Q2.front();
			Q2.pop_front();
		}
		f[1][0] = w[way[1]];
		f[1][1] = 1e15;
		E(i, 2, cnt) {
			f[i][0] = f[i][1] = 1e15;
			E(j, std::max(1, i - k), i - 1) {
				f[i][0] = std::min(f[i][0], f[j][0] + w[way[i]]);
				if (j == i - 2 && k == 3) {
					f[i][0] = std::min(f[i][0], f[j][1] + w[way[i]]);
					f[i][1] = f[j][0] + mins[way[i]];
				}
			}	
		}
		printf("%lld\n", f[cnt][0]);
	}
	return 0;
}
//I'm Nahida's dog!
//If I get tg1=, Kaka'll wear Lolita 114514times!(Kaka is not me actually)
//Perhaps I will be involved in moral dilemma... 
