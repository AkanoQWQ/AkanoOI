#include <bits/stdc++.h>
typedef long long ll;
#define E(i, l, r) for (int i = l; i <= r; ++ i)
const int N = 2505, M = 1e4 + 5;
struct Node {
	int id, dis;
	friend bool operator < (Node x, Node y) {
		return x.dis > y.dis;
	}
};
struct State {
	int id; ll dis;
	State() {
		id = dis = 0;
	}
	friend bool operator < (State x, State y) {
		return x.dis > y.dis;
	}
};
int n, m, k;
ll w[N], ans;
State ban[N][3], banH[N][3];
bool t[N];
int dist[N][N];
int h[N], e[M * 2], ne[M * 2], idx;
void add(int x, int y) {
	ne[idx] = h[x];
	e[idx] = y;
	h[x] = idx ++;
}
void dijkstra(int x) {
	memset(t, 0, sizeof t);
	std::priority_queue<Node> Q;
	E(i, 1, n) dist[x][i] = 1e9;
	dist[x][x] = 0; Q.push({.id = x, .dis = 0});
	while (!Q.empty()) {
		Node cur = Q.top(); Q.pop();
		if (t[cur.id]) continue;
		t[cur.id] = 1;
		for (int i = h[cur.id]; ~i; i = ne[i]) {
			int go = e[i];
			if (dist[x][go] > dist[x][cur.id] + 1) {
				dist[x][go] = dist[x][cur.id] + 1;
				Q.push({.id = go, .dis = dist[x][go]}); 
			}
		}
	}
}
int main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	memset(h, -1, sizeof h);
	E(i, 2, n) scanf("%lld", w + i);
	E(i, 1, m) {
		int x, y; scanf("%d%d", &x, &y);
		add(x, y); add(y, x);
	}
	E(i, 1, n)
		dijkstra(i);
	E(i, 1, n) {
		State st[N]; int cnt = 0;
		E(j, 1, n)
			if (dist[i][j] <= k + 1 && i != j) {
				++ cnt;
				st[cnt].id = j;
				st[cnt].dis = w[i] + w[j];
			}
		std::sort(st + 1, st + cnt + 1);
		ban[i][0] = st[1], ban[i][1] = st[2], ban[i][2] = st[3];
	} 
	E(i, 1, n) {
		State st[N]; int cnt = 0;
		E(j, 1, n)
			if (dist[i][j] <= k + 1 && i != j && dist[j][1] <= k + 1) {
				++ cnt;
				st[cnt].id = j;
				st[cnt].dis = w[i] + w[j];
			}
		std::sort(st + 1, st + cnt + 1);
		banH[i][0] = st[1], banH[i][1] = st[2], banH[i][2] = st[3];
	}
	E(i, 2, n) {
		if (dist[i][1] > k + 1) continue;
		E(ix, 0, 2)
			if (ban[i][ix].id != 0) {
				if (ban[i][ix].id == 1) continue;
				E(j, 2, n) {
					if (j == i) continue;
					if (j == ban[i][ix].id) continue;
					if (dist[j][ban[i][ix].id] > k + 1) continue;
					E(jx, 0, 2)
						if (ban[j][jx].id != 0) {
							if (banH[j][jx].id == 1) continue;
							if (banH[j][jx].id == i) continue;
							if (banH[j][jx].id == ban[i][ix].id) continue;
							ans = std::max(ans, ban[i][ix].dis + banH[j][jx].dis);
						}
				}
			}
	}
	printf("%lld", ans);
	return 0;
}
//I'm Nahida's dog!
//If I get tg1=, Kaka'll wear Lolita 114514times!(Kaka is not me actually)
//Perhaps I will be involved in moral dilemma... 
