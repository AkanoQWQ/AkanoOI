#include <bits/stdc++.h>
typedef long long ll;
#define ls(p) p << 1
#define rs(p) p << 1 | 1 
#define l(x, p) tree[x][p].l
#define r(x, p) tree[x][p].r
#define data(x, p) tree[x][p].data
#define E(i, l, r) for (int i = l; i <= r; ++ i)
const int N = 1e5 + 5, N1 = 1e3 + 5;
struct Node {
	int l, r;
	ll data;
} tree[N1][N1 * 4];
struct Segment {
	int l, r;
	ll data;
} minT[N * 4], maxT[N * 4];
int n, m, q;
ll a[N], b[N];
bool flag;
void buildMi(int p, int l, int r) {
	minT[p].l = l; minT[p].r = r;
	if (l == r) {
		minT[p].data = b[l];
		return;
	}
	int mid = l + r >> 1;
	buildMi(p << 1, l, mid);
	buildMi(p << 1 | 1, mid + 1, r);
	minT[p].data = std::min(minT[p << 1].data, minT[p << 1 | 1].data); 
}
void buildMa(int p, int l, int r) {
	maxT[p].l = l; maxT[p].r = r;
	if (l == r) {
		maxT[p].data = a[l];
		return;
	}
	int mid = l + r >> 1;
	buildMa(p << 1, l, mid);
	buildMa(p << 1 | 1, mid + 1, r);
	maxT[p].data = std::max(maxT[p << 1].data, maxT[p << 1 | 1].data);
}
void build(int X, int p, int l, int r) {
	l(X, p) = l; r(X, p) = r;
	if (l == r) {
		data(X, p) = a[X] * b[l];
		return;
	}
	int mid = l + r >> 1;
	build(X, ls(p), l, mid);
	build(X, rs(p), mid + 1, r);
	data(X, p) = std::min(data(X, ls(p)), data(X, rs(p)));
}
ll queryMi(int p, int l, int r) {
	if (minT[p].l > r || minT[p].r < l) return 1e18 + 5;
	if (l <= minT[p].l && minT[p].r <= r) return minT[p].data;
	return std::min(queryMi(p << 1, l, r), queryMi(p << 1 | 1, l, r));
}
ll queryMa(int p, int l, int r) {
	if (maxT[p].l > r || maxT[p].r < l) return -1e18 - 5;
	if (l <= maxT[p].l && maxT[p].r <= r) return maxT[p].data;
	return std::max(queryMa(p << 1, l, r), queryMa(p << 1 | 1, l, r)); 
}
ll query(int X, int p, int l, int r) {
	if (l(X, p) > r || r(X, p) < l) return 1e18 + 5;
	if (l <= l(X, p) && r(X, p) <= r) return data(X, p);
	return std::min(query(X, ls(p), l, r), query(X, rs(p), l, r));
}
int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &q);
	E(i, 1, n) scanf("%lld", a + i);
	E(i, 1, m) scanf("%lld", b + i);
	if (n <= 1000 && m <= 1000 && q <= 1000) {
		E(i, 1, n)
			build(i, 1, 1, m);
		while (q --) {
			int l1, r1, l2, r2;
			scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
			ll ans = -1e18;
			E(i, l1, r1)
				ans = std::max(ans, query(i, 1, l2, r2));
			printf("%lld\n", ans);
		}
	}
	else {
		buildMi(1, 1, m);
		buildMa(1, 1, n);
		E(i, 1, n)
			if (a[i] <= 0) {
				flag = 1;
				break;
			}
		E(i, 1, m)
			if (b[i] <= 0) {
				flag = 1;
				break;
			}
		std::cout << flag;
		while (q --) {
			int l1, r1, l2, r2;
			scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
			ll ans;
			if (l1 == r1) {
				ans = 1e18;
				E(i, l2, r2)
					ans = std::min(ans, a[l1] * b[i]);
			}
			else if (l2 == r2) {
				ans = -1e18;
				E(i, l1, r1)
					ans = std::max(ans, a[i] * b[l2]);
			}
			else if (!flag)
				ans = queryMi(1, l2, r2) * queryMa(1, l1, r1);
			printf("%lld\n", ans); 
		}
	}
	return 0;
}
//I'm Nahida's dog!
//If I get tg1=, Kaka'll wear Lolita 114514times!(Kaka is not me actually)
//Perhaps I will be involved in moral dilemma... 
