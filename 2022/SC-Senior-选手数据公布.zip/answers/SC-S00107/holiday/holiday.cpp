#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,m,k,mch=0;
int to[20005],nex[20005],lk[20005];
int Least[2505][2505];
int que[2505],hd,tl;
bool vis[2505];
long long s[2505];
long long rd[2505][2505]; 
long long mx[3][2505];
int p[3][2505];
void bfs(int st)
{
	int fr,nxt;
	hd=0;tl=-1;
	que[++tl]=st;
	Least[st][st]=0;
	for (int i=1;i<=n;i++)
		vis[i]=false;
	vis[st]=true;
	while(hd<=tl)
	{
		fr=que[hd];
		hd++;
		for (int i=lk[fr];i>0;i=nex[i])
		{
			if (vis[to[i]]) continue;
			vis[to[i]]=true;
			que[++tl]=to[i];
			Least[st][to[i]]=Least[st][fr]+1;
		}
	}
	return ;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int u,v,pb,pc,nb,nc;
	long long pt,ans=0LL,es;
	scanf("%d%d%d",&n,&m,&k);
	s[1]=0LL;
	for (int i=1;i<=n;i++) lk[i]=-1;
	for (int i=2;i<=n;i++) scanf("%lld",&s[i]);
	for (int i=1;i<=m;i++)
	{
		scanf("%d%d",&u,&v);
		to[++mch]=v;nex[mch]=lk[u];lk[u]=mch;
		to[++mch]=u;nex[mch]=lk[v];lk[v]=mch;
	}
	for (int i=1;i<=n;i++) bfs(i);
	for (int a=1;a<=n;a++)
	{
		for (int b=1;b<=n;b++)
		{
			rd[a][b]=-1;
			if (a==b||a==1||b==1) continue;
			if (Least[1][a]-1>k||Least[a][b]-1>k) continue;
			rd[a][b]=s[a]+s[b];
		}
	}
	for (int i=1;i<=n;i++)
	{
		for (int t=0;t<3;t++) mx[t][i]=p[t][i]=-1;
		for (int j=1;j<=n;j++)
		{
			if (rd[j][i]>mx[0][i])
			{
				for (int t=2;t>0;t--)
					mx[t][i]=mx[t-1][i],p[t][i]=p[t-1][i];
				mx[0][i]=rd[j][i];p[0][i]=j;
			}
			else if (rd[j][i]>mx[1][i])
			{
				mx[2][i]=mx[1][i],p[2][i]=p[1][i];
				mx[1][i]=rd[j][i];p[1][i]=j;
			}
			else if (rd[j][i]>mx[2][i])
			{
				mx[2][i]=rd[j][i];p[2][i]=j;
			}
		}
	 } 
	for (int b=1;b<=n;b++)
	{
		for (int c=1;c<=n;c++)
		{
			if(b==c||Least[b][c]-1>k) continue;
			pb=0;if (p[0][b]==c) pb=1;
			nb=pb+1;if (p[nb][b]==c) nb++;
			pc=0;if (p[0][c]==b) pc=1;
			nc=pc+1;if (p[nc][c]==b) nc++;
			if (p[pb][b]==-1||p[pc][c]==-1) continue;
			pt=mx[pb][b]+mx[pc][c];
			if (p[pb][b]==p[pc][c]){
				if (p[nb][b]==-1&&p[nc][c]==-1) continue;
				es=mx[pb][b]-mx[nb][b];
				if (p[nb][b]==-1||(p[nc][c]>-1&&mx[pc][c]-mx[nc][c]<es))
					es=mx[pc][c]-mx[nc][c];
				pt-=es;
			}
			ans=max(ans,pt);
		}
	}
	printf("%lld\n",ans);
	return 0;
 } 
