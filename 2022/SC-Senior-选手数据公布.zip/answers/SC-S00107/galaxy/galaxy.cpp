#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn=5e5;
int cnt[maxn+5];
int lk[maxn+5],to[2*maxn+5],nex[2*maxn+5],mch=0;
int lk2[maxn+5],to2[2*maxn+5],nex2[2*maxn+5];
bool dest[maxn+5];
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m,u,v,q,op,cnt1=0;
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++) lk[i]=lk2[i]=-1;
	for (int i=1;i<=m;i++){
		scanf("%d%d",&u,&v);
		to[++mch]=v;nex[mch]=lk[u];lk[u]=mch;
		cnt[u]++;dest[mch]=false;
		to2[mch]=u;nex2[mch]=lk2[v];lk2[v]=mch;
	}
	for (int i=1;i<=n;i++) if (cnt[i]==1) cnt1++;
	scanf("%d",&q);
	for (int i=1;i<=q;i++)
	{
		scanf("%d",&op);
		if (op==1){
			scanf("%d%d",&u,&v);
			if (n<=2000)
			{
				int j;
				for (j=lk[u];j>0;j=nex[j])
					if (to[j]==v) break;
				dest[j]=true;
			}
			if (cnt[u]==1) cnt1--;
			cnt[u]--;
			if (cnt[u]==1) cnt1++;
		}
		if (op==2){
			scanf("%d",&u);
			for (int j=lk2[u];j>0;j=nex2[j])
			{
				if (!dest[j])
				{
					dest[j]=true;
					if (cnt[to2[j]]==1) cnt1--;
					cnt[to2[j]]--;
					if (cnt[to2[j]]==1) cnt1++;
				}
			}
		}
		if (op==3){
			scanf("%d%d",&u,&v);
			if (n<=2000)
			{
				int j;
				for (j=lk[u];j>0;j=nex[j])
					if (to[j]==v) break;
				dest[j]=false;
			}
			if (cnt[u]==1) cnt1--;
			cnt[u]++;
			if (cnt[u]==1) cnt1++;
		}
		if (op==4){
			scanf("%d",&u);
			for (int j=lk2[u];j>0;j=nex2[j])
			{
				if (dest[j])
				{
					dest[j]=false;
					if (cnt[to2[j]]==1) cnt1--;
					cnt[to2[j]]++;
					if (cnt[to2[j]]==1) cnt1++;
				}
			}
		}
		if (cnt1==n) puts("YES");
		else puts("NO");
	}
	return 0;
 } 
