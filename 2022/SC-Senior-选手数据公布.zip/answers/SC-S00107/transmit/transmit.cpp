#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const long long INF=0x3f7f7f7f7f7f7f7f;
const int maxn=2e5,maxk=19;
int K;
int pre[maxk+1][maxn+5],D=0;
int dep[maxn+5];
long long dp[maxk+1][maxn+5][4][4];
int lk[maxn+5],to[2*maxn+5],nex[2*maxn+5],m=0;
long long val[maxn+5];
bool vis[maxn+5];
void build(int st)
{
	vis[st]=true;
	D++;dep[st]=D;
	for (int i=lk[st];i>0;i=nex[i])
	{
		if (vis[to[i]]) continue;
		build(to[i]);
		pre[0][to[i]]=st;
		dp[0][to[i]][0][0]=val[to[i]]+val[st];
		dp[0][to[i]][0][1]=val[st];
		dp[0][to[i]][1][0]=val[to[i]];
	}
	D--;
	return ;
}
long long Solve(int a,int b)
{
	long long fa[4],fb[4],p[4],pt;
	if (dep[a]<dep[b]) swap(a,b);
	for (int i=0;i<=K;i++) fa[i]=fb[i]=-1;
	fa[0]=val[a];fb[0]=val[b];
	for (int k=maxk;k>=0;k--)
	{
		if (dep[pre[k][a]]>=dep[b])
		{
			for (int fr=0;fr<=K;fr++) p[fr]=INF;
			for (int midfr=0;midfr<=K&&midfr<=(1<<k);midfr++)
			{
				for (int mided=0;mided<=K;mided++)
				{
					if (fa[mided]==-1) continue;
					if (midfr==(1<<k)&&mided+midfr<=K)
					{
						if (p[mided+midfr]==-1)
							p[mided+midfr]=fa[mided];
						else p[mided+midfr]=min(p[mided+midfr],fa[mided]);
					}
					if (midfr==(1<<k)) continue;
					if (midfr+mided>K) continue;
					for (int fr=0;fr<=K&&fr+midfr<(1<<k);fr++)
					{
						if (dp[k][a][fr][midfr]==-1) continue;
						pt=fa[mided]+dp[k][a][fr][midfr];
						if (mided==0&&midfr==0) pt-=val[a];
						p[fr]=min(p[fr],pt);
					}
				}
			}
			for (int fr=0;fr<=K;fr++) if (p[fr]==INF) p[fr]=-1;
			for (int fr=0;fr<=K;fr++) fa[fr]=p[fr];
			a=pre[k][a];
		}
	}
	if (a==b)
	{
		long long minn=INF;
		for (int i=0;i<=K;i++) {
			pt=fa[i];
			if (pt==-1) continue;
			if (i>0) pt+=val[b];
			minn=min(minn,pt);
		}
		return minn;
	}
	for (int k=maxk;k>=0;k--)
	{
		if (pre[k][a]!=pre[k][b])
		{
			for (int fr=0;fr<=K;fr++) p[fr]=INF;
			for (int midfr=0;midfr<=K&&midfr<=(1<<k);midfr++)
			{
				for (int mided=0;mided<=K;mided++)
				{
					if (fa[mided]==-1) continue;
					if (midfr==(1<<k)&&mided+midfr<=K)
					{
						if (p[mided+midfr]==-1)
							p[mided+midfr]=fa[mided];
						else p[mided+midfr]=min(p[mided+midfr],fa[mided]);
					}
					if (midfr==(1<<k)) continue;
					if (midfr+mided>K) continue;
					for (int fr=0;fr<=K&&fr+midfr<(1<<k);fr++)
					{
						if (dp[k][a][fr][midfr]==-1) continue;
						pt=fa[mided]+dp[k][a][fr][midfr];
						if (mided==0&&midfr==0) pt-=val[a];
						p[fr]=min(p[fr],pt);
					}
				}
			}
			for (int fr=0;fr<=K;fr++) if (p[fr]==INF) p[fr]=-1;
			for (int fr=0;fr<=K;fr++) fa[fr]=p[fr];
			a=pre[k][a];
			
			for (int fr=0;fr<=K;fr++) p[fr]=INF;
			for (int midfr=0;midfr<=K&&midfr<=(1<<k);midfr++)
			{
				for (int mided=0;mided<=K;mided++)
				{
					if (fb[mided]==-1) continue;
					if (midfr==(1<<k)&&mided+midfr<=K)
					{
						if (p[mided+midfr]==-1)
							p[mided+midfr]=fb[mided];
						else p[mided+midfr]=min(p[mided+midfr],fb[mided]);
					}
					if (midfr==(1<<k)) continue;
					if (midfr+mided>K) continue;
					for (int fr=0;fr<=K&&fr+midfr<(1<<k);fr++)
					{
						if (dp[k][b][fr][midfr]==-1) continue;
						pt=fb[mided]+dp[k][b][fr][midfr];
						if (mided==0&&midfr==0) pt-=val[b];
						p[fr]=min(p[fr],pt);
					}
				}
			}
			for (int fr=0;fr<=K;fr++) if (p[fr]==INF) p[fr]=-1;
			for (int fr=0;fr<=K;fr++) fb[fr]=p[fr];
			b=pre[k][b];
		}
	}
	long long ans=INF;
	for (int ra=0;ra<=K;ra++)
	{
		for (int rb=0;rb<=K;rb++)
		{
			if (fa[ra]==-1||fb[rb]==-1) continue;
			pt=fa[ra]+fb[rb];
			if (ra+rb+2>K)
				pt+=val[pre[0][a]];
			ans=min(ans,pt);
		}
	}
	return ans;
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int n,Q,u,v,a,b;
	long long pt;
	scanf("%d%d%d",&n,&Q,&K);
	memset(dp,-1,sizeof(dp));
	for (int i=1;i<=n;i++) scanf("%lld",&val[i]),lk[i]=-1,vis[i]=false;
	for (int i=1;i<n;i++){
		scanf("%d%d",&u,&v);
		to[++m]=v;nex[m]=lk[u];lk[u]=m;
		to[++m]=u;nex[m]=lk[v];lk[v]=m;
	}
	build(1);pre[0][1]=0;
	for (int k=1;k<=maxk;k++)
	{
		for (int i=1;i<=n;i++)
		{
			pre[k][i]=pre[k-1][pre[k-1][i]];
			for (int midfr=0;midfr<=K;midfr++)
			{
				for (int mided=0;mided<=K;mided++)
				{
					if (midfr+mided>K) continue;
					for (int fr=0;fr<=K;fr++)
					{
						if (dp[k-1][pre[k-1][i]][fr][midfr]==-1) continue;
						for (int ed=0;ed<=K;ed++)
						{
							if (dp[k-1][i][mided][ed]==-1) continue;
							pt=dp[k-1][pre[k-1][i]][fr][midfr]+dp[k-1][i][mided][ed];
							if (midfr==mided&&midfr==0)
								pt-=val[pre[k-1][i]];
							if (dp[k][i][fr][ed]==-1)
								dp[k][i][fr][ed]=pt;
							else dp[k][i][fr][ed]=min(dp[k][i][fr][ed],pt);
						}
					}
				}
			}
		}
	}
	while(Q--)
	{
		scanf("%d%d",&a,&b);
		printf("%lld\n",Solve(a,b));
	}
	return 0;
 } 
