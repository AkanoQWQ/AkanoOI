#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn=1e5,maxk=18;
const long long INF=2e9;
long long a[maxn+5],b[maxn+5];
int LOG2[maxn+5];
long long f[2][4][maxn+5][maxk+1];
int cnt0[2][maxn+5],cntn[2][maxn+5],cnt[2][maxn+5];
// 0-> a  1-> b
// 0-> min+ 1->min- 2-> max+ 3->max-
long long cal(int bel,int tp,int l,int r)
{
	int len=LOG2[r-l+1];
	long long d=f[bel][tp][l][len];
	if (tp<=1) d=min(f[bel][tp][r-(1<<len)+1][len],d);
	else d=max(f[bel][tp][r-(1<<len)+1][len],d);
	return d;
}
long long Solve(int l1,int r1,int l2,int r2)
{
	long long ans,ac,bc;
	if (cnt0[1][r2]-cnt0[1][l2-1]==r2-l2+1) return 0LL;
	if (cnt0[0][r1]-cnt0[0][l1-1]==r1-l1+1) return 0LL;
	if (cnt[1][r2]==cnt[1][l2-1]){
		ac=cal(0,1,l1,r1);
		bc=cal(1,3,l2,r2);
		if (cntn[0][r1]==cntn[0][l1-1])
		{
			ac=cal(0,0,l1,r1);
			bc=cal(1,1,l2,r2);
		}
		ans=ac*bc;
	}
	else if (cntn[1][r2]==cntn[1][l2-1])
	{
		ac=cal(0,2,l1,r1);
		bc=cal(1,0,l2,r2);
		if (cnt[0][r1]==cnt[0][l1-1])
		{
			ac=cal(0,3,l1,r1);
			bc=cal(1,2,l2,r2);
		}
		ans=ac*bc;
	}
	else{
		ans=-INF*INF;
		ac=cal(0,0,l1,r1);
		if (ac!=INF){
			bc=cal(1,1,l2,r2);
			ans=max(ans,ac*bc);
		}
		ac=cal(0,3,l1,r1);
		if (ac!=-INF){
			bc=cal(1,2,l2,r2);
			ans=max(ans,ac*bc);
		}
	}
	if (ans<0&&cnt0[0][r1]-cnt0[0][l1-1]>0) ans=0LL;
	if (ans>0&&cnt0[1][r2]-cnt0[1][l2-1]>0) ans=0LL;
	return ans;
}
void Init(long long *N,int len,int id)
{
	long long d;
	for (int k=0;k<=maxk;k++)
	{
		for (int i=1;i<=len;i++)
		{
			if (k==0){
				f[id][0][i][k]=INF;
				f[id][1][i][k]=INF;
				f[id][2][i][k]=-INF;
				f[id][3][i][k]=-INF;
				if (N[i]>0) f[id][0][i][k]=f[id][2][i][k]=N[i];
				if (N[i]<0) f[id][1][i][k]=f[id][3][i][k]=N[i];
			}
			else
			{
				d=f[id][0][i][k-1];
				if (i+(1<<(k-1))<=len) d=min(f[id][0][i+(1<<(k-1))][k-1],d);
				f[id][0][i][k]=d;
				
				d=f[id][1][i][k-1];
				if (i+(1<<(k-1))<=len) d=min(f[id][1][i+(1<<(k-1))][k-1],d);
				f[id][1][i][k]=d;
				
				d=f[id][2][i][k-1];
				if (i+(1<<(k-1))<=len) d=max(f[id][2][i+(1<<(k-1))][k-1],d);
				f[id][2][i][k]=d;
				
				d=f[id][3][i][k-1];
				if (i+(1<<(k-1))<=len) d=max(f[id][3][i+(1<<(k-1))][k-1],d);
				f[id][3][i][k]=d;
			}
		}
	}
	cnt0[id][0]=0;
	cntn[id][0]=0;
	cnt[id][0]=0;
	for (int i=1;i<=len;i++)
	{
		cnt0[id][i]=cnt0[id][i-1]+(N[i]==0?1:0);
		cntn[id][i]=cntn[id][i-1]+(N[i]<0?1:0);
		cnt[id][i]=cnt[id][i-1]+(N[i]>0?1:0);
	}
	return ; 
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q,l1,l2,r1,r2;LOG2[0]=LOG2[1]=0;
	scanf("%d%d%d",&n,&m,&q);
	for (int i=2;i<=max(m,n);i++) LOG2[i]=LOG2[i/2]+1;
	for (int i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	for (int i=1;i<=m;i++)
		scanf("%lld",&b[i]);
	Init(a,n,0);
	Init(b,m,1);
	for (int i=1;i<=q;i++){
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		printf("%lld\n",Solve(l1,r1,l2,r2));
	}
	return 0;
 } 
