#include <bits/stdc++.h>
#include <cstdio>
#include <algorithm>
#include <queue>
#include <vector>
using namespace std;
const int N=2e4+5,INF=0x3f3f3f3f;
typedef pair<int,int> node;
int a[N],b[N],c[N][N];
int mini[N];
int l1,r1,l2,r2;
int n,m,q;
bool nil;
bool stf0[N];//ȫ0�� 
bool st0[N];//��0�� 
bool stp[N];//ȫ���� 
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)scanf("%d",&b[i]);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)c[i][j]=a[i]*b[j];
	while(q--)
	{
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		int minn=INF,minx,miny;
		int maxn=0,maxx,maxy;
		for(int i=l1;i<=r1;i++)
		{
			int hsm=INF;//����С
			int znum=0;//ÿ��0�� 
			for(int j=l2;j<=r2;j++)
			{
				hsm=min(hsm,c[i][j]);
				if(minn>c[i][j])
				{
					minn=c[i][j];
					minx=i,miny=j;
				}
				if(c[i][j]==0)znum++;
			}
			if(znum==r2-l2+1)stf0[i]=true;
			mini[i]=hsm;
		}
		if(minn>=0)
		{
			int ans=0;
			for(int i=l1;i<=r1;i++)ans=max(ans,mini[i]);
			printf("%d\n",ans);
			continue;
		}
		if(minn<0)
		{
			for(int i=l1;i<=r1;i++)if(mini[i]>0)stp[i]=true;
			int ans=0;
			for(int i=l1;i<=r1;i++)
				if(stp[i])ans=max(ans,mini[i]);
			if(ans!=0)
			{
				printf("%d\n",ans);
				continue;
			}
			bool cmp=false;
			for(int i=l1;i<=r1;i++)
				if(stf0[i])
				{
					cmp=true;
					break;
				}
			if(cmp)
			{
				printf("0\n");
				continue;			
			}
			else
			{
				ans=-INF;
				for(int i=l1;i<=r1;i++)
					if(ans<mini[i])ans=mini[i];
				printf("%d\n",ans);
				continue;				
			}
		}
	}
	return 0;
} 
