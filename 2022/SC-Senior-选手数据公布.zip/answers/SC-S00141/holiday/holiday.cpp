#include <bits/stdc++.h>
#include <cstdio>
#include <algorithm>
#include <queue>
#define LL long long
using namespace std;
const int N=2505,M=2e4+5;
typedef pair<int,int> node;
int n,m,k,head[N],num=0,dis[N],res,position;
bool st[N],vis[N];
int cnt=0;
LL w[N],ans=0;
struct edge{
	int next,to;
}e[M];
void init()
{
	memset(head,-1,sizeof(head));
	memset(w,0,sizeof(w));
	memset(st,0,sizeof(st));
	memset(dis,0x3f,sizeof(dis));
	num=0;
}
void add(int a,int b)
{
	e[num].next=head[a];
	e[num].to=b;
	head[a]=num++;
}
void dijkstra()
{
	priority_queue<node,vector<node>,greater<node> >q1;
	q1.push({0,1});
	while(!q1.empty())
	{
		node t=q1.top();
		int u=t.second;
		q1.pop();
		if(st[u])continue;
		st[u]=true;
		for(int i=head[u];i!=-1;i=e[i].next)
		{
			int v=e[i].to;
			if(dis[v]>dis[u]+1)
			{
				dis[v]=dis[u]+1;
				q1.push({dis[v],v});
			}
		}
	}
}
void bfs(int s)
{
	vis[s]=true;
	cnt++;
	memset(st,0,sizeof(st));
	queue<node>q2;
	LL maxx=0;
	q2.push({s,0});
	st[s]=true;
	while(!q2.empty())
	{
		node t=q2.front();
		q2.pop();
		int u=t.first;
		if(!vis[u]&&maxx<=w[u])
		{
			maxx=w[u];
			position=u;
		}
		if(t.second==k)continue;
		for(int i=head[u];i!=-1;i=e[i].next)
		{
			int v=e[i].to;
			if(vis[v])continue;
			if(st[v])continue;
			q2.push({v,t.second+1});
			st[v]=true;
			if(dis[v]>res*k)continue;
		}
	}
	ans+=maxx;
	vis[position]=true;
	return;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	init();
	scanf("%d%d%d",&n,&m,&k);
	k++;
	w[1]=0;
	dis[1]=0;
	for(int i=2;i<=n;i++)scanf("%lld",&w[i]);
	for(int i=1;i<=m;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
	}
	dijkstra();
	position=1;
	vis[1]=true;
	for(int i=1;i<=4;i++)
	{
		res=5-i;
		bfs(position);
	}
	printf("%lld\n",ans);
	return 0;
}
