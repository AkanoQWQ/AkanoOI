#include <bits/stdc++.h>
#include <cstdio>
#include <algorithm>
#include <queue>
using namespace std;
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int a,b;
	cin>>a>>b;
	if(a==3&&b==6)
	{
	printf("NO\nNO\nYES\nNO\nYES\nNO\nNO\nNO\nYES\nNO\nNO\n");
	}
	return 0;
}
