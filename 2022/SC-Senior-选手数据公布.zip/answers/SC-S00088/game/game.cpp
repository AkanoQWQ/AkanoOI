#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5;
int n,m,q;
int a[N],b[N];
struct node{
	int l,r,datm,dats;
}t[N*4];
void build(int p,int l,int r){
	t[p].l=l,t[p].r=r;
	if(l==r){
		t[p].datm=t[p].dats=b[l];
		return;
	}
	int mid=(l+r)/2;
	build(p*2,l,mid);
	build(p*2+1,mid+1,r);
	t[p].datm=max(t[p*2].datm,t[p*2+1].datm);
	t[p].dats=min(t[p*2].dats,t[p*2+1].dats);
	return;
}
int ask(int p,int l,int r,int que){
	if(l<=t[p].l&&t[p].r<=r) return (que?t[p].datm:t[p].dats);
	int mid=(t[p].l+t[p].r)/2;
	int ans=(que?INT_MIN:INT_MAX);
	if(l<=mid) ans=(que?max(ask(p*2,l,r,que),ans):min(ask(p*2,l,r,que),ans));
	if(r>mid) ans=(que?max(ask(p*2+1,l,r,que),ans):min(ask(p*2+1,l,r,que),ans));
	return ans;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(register int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(register int j=1;j<=m;j++) scanf("%d",&b[j]);
	build(1,1,n);
	for(register int i=1;i<=q;i++){
		int l1,r1,l2,r2;scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		long long bmax=ask(1,l2,r2,0),bmin=ask(1,l2,r2,1);
		long long maxs=LONG_LONG_MIN;
		for(register int i=l1;i<=r1;i++){
			maxs=max(maxs,min(bmax*a[i],bmin*a[i]));
		}
		cout<<maxs<<endl;
	}
	return 0;
}
