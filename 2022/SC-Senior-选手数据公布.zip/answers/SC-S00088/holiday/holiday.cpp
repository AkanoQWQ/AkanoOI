#include<bits/stdc++.h>
using namespace std;
const int N=2505;
int mp[N][N],n,m;
long long p[N];
void floyd(){
	for(register int k=1;k<=n;k++){
		for(register int i=1;i<=n;i++){
			for(register int j=i+1;j<=n;j++){
				mp[j][i]=mp[i][j]=(mp[i][j]<mp[i][k]+mp[j][k]?mp[i][j]:mp[i][k]+mp[j][k]);
			}
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int k;
	cin>>n>>m>>k;
	memset(mp,0x3f,sizeof mp);
	for(register int i=2;i<=n;i++) cin>>p[i];
	for(register int i=1;i<=m;i++){
		int u,v;cin>>u>>v;
		mp[u][v]=mp[v][u]=1;
	}
	for(int i=1;i<=n;i++) mp[i][i]=0;
	floyd();long long ans=0;
	for(register int i=2;i<=n;i++){
		if(mp[1][i]-1>k) continue;
		for(register int j=2;j<=n;j++){
			if(mp[i][j]-1>k||i==j) continue;
			for(register int c=2;c<=n;c++){
				if(mp[j][c]-1>k||c==j||c==i) continue;
				for(register int d=2;d<=n;d++){
					if(mp[c][d]-1>k||mp[d][1]-1>k||d==j||d==i||d==c) continue;
					ans=(ans>p[i]+p[j]+p[c]+p[d]?ans:p[i]+p[j]+p[c]+p[d]);
				}
			}
		}
	}
	cout<<ans;
	return 0;
}
