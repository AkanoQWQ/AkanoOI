#include<bits/stdc++.h>
using namespace std;
const int N=2e5+5;
int n,q,k;
long long v[N];
int head[N],tot;
struct edge{
	int v,next;
}e[N*2];
void add(int u,int v){
	e[++tot]={v,head[u]};
	head[u]=tot;
}
struct node{
	int p;long long a;int stp;int fa;
};
bool vis[N];
long long bfs(int s,int t){
	long long ans=LONG_LONG_MAX;
	queue<node> q;
	memset(vis,0,sizeof vis);
	q.push({s,v[s],0,0});
	while(!q.empty()){
		node ln=q.front();q.pop();
		if(ln.p==t){
			ans=min(ans,ln.a+v[t]);
			continue;
		}
		for(int i=head[ln.p];i;i=e[i].next){
			if(e[i].v!=ln.fa){
				if(ln.stp+1>k){
					q.push({e[i].v,ln.a+v[ln.p],1,ln.p});
				}else{
					q.push({e[i].v,ln.a,ln.stp+1,ln.p});
					q.push({e[i].v,ln.a+v[ln.p],1,ln.p});
				}
			}
		}
	}
	return ans;
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++) cin>>v[i];
	for(int i=1;i<n;i++){
		int u,v;cin>>u>>v;
		add(u,v);add(v,u);
	}
	for(int i=1;i<=q;i++){
		int s,t;cin>>s>>t;
		cout<<bfs(s,t)<<endl;
	}
	return 0;
}
