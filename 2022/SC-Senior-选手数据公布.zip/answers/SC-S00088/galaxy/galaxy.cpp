#include<bits/stdc++.h>
using namespace std;
const int N=5e5+5;
int n,m,q;
struct edge{
	int v,next;bool f;
}e[N];
int tot,head[N];
void add(int u,int v){
	e[++tot]={v,head[u],true};
	head[u]=tot;
} 
bool vis[N];
inline void reset(){
	memset(vis,0,sizeof vis);
	return;
}
bool isoncir(int x){
	vis[x]=1;
	for(int i=head[x];i;i=e[i].next){
		if(vis[e[i].v]&&e[i].f){
			return true;
		}
		if(e[i].f){
			bool ret=isoncir(e[i].v);
			if(ret) return ret;
		}
	} 
	return false;
}
bool iscan(){
	for(int i=1;i<=n;i++){
		bool f=0;
		for(int j=head[i];j;j=e[j].next){
			if(e[j].f){
				if(f) return false;
				f=1;
			}
		}
	}
	return true;
}
vector<int> idx[N];
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int u,v;
		cin>>u>>v;
		add(u,v);
		idx[v].push_back(tot);
	}
	cin>>q;
	for(int l=1;l<=q;l++){
		int op,u,v;cin>>op;
		if(op==1){
			cin>>u>>v;
			for(int i=head[u];i;i=e[i].next){
				if(e[i].v==v){
					e[i].f=0;
					break;
				}
			}
		}else if(op==2){
			cin>>u;
			for(int i=0;i<idx[u].size();i++){
				e[idx[u][i]].f=0;
			}
		}else if(op==3){
			cin>>u>>v;
			for(int i=head[u];i;i=e[i].next){
				if(e[i].v==v){
					e[i].f=1;
					break;
				}
			}
		}else{
			cin>>u;
			for(int i=0;i<idx[u].size();i++){
				e[idx[u][i]].f=1;
			}
		}
		bool flg=1;
		for(int i=1;i<=n;i++){
			reset();
			flg&=isoncir(i);
		}
		cout<<(flg&iscan()?"YES\n":"NO\n");
	}
	return 0;
} 
