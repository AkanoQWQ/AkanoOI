#include<bits/stdc++.h>
using namespace std;
const int N=7000006;
int n,m,k,a[2505],chan[2505][2505],cnt[2505],s[5][2505];
int hd[N],nxt[2*N],to[2*N],cost[2*N],tot=1,ans,q;
bool vis[N];
void add(int u,int v,int we)
{
	to[++tot]=v;
	nxt[tot]=hd[u];
	cost[tot]=we;
	hd[u]=tot;
}
void dfs(int s)
{
	queue<int>q;
	memset(vis,0,sizeof(vis));
	vis[s]=1;
	q.push(s);
	while(q.size())
	{
		int u=q.front();
		q.pop();
		for(int e=hd[u];e;e=nxt[e])
		{
			int v=to[e];
			if(u==s) chan[s][v]=0;
			else chan[s][v]=min(chan[s][v],chan[s][u]+1);
			//cout<<u<<" "<<v<<" "<<chan[s][v]<<endl;
			if(!vis[v])
			{
				vis[v]=true;
				q.push(v);
			}
		}
	}
}
/*void spfa(int s)
{
	queue<int>q;
	memset(vis,0,sizeof(vis));
	memset(dis,0,sizeof(dis));
	cnt[1]=0;
	q.push(s);
	while(q.size())
	{
		int u=q.front();
		vis[u]=1;
		q.pop();
		for(int e=hd[u];e;e=nxt[e])
		{
			int v=to[e];
			if(vis[v]&&v!=1) continue;
			if(!cnt[v]&&v!=1) cnt[v]=cnt[u]+1;
			if(cnt[v]>=5&&v!=1) continue;
			if(dis[v]<dis[u]+cost[e])
			{
				dis[v]=dis[u]+cost[e];
				q.push(v);
			}
			
		}
	}
	for(int i=1;i<=n;++i) cout<<dis[i]<<endl;;
}*/
//void spfa(int u)
//{
//	if(u!=1) vis[u]=1;
//	for(int e=hd[u];e;e=nxt[e])
//	{
//		int v=to[e];
//		//if(vis[v]&&v!=1) continue;
//		if(dis[v]<dis[u]+cost[e]) dis[v]=dis[u]+cost[e];
//	}
//}
void sdfs(int u,int turn,int dis)
{
	if(u==1&&turn==5)
	{
		ans=max(ans,dis);
		return ;
	}
	for(int e=hd[u];e;e=nxt[e])
	{
		int v=to[e];
		if(vis[v]) continue;
		dis+=cost[e];
		vis[v]=1;
		sdfs(v,turn+1,dis);
		dis-=cost[e];
		vis[v]=0;
	}
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=m;++i)
	{
		int u,v;
		scanf("%d%d",&u,&v);
	}
	for(int i=1;i<=q;++i)
	{
		int t,x,y;
		scanf("%d%d%d",&t,&x,&y);
		cout<<"YES"<<endl;
	}
	return 0;
}
