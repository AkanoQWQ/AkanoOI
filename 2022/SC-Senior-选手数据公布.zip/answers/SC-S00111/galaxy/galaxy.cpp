#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const int N=5e5+3;
int outd[N],beg[N],n,m,q,sum;
bool edel[N];
struct Edge{
	int u,v;
	bool operator < (const Edge &rhs)const{
		return v==rhs.v?u<rhs.u:v<rhs.v;
	}
}E[N];
int find(int u,int v){
	int l=beg[v],r=beg[v+1]-1,mid;
	while(l<r){
		mid=(l+r)>>1;
		if(E[mid].u<u)l=mid+1;
		else r=mid;
	}
	return l;
}
void read(int &x){
	x=0;
	int f=1;
	char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-')f*=-1;
		c=getchar();
	}
	while(c<='9'&&c>='0'){
		x=x*10+c-'0';
		c=getchar();
	}
	x*=f;
	return;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	read(n),read(m);
	for(int i=1;i<=m;++i){
		read(E[i].u),read(E[i].v);
		if(outd[E[i].u]==0)sum++;
		if(outd[E[i].u]==1)sum--;
		outd[E[i].u]++;
	}
	sort(E+1,E+1+m);
	for(int i=1;i<=m;++i){
		if(E[i].v!=E[i-1].v){
			for(int j=E[i-1].v+1;j<=E[i].v;++j)beg[j]=i;
		}
	}
	beg[n+1]=m+1; 
	read(q);
	while(q--){
		int t,u,v;
		read(t),read(u);
		if(t&1){
			read(v);
			int Id=find(u,v);
			if(t==1||!edel[Id]){
				edel[Id]=1;
				if(outd[u]==1)sum--;
				if(outd[u]==2)sum++;
				outd[u]--;
			}
			if(t==3){
				edel[Id]=0;
				if(outd[u]==1)sum--;
				if(outd[u]==0)sum++;
				outd[u]++;
			}
		}
		else{
			if(t==2){
				for(int i=beg[u];i<beg[u+1];++i)if(!edel[i]){
					edel[i]=1;
					if(outd[E[i].u]==1)sum--;
					if(outd[E[i].u]==2)sum++;
					outd[E[i].u]--;
				}
			}
			else{
				for(int i=beg[u];i<beg[u+1];++i)if(edel[i]){
					edel[i]=0;
					if(outd[E[i].u]==1)sum--;
					if(outd[E[i].u]==0)sum++;
					outd[E[i].u]++;
				}
			}
		}
		printf(sum==n?"YES\n":"NO\n");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
