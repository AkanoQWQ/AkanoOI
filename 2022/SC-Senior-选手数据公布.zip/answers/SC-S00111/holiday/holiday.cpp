#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const int N=2503;
vector<int> G[N],NG[N];
int n,m,k;
LL sco[N],f[N][5];
bool rh[N][N],vis[N];
void dfs(int rt,int u,int d){
	rh[rt][u]=1;
	if(d>=k)return;
	vis[u]=1;
	for(int i=0;i<G[u].size();++i){
		int v=G[u][i];
		if(vis[v])continue;
		dfs(rt,v,d+1);
	}
	vis[u]=0;
	return;
}
LL ans,mx;
void solve(int u,int t,LL sum){
	if(t==4){
		if(rh[u][1])ans=max(ans,sum);
		return;
	}
	vis[u]=1;
	for(int i=0;i<NG[u].size();++i){
		int v=NG[u][i];
		if(vis[v])continue;
		solve(v,t+1,sum+1ll*sco[v]); 
	}
	vis[u]=0;
	return;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;++i){
		scanf("%lld",&sco[i]);
		mx=max(mx,sco[i]);
	}
	for(int i=1;i<=m;++i){
		int x,y;
		scanf("%d%d",&x,&y);
		G[x].push_back(y);
		G[y].push_back(x);
	}
	for(int i=1;i<=n;++i){
		dfs(i,i,-1);
		rh[i][i]=0;
		for(int j=1;j<=n;++j){
			if(rh[i][j]){
				NG[i].push_back(j);
			}
		}
	}//n*n
	if(n<=100||k==0){
		solve(1,0,0ll);//n*n*n*n
		printf("%lld\n",ans);
	}
	else{
		for(int i=0;i<=4;++i){
			for(int j=1;j<=n;++j){
				f[i][j]=-1ll;
			}
		}
		f[0][1]=0ll;
		for(int i=0;i<=3;++i){
			for(int j=1;j<=n;++j){
				if(f[j][i]==-1ll)continue;
				for(int k=0;k<NG[j].size();++k){
					int v=NG[j][k];
					f[i+1][v]=max(f[i+1][v],f[i][j]+sco[v]);
				}
			}
		}
		srand(time(0));
		for(int i=1;i<=n;++i){
			if(rh[i][1]&&rand()&1)ans=max(ans,f[4][i]);
		}
		printf("%lld\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
