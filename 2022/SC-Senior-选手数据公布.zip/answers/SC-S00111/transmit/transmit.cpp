#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const int N=2e5+3;
int n,Q,k,v[N];
vector<int> G[N];
void read(int &x){
	x=0;
	int f=1;
	char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-')f*=-1;
		c=getchar();
	}
	while(c<='9'&&c>='0'){
		x=x*10+c-'0';
		c=getchar();
	}
	x*=f;
}
int fa[21][N],dep[N];
LL sum[N];
void dfs(int u,int d,LL Sum){
	dep[u]=d;
	sum[u]=Sum;
	for(int i=0;i<G[u].size();++i){
		int to=G[u][i];
		if(dep[to])continue;
		fa[0][to]=u;
		dfs(to,d+1,Sum+1ll*v[to]);
	}
	return;
}
void Init(){
	read(n),read(Q),read(k);
	for(int i=1;i<=n;++i)read(v[i]);
	for(int i=1;i<n;++i){
		int u,v;
		read(u),read(v);
		G[u].push_back(v);
		G[v].push_back(u);
	}
	fa[0][1]=1;
	dfs(1,1,v[1]);
	for(int i=1;i<=19;++i){
		for(int j=1;j<=n;++j){
			fa[i][j]=fa[i-1][fa[i-1][j]];
		}
	}
	return;
}
int LCA(int x,int y){
	if(dep[x]<dep[y])swap(x,y);
	for(int i=19;i>=0;--i){
		if(dep[x]-dep[y]>=(1<<i))x=fa[i][x];
	}
	if(x==y)return x;
	for(int i=19;i>=0;--i){
		if(fa[i][x]==fa[i][y])continue;
		x=fa[i][x],y=fa[i][y];
	}
	return fa[0][x];
}
int F[N],tot;
LL f[4][N];
void Getline(int u,int v){
	int lca=LCA(u,v);
	tot=0;
	while(u!=lca){
		F[++tot]=u;
		u=fa[0][u];
	}
	F[++tot]=u;
	int nw=tot+1;
	while(v!=lca){
		F[++tot]=v;
		v=fa[0][v];
	}
	for(int i=((nw+tot)>>1)+1;i<=tot;++i){
		swap(F[i],F[tot+nw-i]);
	}//�õ���
	return;
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	Init();
	while(Q--){
		int s,t;
		read(s),read(t);
		if(k>=2){
			Getline(s,t);
			f[0][1]=1ll*v[F[1]];
			for(int i=2;i<=tot;++i){
				f[0][i]=f[0][i-1];
				if(k==2&&i>2)f[0][i]=min(f[0][i],f[0][i-2]);
				if(k==3&&i>3)f[0][i]=min(f[0][i],f[0][i-3]);
				f[0][i]+=1ll*v[F[i]];
			}
			printf("%lld\n",f[0][tot]);
		}
		else{
			int lca=LCA(s,t);
			printf("%lld\n",sum[s]+sum[t]-2ll*sum[lca]+v[lca]);
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
/*
15 100 1
1 2 1 1 1 2 1 1 1 1 1 1 1 1 1
1 2 2 4 4 8 4 9 5 10 5 11 5 2 3 6 3 7 7 14 7 15 6 12 6 13 1 3

*/
