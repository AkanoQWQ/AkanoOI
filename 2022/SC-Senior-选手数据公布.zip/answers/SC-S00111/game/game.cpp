#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const int N=1e5+3;
const int MX=1e9+3;
int n,m,q,a[N],b[N],Log[N];
int l1,l2,r1,r2;
struct ST{
	int mx,mn,cl1,cl2;//1>=0,2<0
}sta[19][N],stb[19][N];
void Init(){
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;++i){
		scanf("%d",&a[i]);
		if(a[i]<0)sta[0][i]=ST{a[i],a[i],MX,a[i]};
		else sta[0][i]=ST{a[i],a[i],a[i],-MX};
	}
	for(int i=1;i<=m;++i){
		scanf("%d",&b[i]);
		if(b[i]<0)stb[0][i]=ST{b[i],b[i],MX,b[i]};
		else stb[0][i]=ST{b[i],b[i],b[i],-MX};
	}
	Log[1]=0;
	for(int i=2;i<=max(n,m);++i){
		Log[i]=Log[i>>1]+1; 
	}
	for(int i=1;i<=18;++i){
		for(int j=1;j+(1<<i)-1<=n;++j){
			sta[i][j].mx=max(sta[i-1][j].mx,sta[i-1][j+(1<<(i-1))].mx);
			sta[i][j].mn=min(sta[i-1][j].mn,sta[i-1][j+(1<<(i-1))].mn);
			sta[i][j].cl1=min(sta[i-1][j].cl1,sta[i-1][j+(1<<(i-1))].cl1);
			sta[i][j].cl2=max(sta[i-1][j].cl2,sta[i-1][j+(1<<(i-1))].cl2);
		}
	}
	for(int i=1;i<=18;++i){
		for(int j=1;j+(1<<i)-1<=m;++j){
			stb[i][j].mx=max(stb[i-1][j].mx,stb[i-1][j+(1<<(i-1))].mx);
			stb[i][j].mn=min(stb[i-1][j].mn,stb[i-1][j+(1<<(i-1))].mn);
			stb[i][j].cl1=min(stb[i-1][j].cl1,stb[i-1][j+(1<<(i-1))].cl1);
			stb[i][j].cl2=max(stb[i-1][j].cl2,stb[i-1][j+(1<<(i-1))].cl2);
		}
	}
	return;
}
ST Querya(int l,int r){
	int len=Log[r-l+1];
	ST ret;
	ret.mx=max(sta[len][l].mx,sta[len][r-(1<<len)+1].mx);
	ret.mn=min(sta[len][l].mn,sta[len][r-(1<<len)+1].mn);
	ret.cl1=min(sta[len][l].cl1,sta[len][r-(1<<len)+1].cl1);
	ret.cl2=max(sta[len][l].cl2,sta[len][r-(1<<len)+1].cl2);
	return ret;
}
ST Queryb(int l,int r){
	int len=Log[r-l+1];
	ST ret;
	ret.mx=max(stb[len][l].mx,stb[len][r-(1<<len)+1].mx);
	ret.mn=min(stb[len][l].mn,stb[len][r-(1<<len)+1].mn);
	ret.cl1=min(stb[len][l].cl1,stb[len][r-(1<<len)+1].cl1);
	ret.cl2=max(stb[len][l].cl2,stb[len][r-(1<<len)+1].cl2);
	return ret;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	Init();
	while(q--){
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		ST A=Querya(l1,r1),B=Queryb(l2,r2);
		LL ans;
		if(B.mn>=0){
			ans=min(1ll*A.mx*B.mx,1ll*A.mx*B.mn);
			printf("%lld\n",ans);
			continue;
		}
		if(B.mx<=0){
			ans=min(1ll*A.mn*B.mx,1ll*A.mn*B.mn);
			printf("%lld\n",ans);
			continue;
		}
		ans=-1e18-3;
		if(A.cl1!=MX)ans=max(ans,1ll*A.cl1*B.mn);
		if(A.cl2!=-MX)ans=max(ans,1ll*A.cl2*B.mx);
		printf("%lld\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
