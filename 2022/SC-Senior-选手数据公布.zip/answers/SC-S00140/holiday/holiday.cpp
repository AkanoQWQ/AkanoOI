#include<bits/stdc++.h>
#define ll long long
const int MAXN=3000;
const ll inf=1e18+100;
using namespace std;
ll n,m,K;
ll val[MAXN];
ll dis[MAXN][MAXN];
ll dp[MAXN][10];
ll ans;
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>K;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++) dis[i][j]=inf;
	}
	for(int i=2;i<=n;i++) cin>>val[i];
	for(int i=1;i<=m;i++){
		int u,v;
		cin>>u>>v;
		dis[u][v]=dis[v][u]=0;
	}
	for(int k=1;k<=n;k++){
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(dis[i][k]!=inf&&dis[k][j]!=inf){
					dis[i][j]=min(dis[i][j],dis[i][k]+dis[k][j]+1);
				}
			}
		}
	}
	for(int i=2;i<=n;i++){
		if(dis[1][i]<=K){
			dp[i][1]=val[i];
		}
	}
    for(int i=1;i<=n;i++){
    	for(int j=i;j<=n;j++){
    		if(i==j) continue;
    		for(int k=2;k<=4;k++){
    			if(dis[i][j]<=K){
    				dp[j][k]=max(dp[i][k-1]+val[j],dp[j][k]);
				}
			}
		}
	}
	for(int i=2;i<=n;i++) {
        if(dis[i][1]<=K) ans=max(ans,dp[i][4]);
	}
	cout<<ans<<endl;
}
