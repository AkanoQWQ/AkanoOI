#include<bits/stdc++.h>
#define lson rt<<1
#define rson rt<<1|1
#define mid (l+r)/2
#define ll long long
const int MAXN=2e5+100;
const ll inf=1e18+100;
using namespace std;
int n,m,q;
ll a[MAXN],b[MAXN];
ll tree_Max[MAXN*4];
ll tree_Min[MAXN*4];
ll tree_D[MAXN*4];
ll tree_X[MAXN*4];
ll tree_max[MAXN*4];
ll tree_min[MAXN*4];
void build_b(int rt,int l,int r){
	if(l==r){
		tree_Min[rt]=b[l];
		tree_Max[rt]=b[l];
		return ;
	}
	build_b(lson,l,mid);
	build_b(rson,mid+1,r);
	tree_Min[rt]=min(tree_Min[lson],tree_Min[rson]);
	tree_Max[rt]=max(tree_Max[lson],tree_Max[rson]);
}
void build_a(int rt,int l,int r){
	if(l==r){
		tree_max[rt]=a[l];
		tree_min[rt]=a[l];
		if(a[l]<0){
			tree_D[rt]=inf;
			tree_X[rt]=a[l];
		}
		if(a[l]>0){
			tree_X[rt]=-inf;
			tree_D[rt]=a[l];
		}
		if(a[l]==0){
			tree_D[rt]=a[l];
			tree_X[rt]=a[l];
		}
		return ;
	}
	build_a(lson,l,mid);
	build_a(rson,mid+1,r);
	tree_D[rt]=min(tree_D[lson],tree_D[rson]);
	tree_X[rt]=max(tree_X[lson],tree_X[rson]);
	tree_max[rt]=max(tree_max[lson],tree_max[rson]);
	tree_min[rt]=min(tree_min[lson],tree_min[rson]);
}
ll query_D(int rt,int l,int r,int ql,int qr){
	if(ql<=l&&r<=qr) return tree_D[rt];
	ll ans=inf;
	if(ql<=mid) ans=min(ans,query_D(lson,l,mid,ql,qr));
	if(qr>mid) ans=min(ans,query_D(rson,mid+1,r,ql,qr));
	return ans;
}
ll query_X(int rt,int l,int r,int ql,int qr){
	if(ql<=l&&r<=qr) return tree_X[rt];
	ll ans=-inf;
	if(ql<=mid) ans=max(ans,query_X(lson,l,mid,ql,qr));
	if(qr>mid) ans=max(ans,query_X(rson,mid+1,r,ql,qr));
	return ans;
}
ll query_max(int rt,int l,int r,int ql,int qr){
	if(ql<=l&&r<=qr) return tree_Max[rt];
	ll ans=-inf;
	if(ql<=mid) ans=max(ans,query_max(lson,l,mid,ql,qr));
	if(qr>mid) ans=max(ans,query_max(rson,mid+1,r,ql,qr));
	return ans;
}
ll query_min(int rt,int l,int r,int ql,int qr){
	if(ql<=l&&r<=qr) return tree_Min[rt];
	ll ans=inf;
	if(ql<=mid) ans=min(ans,query_min(lson,l,mid,ql,qr));
	if(qr>mid) ans=min(ans,query_min(rson,mid+1,r,ql,qr));
	return ans;
}
ll query_maxa(int rt,int l,int r,int ql,int qr){
	if(ql<=l&&r<=qr) return tree_max[rt];
	ll ans=-inf;
	if(ql<=mid) ans=max(ans,query_maxa(lson,l,mid,ql,qr));
	if(qr>mid) ans=max(ans,query_maxa(rson,mid+1,r,ql,qr));
	return ans;
}
ll query_mina(int rt,int l,int r,int ql,int qr){
	if(ql<=l&&r<=qr) return tree_min[rt];
	ll ans=inf;
	if(ql<=mid) ans=min(ans,query_mina(lson,l,mid,ql,qr));
	if(qr>mid) ans=min(ans,query_mina(rson,mid+1,r,ql,qr));
	return ans;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=1;i<=m;i++) cin>>b[i];
	build_a(1,1,n);
	build_b(1,1,m);
	for(int i=1;i<=q;i++){
		int la,ra,lb,rb;
		ll ans=-inf;
		cin>>la>>ra>>lb>>rb;
		ll maxx=query_max(1,1,m,lb,rb);
		ll minn=query_min(1,1,m,lb,rb);
		ll D=query_D(1,1,n,la,ra);
		ll X=query_X(1,1,n,la,ra);
		//cout<<maxx<<" "<<minn<<endl;
		//cout<<D<<" "<<X<<endl;
//		if(maxx<0) cout<<maxx*query_mina(1,1,n,la,ra)<<endl;
//		else if(minn>0) cout<<minn*query_maxa(1,1,n,la,ra)<<endl;
//		else {
//		    
//		}
//		
//		cout<<maxx<<" "<<minn<<endl;
//		for(int j=la;j<=ra;j++){
//			if(maxx*a[j]<minn*a[j]) ans=max(ans,maxx*a[j]);
//			else ans=max(ans,minn*a[j]);
//		}
//		cout<<ans<<endl;
//		
        if(maxx<0||minn>0){
        	for(int j=la;j<=ra;j++){
			if(maxx*a[j]<minn*a[j]) ans=max(ans,maxx*a[j]);
			else ans=max(ans,minn*a[j]);
		    }
		    cout<<ans<<endl;
		} else {
//			cout<<maxx*X<<" "<<minn*D<<endl;
            if(D==inf) cout<<maxx*X<<endl;
            else if(X==-inf) cout<<minn*D<<endl;
            else cout<<max(maxx*X,minn*D)<<endl;
//			ans=max(maxx*X,minn*D);
//			cout<<ans<<endl;
		}
	}
}
