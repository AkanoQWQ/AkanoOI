#include<stdio.h>
#include<algorithm>
using namespace std ;
inline int read()
{
	int ans=0,f=1;
	char c=getchar();
	while(c<'0' || c>'9'){if(c=='-')f=-1;c=getchar();}
	while('0'<=c && c<='9'){ans=ans*10+c-'0';c=getchar();}
	return ans*f;
}
int n,m,sd[50005];
char us[5005][5005];
struct side
{
	int to,nxt;
}a[50005];
bool f(int d)
{
	for(int fla,sid=sd[d],nd=a[sid].to;nd;sid=a[sid].nxt,nd=a[sid].to)
	{
		if(us[d][nd]==1)
		{
			return 1 ;
		}
		if(us[d][nd]==-1)
		{
			continue;
		}
		us[d][nd]=1;
		fla=f(nd);
		us[d][nd]=0;
		if(fla==1)
		{
			return 1 ;
		}
	}
	return 0 ;
}
int main ()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read();m=read();
	int u,v;
	for(int i=1;i<=m;i++)
	{
		u=read();v=read();
		a[i].nxt=sd[u];
		a[i].to=v;
		sd[u]=i;
	}
	int q=read(),t;
	while(q--)
	{
		t=read();
		if(t==1)
		{
			u=read();v=read();
			us[u][v]=-1;
		}
		if(t==2)
		{
			u=read();
			for(int i=1;i<=n;i++)
			{
				us[u][i]=-1;
			}
		}
		if(t==3)
		{
			u=read();v=read();
			us[u][v]=0;
		}
		if(t==4)
		{
			u=read();
			for(int i=1;i<=n;i++)
			{
				us[u][i]=0;
			}
		}
		bool fg=1;
		for(int i=1;i<=n;i++)
		{
			if(f(i))
			{
				fg=0;
				printf("YES\n");
				break;
			}
		}
		if(fg)printf("NO\n");
	}
	fclose(stdout);
	fclose(stdin);
	return 0 ;
}
