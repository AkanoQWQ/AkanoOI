#include<stdio.h>
#include<algorithm>
#define ll long long
using namespace std ;
inline ll read()
{
	int ans=0,f=1;
	char c=getchar();
	while(c<'0' || c>'9'){if(c=='-')f=-1;c=getchar();}
	while('0'<=c && c<='9'){ans=ans*10+c-'0';c=getchar();}
	return ans*f;
}
ll a[2505];
bool book[2505];
int n,m,k,sid[2505][2505];
inline void f_read()
{
	n=read();m=read();k=read();
	for(int i=2;i<=n;i++){a[i]=read();}
	int x,y;
	for(int i=0;i<m;i++)
	{
		x=read();y=read();
		sid[x][++sid[x][0]]=y;
		sid[y][++sid[y][0]]=x;
	}
	return ;
}
ll dfs(int lt,int dep,int k1)
{
	if(0==dep)
	{
		if(lt==1)return 0 ;
		return -1 ;
	}
	ll ans=0,an;
	for(int i=1;i<=sid[lt][0];i++)
	{
		if(!book[i])
		{
			book[i]=1;
			an=dfs(sid[lt][i],dep-1,k+1);
			book[i]=0;
			if(an==-1)continue;
			ans=max(ans,an+a[lt]);
		}
		if(k1>=1)
		{
			if(book[i])
			{
				an=dfs(sid[lt][i],dep,k1-1);
				if(an==-1)continue;
				ans=max(ans,an);
			}
			else
			{
				book[i]=1;
				an=dfs(sid[lt][i],dep,k1-1);
				book[i]=0;
				if(an==-1)continue;
				ans=max(ans,an);
			}
		}
	}
	return ans;
}
int main ()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	f_read();
	printf("%lld",dfs(1,5,k+1));
	fclose(stdout);
	fclose(stdin);
	return 0 ;
}
