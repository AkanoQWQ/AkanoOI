#include<stdio.h>
#include<algorithm>
#define MX 0x7ffffff0
using namespace std ;
inline int read()
{
	int ans=0,f=1;
	char c=getchar();
	while(c<'0' || c>'9'){if(c=='-')f=-1;c=getchar();}
	while('0'<=c && c<='9'){ans=ans*10+c-'0';c=getchar();}
	return ans*f;
}
int n,m,q,a[100005],b[100005];
int main ()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();m=read();q=read();
	for(int i=1;i<=n;i++)a[i]=read();
	for(int i=1;i<=m;i++)b[i]=read();
	int l1,r1,l2,r2;
	while(q--)
	{
		l1=read();r1=read();l2=read();r2=read();
		if(l1==r1)
		{
			if(l2==r2)
			{
				printf("%d\n",a[l1]*b[r2]);
				continue;
			}
			int mi=MX;
			for(int i=l2;i<=r2;i++)
			{
				mi=min(mi,b[i]);
			}
			printf("%d\n",a[l1]*mi);
			continue;
		}
		if(l2==r2)
		{
			int mx=-MX;
			for(int i=l2;i<=r2;i++)
			{
				mx=max(mx,a[i]*b[l2]);
			}
			printf("%d\n",mx);
			continue;
		}
		int ix,mx=-MX,in,mn=MX;
		for(int i=l1;i<=r1;i++)
		{
			for(int j=l2;j<=r2;j++)
			{
				mx=max(mx,a[i]*b[i]);
			}
			if(mn>mx)
			{
				ix=i;
				mn=mx;
			}
		}
		mx=-MX,in,mn=MX;
		for(int i=l2;i<=r2;i++)
		{
			for(int j=l1;j<=r1;j++)
			{
				mn=min(mn,a[i]*b[i]);
			}
			if(mx<mn)
			{
				in=i;
				mx=mn;
			}
		}
		printf("%d\n",a[ix]*a[in]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0 ;
}
