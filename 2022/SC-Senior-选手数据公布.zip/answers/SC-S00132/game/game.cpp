#include<bits/stdc++.h>
#define N 100001
#define inf 1000000000
using namespace std;
int a[N],b[N],amax,amax0,amin,amin0,bmax,bmax0,bmin,bmin0;
int n,m,q,l1,r1,l2,r2,x,y;
int read(){
	int x=0,f=1;char c=getchar();
	if(c=='-') f=-1,c=getchar();
	while('0'<=c&&c<='9') x=(x<<3)+(x<<1)+c-'0',c=getchar();
	return x*f;
}
bool x0(int l,int r,int s[]){
	for(int i=l;i<=r;i++)
		if(!s[i]) return 1;
	return 0;
}
void xm(int l,int r,int s[],int &max,int &max0,int &min,int &min0){
	max=min=s[l],max0=-inf,min0=inf;
	for(int i=l;i<=r;i++){
		if(s[i]>max) max=s[i];
		if(s[i]<=0&&s[i]>max0) max0=s[i];
		if(s[i]<min) min=s[i];
		if(s[i]>=0&&s[i]<min0) min0=s[i];
	}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=m;i++) b[i]=read();
	while(q--){
		l1=read(),r1=read(),l2=read(),r2=read();
		xm(l1,r1,a,amax,amax0,amin,amin0);
		xm(l2,r2,b,bmax,bmax0,bmin,bmin0);
		x=amax,y=bmin;
		if(amin>0){
			y=bmin;
			if(bmin>0) x=amax;
			else x=amin;
		}else if(amax<0){
			y=bmax;
			if(bmax<0) x=amin;
			else x=amax;
		}else{
			if(bmin>0) x=amax,y=bmin;
			else if(bmax<0) x=amin,y=bmax;
			else{
				printf("%d\n",max(amin0*bmin,amax0*bmax));
				continue;
			}
		}printf("%d\n",x*y);
	}
	return 0;
}
