#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	printf("--------------------------------");
	printf("Process exited after 1 year with return value 0");
	printf("�밴���������. . .");
	return 0;
}
