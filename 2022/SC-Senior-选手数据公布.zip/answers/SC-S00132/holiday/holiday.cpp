#include<bits/stdc++.h>
using namespace std;
bool a[2501][2501],b[2501][2501],d[2501];
long long p[2501],ans=0;
int n,m,k,x,y;
void f(int u,int i,int k){
	if(!k) return;
	for(int j=1;j<=n;j++)
		if(a[i][j]&&!b[u][j]) b[u][j]=1,f(u,j,k-1);
}
void g(int i,int k,long long q){
	if(k==4){
		if(b[i][1]&&q>ans) ans=q;
		return;
	}
	for(int j=2;j<=n;j++)
		if(b[i][j]&&!d[j]) d[j]=1,g(j,k+1,q+p[j]),d[j]=0;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);k++;
	for(int i=2;i<=n;i++)
		scanf("%lld",&p[i]);
	while(m--){
		scanf("%d%d",&x,&y);
		if(x!=y) a[x][y]=a[y][x]=1;
	}
	for(int i=1;i<=n;i++)
		b[i][i]=1,f(i,i,k),b[i][i]=0;
	d[1]=1,g(1,0,0);
	printf("%lld",ans);
	return 0;
}
