#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m,u,v,q,t;
	scanf("%d%d",&n,&m);
	while(m--) scanf("%d%d",&u,&v);
	scanf("%d",&q);
	while(q--){
		scanf("%d",&t);printf("NO\n");
		if(t==1||t==3) scanf("%d%d",&u,&v);
		else scanf("%d",&u);
	}
	return 0;
}
