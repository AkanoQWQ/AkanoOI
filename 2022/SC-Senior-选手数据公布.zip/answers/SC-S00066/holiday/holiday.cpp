#include<iostream>

using namespace std;
typedef long long ll;//1e19 --> __int128
const int N = 5010, M = 20010;

int n, m, k;
ll score[N];
struct Edge{
	int from, to, next;
	Edge(int from=0, int to=0, int next=0) : from(from), to(to), next(next) {}
} edge[M];
int h[N], cnt;

bool vis[N], dis[N];
ll ans, maxx;
ll ss[N][N], tt;

void get(int x,int y, ll s, int cnt)//��ǰλ�ã� �÷�, ת������ 
{
	if(x == y)
		tt = max(tt, s);
	for(int i=h[x]; i; i=edge[i].next)//ת�� 
	{
		int u = edge[i].from;
		int v = edge[i].to;
		if(cnt<=k)
		{
			if(s==0)
				get(v, y, score[u], cnt+1);
			else
				get(v, y, s, cnt+1);
		}
	}
}

void dis1(int st, int cnt)
{
	for(int i=h[st]; i; i = edge[i].next)
	{
		int v = edge[i].to;
		if(cnt<=k)
		{
			dis[v] = 1;
			dis1(v, cnt+1);
		}
	}
}
int main()
{
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	for(int i=2; i<=n; i++)
		scanf("%lld", &score[i]);
	for(int i=1; i<=m; i++)
	{
		int u, v;
		scanf("%d%d", &u, &v);
		edge[++cnt] = Edge(v, u, h[v]);
		h[v] = cnt;
		edge[++cnt] = Edge(u, v, h[u]);
		h[u] = cnt;
	}

	for(int i=2; i<=n; i++)//�ҵ���������������� 
	{
		for(int j=1; j<=n; j++)
		{
			tt = 0;
			get(i, j, 0, 0);
			ss[i][j] = tt;
		}	
	}
	dis1(1, 0);
	for(int i=1; i<=n; i++)
	{
		ans = 0;
		if(vis[i]) continue;
		if(!dis[i]) continue;
		vis[i] = 1;
		for(int j=1; j<=n; j++)
		{
			if(vis[j]) continue;
			if(ss[i][j]==0) continue;
			vis[j] = 1;
			ans += ss[i][j];
			for(int k=1; k<=n; k++)
			{
				if(vis[k]) continue;
				if(ss[j][k]==0) continue;
				vis[k] = 1;
				ans += ss[j][k];
				for(int o=1; o<=n; o++)
				{
					if(vis[o]) continue;
					if(ss[k][o]==0) continue;
					if(ss[o][1]==0) continue;
					vis[o] = 1;
					ans += ss[k][o];
					ans += ss[o][1];
					vis[o] = 0;
					if(ans==30)
						cout<<i<<" "<<j<<" "<<k<<" "<<o<<"\n";
					maxx = max(maxx, ans);
					ans -= ss[k][o];
					ans -= ss[o][1];
				}
				vis[k] = 0;
				ans -= ss[j][k];
			}
			vis[j] = 0;
			ans -= ss[i][j];
		}
		vis[i] = 0;
	}
	
	cout<<maxx<<endl;
	return 0;
}
