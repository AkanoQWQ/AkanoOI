//����-->50pts
//o(nmq)

#include<iostream>

using namespace std;
typedef long long ll;
const int N = 1e4+10;

int n, m, q;
ll a[N], b[N], c[N][N], minn[N];

int main()
{
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	
	scanf("%d%d%d", &n, &m, &q);
	for(int i=1; i<=n; i++)
	{
		scanf("%lld", &a[i]);
	}
	for(int i=1; i<=m; i++)
	{
		scanf("%lld", &b[i]);
	}
	for(int i=1; i<=n; i++)
	{
		for(int j=1; j<=m; j++)
		{
			c[i][j] = a[i]*b[j];
	//		minn[i] = min(minn[i], c[i][j]);
		}
	}
	
//	for(int i=1; i<=n; i++)
//	{
//		for(int j=1; j<=m; j++)
//			cout<<c[i][j]<<" ";
//		cout<<endl;
//	}
	ll ans;
	for(int k=1; k<=q; k++)
	{
		int l1, r1, l2, r2;
		scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
		ll tmp = -((ll)1<<60);
		for(int i=l1; i<=r1; i++)
		{	
			ans = ((ll)1<<60);
			for(int j=l2; j<=r2; j++)
			{
				ans = min(ans, c[i][j]);
			}
			if(i==l1)
				tmp = ans;
			if(i!=l1) 
				ans = max(tmp, ans), tmp = ans;

		}
		cout<<ans<<"\n";
	}
	return 0;
}
