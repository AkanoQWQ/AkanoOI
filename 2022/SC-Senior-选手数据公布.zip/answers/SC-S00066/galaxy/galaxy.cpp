//��������n, ÿ���ݵ���һ�����Ⱥ�һ����� 
//problem : op�������in & out 
#include<iostream>
#include<unordered_map>

using namespace std;
const int N = 2e6+10;

int n, m, q;
struct Edge{
	int from, to, next;
	bool isok;
	Edge(int from=0, int to=0, int next = 0, bool isok=0) : from(from), to(to), next(next), isok(isok) {}
} edge[N];
int cnt, out[N], in[N];
int h[N];

int find1(int u, int v)
{
	for(int i=1; i<=cnt; i++)
	{
		if(edge[i].from==u && edge[i].to==v)
		{
			return i;
		}
	}
	return -1;
}

int find2(int u, int last)
{
	for(int i=last; i<=cnt; i++)
	{
		if(edge[i].to==u)
		{
			return i;
		}
	}	
	return -1;
}

void op1(int u, int v)
{
	int t = find1(u, v);
	if(edge[t].isok == 0)
		return;
		
	edge[t].isok = 0;
	out[u]--;
	in[v]--;
}

void op2(int u, int v)
{
	int t = 1;
	while(t!=-1)
	{
		if(edge[t].isok==1)
		{
			int from = edge[t].from, to = edge[t].to;
			edge[t].isok = 0;
			out[from]--;
			in[to]--;
		}
		t = find2(u, t+1);
	}
}

void op3(int u, int v)
{
	int t = find1(u, v);
	if(edge[t].isok == 1)
		return;
		
	edge[t].isok = 1;
	out[u]++;
	in[v]++;
}

void op4(int u, int v)
{
	int t = 1;
	while(t!=-1)
	{
		if(edge[t].isok==0)
		{
			int from = edge[t].from, to = edge[t].to;
			edge[t].isok = 1;
			out[from]++;
			in[to]++;
		}
		t = find2(u, t+1);
	}
}

bool judge(int st, int ed)
{
	if(st==ed)
		return true;
	for(int i=h[st]; i; i = edge[i].next)
	{
		int v = edge[i].to;
		if(judge(v, ed))
			return true;
	}
	return false;
}

bool check()
{
	for(int i=1; i<=n; i++)
	{
		if(in[i]!=1 && out[i]!=1)
			return false;
		if(!judge(i, i))
			return false;
	}
	
	return true;
}

int main()
{
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	for(int i=1; i<=m; i++)
	{
		int u, v;
		scanf("%d%d", &u, &v);
		edge[++cnt] = Edge(u, v, h[u], 1);
		h[u] = cnt;
		out[u]++, in[v]++;
	}
	scanf("%d", &q);

	for(int i=1; i<=q; i++)
	{
		int op, u, v;
		scanf("%d", &op);
		
		if(op==1)
		{
			scanf("%d%d", &u, &v);
			op1(u, v);
		}
		else if(op==2)
		{
			
			scanf("%d", &u);
			op2(u, v);
		}
		else if(op==3)
		{
			scanf("%d%d", &u, &v);
			op3(u, v);
		}
		else if(op==4)
		{
			scanf("%d", &u);
			op4(u, v);
		}
//		if(i==3)
//			for(int j=1; j<=n; j++)
//				cout<<out[j]<<" "<<in[j]<<"\n";
//			cout<<"\n-----------------------\n"; 
		if(check())
			cout<<"YES\n";
		else
			cout<<"NO\n";
		
	}
	return 0;
}
