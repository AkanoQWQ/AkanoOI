#include<bits/stdc++.h>
#define elif else if
#define N 100001
typedef long long LL;
int in(){
   int s=0;char c=0;bool k=false;
   while(c<48||c>57){
	   c=getchar();
	   if(c=='-')k=true;
	}
	while(c>=48&&c<=57){
		s=(s<<1)+(s<<3)+c-48;
		c=getchar();
	}
	if(k)return ~(s-1);
	else return s;
}
int a[10101],b[10101],
c[10101][10101],
n,m,q,i,j;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=in(),m=in(),q=in();
	for(i=1;i<=n;i++)
		a[i]=in();
	for(i=1;i<=m;i++)
		b[i]=in();
	for(i=1;i<=n;i++)
		for(j=1;j<=m;j++)
			c[i][j]=a[i]*b[j];
	for(i=1;i<=q;i++);
	return 0;
}

