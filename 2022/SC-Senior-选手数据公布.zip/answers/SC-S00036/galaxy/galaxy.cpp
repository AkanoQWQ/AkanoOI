#include<bits/stdc++.h>
#define elif else if
#define N 100001
typedef long long LL;
int n,m,q,t,x,y,i,j,ans,
bookp[1001];
struct hol{								//ͼ���� 
	bool la[1001][2];						//��uΪ���ڵľݵ�  la[v][0]--> �Ƿ��г涴��v��u la[v][1]�Ƿ񱻴ݻ� 
	bool to[1001][2];						//��uΪ��ڵľݵ�  to[v][0]--> �Ƿ��г涴��u��v la[v][1]�Ƿ񱻴ݻ� 
	int ansl;							//��ǰ�ݵ�������� 
	int anst;							//��ǰ�ݵ�������� 
}ho[1001];
int in(){								 //���
   int s=0;char c=0;
   while(c<48||c>57){
	   c=getchar();
	}
	while(c>=48&&c<=57){
		s=(s<<1)+(s<<3)+c-48;
		c=getchar();
	}
	return s;
}
void Addl(int u,int v){					//������uΪ��㣬vΪ�յ�ĳ涴 
	ho[u].to[v][0]=1;					//�涴���� 
	ho[u].to[v][1]=1;					//���״̬  
	ho[v].la[u][0]=1;					//ͬ��1 
	ho[v].la[u][1]=1;					//ͬ��2 
	ho[v].ansl++;
	ho[u].anst++;
	return;
}
void Dell(int u,int v){					//�ݻ���uΪ��㣬vΪ�յ�ĳ涴 
	ho[u].to[v][1]=0;
	ho[v].la[u][1]=0;
	ho[u].anst--;
	ho[v].ansl--;
	return;
}
void Delp(int u){						//�ݻپݵ�u 
	for(int k=1;k<=n;k++)
		if(ho[u].la[k][1]){
			ho[u].la[k][1]=0;
			ho[u].ansl--;
			ho[k].to[u][1]=0;
			ho[k].anst--;
		}
	return;
}
void Fixl(int u,int v){					//�޸���uΪ��㣬vΪ�յ�ĳ涴 
	ho[u].to[v][1]=1;
	ho[v].la[u][1]=1;
	ho[u].anst++;
	ho[v].ansl++;
	return;
}
void Fixp(int u){						//�޸��ݵ�u 
	for(int k=1;k<=n;k++)
		if(ho[u].la[k][0]&&!ho[u].la[k][1]){
			ho[u].la[k][1]=1;
			ho[u].ansl++;
			ho[k].to[u][1]=1;
			ho[k].anst++;
		}
	for(int k=1;k<=n;k++)
		if(ho[u].to[k][0]&&!ho[u].to[k][1]){
			ho[u].to[k][1]=1;
			ho[u].anst++;
			ho[k].la[u][1]=1;
			ho[k].ansl++;
		}
	return;
}
void ch1(){
	for(int k=1;k<=n;k++){
		if(ho[k].anst==1){
			if(!bookp[k]){
				bookp[k]=1;
				ans++;
			}
		}else{
			if(bookp[k]){
				bookp[k]=0;
				ans--;
			}
		}
	}
	return;
}
bool ch2(){
	for(int ps=1;ps<=n;ps++){
		bool book[n+1];
		memset(book,false,sizeof(book));
		int pn=ps,ans1=0;
		while(ans1<=n&&!book[pn]){
			book[pn]=1;
			for(int pt=1;pt<=n;pt++)
				if(ho[pn].to[pt]){
					pn=pt,ans1++;
					break;
				}
		}
		if(ans1>n)return false;
	}
	return true;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=in();m=in();
	for(i=1;i<=m;i++){
		x=in(),y=in();
		Addl(x,y);
	}
	ch1();
	q=in();
	for(i=1;i<=q;i++){
		t=in();
		if(t==1){
			x=in(),y=in();
			Dell(x,y);
			ch1();
		}else{
			if(t==2){
				x=in();
				Delp(x);
				ch1();
			}else{
				if(t==3){
					x=in(),y=in();
					Fixl(x,y);
					ch1();
				}else{
					if(t==4){
						x=in();
						Fixp(x);
						ch1();
					}
				}
			}
		}
		if(ans==n){
			if(ch2())
				printf("YES\n");
		}
		else{
			printf("NO\n");
		}
	}
	return 0;
}
