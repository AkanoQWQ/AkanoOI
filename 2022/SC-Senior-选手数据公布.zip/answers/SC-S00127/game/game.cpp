#include<bits/stdc++.h>
using namespace std;
long long n,m,q,x[100001],y[100001],ansp1,ansp2,l1,r1,l2,r2,z1,z2,o1,o2;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	for(long long i=1;i<=n;i++)
	{
		scanf("%lld",&x[i]);
	}
	for(long long i=1;i<=m;i++)
	{
		scanf("%lld",&y[i]);
	}
	while(q--)
	{
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		bool p1=1,p2=1;
		z1=0,z2=0;
		o1=0,o2=0;
		for(long long i=l1;i<=r1;i++)
		{
			if(x[i]<=0)
			{
				p1=0;
				if(x[i]==0)
				z1=1;
			}
			else
			o1=1;
		}
		for(long long i=l2;i<=r2;i++)
		{
			if(y[i]<=0)
			{
				p2=0;
				if(y[i]==0)
				z2=1;
			}
			else
			o2=1;
		}
		if(p1&&p2)
		{
			ansp1=-1e9;
			ansp2=1e9;
			for(long long i=l1;i<=r1;i++)ansp1=max(ansp1,x[i]);
			for(long long i=l2;i<=r2;i++)ansp2=min(ansp2,y[i]);
			printf("%lld\n",ansp1*ansp2);
			continue;
		}
		if(l1==r1)
		{
			if(x[l1]==0)
			{
				printf("0\n");
				continue;
			}
			else
			{
				if(x[l1]>0)
				{
					ansp2=1e9;
					for(long long i=l2;i<=r2;i++)ansp2=min(ansp2,y[i]);
					printf("%lld\n",x[l1]*ansp2);
					continue;
				}
				else
				{
					ansp2=-1e9;
					for(long long i=l2;i<=r2;i++)ansp2=max(ansp2,y[i]);
					printf("%lld\n",x[l1]*ansp2);
					continue;
				}
			}
		}
		if(l2==r2)
		{
			if(y[l2]==0)
			{
				printf("0\n");
				continue;
			}
			else
			{
				if(y[l2]>0)
				{
					ansp1=-1e9;
					for(long long i=l1;i<=r1;i++)ansp1=max(ansp1,x[i]);
					printf("%lld\n",y[l2]*ansp1);
					continue;
				}
				else
				{
					ansp1=1e9;
					for(long long i=l1;i<=r1;i++)ansp1=min(ansp1,x[i]);
					printf("%lld\n",x[l2]*ansp1);
					continue;
				}
			}
		}
		if(p1&&!p2)
		{
			ansp1=1e9;
			ansp2=1e9;
			for(long long i=l1;i<=r1;i++)ansp1=min(ansp1,x[i]);
			for(long long i=l2;i<=r2;i++)ansp2=min(ansp2,y[i]);
			printf("%lld\n",ansp1*ansp2);
			continue;
		}
		if(!p1&&p2)
		{
			ansp1=-1e9;
			ansp2=1e9;
			for(long long i=l1;i<=r1;i++)ansp1=max(ansp1,x[i]);
			for(long long i=l2;i<=r2;i++)ansp2=min(ansp2,y[i]);
			printf("%lld\n",ansp1*ansp2);
			continue;
		}
		if(!p1&&!p2)
		{
			if(z1||z2)
			{
				printf("0\n");
				continue;
			}
			else
			{
				if(o1&&o2)
				{
					ansp1=1e9;
					ansp2=-1e9;
					for(long long i=l1;i<=r1;i++)ansp1=min(ansp1,x[i]);
					for(long long i=l2;i<=r2;i++)ansp2=max(ansp2,y[i]);
				}
				if(o1&&!o2)
				{
					ansp1=1e9;
					ansp2=1e9;
					for(long long i=l1;i<=r1;i++)ansp1=min(ansp1,x[i]);
					for(long long i=l2;i<=r2;i++)ansp2=min(ansp2,y[i]);
				}
				if(!o1&&o2)
				{
					ansp1=1e9;
					ansp2=-1e9;
					for(long long i=l1;i<=r1;i++)ansp1=min(ansp1,x[i]);
					for(long long i=l2;i<=r2;i++)ansp2=max(ansp2,y[i]);
				}
				if(!o1&&!o2)
				{
					ansp1=-1e9;
					ansp2=1e9;
					for(long long i=l1;i<=r1;i++)ansp1=max(ansp1,x[i]);
					for(long long i=l2;i<=r2;i++)ansp2=min(ansp2,y[i]);
				}
			}
			printf("%lld\n",ansp1*ansp2);
			continue;
		}
	}
	return 0;
}
