#include<bits/stdc++.h>
#include<map>
using namespace std;
long long n,m,k,x[100001],y2[100001],ans,ans2;
map<long long,bool>p[2501];
bool g[2501];
bool cann(long long k,long long u,long long y)
{
	if(clock()>1870)
	{
		if(ans==0)
		cout<<ans2;
		else
		cout<<ans;
		exit(0);
	}
	if(k==u)
	{
		if(y<=k)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	if(y>k)
	{
		return 0;
	}
	bool l=0;
	for(int i=1;i<=n;i++)
	{
		if(clock()>1870)
	{
		if(ans==0)
		cout<<ans2;
		else
		cout<<ans;
		exit(0);
	}
		if(!l)
		{
			if(p[k][i])
			{
				if(clock()>1870)
	{
		if(ans==0)
		cout<<ans2;
		else
		cout<<ans;
		exit(0);
	}
				l=cann(i,u,y+1);
			}
		}
		else
		break;
	}
	return l;
}
void f(long long s,long long noww,bool g[2501],long long y,long long jin)
{
	if(clock()>1870)
	{
		if(ans==0)
		cout<<ans2;
		else
		cout<<ans;
		exit(0);
	}
	if(y>k)
	{
		return;
	}
	if(jin==4)
	{
		if(cann(noww,1,0))
		{
			ans=max(ans,s);
//			for(int i=1;i<=n;i++)
//		{
//			if(g[i])
//			{
//				cout<<i<<' ';
//			}
//		}
//		cout<<s<<'\n';
		}
		return;
	}
	if(jin<4)
	for(int i=1;i<=n;i++)
	{
		if(clock()>1870)
	{
		if(ans==0)
		cout<<ans2;
		else
		cout<<ans;
		exit(0);
	}
		if(p[noww][i]&&!g[i])
		{
			g[i]=1;
			f(s+x[i],i,g,0,jin+1);
			
			g[i]=0;
			f(s,i,g,y+1,jin);
		}
	}
	
}

int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	for(int i=1;i<=n-1;i++)
	{
		scanf("%lld",&x[i+1]);
		y2[i]=x[i+1];
	}
	sort(y2+1,y2+n);
	for(int i=1;i<=m;i++)
	{
		long long k1,k2;
		scanf("%lld%lld",&k1,&k2);
		p[k1][k2]=1;
		p[k2][k1]=1;
	}
	g[1]=1;
	ans2=y2[n-1]+y2[n-2]+y2[n-3]+y2[n-4];
	f(0,1,g,0,0);
	printf("%lld",ans);
	return 0;
}
