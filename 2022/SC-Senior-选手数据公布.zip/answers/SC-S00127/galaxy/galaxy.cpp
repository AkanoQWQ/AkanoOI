#include<bits/stdc++.h>
#include<map> 
using namespace std;
map<long long,bool>p[500001],k[500001];
long long n,m,q,t,w,v,u;
bool ans1[500001]={},p1[500001]={},ok;
void f(long long ap,bool r[500001])
{
	if(clock()>1030)
	return;
	if(r[ap]||ans1[ap])
	{
		for(int i=1;i<=n;i++)
		{
			if(r[i])
			{
				ans1[i]=1;
			}
		}
		ok=1;
		return;
	}
	r[ap]=1;
	for(int i=1;i<=n;i++)
	{
		if(k[ap][i])
		{
			f(i,r);
		}
	}
	return;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(int i=1;i<=m;i++)
	{
		long long k1,k2;
		scanf("%lld%lld",&k1,&k2);
		p[k1][k2]=1;
		k[k1][k2]=1;
	} 
	scanf("%lld",&q);
	while(q--)
	{
		scanf("%lld",&t);
		switch(t)
		{
			case 1:
				scanf("%lld%lld",&w,&v);
				k[w][v]=0;
				break;
			case 2:
				scanf("%lld",&u);
				for(int j=1;j<=n;j++)
				{
					if(p[u][j])
					k[u][j]=0;
				}
				break;
			case 3:
				scanf("%lld%lld",&w,&v);
				k[w][v]=1;
				break;
			case 4:
				scanf("%lld",&u);
				for(int j=1;j<=n;j++)
				{
					if(p[u][j])
					k[u][j]=1;
				}
				break;
		}
		memset(ans1,0,sizeof(ans1));
		for(int i=1;i<=n;i++)
		{
			if(ans1[i]==0)
			{
				ok=0;
				f(i,p1);
//				for(int i1=1;i1<=n;i1++)
//		{cout<<ans1[i1]<<' ';};
//cout<<'\n';
				if(!ok)
				{
					ans1[i]=0;
					break;
				}
			}
		}
		bool c=1;
		for(int i=1;i<=n;i++)
		{
			if(ans1[i]==0)
			{
				c=0;
				printf("NO\n");
				break;
			}
		}
		if(!c)
		continue;
		else
		{
			for(int i=1;i<=n;i++)
			{	
				int s=0;
				for(int j=1;j<=n;j++)
				{
					if(k[i][j])
					{
						s++;
					}
					if(s>1)
					{
						break;
					}
				}
				if(s!=1)
				{printf("NO\n");c=0;break;}
			}
			if(c)
			printf("YES\n");
		}
	}
	return 0;
} 
