#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
#include<algorithm>
#include<queue>
#include<vector>
#include<map>
using namespace std;
const int N = 2510;

int n,m,k;
long long w[N];
int g[N][N];

void floyd()
{
	for(int i = 1;i <= n;++ i)
	for(int j = 1;j <= n;++ j)
	for(int p = 1;p <= n;++ p)
	g[i][j] = g[j][i] = min(g[i][p] + g[p][j] + 1,g[i][j]);
}

bool st[N];
long long ans = 0;

void dfs(int x,long long sum,int now)
{
	if(x == 4)
	{
		if(g[now][1] <= k)
		if(ans < sum)
		ans = sum;
		return ;
	}
	for(int i = 2;i <= n;++ i)
	if(! st[i] && g[i][now] <= k)
	{
		st[i] = 1;
		dfs(x + 1,sum + w[i],i);
		st[i] = 0;
	}
}

int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	memset(g,0x3f3f3f3f,sizeof g);
	for(int i = 2;i <= n;++ i)
	scanf("%lld",&w[i]),g[i][i] = 0;
	g[1][1] = 0;
	int x,y;
	for(int i = 1;i <= m;++ i)
	scanf("%d%d",&x,&y),g[y][x] = 0,g[x][y] = 0;
	floyd();
	
	dfs(0,0,1);
	printf("%lld",ans);
	return 0;
}
