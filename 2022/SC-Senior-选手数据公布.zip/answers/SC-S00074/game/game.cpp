#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
#include<algorithm>
#include<queue>
#include<vector>
#include<map>
using namespace std;
const long long N = 100010;
long long n,m,q;
long long a[N][10];
long long l[10];
long long l1,r1,l2,r2;
long long za[N],fa[N],zb[N],fb[N];
long long ans;

long long tr[4 * N][10];
long long len1 = 0,len2 = 0;

long long build1(long long l,long long r,long long k,long long f)
{
	if(l == r)
	{
		tr[k][f] = a[l][(f + 1) / 2];
		return tr[k][f];
	}
	long long mid = (l + r) / 2;
	tr[k][f] = max(build1(l,mid,k * 2,f),build1(mid + 1,r,k * 2 + 1,f));
	return tr[k][f];
}
long long build2(long long l,long long r,long long k,long long f)
{
	if(l == r)
	{
		tr[k][f] = a[l][(f + 1) / 2];
		return tr[k][f];
	}
	long long mid = (l + r) / 2;
	tr[k][f] = min(build2(l,mid,k * 2,f),build2(mid + 1,r,k * 2 + 1,f));
	return tr[k][f];
}

long long Find1(long long l,long long r,long long x,long long y,long long k,long long f)
{
	if(l >= x && r <= y) return tr[k][f];
	if(x > y) return -1e18;
	if(l > y || r < x) return -1e18;
	long long mid = (l + r) / 2;
	return max(Find1(l,mid,x,y,k * 2,f),Find1(mid + 1,r,x,y,k * 2 + 1,f));
}
long long Find2(long long l,long long r,long long x,long long y,long long k,long long f)
{
	if(l >= x && r <= y) return tr[k][f];
	if(x > y) return 1e18;
	if(l > y || r < x) return 1e18;
	long long mid = (l + r) / 2;
	return min(Find2(l,mid,x,y,k * 2,f),Find2(mid + 1,r,x,y,k * 2 + 1,f));
}

long long maxa(long long a,long long b)
{
	return a > b ? a : b;
}
long long mina(long long a,long long b)
{
	return a < b ? a : b;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	for(long long i = 1;i <= n;++ i)
	scanf("%lld",&a[i][0]);
	for(long long i = 1;i <= n;++ i)
	{
		za[i] = za[i - 1],fa[i] = fa[i - 1];
		if(a[i][0] >= 0) a[++ l[1]][1] = a[i][0],++ za[i];
		else a[++ l[2]][2] = a[i][0],++ fa[i];
		for(long long j = 1;j <= 4;++ j)
		tr[i * j][1] = tr[i * j][2] = tr[i * j][5] = tr[i * j][6] = -1,
		tr[i * j][3] = tr[i * j][4] = tr[i * j][7] = tr[i * j][8] = 0;
	}
	for(long long i = 1;i <= m;++ i)
	scanf("%lld",&a[i][0]);
	for(long long i = 1;i <= m;++ i)
	{
		zb[i] = zb[i - 1],fb[i] = fb[i - 1];
		if(a[i][0] >= 0) a[++ l[3]][3] = a[i][0],++ zb[i];
		else a[++ l[4]][4] = a[i][0],++ fb[i];
	}
	for(long long i = 1;i <= 4;++ i)
	build1(1,l[i],1,i * 2 - 1),build2(1,l[i],1,i * 2);
	while(q --)
	{
		ans = -1e18;
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		long long za1 = za[l1 - 1] + 1,za2 = za[r1],
		fa1 = fa[l1 - 1] + 1,fa2 = fa[r2],
		zb1 = zb[l2 - 1] + 1,zb2 = zb[r2],
		fb1 = fb[l2 - 1] + 1,fb2 = fb[r2];
		long long zax = Find1(1,l[1],za1,za2,1,1),zan = Find2(1,l[1],za1,za2,1,2);
		long long fax = Find1(1,l[2],fa1,fa2,1,3),fan = Find2(1,l[2],fa1,fa2,1,4);
		long long zbx = Find1(1,l[3],zb1,zb2,1,5),zbn = Find2(1,l[3],zb1,zb2,1,6);
		long long fbx = Find1(1,l[4],fb1,fb2,1,7),fbn = Find2(1,l[4],fb1,fb2,1,8);
		if(za1 > za2) zax = zan = -1;
		if(fa1 > fa2) fax = fan = 0;
		if(zb1 > zb2) zbx = zbn = -1;
		if(fb1 > fb2) fbx = fbn = 0;
		if(zax == -1) ans = maxa(ans,zbx * fax);
		if(zbx == -1) ans = maxa(ans,fan * fbx);
		if(fax == 0) ans = maxa(ans,fbn * zan);
		if(fbx == 0) ans = maxa(ans,zax * zbn);
		if(zax != -1 && zbx != -1 && fax && fbx)
		ans = maxa(zan * fbn,ans),
		ans = maxa(fbx * zbx,ans);
		
		if(zan == 0) ans = maxa(ans,0);
		if(zbn == 0) ans = mina(ans,0);
		printf("%lld\n",ans);
	}
	return 0;
}
/*
6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3

0
-2
3
2
-1

0 0 3 3 3
*/
