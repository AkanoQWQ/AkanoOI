#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
#include<algorithm>
#include<queue>
#include<vector>
#include<map>
using namespace std;
const int N = 500010;
int n,m,q;
int f[N],s[N],p[N];

int h[N],e[N],ne[N],idx = 0;
int h1[N],e1[N],ne1[N],idx1 = 0;

int ss[N];
int sp[N];

int Find(int x)
{
	if(f[x] != x) f[x] = Find(f[x]);
	return f[x];
}

void add(int a,int b)
{
	e[idx] = b,ne[idx] = h[a],h[a] = idx ++;
}
void add1(int a,int b)
{
	e1[idx] = b,ne1[idx] = h1[a],h1[a] = idx1 ++;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	memset(h1,-1,sizeof h1);
	memset(h,-1,sizeof h);
	int a,b;
	for(int i = 1;i <= m;++ i)
	{
		scanf("%d%d",&a,&b);
		add(a,b);
		add1(b,a);
		f[a] = Find(f[b]);
		sp[b] = 1;
	}
	scanf("%d",&q);
	for(int i = 1;i <= q;++ i)
	printf("NO\n");
	return 0;
}
