#include<bits/stdc++.h>
using namespace std;
#define ll long long
inline ll read()
{
	ll x=0;
	bool flag=0;
	char ch;
	while(!isdigit(ch))
	{
		ch=getchar();
		if(ch=='-')flag=1;
	}
	while(isdigit(ch)){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	if(flag)return -x;
	return x;
}
ll u[21],cn=0;
inline void print(ll x)
{
	cn=0;
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	if(!x)
	{
		puts("0");
		return ;
	}
	while(x)
	{
		u[++cn]=x%10;
		x/=10;
	}
	for(int i=cn;i>=1;i--)putchar(u[i]+'0');
	putchar(10);
	return ;
}
#define N 100010
ll a[N],b[N],n,m,q;
ll tmp[N];
#define inf (1e9+1)
#define inff (1e18+1)
ll len=0;
struct node{
	ll fmx[N][20],fmi[N][20];
	ll lg[N];
	inline void build()
	{
		lg[0]=-1;
		for(int i=1;i<=len;i++)lg[i]=lg[i>>1]+1;
		for(int i=1;i<=len;i++)fmx[i][0]=((tmp[i]==1e9+1)?-inf:tmp[i]);
		for(int i=1;i<=len;i++)fmi[i][0]=((tmp[i]==1e9+1)?inf:tmp[i]);
		for(int i=1;(1<<i)<=len;i++)
		{
			for(int j=1;j+(1<<i)-1<=len;j++)
			{
				fmi[j][i]=min(fmi[j][i-1],fmi[j+(1<<(i-1))][i-1]);
				fmx[j][i]=max(fmx[j][i-1],fmx[j+(1<<(i-1))][i-1]);
			}
		}
		return ;
	}
	inline ll askmi(ll x,ll y)
	{
		ll k=lg[y-x+1];
		return min(fmi[x][k],fmi[y-(1<<k)+1][k]);
	}
	inline ll askmx(ll x,ll y)
	{
		ll k=lg[y-x+1];
		return max(fmx[x][k],fmx[y-(1<<k)+1][k]);;
	}
}a0,a1,b0,b1;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();m=read();q=read();
	for(int i=1;i<=n;i++)a[i]=read();
	for(int i=1;i<=m;i++)b[i]=read();
	for(int i=1;i<=n;i++)
	{
		if(a[i]>=0)tmp[i]=a[i];
		else
		{
			tmp[i]=1e9+1;
		}
	}
	len=n;
	a1.build();
	for(int i=1;i<=n;i++)
	{
		if(a[i]<0)
		{
			tmp[i]=a[i];
		}else
		{
			tmp[i]=1e9+1;
		}
	}
	a0.build();
//	cout<<a0.askmx(1,6);
	for(int i=1;i<=m;i++)
	{
		if(b[i]<0)
		{
			tmp[i]=b[i];
		}else
		{
			tmp[i]=1e9+1;
		}
	} 
	len=m;
	b0.build();
	for(int i=1;i<=m;i++)
    {
		if(b[i]>=0)tmp[i]=b[i];
		else
		{
			tmp[i]=1e9+1;
		}
	}
	b1.build();
	while(q--)
	{
		ll x=read(),y=read(),o=read(),p=read();
		if(a0.askmx(x,y)==-inf&&b0.askmx(o,p)==-inf)
		{
			print(a1.askmx(x,y)*b1.askmi(o,p));
			continue;
		}
		if(a1.askmx(x,y)==-inf&&b1.askmx(o,p)==-inf)
		{
			print(a0.askmi(x,y)*b0.askmx(o,p));
			continue;
		}		
		if(b1.askmx(o,p)==-inf&&a0.askmx(x,y)!=-inf)
		{
			print(a0.askmi(x,y)*b0.askmx(o,p));
			continue;
		}
		if(b0.askmx(o,p)==-inf&&a1.askmx(x,y)!=-inf)
		{
			print(a1.askmx(x,y)*b1.askmi(o,p));
			continue;
		}
		ll an=-inff;
		if(a0.askmx(x,y)!=-inf&&b1.askmx(o,p)!=-inf)an=max(an,a0.askmx(x,y)*b1.askmx(o,p));
		if(a1.askmx(x,y)!=-inf&&b0.askmx(o,p)!=-inf)an=max(an,a1.askmi(x,y)*b0.askmi(o,p));
		print(an);
	}
	return 0;
}

