#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define N 2510
#define M 10010
ll n,m,k;
ll dis[N];
vector<ll>ji[N];
queue<ll>q;
ll fir[N],nxt[M<<1],v[M<<1],cnt=0;
inline void add(ll x,ll y)
{
	v[++cnt]=y;
	nxt[cnt]=fir[x];
	fir[x]=cnt;
	return ;
}
ll val[N];
bool vis[N][N];
bool vv[N];
inline void gt(ll x)
{
	memset(dis,0x3f,sizeof(dis));
	memset(vv,0,sizeof(vv));
	dis[x]=0;
	q.push(x);
	vv[x]=1;
	while(!q.empty())
	{
		ll o=q.front();
		q.pop();
		for(int i=fir[o];i;i=nxt[i])
		{
			ll vi=v[i];
			if(dis[vi]>dis[o]+1)
			{
				dis[vi]=dis[o]+1;
				if(!vv[vi])
				{
					vv[vi]=1;
					q.push(vi);
				}
			}	
		}
	}
	for(int i=1;i<=n;i++)if(dis[i]<=k+1)vis[x][i]=1;
	for(int i=2;i<=n;i++)if(i!=x&&dis[i]<=k+1&&vis[1][i]==1)ji[x].push_back(i);
	return ;
}
inline bool cmp(ll x,ll y)
{
	return val[x]>val[y];
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++)cin>>val[i]; 
	for(int i=1;i<=m;i++)
	{
		ll u,v;
		cin>>u>>v;
		add(u,v);
		add(v,u);
	} 
	for(int i=1;i<=n;i++)gt(i);
	for(int i=2;i<=n;i++)
	{
		sort(ji[i].begin(),ji[i].end(),cmp);
	} 
	ll ans=0;
	for(int i=2;i<=n;i++)
	{
		for(int j=2;j<=n;j++)
		{
			if(i==j||(!vis[i][j]))continue;
			if(ji[i].empty()||ji[j].empty())continue;
			for(int o=0;o<min((int)ji[i].size(),3);o++)
			{
				for(int p=0;p<min((int)ji[j].size(),3);p++)
				{
					ll u=ji[i][o],v=ji[j][p];
					if(u==v||v==i||u==j||v==j||u==i)continue;
					ans=max(ans,val[i]+val[j]+val[u]+val[v]);
				}
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}

