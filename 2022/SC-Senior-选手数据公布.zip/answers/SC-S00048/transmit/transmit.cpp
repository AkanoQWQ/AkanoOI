#include<bits/stdc++.h>
using namespace std;
#define ll long long
inline ll read()
{
	ll x=0;
	bool flag=0;
	char ch;
	while(!isdigit(ch))
	{
		ch=getchar();
		if(ch=='-')flag=1;
	}
	while(isdigit(ch)){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	if(flag)return -x;
	return x;
}
ll u[21],cnn=0;
inline void print(ll x)
{
	cnn=0;
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	if(!x)
	{
		puts("0");
		return ;
	}
	while(x)
	{
		u[++cnn]=x%10;
		x/=10;
	}
	for(int i=cnn;i>=1;i--)putchar(u[i]+'0');
	putchar(10);
	return ;
}
#define N 200010
#define inf 1e18
ll fir[N],nxt[N<<1],v[N<<1],cnt=0;
inline void add(ll x,ll y)
{
	v[++cnt]=y;
	nxt[cnt]=fir[x];
	fir[x]=cnt;
	return ;
}
struct node{
	ll a[4][4],n,m;
	node operator*(const node &x)const{
		node t;
		memset(t.a,0x3f,sizeof(t.a));
		t.n=n;t.m=x.m;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=t.m;j++)
			{
				for(int k=1;k<=m;k++)t.a[i][j]=min(t.a[i][j],a[i][k]+x.a[k][j]);
			}
		}
		return t;
	}
}tr[N<<2],ji[N],tr1[N<<2];
ll n,q,k;
ll dfn[N],top[N],rev[N];
ll siz[N],son[N];
ll fa[N];
ll dep[N];
inline void dfs(ll x,ll f)
{
	fa[x]=f;
	dep[x]=dep[f]+1;
	siz[x]=1;
	for(int i=fir[x];i;i=nxt[i])
	{
		ll vi=v[i];
		if(vi==f)continue;
		dfs(vi,x);
		siz[x]+=siz[vi];
		if(siz[vi]>siz[son[x]])son[x]=vi;
	}
	return ;
}
ll cn=0;
inline void dfs1(ll x)
{
	if(son[x])
	{
		dfn[son[x]]=++cn;
		top[son[x]]=top[x];
		rev[cn]=son[x];
		dfs1(son[x]);
	}
	for(int i=fir[x];i;i=nxt[i])
	{
		if(!dfn[v[i]])
		{
			top[v[i]]=v[i];
			dfn[v[i]]=++cn;
			rev[cn]=v[i];
			dfs1(v[i]);
		}
	}
	return ;
}
inline void pushup(ll x)
{
	tr[x]=tr[x<<1|1]*tr[x<<1];
	tr1[x]=tr1[x<<1]*tr1[x<<1|1];
	return ;
}
inline void build(ll x,ll l,ll r)
{
	if(l==r)
	{
		tr1[x]=tr[x]=ji[rev[l]];
		return ;
	}
	ll mid=(l+r)>>1;
	build(x<<1,l,mid);
	build(x<<1|1,mid+1,r);
	pushup(x);
	return ;
}
inline node query(ll o,ll l,ll r,ll x,ll y)
{
	if(x<=l&&r<=y)
	{
		return tr[o];
	}
	ll mid=(l+r)>>1;
	if(y>mid&&mid>=x)return query(o<<1|1,mid+1,r,x,y)*query(o<<1,l,mid,x,y);
	if(mid>=x)return query(o<<1,l,mid,x,y);
	return query(o<<1|1,mid+1,r,x,y);
}
inline node query1(ll o,ll l,ll r,ll x,ll y)
{
	if(x<=l&&r<=y)
	{
		return tr1[o];
	}
	ll mid=(l+r)>>1;
	if(y>mid&&mid>=x)return query1(o<<1,l,mid,x,y)*query1(o<<1|1,mid+1,r,x,y);
	if(mid>=x)return query1(o<<1,l,mid,x,y);
	return query1(o<<1|1,mid+1,r,x,y);
}
inline ll lca(ll x,ll y)
{
	while(top[x]!=top[y])
	{
		if(dep[top[x]]<dep[top[y]])swap(x,y);
		x=fa[top[x]];
	}
	if(dep[x]<dep[y])swap(x,y);
	return y;
}
inline ll ask(ll x,ll y)
{
	if(dep[x]<dep[y])swap(x,y);
	node an,an1;
	memset(an1.a,0x3f,sizeof(an1.a));
	an1.n=k;an1.m=k;
	for(int i=1;i<=k;i++)an1.a[i][i]=0;//an1.a[1][1]=an1.a[2][2]=an1.a[3][3]=0;
	an.n=1;an.m=k;
	for(int i=1;i<k;i++)an.a[1][i]=inf;//an.a[1][1]=an.a[1][2]=inf;
	an.a[1][k]=ji[x].a[1][k];
	//an.a[1][3]=ji[x].a[1][3];
	ll lc=lca(x,y);
	if(lc==y)
	{
		x=fa[x];
		while(dep[top[x]]>=dep[y])
		{
			an=an*query(1,1,n,dfn[top[x]],dfn[x]);
			x=fa[top[x]];
		}
		if(dep[x]<dep[y])return an.a[1][k];
		an=an*query(1,1,n,dfn[y],dfn[x]);
		return an.a[1][k];
	}
	x=fa[x];
	while(dep[top[x]]>=dep[lc])
	{
		node o=query(1,1,n,dfn[top[x]],dfn[x]);
		an=an*o;
		x=fa[top[x]];
	}
	if(dep[x]>=dep[lc])an=an*query(1,1,n,dfn[lc],dfn[x]);	
//	return ((an*ji[9])*ji[10]).a[1][3];
	while(dep[top[y]]>dep[lc])
	{
		an1=query1(1,1,n,dfn[top[y]],dfn[y])*an1;
		y=fa[top[y]];
	}
	if(dep[y]>dep[lc]){
		ll o=son[lc];
		an1=query1(1,1,n,dfn[o],dfn[y])*an1;
	}
	return (an*an1).a[1][k];
}
ll dis[2010];
bool vis[2010];
#define  T pair<ll,ll>
#define fi first
#define se second
ll val[N];
#define mk make_pair
priority_queue< T,vector< T >,greater< T > >g;
inline void bfs(ll x,ll nw,ll ff,ll wi)
{
	if(wi>=3)return ;
	for(int i=fir[x];i;i=nxt[i])
	{
		if(v[i]==ff)continue;
		if(dis[nw]+val[v[i]]<dis[v[i]])
		{
			dis[v[i]]=dis[nw]+val[v[i]];
			g.push(mk(dis[v[i]],v[i]));
		}
		bfs(v[i],nw,x,wi+1);
	}
	return ;
}
inline void dj(ll x)
{
	g.push(mk(dis[x],x));
	while(!g.empty())
	{
		ll o=g.top().se;
		g.pop();
		if(vis[o])continue;
		if(o==4)
		{
//			cout<<1;
		}
		vis[o]=1;
		bfs(o,o,0,0);
	}
	return ;
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=read();q=read();k=read();
	for(int i=1;i<=n;i++)
	{
		memset(ji[i].a,0x3f,sizeof(ji[i].a));
		ll x=read();
		val[i]=x;
		ji[i].n=k;ji[i].m=k;
		for(int j=1;j<=k;j++)ji[i].a[j][k]=x;
//		ji[i].a[1][3]=ji[i].a[2][3]=ji[i].a[3][3]=x;
//		ji[i].a[3][2]=ji[i].a[2][1]=0;
		for(int j=1;j<k;j++)ji[i].a[j+1][j]=0;
	}
	for(int i=1;i<n;i++)
	{
		ll u=read(),v=read();
		add(u,v);
		add(v,u);
	}
	if(k==3)
	{
		while(q--)
		{
			ll x=read(),y=read();
			memset(dis,0x3f,sizeof(dis));
			memset(vis,0,sizeof(vis));
			dis[x]=val[x];
			dj(x);
			print(dis[y]);
		}
		return 0;
	}
	dfs(1,0);
	dfn[1]=++cn;rev[1]=top[1]=1;
	dfs1(1);
	build(1,1,n);
	for(int i=1;i<=q;i++)
	{
		ll x=read(),y=read();
		print(ask(x,y)); 
	}
	return 0;
}

