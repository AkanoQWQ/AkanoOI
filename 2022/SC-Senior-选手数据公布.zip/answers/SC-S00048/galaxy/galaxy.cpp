#include<bits/stdc++.h>
using namespace std;
#define ll long long
inline ll read()
{
	ll x=0;
	bool flag=0;
	char ch;
	while(!isdigit(ch))
	{
		ch=getchar();
		if(ch=='-')flag=1;
	}
	while(isdigit(ch)){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	if(flag)return -x;
	return x;
}
#define N 500010
ll w=0;
ll ji[N];
ll n,m;
set<ll>s[N],f[N],g[N];
ll op[N],vv[N],uu[N];
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=m;i++)
	{
		ll u=read(),v=read();
		ji[u]++;s[v].insert(u);
		g[v].insert(u);
	}
	for(int i=1;i<=n;i++)w+=(ji[i]!=1);
	ll q=read();
	bool kz=0; 
	for(int i=1;i<=q;i++)
	{
		op[i]=read();uu[i]=read();
		if(op[i]==1||op[i]==3)vv[i]=read();
		if(op[i]==4)kz=1;
	}
	for(int i=1;i<=q;i++)
	{
		ll opt=op[i];
		ll u=uu[i],v=vv[i];
		if(opt==1)
		{
			if(ji[u]==1)w++;
			ji[u]--;
			if(ji[u]==1)w--;
			s[v].erase(u);
			f[v].insert(u);
		}
		if(opt==2)
		{
			for(auto o:s[u])
			{
				if(ji[o]==1)w++;
				ji[o]--;
				if(ji[o]==1)w--;	
			}
			s[u].clear();
			if(kz)f[u]=g[u];
		}
		if(opt==3)
		{
			if(ji[u]==1)w++;
			ji[u]++;
			if(ji[u]==1)w--;
			s[v].insert(u);
			f[v].erase(u);
		}
		if(opt==4)
		{
			for(auto o:f[u])
			{
				if(ji[o]==1)w++;
				ji[o]++;
				if(ji[o]==1)w--;	
			}
			f[u].clear();
			s[u]=g[u];			
		}
		if(w==0)puts("YES");
		else puts("NO");
	}
	return 0;
}

