#include<bits/stdc++.h>
using namespace std;
#define FOR(u) for(int i=head[u],v=e[i].v;i;i=e[i].nxt,v=e[i].v)
#define mkp make_pair
#define pii pair<int,int>
#define fi first
#define se second
#define int long long
#define in read()
inline int read(){
	int p=0,f=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
	while(isdigit(c))p=p*10+c-48,c=getchar();
	return p*f;
}
const int N=2505,M=10005,inf=1000000000000000000; 
int n,m,k;
int val[N];
struct edge{int v,nxt;}e[M<<1];
int head[N],en;
inline void insert(int u,int v){e[++en]={v,head[u]},head[u]=en;}
int dis[N][N],vis[N];
priority_queue<pii>q;
inline void dij(int s){
	for(int i=1;i<=n;i++)dis[s][i]=1000000000,vis[i]=0;
	dis[s][s]=0;q.push(mkp(0,s));
	while(!q.empty()){
		int u=q.top().se;q.pop();
		if(vis[u])continue;vis[u]=1;
		FOR(u)if(dis[s][v]>dis[s][u]+1)
			dis[s][v]=dis[s][u]+1,q.push({-dis[s][v],v});
	}
}
struct node{
	int d,f;
	friend bool operator>=(node a,node b){
		return a.d>=b.d;
	}
}mx[N],smx[N],tmx[N];

int ans;
signed main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=in,m=in,k=in;
	for(int i=2;i<=n;i++)val[i]=in;
	for(int i=1,u,v;i<=m;i++)u=in,v=in,insert(u,v),insert(v,u);
	for(int i=1;i<=n;i++)dij(i),mx[i].d=smx[i].d=tmx[i].d=-inf;
	for(int i=2;i<=n;i++)if(dis[1][i]<=k+1){
		node tmp={val[i],i};
		for(int j=2;j<=n;j++)if(i^j&&dis[i][j]<=k+1){
			if(tmp>=mx[j])tmx[j]=smx[j],smx[j]=mx[j],mx[j]=tmp;
			else if(tmp>=smx[j])tmx[j]=smx[j],smx[j]=tmp;
			else if(tmp>=tmx[j])tmx[j]=tmp;
		}
	}
	for(int i=2,sum;i<n;i++){
		for(int j=i+1;j<=n;j++)if(dis[i][j]<=k+1){
			sum=val[i]+val[j];
			node a=mx[i],b=mx[j];	
			if(a.f==j)a=smx[i];
			if(b.f==i)b=smx[j];
			if(a.f^b.f)sum+=a.d+b.d;
			else{
				sum+=a.d;
				int td=0;
				if(a.f==smx[i].f)td=max(td,tmx[i].d);
				else td=max(td,smx[i].d);
				if(b.f==smx[j].f)td=max(td,tmx[j].d);
				else td=max(td,smx[j].d);
				sum+=td;
			}
			ans=max(ans,sum);
		}
	}cout<<ans;
	return 0;
}

