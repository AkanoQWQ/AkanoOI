#include<bits/stdc++.h>
using namespace std;
#define FOR(i,u,G) for(int i=G.head[u],v=G.e[i].v;i;i=G.e[i].nxt,v=G.e[i].v)
#define mkp make_pair
#define pii pair<int,int>
#define fi first
#define se second
#define int long long
#define in read()
inline int read(){
	int p=0,f=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
	while(isdigit(c))p=p*10+c-48,c=getchar();
	return p*f;
}
const int N=500005;
int n,m,Q;
struct edge{int u,v,nxt;};
struct Gra{
	edge e[N];
	int head[N],en;
	inline void insert(int u,int v){e[++en]={u,v,head[u]},head[u]=en;}
}G,rG;
int odg[N];
map<pii,int>mp;
int tmp[N];

vector<int>Add[N<<2];
int du[N];int dn;
int cnt;
inline void merge(int x,int y){
	du[++dn]=x,++odg[x];
	if(odg[x]==1)++cnt;
	else if(odg[x]==2)--cnt;
}
inline void del(){
	int u=du[dn--];--odg[u];
	if(odg[u]==1)++cnt;
	else if(odg[u]==0)--cnt;
}
inline void change(int l,int r,int p,int x,int cl,int cr){
	if(cl<=l&&r<=cr){Add[p].emplace_back(x);return ;}
	int mid=(l+r)>>1;
	if(cl<=mid)change(l,mid,p<<1,x,cl,cr);
	if(cr>mid)change(mid+1,r,p<<1|1,x,cl,cr);
}
inline void add(int i,int s,int t){
	if(s<=t)change(1,Q,1,i,s,t);
}
inline void solve(int l,int r,int p){
	int mid=(l+r)>>1,tot=dn;
	for(int i:Add[p])merge(G.e[i].u,G.e[i].v);
	if(l==r){
		if(cnt==n)cout<<"YES\n";
		else cout<<"NO\n";
	}else{
		solve(l,mid,p<<1);
		solve(mid+1,r,p<<1|1);
	}
	while(dn>tot)del();
}

inline void cut(int u,int v,int t){
	int x=mp[mkp(u,v)];
	if(tmp[x])add(x,tmp[x],t-1);
	tmp[x]=0;
}
inline void link(int u,int v,int t){
	int x=mp[mkp(u,v)];
	if(!tmp[x])tmp[x]=t;
}
signed main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=in,m=in;
	for(int i=1,u,v;i<=m;i++)
		u=in,v=in,G.insert(u,v),rG.insert(v,u),mp[mkp(u,v)]=i,tmp[i]=1;
	Q=in;
	for(int i=1,t,u,v;i<=Q;i++){
		t=in,u=in;
		if(t==1)v=in,cut(u,v,i);
		else if(t==2)FOR(j,u,rG)cut(v,u,i);
		else if(t==3)v=in,link(u,v,i);
		else FOR(j,u,rG)link(v,u,i);
	}
	for(int i=1;i<=m;i++)if(tmp[i])add(i,tmp[i],Q);
	for(int i=1;i<=n;i++)odg[i]=0;cnt=0;
	solve(1,Q,1);
	return 0;
}


