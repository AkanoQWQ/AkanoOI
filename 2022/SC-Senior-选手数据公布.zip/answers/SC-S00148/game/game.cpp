#include<bits/stdc++.h>
using namespace std;
#define FOR(u) for(int i=head[u],v=e[i].v;i;i=e[i].nxt,v=e[i].v)
#define mkp make_pair
#define pii pair<int,int>
#define fi first
#define se second
#define int long long
#define in read()
inline int read(){
	int p=0,f=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
	while(isdigit(c))p=p*10+c-48,c=getchar();
	return p*f;
}
const int NM=100005,inf=1000000000000000000;
int n,m,q,lg2[NM];
inline void init(){
	for(int i=2;i<=100000;i++)lg2[i]=lg2[i/2]+1;
}
struct ST{
	int len,maxn[20][NM],minn[20][NM];
	ST(){for(int i=1;i<=100000;i++)maxn[0][i]=-inf,minn[0][i]=inf;}
	inline void pro(){
		for(int i=1;i<=19;i++)
			for(int j=1;j+(1<<(i-1))<=n;j++)
				maxn[i][j]=max(maxn[i-1][j],maxn[i-1][j+(1<<(i-1))]),
				minn[i][j]=min(minn[i-1][j],minn[i-1][j+(1<<(i-1))]);
	}
	inline int queryMax(int l,int r){
		int t=lg2[r-l+1];
		return max(maxn[t][l],maxn[t][r-(1<<t)+1]);
	}
	inline int queryMin(int l,int r){
		int t=lg2[r-l+1];
		return min(minn[t][l],minn[t][r-(1<<t)+1]);
	}
};
struct ar{
	int len,a[NM];
	ST P,N,Z;
	inline void init(){
		for(int i=1;i<=len;i++){
			if(a[i]>0)P.maxn[0][i]=P.minn[0][i]=a[i];
			else if(a[i]<0)N.maxn[0][i]=N.minn[0][i]=a[i];
			else Z.maxn[0][i]=Z.minn[0][i]=a[i];
		}
		P.pro(),N.pro(),Z.pro();
	}
}A,B;
inline int solve(int x,int al,int ar){
	if(x==0)return 0;
	int tmp,ans=inf;
	tmp=B.N.queryMax(al,ar);
	if(tmp!=-inf)ans=min(ans,x*tmp);
	tmp=B.N.queryMin(al,ar);
	if(tmp!=inf)ans=min(ans,x*tmp);
	tmp=B.P.queryMax(al,ar);
	if(tmp!=-inf)ans=min(ans,x*tmp);
	tmp=B.P.queryMin(al,ar);
	if(tmp!=inf)ans=min(ans,x*tmp);
	tmp=B.Z.queryMax(al,ar);
	if(tmp!=-inf)ans=min(ans,x*tmp);
	return ans;
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=in,m=in,q=in,init();
	A.len=n,B.len=m;
	for(int i=1;i<=n;i++)A.a[i]=in;
	for(int i=1;i<=m;i++)B.a[i]=in;
	A.init(),B.init();
	for(int i=1,al,ar,bl,br,tmp,ans;i<=q;i++){
		al=in,ar=in,bl=in,br=in,ans=-inf;
		tmp=A.N.queryMax(al,ar);
		if(tmp!=-inf)ans=max(ans,solve(tmp,bl,br));
		tmp=A.N.queryMin(al,ar);
		if(tmp!=inf)ans=max(ans,solve(tmp,bl,br));
		tmp=A.P.queryMax(al,ar);
		if(tmp!=-inf)ans=max(ans,solve(tmp,bl,br));
		tmp=A.P.queryMin(al,ar);
		if(tmp!=inf)ans=max(ans,solve(tmp,bl,br));
		tmp=A.Z.queryMax(al,ar);
		if(tmp!=-inf)ans=max(ans,solve(tmp,bl,br));
		cout<<ans<<'\n';
	}
	return 0;
}

