#include<bits/stdc++.h>
using namespace std;
#define FOR(u) for(int i=head[u],v=e[i].v;i;i=e[i].nxt,v=e[i].v)
#define mkp make_pair
#define pii pair<int,int>
#define fi first
#define se second
#define int long long
#define in read()
inline int read(){
	int p=0,f=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
	while(isdigit(c))p=p*10+c-48,c=getchar();
	return p*f;
}
const int N=500005,N1=2005,inf=200000000000000;
int n,Q,k;
struct edge{int v,w,nxt;}e[N<<1];
int head[N],en;
inline void insert(int u,int v,int w=0){e[++en]={v,w,head[u]},head[u]=en;}
int val[N],dep[N],fa[N],siz[N],maxp[N],sumc[N],top[N];
inline void dfsFi(int u,int f){
	dep[u]=dep[f]+1,fa[u]=f,siz[u]=1,maxp[u]=0,sumc[u]=sumc[f]+val[u];
	FOR(u)if(v^f)dfsFi(v,u),siz[u]+=siz[v],maxp[u]=siz[v]>siz[maxp[u]]?v:maxp[u];
}
inline void dfsSe(int u,int f,int tp){
	top[u]=tp;
	if(maxp[u])dfsSe(maxp[u],u,tp);
	FOR(u)if(v^f&&v^maxp[u])dfsSe(v,u,v);
}
inline int lca(int x,int y){
	while(top[x]^top[y]){
		if(dep[top[x]]<dep[top[y]])swap(x,y);
		x=fa[top[x]];
	}if(dep[x]<dep[y])swap(x,y);return y;
}
inline int getDis(int x,int y){
	return dep[x]+dep[y]-2*dep[lca(x,y)];
}
inline int getAns(int x,int y){
	int t=lca(x,y);
	return sumc[x]+sumc[y]-sumc[t]-sumc[fa[t]];
}
int dis[N1][N1],vis[N1];
priority_queue<pii>q;
inline void dij(int s){
	for(int i=1;i<=n;i++)dis[s][i]=inf,vis[i]=0;
	dis[s][s]=0,q.push(mkp(0,s));
	while(!q.empty()){
		int u=q.top().se;q.pop();
		if(vis[u])continue;vis[u]=1;
		FOR(u)if(dis[s][v]>dis[s][u]+e[i].w)
			dis[s][v]=dis[s][u]+e[i].w,q.push({-dis[s][v],v});
	}
}
int p[N];
inline void getPath(int x,int y){
	int t=lca(x,y),tl=getDis(x,y)+1,hd=1;
	while(x^t)p[hd++]=x,x=fa[x];
	while(y^t)p[tl--]=y,y=fa[y];
	p[hd]=t;
}
int dp[N]; 
signed main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=in,Q=in,k=in;
	for(int i=1;i<=n;i++)val[i]=in;
	for(int i=1,u,v;i<n;i++)u=in,v=in,insert(u,v),insert(v,u);
	dfsFi(1,0),dfsSe(1,0,1);
	if(k==1){
		for(int i=1,x,y;i<=Q;i++)
			x=in,y=in,cout<<getAns(x,y)<<'\n';
	}else if(n<=2000){
		for(int i=1;i<=n;i++)head[i]=0;en=0;
		for(int i=1;i<=n;i++) for(int j=i;j<=n;j++)
			if(getDis(i,j)<=k)insert(i,j,val[j]),insert(j,i,val[i]);
		for(int i=1;i<=n;i++)dij(i);
		for(int i=1,x,y;i<=Q;i++)
			x=in,y=in,cout<<val[x]+dis[x][y]<<'\n';
	}else{
		for(int i=1,x,y;i<=Q;i++){
			x=in,y=in;
			getPath(x,y);
			int len=getDis(x,y)+1;
			for(int i=1;i<=len;i++)dp[i]=inf;
			dp[1]=val[x];
			for(int i=1;i<len;i++)
				for(int j=1;j<=k&&i+j<=len;j++)
					dp[i+j]=min(dp[i+j],dp[i]+val[p[i+j]]);
			cout<<dp[len]<<'\n';
		}
	}
	return 0;
}


