#include <bits/stdc++.h>
using namespace std;

int n,m,k;
int tp1,tp2;

long long s[2505];
vector<int> node[2505];
vector<int> fast[2505];

bool mem[2505];

long long read()
{
	long long s=0,t=1;
	
	char ch=getchar();
	while((ch<'0'||ch>'9')&&ch!='-') ch=getchar();
	
	if(ch=='-') t=-1,ch=getchar();
	while(ch>='0'&&ch<='9')
	{
		s*=10;
		s+=ch-'0';
		
		ch=getchar();
	}
	
	return s*t;
}

void fast_dfs(int x,int set,int k)
{
	if(x!=set) fast[set].push_back(x);
	
	if(k==0) return;
	else
	{
		for(int i=0;i<int(node[x].size());i++)
		{
			if(!mem[node[x][i]])
			{
				mem[node[x][i]]=true;
				fast_dfs(node[x][i],set,k-1);
				mem[node[x][i]]=false;
			}
		}
	}
}

long long check_dfs(int x,int k,bool first)
{
	if(x==1&&!first&&k!=0) return -0x7fffffff;
	else if(x==1&&!first) return 0;
	else if(k==0) return -0x7fffffff;
	else
	{
		long long ans = -0x7fffffff;
		for(int i=0;i<int(fast[x].size());i++)
		{
			if(!mem[fast[x][i]])
			{
				mem[fast[x][i]]=true;
				ans=max(ans,s[x]+check_dfs(fast[x][i],k-1,false));
				mem[fast[x][i]]=false;
			}
		}
		return ans;
	}
}

int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	
	n=read(),m=read(),k=read();
	k++;
	
	for(int i=2;i<=n;i++) s[i]=read();
	for(int i=1;i<=m;i++)
	{
		tp1=read(),tp2=read();
		node[tp1].push_back(tp2);
		node[tp2].push_back(tp1);
	}
	
	memset(mem,false,sizeof(mem));
	for(int i=1;i<=n;i++)
	{
		mem[i]=true;
		fast_dfs(i,i,k);
		mem[i]=false;
	}
	
	memset(mem,false,sizeof(mem));
	printf("%lld",check_dfs(1,5,true));
	
	return 0;
}
