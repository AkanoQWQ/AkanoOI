#include <bits/stdc++.h>
using namespace std;

int n,q,k;
int s,t;

int tp1,tp2;

int v[200005];
vector<int> node[200005];
vector<int> fast[600005];

long long read()
{
	long long s=0,t=1;
	
	char ch=getchar();
	while((ch<'0'||ch>'9')&&ch!='-') ch=getchar();
	
	if(ch=='-') t=-1,ch=getchar();
	while(ch>='0'&&ch<='9')
	{
		s*=10;
		s+=ch-'0';
		
		ch=getchar();
	}
	
	return s*t;
}

bool mem[200005];
void fast_dfs(int x,int set,int k)
{
	if(x!=set) fast[set].push_back(x);
	
	if(k==0) return;
	else
	{
		for(int i=0;i<int(node[x].size());i++)
		{
			if(!mem[node[x][i]])
			{
				mem[node[x][i]]=true;
				fast_dfs(node[x][i],set,k-1);
				mem[node[x][i]]=false;
			}
		}
	}
}

long long check_dfs(int x)
{
	if(x==t) 
	{
		return v[x];
	}
	else
	{
		long long ans = 1e18;
		for(int i=0;i<int(fast[x].size());i++)
		{
			if(!mem[fast[x][i]])
			{
				mem[fast[x][i]]=true;
				ans=min(ans,v[x]+check_dfs(fast[x][i]));
				mem[fast[x][i]]=false;
			}
		}
		return ans;
	}
}

int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	
	n=read(),q=read(),k=read();
	for(int i=1;i<=n;i++) v[i]=read();
	for(int i=1;i<=n-1;i++)
	{
		tp1=read(),tp2=read();
		node[tp1].push_back(tp2);
		node[tp2].push_back(tp1);
	}
	
	memset(mem,false,sizeof(mem));
	for(int i=1;i<=n;i++)
	{
		mem[i]=true;
		fast_dfs(i,i,k);
		mem[i]=false;
	}
	
	while(q--)
	{
		s=read(),t=read();
		
		memset(mem,false,sizeof(mem));
		mem[s]=true;
		
		printf("%lld\n",check_dfs(s));
	}
	
	return 0;
}

//��дʱ���������⣬�������������ĳɿ�д��������ǰ����
/*
�ֳ���д�Ŀ����д�����������û��ʹ�ÿ�д�� 

long long read()
{
	long long s=0,t=1;
	
	char ch=getchar();
	while((ch<'0'||ch>'9')&&ch!='-') ch=getchar();
	
	if(ch=='-') t=-1,ch=getchar();
	while(ch>='0'&&ch<='9')
	{
		s*=10;
		s+=ch-'0';
		
		ch=getchar();
	}
	
	return s*t;
}

void write(__int128 x)
{
	if(x<0) x=-x,putchar('-');
	if(x<9) putchar(x+'0');
	else
	{
		write(x/10);
		putchar((x%10)+'0');
	}
	return;
}

������printf�滻��write(��)���ɸ�������

*/ 
