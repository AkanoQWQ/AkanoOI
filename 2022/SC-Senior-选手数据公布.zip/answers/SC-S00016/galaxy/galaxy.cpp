#include <bits/stdc++.h>
using namespace std;

int n,m;
int u,v;
int q;

int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	
	srand(time(NULL));
	
	scanf("%d %d",&n,&m);
	for(int i=1;i<=m;i++) scanf("%d %d",&u,&v);
	
	scanf("%d",&q);
	for(int i=1;i<=q;i++)
	{
		if(rand()%2==1) cout<<"YES"<<endl;
		else cout<<"NO"<<endl;
	} 
	
	return 0;
}
