#include <bits/stdc++.h>
using namespace std;

int n,m,q;
int a[100005],b[100005];

int l1,r1,l2,r2;

long long read()
{
	long long s=0,t=1;
	
	char ch=getchar();
	while((ch<'0'||ch>'9')&&ch!='-') ch=getchar();
	
	if(ch=='-') t=-1,ch=getchar();
	while(ch>='0'&&ch<='9')
	{
		s*=10;
		s+=ch-'0';
		
		ch=getchar();
	}
	
	return s*t;
}

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=m;i++) b[i]=read();
	
	while(q--)
	{
		l1=read(),r1=read(),l2=read(),r2=read();
		
		long long upp=-1e10,low=1e10;
		for(int i=l2;i<=r2;i++)
		{
			upp=fmax(upp,b[i]);
			low=fmin(low,b[i]);
		}
		
		long long ans=-1e18;
		
		for(int i=l1;i<=r1;i++)
		{
			if(a[i]>=0) ans=max(ans,a[i]*low);
			else ans=max(ans,a[i]*upp);
		}
		
		printf("%lld\n",ans);
	}
	
	return 0;
}
