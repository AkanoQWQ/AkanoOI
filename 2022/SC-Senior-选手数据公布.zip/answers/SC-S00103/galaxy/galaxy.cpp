#include<bits/stdc++.h>
using namespace std;
int n,m,q;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		scanf("%*d%*d");
	}
	scanf("%d",&q);
	for(int i=1;i<=q;i++){
		printf("NO\n");
	}
	return 0;
}
