#include<bits/stdc++.h>
using namespace std;
typedef long long ULL;
const int MAXN=2510,MAXE=10010;
const ULL MAXX=0x3f3f3f3f3f3f3f3f;
ULL ans=-MAXX,sco[MAXN]={};
ULL graph[2502][2502];
int n,m,k,vis[MAXN]={};
//										int flag=0;
void dfs(int a,int x,ULL sum){
	if(x==6){
		if(a==1&&sum>ans){
			ans=sum;
		}
//										cout<<sum<<endl;
//										if(sum==8){
//											flag=1;
//										}
		return;
	}
	else {
		sum+=sco[a];
		vis[a]=1;
		for(int i=1;i<=n;i++){
			if(((i==1&&x==5)||!vis[i])&&graph[a][i]<=k+1){
				dfs(i,x+1,sum);
//										if(flag){
//											cout<<a<<endl;
//											return;
//										}
			}
		}
		vis[a]=0;
	}
	return;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++){
		scanf("%lld",&sco[i]);
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			graph[i][j]=MAXX;
		}
		graph[i][i]=0;
	}
	for(int i=1,t1,t2;i<=m;i++){
		scanf("%d%d",&t1,&t2);
		graph[t1][t2]=graph[t2][t1]=1;
	}
	if(k!=0){
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				for(int k=1;k<=n;k++){
					if(graph[j][k]>graph[j][i]+graph[i][k]){
						graph[j][k]=graph[j][i]+graph[i][k];
					}
				}
			}
		}
	}
	dfs(1,1,0);
	printf("%lld",ans);
	return 0;
}
