#include<bits/stdc++.h>
using namespace std;
const int MAXN=1e5+20;
typedef long long LL;
LL n,m,q,a[MAXN],b[MAXN];
LL l1,r1,l2,r2;
LL mina[MAXN]={},maxmina;
LL tmin,tmax;
int main(){
//	ios::sync_wirh_stdio(0);
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
	}
	for(int i=1;i<=m;i++){
		scanf("%lld",&b[i]);
	}
	for(int i=1;i<=q;i++){
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		if(l1==r1||l2==r2){
			if(l1==r1){
				tmin=0x7fffffffffffffff;
				for(int j=l2;j<=r2;j++){
					if(a[l1]*b[j]<tmin){
						tmin=a[l1]*b[j];
					}
				}
				printf("%lld\n",tmin);
			}
			else if(l2==r2){
				tmax=-0x7fffffffffffffff;
				for(int j=l2;j<=r2;j++){
					if(a[l1]*b[j]>tmax){
						tmax=a[l1]*b[j];
					}
				}
				printf("%lld\n",tmax);
			}
		}
		else if(m<=MAXN&&n<=MAXN){
			maxmina=-0x7fffffffffffffff;
			for(int j=l1;j<=r1;j++){
				mina[j]=0x7fffffffffffffff;
				for(int k=l2;k<=r2;k++){
					if(a[j]*b[k]<mina[j]){
						mina[j]=a[j]*b[k];
					}
				}
				if(mina[j]>maxmina){
					maxmina=mina[j];
				}
			}
			printf("%lld\n",maxmina);
		}
		
	}
	return 0;
} 
