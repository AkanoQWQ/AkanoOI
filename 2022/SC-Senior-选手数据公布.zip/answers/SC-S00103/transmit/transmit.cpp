#include<bits/stdc++.h>
using namespace std;
typedef long long LL; 
const int MAXN=2e5+2;
const LL MAXX=0x3f3f3f3f3f3f3f3f;
int n,Q,k;
LL server[MAXN];
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&Q,&k);
	for(int i=1;i<=n;i++){
		scanf("%lld",&server[i]);
	}
	if(n<=2500){
		LL graph[2510][2510]={};
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				graph[i][j]=MAXX;
			}
			graph[i][i]=0;
		}
		for(int i=1,t1,t2;i<=n-1;i++){
			scanf("%d%d",&t1,&t2);
			graph[t1][t2]=graph[t2][t1]=1;
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				for(int k=1;k<=n;k++){
					if(graph[j][k]>graph[j][i]+graph[i][k]){
						graph[j][k]=graph[j][i]+graph[i][k];
					}
				}
			}
		}
//							for(int i=1;i<=n;i++){
//								for(int j=1;j<=n;j++){
//									printf("%d ",graph[i][j]);
//								}
//								printf("\n");
//							}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				graph[i][j]=graph[i][j]<=k?server[i]:MAXX;
//							printf("%d ",graph[i][j]);
			}
//							printf("\n");
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				for(int k=1;k<=n;k++){
					if(graph[j][k]>graph[j][i]+graph[i][k]){
						graph[j][k]=graph[j][i]+graph[i][k];
					}
				}
			}
		}
//							for(int i=1;i<=n;i++){
//								for(int j=1;j<=n;j++){
//									printf("%d ",graph[i][j]);
//								}
//								printf("\n");
//							}
		for(int i=1,t1,t2;i<=Q;i++){
			scanf("%d%d",&t1,&t2);
			printf("%lld\n",graph[t1][t2]+server[t2]);
		}
	}
	return 0;
}
