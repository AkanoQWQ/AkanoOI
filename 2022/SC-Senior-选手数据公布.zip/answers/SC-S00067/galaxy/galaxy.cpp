#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

struct edge{
	int id,u,v;
}te;
const int M=2e5+10;
int rd[M],cd[M],st[M],n,m,Q;
bool inq[M];
vector<edge> G[M],F[M];
queue<int> q;

void boom(int p,int f){
	for(int i=0;i<F[p].size();i++){
	
		int t=F[p][i].u;
		if(t!=f){
			if(!st[F[p][i].id]){
				st[F[p][i].id]=1;
			cd[t]--;
			if((cd[t]!=1)&&!inq[t])
				q.push(t);
			if((cd[p]!=1)&&!inq[p])
				q.push(p);
			}	
			boom(t,p);
		}
	}
}

void recov(int p,int f){
	for(int i=0;i<F[p].size();i++){
		int t=F[p][i].u;
		if(t!=f){
			if(st[F[p][i].id]){
				st[F[p][i].id]=0;
			cd[t]--;
			if((cd[t]!=1)&&!inq[t])
				q.push(t);
			if((cd[p]!=1)&&!inq[p])
				q.push(p);
			}	
			recov(t,p);
		}
	}
}

int main(){
	//ios::sync_with_stdio(false);
	ifstream fin;
	ofstream fout;
	fin.open("galaxy.in",ios::in);
	fout.open("galaxy.out",ios::out);
	fin>>n>>m;
	int tu,tv;
	for(int i=1;i<=m;i++){
		fin>>tu>>tv;
		te.id=i;
		te.u=tu,te.v=tv;
		G[tu].push_back(te);
		G[tv].push_back(te);
		cd[tu]++;
	}
	
	for(int i=1;i<=n;i++){
		if(cd[i]!=1){
			q.push(i);
			inq[i]=1;
		}	
	}
	
	fin>>Q;
	int c;
	while(Q--){
		fin>>c;
		if(c==1){
			fin>>tu>>tv;
			int idk=0;
			cd[tu]--;
			if((cd[tu]!=1)&&!inq[tu])
				q.push(tu);
			if((cd[tv]!=1)&&!inq[tv])
				q.push(tv);
				
			for(;;idk++){
				if(G[tu][idk].v==tv){
					break;
				}
			}
			st[G[tu][idk].id]=1;
		}else if(c==2){
			fin>>tu;
			boom(tu,-1);
		}else if(c==3){
			fin>>tu>>tv;
			int idk=0;
			cd[tu]++;
			if((cd[tu]!=1)&&!inq[tu])
				q.push(tu);
			if((cd[tv]!=1)&&!inq[tv])
				q.push(tv);
				
			for(;;idk++){
				if(G[tu][idk].v==tv){
					break;
				}
			}
			st[G[tu][idk].id]=0;
		}else{
			fin>>tu;
			recov(tu,-1);
		}
		int hd=q.front();
	q.push(hd);
	q.pop();
	while(q.front()!=hd){
		inq[q.front()]=0;
		if(cd[q.front()]!=1){
			q.push(q.front());
			inq[q.front()]=0;
		}
		q.pop();
	}
	if(cd[hd]==1){
		q.pop();
		inq[hd]=0;
	}
	fout<<(q.empty()?"YES":"NO")<<"\n";
	}
	
	
	fin.close();
	fout.close();
	
	return 0;
}
