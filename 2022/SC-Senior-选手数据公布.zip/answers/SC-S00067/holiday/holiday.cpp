#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int M=3e3;
ll a[M],n,k,m,ans;
ll dp[M][M];
int dis[M][M];
vector<int> G[M]; 
queue<int> q;

void bf(int p,int id){
	q.push(p);
	int t;
	while(q.size()){
		p=q.front();
		q.pop();
		for(int i=0;i<G[p].size();i++){
			t=G[p][i];
			if(dis[id][t])
				continue;
			dis[id][t]=dis[id][p]+1;
			q.push(t);
		}
	}
}

int main(){
	ios::sync_with_stdio(false);
	ifstream fin;
	ofstream fout;
	fin.open("holiday.in",ios::in);
	fout.open("holiday.out",ios::out);
	fin>>n>>m>>k;
	k++;
	for(int i=2;i<=n;i++)
		fin>>a[i];
	int u,v;
	for(int i=1;i<=m;i++){
		fin>>u>>v;
		G[u].push_back(v);
		G[v].push_back(u);
	}
	for(int i=1;i<=n;i++){
		bf(i,i);
	}
	
	
	for(int i=1;i<=n;i++){
		if(dis[i][1]<=k){
			dp[i][0]=a[i];
		}
	}
	for(int i=1;i<=n;i++){
		if(dp[i][0]){
			for(int j=1;j<=n;j++){
				if(dis[i][j]<=k&&i!=j){
					dp[i][j]=max(dp[i][j],dp[i][0]+a[j]);
				}
			}
		}
	}
	for(int a=1;a<=n;a++){
		if(dp[a][0]){
			for(int b=1;b<=n;b++){
				if(dp[a][b]&&a!=b){
					for(int c=1;c<=n;c++){
						if(dp[c][0]&&c!=a&&c!=b){
							for(int d=1;d<=n;d++){
								if(dp[c][d]&&d!=c&&d!=a&&d!=b&&dis[b][d]<=k){
									ans=max(ans,dp[a][b]+dp[c][d]);
								}	
							}
						}
					}
				}
			}
		}
	}
	fout<<ans;
	fin.close();
	fout.close();
	
	return 0;
}
