#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const ll M=6e5+10,NGI=-1e9-10,INF=1e9+10;
ll a[M],b[M],n,m,q,na[M];
ll amx[M],ami[M],apmi[M],anmx[M],bmx[M],bmi[M];

void pumx(ll c[],ll p){
	if(p>M)
		return;
	c[p]=max(c[p<<1],c[p<<1|1]);
}

void pumi(ll c[],ll p){
	if(p>M)
		return;
	c[p]=min(c[p<<1],c[p<<1|1]);
}

void biumx(ll tag[],ll src[],ll p,ll l,ll r){
	if(l==r){
		tag[p]=src[l];
		return;
	}
	ll m=(l+r)>>1;
	biumx(tag,src,p<<1,l,m);
	biumx(tag,src,p<<1|1,m+1,r);
	pumx(tag,p);
}

void biumi(ll tag[],ll src[],ll p,ll l,ll r){
	if(l==r){
		tag[p]=src[l];
		return;
	}
	ll m=(l+r)>>1;
	biumi(tag,src,p<<1,l,m);
	biumi(tag,src,p<<1|1,m+1,r);
	pumi(tag,p);
}

ll fdmx(ll tag[],ll p,ll l,ll r,ll L,ll R){
	if(l>=L&&r<=R){
		return tag[p];
	}
	ll m=(l+r)>>1,res=NGI;
	if(m>=L)
		res=max(res,fdmx(tag,p<<1,l,m,L,R));
	if(m<R){
		res=max(res,fdmx(tag,p<<1|1,m+1,r,L,R));
	}
	return res;
}

ll fdmi(ll tag[],ll p,ll l,ll r,ll L,ll R){
	if(l>=L&&r<=R){
		return tag[p];	
	}
	ll m=(l+r)>>1,res=INF;
	if(m>=L)
		res=min(res,fdmi(tag,p<<1,l,m,L,R));
	if(m<R){
		res=min(res,fdmi(tag,p<<1|1,m+1,r,L,R));
	}
	return res;
}

int main(){
	//ios::sync_with_stdio(false);
	ifstream fin;
	ofstream fout;
	fin.open("game.in",ios::in);
	fout.open("game.out",ios::out);
	fin>>n>>m>>q;
	ll t;
	for(ll i=1;i<=n;i++){
		fin>>t;
		a[i]=t;
		if(t<0){
			na[i]=t;
		}else
			na[i]=NGI;
	}
	biumx(amx,a,1,1,n);
	biumx(anmx,na,1,1,n);
	biumi(ami,a,1,1,n);
	for(ll i=1;i<=n;i++){
		if(a[i]<0){
			a[i]=INF;
		}
	}
	
	biumi(apmi,a,1,1,n);
	for(ll i=1;i<=m;i++){
		fin>>b[i];
	}
	biumx(bmx,b,1,1,n);
	biumi(bmi,b,1,1,n);

	
	
	ll l1,r1,l2,r2,amax,amin,bmax,bmin,anmax,apmin;
	while(q--){
		fin>>l1>>r1>>l2>>r2;
		amax=fdmx(amx,1,1,n,l1,r1);
		amin=fdmi(ami,1,1,n,l1,r1);
		//fout<<amax<<" "<<amin<<" ";
		if(amax<0){
			fout<<1ll*fdmx(anmx,1,1,n,l1,r1)*fdmx(bmx,1,1,n,l2,r2)<<"\n";
			continue;
		}else if(amin>0){
			bmax=fdmx(bmx,1,1,n,l2,r2);
			bmin=fdmi(bmi,1,1,n,l2,r2);
			if(bmin<0){
				fout<<1ll*bmin*amin<<"\n";
				continue;
			}else{
				fout<<1ll*bmin*amax<<"\n";
				continue;
			}
		}else{
			bmax=fdmx(bmx,1,1,n,l2,r2);
			bmin=fdmi(bmi,1,1,n,l2,r2);
			//fout<<bmax<<" "<<bmin<<" ";
			if(bmax<0){
				fout<<1ll*bmax*amin<<"\n";
			}else if(bmin>0){
				fout<<1ll*bmin*amax<<"\n";
			}else{
				apmin=fdmi(apmi,1,1,n,l1,r1);
				anmax=fdmx(anmx,1,1,n,l1,r1);
				//fout<<"!!!"<<apmin<<" "<<anmax;
				fout<<max(1ll*apmin*bmin,1ll*anmax*bmax)<<"\n";
			}
			continue;
		}
	}
	
	
	fin.close();
	fout.close();
	
	return 0;
}
