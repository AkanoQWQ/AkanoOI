// probably 100 solution, but neet to pai

#include <algorithm>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <functional>
#include <iostream>
#include <queue>
#include <vector>

constexpr int MAXN = 2500;

std::vector<int> g[MAXN + 5];
std::bitset<MAXN + 5> con[MAXN + 5];
long long s[MAXN + 5];
int n, m, k;

struct node_t
{
    int to;
    int d;
    node_t() {}
    node_t(int to, int d) : to(to), d(d) {}
    bool operator>(const node_t &a) const { return d > a.d; }
};
int dis[MAXN + 5][MAXN + 5];

void dij(int start)
{
    std::vector<bool> vis(n + 1, 0);
    std::priority_queue<node_t, std::vector<node_t>, std::greater<node_t>> q;
    dis[start][start] = 0;
    q.emplace(start, 0);
    while (!q.empty())
    {
        int u = q.top().to;
        q.pop();
        if (vis[u]) continue;
        vis[u] = 1;
        if (dis[start][u] - 1 >= k) continue;
        for (auto v : g[u]) {
            if (dis[start][v] > dis[start][u] + 1) {
                dis[start][v] = dis[start][u] + 1;
                q.emplace(v, dis[start][v]);
            }
        }
    }
}

std::vector<int> status[MAXN + 5];

int main()
{
#ifndef DFO
    freopen("holiday.in", "r", stdin);
    freopen("holiday.out", "w", stdout);
#endif

    memset(dis, 0x3f, sizeof(dis));
    std::cin >> n >> m >> k;
    for (int i = 2; i <= n; i++) std::cin >> s[i];
    for (int i = 0; i < m; i++) {
        int u, v;
        std::cin >> u >> v;
        g[u].emplace_back(v);
        g[v].emplace_back(u);
    }

    for (int i = 1; i <= n; i++) dij(i);
    for (int i = 1; i <= n; i++) {
        g[i].clear();
        for (int j = 1; j <= n; j++) {
            if (i == j) continue;
            if (dis[i][j] - 1 <= k) {
                g[i].emplace_back(j);
                con[i][j] = true;
            }
        }
    }
    for (auto i : g[1]) {
        for (auto j : g[i]) {
            if (i == j) continue;
            status[j].emplace_back(i);
        }
    }
    for (int i = 1; i <= n; i++) {
        std::sort(status[i].begin(), status[i].end(), [](int a, int b) { return s[a] > s[b]; });
    }
    long long ans = 0;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            if (i == j) continue;
            if (con[i][j] && status[i].size() != 0 && status[j].size() != 0) {
                for (int ki = 0; ki < std::min(2, (int)status[i].size()); ki++) {
                    for (int kj = 0; kj < std::min(2, (int)status[j].size()); kj++) {
                        if (status[i][ki] != status[j][kj] && status[i][ki] != j && status[j][kj] != i) {
                            // printf("%d %d %d %d => %lld\n", 
                            //         i, j, 
                            //         status[i][ki], 
                            //         status[j][kj], 
                            //         s[i] + s[j] + s[status[i][ki]] + s[status[j][kj]]);
                            ans = std::max(ans, s[i] + s[j] + s[status[i][ki]] + s[status[j][kj]]);
                        }
                    }
                }
            }
        }
    }
    std::cout << ans << std::endl;
}
