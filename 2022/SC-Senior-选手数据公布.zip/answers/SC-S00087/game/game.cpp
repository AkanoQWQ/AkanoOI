// O(n lg (n)) but with a huge constant
// i dont know whether it can pass

#include <cstdio>
#include <functional>
#include <vector>
#include <algorithm>
#include <iostream>

const int MAXN = 1e5;

int lg2[MAXN + 5];
int n, m, q;

struct st_t
{
    std::function<int(int, int)> f;
    std::vector<std::vector<int>> st;
    st_t(std::function<int(int, int)> f, int n) : f(f), st(n, std::vector<int>(18)) {}

    void init(const std::vector<int> &v)
    {
        int n = v.size();
        for (int i = 0; i < n; i++) st[i][0] = v[i];
        for (int k = 1; k < 18; k++) {
            for (int i = 0; i <= n - (1 << k); i++) {
                st[i][k] = f(st[i][k - 1], st[i + (1 << (k - 1))][k - 1]);
            }
        }
    }
    int ask(int l, int r)
    {
        int t = lg2[r - l + 1];
        return f(st[l][t], st[r - (1 << t) + 1][t]);
    }
};

int main()
{
#ifndef DFO
    freopen("game.in", "r", stdin);
    freopen("game.out", "w", stdout);
#endif

    std::cin >> n >> m >> q;

    for (int i = 2; i <= n; i++) lg2[i] = lg2[i / 2] + 1;

    std::vector<int> a(n), b(m), aaz(n), abz(n), baz(m), bbz(m);
    for (int i = 0; i < n; i++) {
        std::cin >> a[i];
        aaz[i] = a[i] < 0 ? std::numeric_limits<int>::max() : a[i];
        abz[i] = a[i] > 0 ? std::numeric_limits<int>::min() : a[i];
    }
    for (int i = 0; i < m; i++) {
        std::cin >> b[i];
        baz[i] = b[i] < 0 ? std::numeric_limits<int>::max() : b[i];
        bbz[i] = b[i] > 0 ? std::numeric_limits<int>::min() : b[i];
    }
    auto mymax = [](int a, int b) { return a > b ? a : b; };
    auto mymin = [](int a, int b) { return a < b ? a : b; };
    st_t amax(mymax, n), amin(mymin, n), aazmin(mymin, n), abzmax(mymax, n);
    st_t bmax(mymax, m), bmin(mymin, m), bazmin(mymin, m), bbzmax(mymax, m);
    amax.init(a); amin.init(a); aazmin.init(aaz); abzmax.init(abz);
    bmax.init(b); bmin.init(b); bazmin.init(baz); bbzmax.init(bbz);

    while (q--) {
        int l1, r1, l2, r2;
        std::cin >> l1 >> r1 >> l2 >> r2;
        l1--;
        r1--;
        l2--;
        r2--;
        long long ans = std::numeric_limits<long long>::min();
        int a1 = amax.ask(l1, r1),
            a2 = amin.ask(l1, r1),
            a3 = aazmin.ask(l1, r1),
            a4 = abzmax.ask(l1, r1);
        int b1 = bmax.ask(l2, r2),
            b2 = bmin.ask(l2, r2),
            b3 = bazmin.ask(l2, r2),
            b4 = bbzmax.ask(l2, r2);
        // for (auto i : {a1, a2, a3, a4, b1, b2, b3, b4}) std::cout << i << std::endl;
        for (auto i : {a1, a2, a3, a4}) {
            long long tmp = std::numeric_limits<long long>::max();
            if (i == std::numeric_limits<int>::max() || i == std::numeric_limits<int>::min()) continue;
            for (auto j : {b1, b2, b3, b4}) {
                if (j == std::numeric_limits<int>::max() || j == std::numeric_limits<int>::min()) continue;
                tmp = std::min(tmp, (long long)i * j);
            }
            ans = std::max(ans, tmp);
        }
        std::cout << ans << std::endl;
    }
}

