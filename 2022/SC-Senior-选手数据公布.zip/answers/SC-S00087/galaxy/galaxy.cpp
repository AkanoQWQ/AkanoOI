#include <cstdio>
#include <vector>
#include <algorithm>
#include <iostream>

const int MAXN = 5e5;
std::vector<int> G[MAXN + 5];

int main()
{
#ifndef DFO
    freopen("galaxy.in", "r", stdin);
    freopen("galaxy.out", "w", stdout);
#endif

    int n, m;
    std::cin >> n >> m;
    for (int i = 1; i <= m; i++) {
        int u, v;
        std::cin >> u >> v;
        G[u].emplace_back(v);
    }
    int q;
    std::cin >> q;
    while (q--) {
        puts("NO");
    }
}
