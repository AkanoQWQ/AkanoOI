#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>

const int MAXN = 2e5;
std::vector<int> G[MAXN + 5];
long long c[MAXN + 5];
int dep[MAXN + 5];
int fa[MAXN + 5][20];
long long fac[MAXN + 5][20];

void dfs(int cur, int from)
{
    dep[cur] = dep[from] + 1;
    fa[cur][0] = from;
    fac[cur][0] = c[from];
    for (int i = 1; i < 20; i++) {
        fa[cur][i] = fa[fa[cur][i - 1]][i - 1];
        fac[cur][i] = fac[cur][i - 1] + fac[fa[cur][i - 1]][i - 1];
    }
    for (auto i : G[cur]) {
        if (i == from) continue;
        dfs(i, cur);
    }
}

long long lca(int x, int y)
{
    long long sum = c[x] + c[y];
    if (dep[x] < dep[y]) std::swap(x, y);
    for (int i = 19; i >= 0; i--) {
        if ((dep[x] - dep[y]) & (1 << i)) {
            sum += fac[x][i];
            x = fa[x][i];
        }
    }
    if (x == y) return sum - c[y];
    for (int i = 19; i >= 0; i--) {
        if (fa[x][i] != fa[y][i]) {
            sum += fac[x][i] + fac[y][i];
            x = fa[x][i];
            y = fa[y][i];
        }
    }
    return sum + c[fa[x][0]];
}

int main()
{
#ifndef DFO
    freopen("transmit.in", "r", stdin);
    freopen("transmit.out", "w", stdout);
#endif
    int n, q, k;
    std::cin >> n >> q >> k;
    for (int i = 1; i <= n; i++) {
        std::cin >> c[i];
    }
    for (int i = 1; i < n; i++) {
        int u, v;
        std::cin >> u >> v;
        G[u].emplace_back(v);
        G[v].emplace_back(u);
    }

    if (k == 1) {
        dfs(1, 0);

        while (q--) {
            int u, v;
            std::cin >> u >> v;
            std::cout << lca(u, v) << std::endl;
        }
    }
}
