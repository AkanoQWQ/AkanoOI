#include<bits/stdc++.h>
using namespace std;
int n,m,q,l1,l2,r1,r2;
long long a[1005],b[1005];
//�ڶ�λ1Ϊ����2Ϊ�� 
long long max11[1005][1005],max12[1005][1005],min11[1005][1005],min12[1005][1005],max21[1005][1005],max22[1005][1005],min21[1005][1005],min22[1005][1005],isz1[1005][1005],isz2[1005][1005];
void csh(){
	for(int i=1;i<=n;i++){
		if(a[i]>0){
			max11[i][i]=a[i];
			min11[i][i]=a[i];
		} 
		else if(a[i]==0) isz1[i][i]=true;
		else{
			max12[i][i]=a[i];
			min12[i][i]=a[i];
		} 
	}
	
		for(int i=1;i<=m;i++){
		if(b[i]>0){
			max21[i][i]=b[i];
			min21[i][i]=b[i];
		} 
		else if(b[i]==0) isz2[i][i]=true;
		else{
			max22[i][i]=b[i];
			min22[i][i]=b[i];
		} 
	}
	
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
		max11[i][j]=max(max11[i][j-1],max11[j][j]);
		
		if(min11[i][j-1]>0 && min11[j][j]>0)	min11[i][j]=min(min11[i][j-1],min11[j][j]); 
			else min11[i][j]=max(min11[i][j-1],min11[j][j]);
			
			max12[i][j]=min(max12[i][j-1],max12[j][j]);
			
			if(min12[i][j-1]<0 && min12[j][j]<0) min12[i][j]=max(min12[i][j-1],min12[j][j]);
			else min12[i][j]=min(min12[i][j-1],min12[j][j]);			
			isz1[i][j]=isz1[i][j-1]|isz1[j][j];
		}
    }
	for(int i=1;i<=m-1;i++){
		for(int j=i+1;j<=m;j++){
			max21[i][j]=max(max21[i][j-1],max21[j][j]);
			if(min21[i][j-1]>0 && min21[j][j]>0)	min21[i][j]=min(min21[i][j-1],min21[j][j]); 
			else min21[i][j]=max(min21[i][j-1],min21[j][j]);
			max22[i][j]=min(max22[i][j-1],max22[j][j]);
			if(min22[i][j-1]<0 && min22[j][j]<0)    min22[i][j]=max(min22[i][j-1],min22[j][j]);
			else min22[i][j]=min(min22[i][j-1],min22[j][j]);
			isz2[i][j]=isz2[i][j-1]|isz2[j][j];
		}
	}
	
}


signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	if(n<=1000 && m<=1000 && q<=1000){
		for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
		for(int i=1;i<=m;i++) scanf("%lld",&b[i]);
		csh();
		for(int i=1;i<=q;i++){
			scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
			if(max21[l2][r2] !=0 && max22[l2][r2]!=0){
				if(isz1[l1][r1]) printf("0\n");
				else printf("%lld\n",max(min11[l1][r1]*max22[l2][r2],min12[l1][r1]*max21[l2][r2]));
			}
			
			else if(max21[l2][r2]==0 && max22[l2][r2]==0) printf("0\n");
			
			else if(max11[l1][r1]==0 && max12[l1][r1]==0) printf("0\n");
			
			else if(max21[l2][r2]==0){
				if(max12[l1][r1]!=0){
					if(isz2[l2][r2]) printf("0\n");
					else printf("%lld\n",max12[l1][r1]*min22[l2][r2]);
				}
				else if(isz1[l1][r1]) printf("0\n");
				else  printf("%lld\n",min11[l1][r1]*max22[l2][r2]);
			}
			
			else{
				if(max11[l1][r1]!=0){
					if(isz2[l2][r2]) printf("0\n");
					else{
						printf("%lld\n",max11[l1][r1]*min21[l2][r2]);
					} 
				}
				else if(isz1[l1][r1]) printf("0\n");
				else  printf("%lld\n",min12[l1][r1]*max21[l2][r2]);
			}
		}
	}
	return 0;
}
