#include<bits/stdc++.h>
using namespace std;
long long n,m,k,ans=-99999,cnt=0,d,f,pl;
long long p[21];
bool isg[21][21];
bool isl[21][21];

void dfs(long long x,int s){
	if(s==5){
		ans=max(ans,cnt);
		return;
	} 
	else if(s<4){
		for(int i=2;i<=n;i++){
			if(isl[x][i]==true && isg[x][i]==false){
			isg[x][i]=true;
			isg[i][x]=true;
			cnt+=p[x];
			dfs(i,s+1);
			cnt-=p[x];
			} 
		}
	}
	else {
		if(isl[x][1]==true){
			cnt+=p[x];
			dfs(1,s+1);
			cnt-=p[x];
		} 
	}
}

int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	if(k==0){
		for(int i=2;i<=n;i++){
			scanf("%lld",&p[i]);	
		}
		
		for(int i=1;i<=m;i++){
			scanf("%lld%lld",&d,&f);
			isl[d][f]=true;
			isl[f][d]=true;
		}
		dfs(1,1);
		printf("%lld",ans);
	}	
	return 0;
}
