#include<bits/stdc++.h>
using namespace std;

long long ans,minx=2147483647,p;

int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	long long n,q,k;
	scanf("%lld%lld%lld",&n,&q,&k);
	for(int i=1;i<=n;i++)
	for(int i=1;i<=n;i++){
		scanf("%d",&p);
		minx=min(minx,p);
		ans+=p;
	}
	cout<<ans-minx;
	return 0;
}
