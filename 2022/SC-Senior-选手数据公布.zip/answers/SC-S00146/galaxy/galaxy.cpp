#include<bits/stdc++.h>
using namespace std;
int n,m,q,x,y;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++) scanf("%d%d",&x,&y);
	scanf("%d",&q);
	for(int i=1;i<=q;i++) printf("Yes\n");
	return 0;
}
